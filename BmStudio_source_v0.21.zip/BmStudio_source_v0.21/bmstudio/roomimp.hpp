// BmStudio - "Import room (level)": brings a whole room from another map (e.g. a DLC challenge) into the open map.
// The room is shown over the map in the viewport (ghost), the user positions it with the gizmo and builds the packages.
// Core in ../bmcpp/bmroomimp.hpp (the same code that restored the Admin room). Included by app.cpp after level.hpp.
#pragma once
#include "../bmcpp/bmroomimp.hpp"
#include <restartmanager.h>
static void ReleaseHoldsOn(const std::wstring& path);   // beta.hpp: releases ALL the panels that keep the file open (viewport, library, copy...)
// who has the file open (Windows Restart Manager): process names, for the error message
static std::string WhoHolds(const std::wstring& path) {
    DWORD sess = 0; WCHAR key[CCH_RM_SESSION_KEY + 1] = { 0 }; if (RmStartSession(&sess, 0, key) != ERROR_SUCCESS) return "";
    std::string out; LPCWSTR f = path.c_str();
    if (RmRegisterResources(sess, 1, &f, 0, NULL, 0, NULL) == ERROR_SUCCESS) { UINT need = 0, n = 0; DWORD why = 0; RM_PROCESS_INFO info[16];
        n = 16; DWORD r = RmGetList(sess, &need, &n, info, &why); if (r == ERROR_SUCCESS) for (UINT i = 0; i < n; i++) { if (!out.empty()) out += ", "; out += U8(info[i].strAppName); char b[32]; snprintf(b, sizeof b, " (pid %lu)", (unsigned long)info[i].Process.dwProcessId); out += b; } }
    RmEndSession(sess); return out;
}

struct RimpLayer { std::string name; std::wstring path; std::unique_ptr<Doc> doc; LvlCache c; Level L; bool on = true, failed = false; std::string err; };
struct RimpState {
    bool open = false;
    std::wstring srcDir; std::string srcBase; std::vector<std::unique_ptr<RimpLayer>> layers;
    std::vector<rimp::Candidate> cands; std::vector<char> candOn; bool showAll = false;
    std::vector<std::pair<std::string, std::wstring>> targets; int target = -1; std::vector<std::string> anchors; int anchor = -1; char newBase[96] = "";
    bool clip = true; rimp::Box autoBox{}; bool hasAuto = false; bool snap = true; float snapStep = 16;
    char outDir[512] = ""; bool install = false;
    std::vector<std::string> log; std::vector<rimp::OutFile> outs; bool lastOk = false;
};
static RimpState gRi;

static rimp::IO RimpIO() {
    rimp::IO io;
    io.read = [](const std::string& p, std::vector<u8>& out) { HANDLE h = CreateFileW(W(p).c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL); if (h == INVALID_HANDLE_VALUE) return false;
        LARGE_INTEGER sz; GetFileSizeEx(h, &sz); out.resize((size_t)sz.QuadPart); DWORD rd = 0; BOOL ok = out.empty() || ReadFile(h, out.data(), (DWORD)out.size(), &rd, NULL); CloseHandle(h); return ok && rd == out.size(); };
    io.write = [](const std::string& p, const std::vector<u8>& d) { HANDLE h = CreateFileW(W(p).c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL); if (h == INVALID_HANDLE_VALUE) return false;
        DWORD wr = 0; BOOL ok = d.empty() || WriteFile(h, d.data(), (DWORD)d.size(), &wr, NULL); CloseHandle(h); return ok && wr == d.size(); };
    return io;
}
static std::wstring RimpPickUmap(const std::wstring& initialDir) {
    wchar_t file[MAX_PATH] = { 0 };
    OPENFILENAMEW of = {}; of.lStructSize = sizeof(of); of.hwndOwner = gHwnd; of.lpstrFilter = L"Unreal map (*.umap)\0*.umap\0\0"; of.lpstrFile = file; of.nMaxFile = MAX_PATH;
    of.lpstrInitialDir = initialDir.empty() ? NULL : initialDir.c_str(); of.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST; return GetOpenFileNameW(&of) ? file : L"";
}
static std::wstring RimpPickFolder() {
    BROWSEINFOW bi = {}; bi.hwndOwner = gHwnd; bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE; wchar_t path[MAX_PATH] = { 0 };
    LPITEMIDLIST id = SHBrowseForFolderW(&bi); if (!id) return L""; SHGetPathFromIDListW(id, path); CoTaskMemFree(id); return path;
}
static std::string RimpSlash(std::string s) { for (auto& c : s) if (c == '/') c = '\\'; if (!s.empty() && s.back() != '\\') s += '\\'; return s; }
static std::string RimpCooked() { return RimpSlash(cookedDirOf(U8(gDoc.path))); }

static void RimpReleaseGhost() {
    for (auto& l : gRi.layers) LvlCacheRelease(l->c); gRi.layers.clear(); gGhost.layers.clear(); gGhost.on = false; gGhost.sel = false; gGhost.hasBox = false;
}
// possible target maps: the parent chain of the document (context sub-levels)
static void RimpTargets() {
    gRi.targets.clear(); gRi.target = -1;
    if (gCtx.builtFor != gDoc.path) LvlBuildFamily(gCtx.up);
    for (auto& p : gCtx.parents) { auto it = gCtx.index.find(LvlLower(p)); if (it != gCtx.index.end()) gRi.targets.push_back({ p, it->second }); }
}
static void RimpSetTarget(int t) {
    gRi.target = t; gRi.anchors.clear(); gRi.anchor = -1; gRi.newBase[0] = 0; if (t < 0 || t >= (int)gRi.targets.size()) return;
    Doc d; if (!d.open(gRi.targets[t].second).empty()) { Status("cannot open " + U8(gRi.targets[t].second)); return; }
    gRi.anchors = rimp::anchorRooms(d.pk);
    std::string me = LvlLower(LvlPkgName(gDoc.path)); size_t bestLen = 0;   // room of the open document = suggestion
    for (int i = 0; i < (int)gRi.anchors.size(); i++) { std::string a = LvlLower(gRi.anchors[i]); if ((me == a || me.rfind(a + "_", 0) == 0) && a.size() > bestLen) { bestLen = a.size(); gRi.anchor = i; } }
    if (gRi.anchor < 0 && !gRi.anchors.empty()) gRi.anchor = 0;
    if (gRi.anchor >= 0) { std::set<std::string> files; for (auto& kv : gCtx.index) files.insert(kv.first); snprintf(gRi.newBase, sizeof gRi.newBase, "%s", rimp::freeNewBase(d.pk, gRi.anchors[gRi.anchor], files).c_str()); }
}
static void RimpSetAnchor(int i) {
    gRi.anchor = i; if (gRi.target < 0 || i < 0) return; Doc d; if (!d.open(gRi.targets[gRi.target].second).empty()) return;
    std::set<std::string> files; for (auto& kv : gCtx.index) files.insert(kv.first); snprintf(gRi.newBase, sizeof gRi.newBase, "%s", rimp::freeNewBase(d.pk, gRi.anchors[i], files).c_str());
}
static void RimpLoadSource(const std::wstring& picked) {
    RimpReleaseGhost(); gRi.cands.clear(); gRi.candOn.clear(); gRi.log.clear(); gRi.outs.clear();
    std::wstring dir = picked.substr(0, picked.find_last_of(L"\\/") + 1); std::string base = LvlPkgName(picked);
    std::vector<std::string> files; { WIN32_FIND_DATAW fd; HANDLE h = FindFirstFileW((dir + L"*.umap").c_str(), &fd);
        if (h != INVALID_HANDLE_VALUE) { do files.push_back(U8(fd.cFileName)); while (FindNextFileW(h, &fd)); FindClose(h); } }
    // picked a sub-level (e.g. _Static)? go up to the main room
    for (;;) { size_t u = base.rfind('_'); if (u == std::string::npos) break; std::string up = base.substr(0, u); bool exists = false; for (auto& f : files) if (LvlLower(rimp::fileBase(f)) == LvlLower(up)) exists = true;
        if (!exists) break; auto members = rimp::roomPackages(up, files); bool contains = false; for (auto& m : members) if (LvlLower(m) == LvlLower(base)) contains = true; if (!contains) break; base = up; }
    gRi.srcDir = dir; gRi.srcBase = base;
    std::vector<const Package*> pks;
    for (auto& n : rimp::roomPackages(base, files)) {
        auto l = std::make_unique<RimpLayer>(); l->name = n; l->path = dir + W(n) + L".umap"; l->doc = std::make_unique<Doc>();
        std::string e = l->doc->open(l->path); if (!e.empty()) { l->failed = true; l->err = e; l->on = false; l->doc.reset(); gRi.layers.push_back(std::move(l)); continue; }
        l->c.pk = &l->doc->pk; l->c.path = l->path; l->L = parseLevel(l->doc->pk); LvlLoadInto(l->c, l->L); pks.push_back(&l->doc->pk);
        try { rimp::listCandidates(l->doc->pk, n, gRi.cands); } catch (std::exception& ex) { gRi.log.push_back("! " + n + ": " + ex.what()); }
        gRi.layers.push_back(std::move(l)); }
    for (auto& c : gRi.cands) gRi.candOn.push_back(c.def ? 1 : 0);
    gRi.hasAuto = rimp::autoRoomBox(pks, gRi.autoBox);
    gGhost.hasBox = gRi.hasAuto; if (gRi.hasAuto) { memcpy(gGhost.bmn, gRi.autoBox.mn, 12); memcpy(gGhost.bmx, gRi.autoBox.mx, 12); }
    gGhost.off[0] = gGhost.off[1] = gGhost.off[2] = 0; gGhost.yaw90 = 0; gGhost.on = true;
}
static void RimpOpen() {
    gRi.open = true; RimpTargets();
    if (gRi.target < 0 && !gRi.targets.empty()) RimpSetTarget((int)gRi.targets.size() - 1);   // the topmost parent (persistent map)
    for (int t = 0; t < (int)gRi.targets.size(); t++) { Doc d; if (!d.open(gRi.targets[t].second).empty()) continue;   // prefer the first parent that has rooms
        if (!rimp::anchorRooms(d.pk).empty()) { d.close(); RimpSetTarget(t); break; } }
    if (!gRi.outDir[0]) { std::string ck = RimpCooked(); std::string game = ck; for (int k = 0; k < 2 && !game.empty(); k++) { game.pop_back(); game = game.substr(0, game.find_last_of('\\') + 1); }
        snprintf(gRi.outDir, sizeof gRi.outDir, "%s_bmtk\\RoomImport\\", game.c_str()); }
    if (gRi.layers.empty()) { std::wstring dlc = W(RimpCooked()) + L"Maps\\DLC"; std::wstring f = RimpPickUmap(GetFileAttributesW(dlc.c_str()) != INVALID_FILE_ATTRIBUTES ? dlc : W(RimpCooked()) + L"Maps"); if (!f.empty()) RimpLoadSource(f); }
}
static void RimpFocus() { float p[3]; for (int k = 0; k < 3; k++) p[k] = (gGhost.bmn[k] + gGhost.bmx[k]) * 0.5f + gGhost.off[k]; float d[3]; LvlDir(d);
    float r = 0; for (int k = 0; k < 3; k++) r = std::max(r, gGhost.bmx[k] - gGhost.bmn[k]); for (int k = 0; k < 3; k++) gLvl.eye[k] = p[k] - d[k] * std::max(800.f, r * 0.9f); }

static bool RimpMkdirs(const std::string& dir) { std::wstring w = W(dir); for (size_t i = 3; i <= w.size(); i++) if (i == w.size() || w[i] == L'\\') { CreateDirectoryW(w.substr(0, i).c_str(), NULL); }
    DWORD a = GetFileAttributesW(W(dir).c_str()); return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY); }
// same file? (full path, ignoring slash/case differences)
static bool RimpSamePath(const std::wstring& a, const std::wstring& b) {
    wchar_t fa[MAX_PATH * 2] = { 0 }, fb[MAX_PATH * 2] = { 0 }; GetFullPathNameW(a.c_str(), MAX_PATH * 2, fa, NULL); GetFullPathNameW(b.c_str(), MAX_PATH * 2, fb, NULL);
    for (wchar_t* p = fa; *p; p++) if (*p == L'/') *p = L'\\'; for (wchar_t* p = fb; *p; p++) if (*p == L'/') *p = L'\\';
    return _wcsicmp(fa, fb) == 0;
}
static void RimpRun() {
    gRi.log.clear(); gRi.outs.clear(); gRi.lastOk = false;
    if (gRi.target < 0 || gRi.target >= (int)gRi.targets.size() || gRi.anchor < 0 || gRi.anchor >= (int)gRi.anchors.size()) { gRi.log.push_back("! target map/room not chosen"); return; }
    rimp::Spec S; S.srcDir = U8(gRi.srcDir); S.srcBase = gRi.srcBase;
    for (auto& l : gRi.layers) if (!l->failed && l->on) S.srcPkgs.push_back(l->name);
    if (std::find(S.srcPkgs.begin(), S.srcPkgs.end(), S.srcBase) == S.srcPkgs.end()) { gRi.log.push_back(std::string("! ") + gRi.srcBase + ": the main room package is required"); return; }
    S.targetMap = U8(gRi.targets[gRi.target].second); S.anchor = gRi.anchors[gRi.anchor]; S.newBase = gRi.newBase;
    memcpy(S.delta, gGhost.off, 12); S.yaw90 = gGhost.yaw90 & 3; for (int k = 0; k < 3; k++) S.pivot[k] = gGhost.hasBox ? (gGhost.bmn[k] + gGhost.bmx[k]) * 0.5f : 0.f; S.clip = gRi.clip && gGhost.hasBox; memcpy(S.room.mn, gGhost.bmn, 12); memcpy(S.room.mx, gGhost.bmx, 12);
    for (size_t i = 0; i < gRi.cands.size(); i++) if (gRi.candOn[i]) (gRi.cands[i].kind ? S.disable : S.remove).insert(gRi.cands[i].pkg + "|" + gRi.cands[i].path);
    std::string ck = RimpCooked(); if (GetFileAttributesW(W(ck + "GuidCache.upk").c_str()) != INVALID_FILE_ATTRIBUTES) S.guidCache = ck + "GuidCache.upk";
    S.outDir = RimpSlash(gRi.outDir) + gRi.newBase + "\\";
    if (!RimpMkdirs(S.outDir)) { gRi.log.push_back("! " + S.outDir + ": cannot create folder"); return; }
    if (gRi.install && gDoc.dirty) {   // installing over the open document with unsaved changes: ask to save first
        std::wstring tm = W(S.targetMap); if (RimpSamePath(tm, gDoc.path)) { gRi.log.push_back(std::string("! ") + T(L_RI_CLOSEFIRST) + S.targetMap); return; } }
    rimp::Log log; log.sink = [](const std::string& s) { gRi.log.push_back(s); };
    try { gRi.outs = rimp::run(RimpIO(), S, log); gRi.lastOk = true; }
    catch (std::exception& e) { gRi.log.push_back(std::string("! ") + e.what()); return; }
    { std::string rd; for (auto& l : log.lines) rd += l + "\r\n"; RimpIO().write(S.outDir + "import_room.log", std::vector<u8>(rd.begin(), rd.end())); }
    if (gRi.install) {
        // the open document (mapped file = locked) may be one of the installed ones: close, copy and reopen at the end
        std::wstring reopen; for (auto& o : gRi.outs) if (gDoc.loaded && RimpSamePath(W(ck + o.installAs), gDoc.path)) reopen = gDoc.path;
        if (!reopen.empty()) { RimpReleaseGhost(); LevelClear(); gDoc.close(); gDocGen++; }
        struct Reopen { std::wstring p; ~Reopen() { if (!p.empty()) { DoOpen(p); if (gDoc.loaded) gLevelMode = PackageHasLevel(); } } } reopenGuard{ reopen };
        for (auto& o : gRi.outs) { std::wstring dst = W(ck + o.installAs); LvlCtxReleasePath(dst);
            std::wstring bak = dst + L".bak"; if (GetFileAttributesW(dst.c_str()) != INVALID_FILE_ATTRIBUTES && GetFileAttributesW(bak.c_str()) == INVALID_FILE_ATTRIBUTES) CopyFileW(dst.c_str(), bak.c_str(), TRUE);
            ReleaseHoldsOn(dst);
            BOOL okc = FALSE; DWORD er = 0; for (int tr = 0; tr < 10 && !okc; tr++) { okc = CopyFileW(W(o.file).c_str(), dst.c_str(), FALSE); if (!okc) { er = GetLastError(); if (er != ERROR_SHARING_VIOLATION && er != ERROR_LOCK_VIOLATION && er != ERROR_ACCESS_DENIED) break; Sleep(400); } }   // antivirus often locks it for a moment
            if (!okc) { char eb[64]; snprintf(eb, sizeof eb, " (error %lu)", er); std::string who = WhoHolds(dst);
                gRi.log.push_back("! " + U8(dst) + ": " + T(er == ERROR_SHARING_VIOLATION || er == ERROR_LOCK_VIOLATION ? L_RI_LOCKED : L_RI_COPYFAIL) + eb + (who.empty() ? "" : " -> held open by: " + who));
                if (er == ERROR_ACCESS_DENIED && (GetFileAttributesW(dst.c_str()) & FILE_ATTRIBUTE_READONLY)) gRi.log.push_back("  (the file is marked read-only)");
                gRi.lastOk = false; return; }
            gRi.log.push_back(std::string(T(L_RI_INSTALLED)) + o.installAs); }
        gCtx.forDir.clear(); gCtx.builtFor.clear();   // reindexes the maps (new files)
    }
    char b[200]; snprintf(b, sizeof b, T(L_RI_DONE), (int)gRi.outs.size()); Status(b);
}

static void RimpAutoTest() {   // test: BMS_AUTORIMP=room.umap (with the level open in the viewport); BMS_AUTORIMP_DZ=-256; BMS_AUTORIMP_OUT=folder -> builds
    static int frames = 0; static bool done = false; if (done || !gLevelMode || !gDoc.loaded) return; wchar_t b[1024]; if (!GetEnvironmentVariableW(L"BMS_AUTORIMP", b, 1024)) { done = true; return; }
    if (++frames < 30) return; done = true; RimpLoadSource(b); RimpOpen();
    if (GetEnvironmentVariableW(L"BMS_AUTORIMP_DZ", b, 1024)) gGhost.off[2] = (float)_wtof(b);
    if (GetEnvironmentVariableW(L"BMS_AUTORIMP_YAW", b, 1024)) gGhost.yaw90 = _wtoi(b) & 3;
    if (GetEnvironmentVariableW(L"BMS_AUTORIMP_BOX", b, 1024)) swscanf(b, L"%f %f %f %f %f %f", &gGhost.bmn[0], &gGhost.bmn[1], &gGhost.bmn[2], &gGhost.bmx[0], &gGhost.bmx[1], &gGhost.bmx[2]);
    gGhost.sel = true; RimpFocus();
    if (GetEnvironmentVariableW(L"BMS_AUTORIMP_INSTALL", b, 1024)) gRi.install = true;
    if (GetEnvironmentVariableW(L"BMS_AUTORIMP_OUT", b, 1024)) { snprintf(gRi.outDir, sizeof gRi.outDir, "%s", RimpSlash(U8(b)).c_str()); RimpRun(); }
}
static void RimpWindow() {
    RimpAutoTest();
    if (!gRi.open) { if (gGhost.on || !gRi.layers.empty()) RimpReleaseGhost(); return; }
    if (!gDoc.loaded || !gLevelMode) { /* the window stays open; the ghost only shows up in the viewport */ }
    // ghost meshes a few at a time + visible layers
    { double t0 = ImGui::GetTime(); for (auto& l : gRi.layers) { if (!l->on || l->failed) continue; while (l->c.loaded < l->c.toLoad.size() && ImGui::GetTime() - t0 < 0.03) { LvlBuildMesh(l->c, l->c.toLoad[l->c.loaded]); l->c.loaded++; } } }
    gGhost.layers.clear(); for (auto& l : gRi.layers) if (l->on && !l->failed) gGhost.layers.push_back({ &l->c, &l->L }); gGhost.on = !gRi.layers.empty();
    ImGui::SetNextWindowPos(ImVec2(60, 90), ImGuiCond_FirstUseEver); ImGui::SetNextWindowSize(ImVec2(720, 680), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(1.0f);
    if (!ImGui::Begin(T(L_RI_TITLE), &gRi.open)) { ImGui::End(); return; }
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_RI_INTRO)); ImGui::PopStyleColor();
    // 1. source
    ImGui::SeparatorText(T(L_RI_SRC));
    if (ImGui::Button(T(L_RI_PICKSRC))) { std::wstring f = RimpPickUmap(gRi.srcDir.empty() ? W(RimpCooked()) + L"Maps\\DLC" : gRi.srcDir); if (!f.empty()) RimpLoadSource(f); }
    if (gRi.layers.empty()) { ImGui::SameLine(); ImGui::TextDisabled("%s", T(L_RI_NOSRC)); }
    else { ImGui::SameLine(); ImGui::Text("%s", gRi.srcBase.c_str()); ImGui::SameLine(); ImGui::TextDisabled("(%s)", U8(gRi.srcDir).c_str());
        for (auto& l : gRi.layers) { ImGui::PushID(l->name.c_str()); ImGui::BeginDisabled(l->failed || l->name == gRi.srcBase); ImGui::Checkbox(l->name.c_str(), &l->on); ImGui::EndDisabled();
            ImGui::SameLine(); if (l->failed) ImGui::TextDisabled("(%s)", l->err.c_str()); else ImGui::TextDisabled("%zu/%zu", l->c.loaded, l->c.toLoad.size()); ImGui::PopID(); } }
    // 2. target
    ImGui::SeparatorText(T(L_RI_DST));
    ImGui::SetNextItemWidth(260);
    if (ImGui::BeginCombo(T(L_RI_MAP), gRi.target >= 0 ? gRi.targets[gRi.target].first.c_str() : "-")) {
        for (int t = 0; t < (int)gRi.targets.size(); t++) if (ImGui::Selectable(gRi.targets[t].first.c_str(), t == gRi.target)) RimpSetTarget(t);
        if (ImGui::Selectable(T(L_RI_OTHERMAP))) { std::wstring f = RimpPickUmap(W(RimpCooked()) + L"Maps"); if (!f.empty()) { gRi.targets.push_back({ LvlPkgName(f), f }); RimpSetTarget((int)gRi.targets.size() - 1); } }
        ImGui::EndCombo(); }
    if (gRi.target >= 0) { ImGui::SameLine(); ImGui::TextDisabled("%s", U8(gRi.targets[gRi.target].second).c_str()); }
    ImGui::SetNextItemWidth(260);
    if (ImGui::BeginCombo(T(L_RI_ANCHOR), gRi.anchor >= 0 ? gRi.anchors[gRi.anchor].c_str() : "-")) {
        for (int i = 0; i < (int)gRi.anchors.size(); i++) if (ImGui::Selectable(gRi.anchors[i].c_str(), i == gRi.anchor)) RimpSetAnchor(i);
        ImGui::EndCombo(); }
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_RI_ANCHOR_TIP));
    ImGui::SetNextItemWidth(260); ImGui::InputText(T(L_RI_NEWNAME), gRi.newBase, sizeof gRi.newBase); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_RI_NEWNAME_TIP));
    bool nameOk = gRi.anchor >= 0 && LvlLower(gRi.newBase).rfind(LvlLower(gRi.anchors[gRi.anchor]) + "_", 0) == 0 && strlen(gRi.newBase) > gRi.anchors[gRi.anchor].size() + 1;
    if (gRi.anchor >= 0 && !nameOk) { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, .5f, .4f, 1), T(L_RI_BADNAME), gRi.anchors[gRi.anchor].c_str()); }
    {   // v0.19: redo an already installed room in the same place (same name + position/rotation/box from the previous import_room.log)
        std::string prev = RimpSlash(gRi.outDir) + gRi.newBase + "\\import_room.log";
        if (GetFileAttributesW(W(prev).c_str()) != INVALID_FILE_ATTRIBUTES) { ImGui::SameLine(); if (ImGui::SmallButton(T(L_RI_PREVPOS))) {
            std::vector<u8> b; if (RimpIO().read(prev, b)) { std::string t(b.begin(), b.end()); float d[3], c[3]; int deg = 0; size_t a = t.find("offset ("); bool ok = false;
                if (a != std::string::npos && sscanf(t.c_str() + a, "offset (%f, %f, %f), rotation %d degrees around (%f, %f, %f)", &d[0], &d[1], &d[2], &deg, &c[0], &c[1], &c[2]) == 7) {
                    memcpy(gGhost.off, d, 12); gGhost.yaw90 = ((deg / 90) % 4 + 4) % 4; ok = true;
                    size_t bx = t.find("room box (source): "); float mn[3], mx[3];
                    if (bx != std::string::npos && sscanf(t.c_str() + bx, "room box (source): x[%f..%f] y[%f..%f] z[%f..%f]", &mn[0], &mx[0], &mn[1], &mx[1], &mn[2], &mx[2]) == 6) { memcpy(gGhost.bmn, mn, 12); memcpy(gGhost.bmx, mx, 12); gGhost.hasBox = true; }
                    else if (gGhost.hasBox) { float cur[3]; for (int k = 0; k < 3; k++) cur[k] = (gGhost.bmn[k] + gGhost.bmx[k]) * 0.5f; for (int k = 0; k < 3; k++) { float h = (gGhost.bmx[k] - gGhost.bmn[k]) * 0.5f; gGhost.bmn[k] = c[k] - h; gGhost.bmx[k] = c[k] + h; } (void)cur; }
                    gRi.snap = false; }
                Status(ok ? std::string(T(L_RI_PREVPOS_OK)) : "import_room.log: " + std::string(T(L_OPENFAIL))); } }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_RI_PREVPOS_TIP)); }
    }
    // 3. position
    ImGui::SeparatorText(T(L_RI_POS));
    ImGui::BeginDisabled(gRi.layers.empty());
    ImGui::SetNextItemWidth(330); ImGui::DragFloat3(T(L_RI_DELTA), gGhost.off, 1.f, 0, 0, "%.0f");
    if (ImGui::Button(T(L_RI_SELECT))) { gGhost.sel = true; gLvl.sel = -1; gLvl.selActor = -1; gLvl.mode = 0; gLevelMode = PackageHasLevel(); }
    ImGui::SameLine(); if (ImGui::Button(T(L_RI_FOCUS))) { gLevelMode = PackageHasLevel(); RimpFocus(); }
    ImGui::SameLine(); if (ImGui::Button("0,0,0")) { gGhost.off[0] = gGhost.off[1] = gGhost.off[2] = 0; }
    ImGui::SameLine(); ImGui::Checkbox(T(L_RI_SNAP), &gRi.snap);
    if (ImGui::Button("<##riy")) gGhost.yaw90 = (gGhost.yaw90 + 3) & 3; ImGui::SameLine(); if (ImGui::Button(">##riy")) gGhost.yaw90 = (gGhost.yaw90 + 1) & 3;
    ImGui::SameLine(); ImGui::Text("%s: %d°", T(L_RI_ROT), (gGhost.yaw90 & 3) * 90); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_RI_ROT_TIP));
    if (gRi.snap && !ImGui::IsMouseDown(ImGuiMouseButton_Left)) for (auto& v : gGhost.off) v = SnapF(v, gRi.snapStep);
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_RI_GIZMONOTE)); ImGui::PopStyleColor();
    ImGui::Checkbox(T(L_RI_BOX), &gGhost.boxOn); ImGui::SameLine(); ImGui::Checkbox(T(L_RI_CLIP), &gRi.clip); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_RI_CLIP_TIP));
    if (gRi.clip) { ImGui::SameLine(); if (ImGui::SmallButton(T(L_RI_BOXAUTO)) && gRi.hasAuto) { memcpy(gGhost.bmn, gRi.autoBox.mn, 12); memcpy(gGhost.bmx, gRi.autoBox.mx, 12); }
        ImGui::SetNextItemWidth(330); ImGui::DragFloat3(T(L_RI_MIN), gGhost.bmn, 4.f, 0, 0, "%.0f"); ImGui::SetNextItemWidth(330); ImGui::DragFloat3(T(L_RI_MAX), gGhost.bmx, 4.f, 0, 0, "%.0f"); }
    ImGui::EndDisabled();
    // 4. actors/events
    ImGui::SeparatorText(T(L_RI_ACTORS)); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_RI_ACTORS_TIP));
    ImGui::Checkbox(T(L_RI_SHOWALL), &gRi.showAll);
    { int n = 0, nl = 0; for (size_t i = 0; i < gRi.candOn.size(); i++) { n += gRi.candOn[i]; if (gRi.candOn[i] && gRi.cands[i].cls.find("Light") != std::string::npos) nl++; } ImGui::SameLine(); ImGui::TextDisabled("%d", n);
      if (nl) { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, .45f, .3f, 1), T(L_RI_LIGHTSOFF), nl); } }
    float logH = gRi.log.empty() ? 0.f : 170.f;
    float tabH = std::max(120.f, ImGui::GetContentRegionAvail().y - logH - ImGui::GetFrameHeightWithSpacing() * 4);
    if (ImGui::BeginTable("ritab", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_Resizable, ImVec2(0, tabH))) {
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, 24); ImGui::TableSetupColumn(T(L_RI_COL_PKG), ImGuiTableColumnFlags_WidthStretch, 0.6f);
        ImGui::TableSetupColumn(T(L_RI_COL_OBJ), ImGuiTableColumnFlags_WidthStretch, 1.f); ImGui::TableSetupColumn(T(L_RI_COL_WHY), ImGuiTableColumnFlags_WidthStretch, 1.4f);
        ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableHeadersRow();
        for (size_t i = 0; i < gRi.cands.size(); i++) { const rimp::Candidate& c = gRi.cands[i]; if (!gRi.showAll && c.why.empty()) continue;
            ImGui::PushID((int)i); ImGui::TableNextRow(); ImGui::TableNextColumn(); bool on = gRi.candOn[i] != 0; if (ImGui::Checkbox("##c", &on)) gRi.candOn[i] = on;
            ImGui::TableNextColumn(); ImGui::TextUnformatted(c.pkg.c_str());
            ImGui::TableNextColumn(); std::string nm = c.path.substr(c.path.find_last_of('.') + 1); ImGui::Text("%s%s", c.kind ? "[Kismet] " : "", nm.c_str()); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s\n%s", c.path.c_str(), c.cls.c_str());
            if (c.hasLoc && ImGui::IsItemClicked()) { float d[3]; LvlDir(d); for (int k = 0; k < 3; k++) gLvl.eye[k] = c.loc[k] + gGhost.off[k] - d[k] * 500; }
            ImGui::TableNextColumn(); ImGui::TextDisabled("%s", c.why.empty() ? c.cls.c_str() : c.why.c_str());
            ImGui::PopID(); }
        ImGui::EndTable(); }
    // 5. build
    ImGui::SeparatorText(T(L_RI_OUT));
    ImGui::SetNextItemWidth(-140); ImGui::InputText("##od", gRi.outDir, sizeof gRi.outDir); ImGui::SameLine(); if (ImGui::Button(T(L_RI_OUTDIR))) { std::wstring f = RimpPickFolder(); if (!f.empty()) snprintf(gRi.outDir, sizeof gRi.outDir, "%s", RimpSlash(U8(f)).c_str()); }
    ImGui::Checkbox(T(L_RI_INSTALL), &gRi.install);
    ImGui::SameLine(); ImGui::BeginDisabled(gRi.layers.empty() || gRi.target < 0 || !nameOk); if (ImGui::Button(T(L_RI_RUN), ImVec2(200, 0))) RimpRun(); ImGui::EndDisabled();
    if (!gRi.log.empty()) {
        if (ImGui::BeginChild("rilog", ImVec2(0, 0), ImGuiChildFlags_Borders)) {
            if (gRi.lastOk && !gRi.outs.empty()) { ImGui::TextColored(ImVec4(.5f, 1, .6f, 1), "%s", T(L_RI_FILES)); for (auto& o : gRi.outs) ImGui::Text("   %s  ->  CookedPC\\%s", rimp::fileBase(o.file).c_str(), o.installAs.c_str()); ImGui::Separator(); }
            for (auto& l : gRi.log) { bool bad = l[0] == '!' || l.find("warning") != std::string::npos; if (bad) ImGui::TextColored(ImVec4(1, .7f, .35f, 1), "%s", l.c_str()); else ImGui::TextUnformatted(l.c_str()); } }
        ImGui::EndChild(); }
    ImGui::End();
}
