// BmStudio - Phase 5: importing FBX into an existing cooked SkeletalMesh (replaces the geometry; keeps skeleton,
// materials and properties). Included by app.cpp after script.hpp.
#pragma once
#include "../bmcpp/bmskelimp.hpp"

struct ImportState {
    bool open = false; i32 mesh = 0; std::wstring file; fbxr::Scene scene; ImportOptions opt; ImportReport rep; std::vector<std::string> slots; bool analyzed = false;
};
static ImportState gImp;

static std::wstring OpenFbxDialog() {
    wchar_t file[MAX_PATH] = { 0 };
    OPENFILENAMEW of = {}; of.lStructSize = sizeof(of); of.hwndOwner = gHwnd; of.lpstrFilter = L"FBX (binary) (*.fbx)\0*.fbx\0\0"; of.lpstrFile = file; of.nMaxFile = MAX_PATH;
    of.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST; return GetOpenFileNameW(&of) ? file : L"";
}
static void ImportAnalyze() {
    gImp.rep = importFBXToSkeletalMesh(gDoc.pk, gImp.mesh, gImp.scene, gImp.opt); gImp.analyzed = true;
}
static void ImportBegin(i32 mesh) {
    std::wstring f = OpenFbxDialog(); if (f.empty()) return;
    HANDLE h = CreateFileW(f.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); if (h == INVALID_HANDLE_VALUE) { Status("cannot open " + U8(f)); return; }
    LARGE_INTEGER sz; GetFileSizeEx(h, &sz); std::vector<u8> data((size_t)sz.QuadPart); DWORD rd = 0; ReadFile(h, data.data(), (DWORD)data.size(), &rd, NULL); CloseHandle(h);
    gImp = ImportState(); gImp.open = true; gImp.mesh = mesh; gImp.file = f; gImp.scene = fbxr::readScene(data);
    SkeletalMesh sm = parseSkeletalMesh(gDoc.pk, mesh); for (auto& m : sm.materials) { std::string s = m; size_t d = s.rfind('.'); if (d != std::string::npos) s = s.substr(d + 1); gImp.slots.push_back(s); }
    ImportAnalyze();
}
static void ImportWindow() {
    if (!gImp.open) return;
    ImGui::SetNextWindowSize(ImVec2(720, 560), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(1.0f);
    if (!ImGui::Begin(T(L_IMP_TITLE), &gImp.open)) { ImGui::End(); return; }
    ImGui::TextWrapped("%s:  %s", T(L_IMP_TARGET), gDoc.pk.objPath(gImp.mesh).c_str());
    ImGui::TextWrapped("FBX:  %s", U8(gImp.file).c_str());
    ImGui::Separator();
    const ImportReport& r = gImp.rep;
    if (!r.ok) { ImGui::TextColored(ImVec4(1, .45f, .45f, 1), "%s", r.err.c_str()); }
    else {
        ImGui::Text("%s: %d  |  %s: %d  |  %s: %d  |  %s %d / chunks %d", T(L_IMP_FBXMESHES), r.fbxMeshes, T(L_IMP_TRIS), r.triangles, T(L_VERTS), r.vertices, T(L_IMP_SECTIONS), r.sections, r.chunks);
        ImGui::Text("%s: %d %s, %s %.4f, %s %.3f / %.3f", T(L_IMP_FIT), r.fitPairs, T(L_BONES), T(L_IMP_SCALE), r.fitScale, T(L_IMP_ERR), r.fitError, r.fitMaxError);
        if (r.fitMaxError <= 2.0) { ImGui::SameLine(); ImGui::TextColored(ImVec4(.5f, 1, .6f, 1), "OK"); }
        ImGui::Spacing(); ImGui::TextUnformatted(T(L_MATERIALS));
        bool changed = false;
        for (size_t k = 0; k < r.fbxMaterials.size(); k++) {
            ImGui::PushID((int)k); ImGui::SetNextItemWidth(260);
            int cur = k < r.materialSlot.size() ? r.materialSlot[k] : 0; std::string prev = cur >= 0 && cur < (int)gImp.slots.size() ? std::to_string(cur) + ": " + gImp.slots[cur] : "?";
            if (ImGui::BeginCombo("##slot", prev.c_str())) { for (int s = 0; s < (int)gImp.slots.size(); s++) { std::string l = std::to_string(s) + ": " + gImp.slots[s]; if (ImGui::Selectable(l.c_str(), s == cur)) { gImp.opt.materialMap[r.fbxMaterials[k]] = s; changed = true; } } ImGui::EndCombo(); }
            ImGui::SameLine(); ImGui::Text("<-  %s", r.fbxMaterials[k].c_str()); ImGui::PopID();
        }
        if (changed) ImportAnalyze();
        if (!r.warnings.empty()) { ImGui::Spacing(); for (auto& w : r.warnings) ImGui::TextColored(ImVec4(1, .75f, .3f, 1), "! %s", w.c_str()); }
        if (!r.unmatchedBones.empty() && ImGui::TreeNode(T(L_IMP_UNMATCHED))) { for (auto& b : r.unmatchedBones) ImGui::BulletText("%s", b.c_str()); ImGui::TreePop(); }
    }
    ImGui::Separator();
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_IMP_HINT)); ImGui::PopStyleColor();
    ImGui::BeginDisabled(!r.ok);
    if (ImGui::Button(T(L_IMP_APPLY), ImVec2(200, 0))) {
        Export& e = gDoc.pk.exports[gImp.mesh - 1]; e.data = r.newData; e.owned = true; gDoc.dirty = true;
        SkeletalMesh chk = parseSkeletalMesh(gDoc.pk, gImp.mesh);
        if (!chk.err.empty()) { e.owned = false; e.data.clear(); Status("import failed: " + chk.err); }
        else { Status(T(L_IMP_DONE)); gPrev.idx = 0; gOpenPreviewTab = true; GotoObject(gImp.mesh); gImp.open = false; }
    }
    ImGui::EndDisabled(); ImGui::SameLine();
    if (ImGui::Button(T(L_CANCEL), ImVec2(120, 0))) gImp.open = false;
    ImGui::End();
}
