// BmStudio - Cooked/Uncooked phase 1: importing animations (PSA from Blender/umodel/ActorX) into a cooked AnimSet.
// Each PSA sequence replaces an existing AnimSequence or becomes a NEW one (cloned from a template: inherits notifies,
// combat cancel/collision points etc.). Included by app.cpp after import.hpp.
#pragma once
#include "../bmcpp/bmanimimp.hpp"

struct AnimImpRow { bool on = true; int target = -1; char name[128] = ""; };   // target: index into gAi.setSeqs (-1 = new)
struct AnimImpState {
    bool open = false; i32 setIdx = 0; std::wstring file; PsaFile psa; std::vector<AnimImpRow> rows;
    std::vector<std::pair<i32, std::string>> setSeqs; int tmpl = 0; bool force30 = false, scaleNotifies = true, rootMotion = true;
    std::vector<std::string> log; bool lastOk = false; std::wstring cfgFile; int cfgEntries = 0;
};
static AnimImpState gAi;

static std::wstring OpenPsaDialog() {
    wchar_t file[MAX_PATH] = { 0 };
    OPENFILENAMEW of = {}; of.lStructSize = sizeof(of); of.hwndOwner = gHwnd; of.lpstrFilter = L"PSA (ActorX / Blender) (*.psa)\0*.psa\0\0"; of.lpstrFile = file; of.nMaxFile = MAX_PATH;
    of.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST; return GetOpenFileNameW(&of) ? file : L"";
}
static void AnimImpLoadSet() {
    gAi.setSeqs.clear(); AnimSetData s = parseAnimSet(gDoc.pk, gAi.setIdx);
    for (i32 r : s.seqRefs) { if (r <= 0) continue; ObjProps op = objProps(gDoc.pk, r); std::string n = op.ok ? tagName(gDoc.pk, op.tags, "SequenceName") : ""; if (n.empty() || n == "None") n = gDoc.pk.objName(r); gAi.setSeqs.push_back({ r, n }); }
}
static void AnimImpBegin(i32 setIdx, int templateSeq) {
    wchar_t envp[1024]; std::wstring f = GetEnvironmentVariableW(L"BMS_AUTOANIM", envp, 1024) ? std::wstring(envp) : OpenPsaDialog(); if (f.empty()) return;   // (variable = test hook)
    HANDLE h = CreateFileW(f.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); if (h == INVALID_HANDLE_VALUE) { Status("cannot open " + U8(f)); return; }
    LARGE_INTEGER sz; GetFileSizeEx(h, &sz); std::vector<u8> data((size_t)sz.QuadPart); DWORD rd = 0; ReadFile(h, data.data(), (DWORD)data.size(), &rd, NULL); CloseHandle(h);
    bool f30 = gAi.force30, sn = gAi.scaleNotifies, rm = gAi.rootMotion;
    gAi = AnimImpState(); gAi.force30 = f30; gAi.scaleNotifies = sn; gAi.rootMotion = rm;
    gAi.open = true; gAi.setIdx = setIdx; gAi.file = f; gAi.psa = parsePSA(data); AnimImpLoadSet();
    // umodel: Name.config next to Name.psa lists the tracks that do not exist in the source (Arkham City etc.)
    if (gAi.psa.err.empty()) { std::wstring cf = f; size_t d = cf.find_last_of(L'.'); if (d != std::wstring::npos) cf = cf.substr(0, d); cf += L".config";
        HANDLE hc = CreateFileW(cf.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
        if (hc != INVALID_HANDLE_VALUE) { LARGE_INTEGER cs; GetFileSizeEx(hc, &cs); std::string t((size_t)cs.QuadPart, '\0'); DWORD cr = 0; ReadFile(hc, t.data(), (DWORD)t.size(), &cr, NULL); CloseHandle(hc);
            t.resize(cr); gAi.cfgEntries = applyUmodelConfig(gAi.psa, t); if (gAi.cfgEntries) gAi.cfgFile = cf; } }
    gAi.tmpl = std::max(0, std::min(templateSeq, (int)gAi.setSeqs.size() - 1));
    for (auto& s : gAi.psa.seqs) { AnimImpRow r; r.on = gAi.psa.seqs.size() == 1; snprintf(r.name, sizeof r.name, "%s", s.name.c_str());   // several: the user chooses (a umodel PSA carries the whole AnimSet)
        for (int k = 0; k < (int)gAi.setSeqs.size(); k++) if (_bmieq(gAi.setSeqs[k].second, s.name)) r.target = k;   // same name -> replace
        gAi.rows.push_back(r); }
}
static void AnimImpRun() {
    gAi.log.clear(); gAi.lastOk = true; int done = 0; bool added = false;
    PsaFile psa = gAi.psa; if (gAi.force30) for (auto& s : psa.seqs) s.fps = 30.f;
    AnimImportOptions opt; opt.scaleNotifies = gAi.scaleNotifies; opt.keepRootMotion = gAi.rootMotion;
    for (size_t i = 0; i < gAi.rows.size(); i++) { const AnimImpRow& r = gAi.rows[i]; if (!r.on) continue;
        bool isNew = r.target < 0; if (gAi.setSeqs.empty()) { gAi.log.push_back("! AnimSet has no sequence to use as template"); gAi.lastOk = false; break; }
        i32 tgt = isNew ? gAi.setSeqs[gAi.tmpl].first : gAi.setSeqs[r.target].first;
        std::string nn = isNew ? std::string(r.name) : std::string();
        if (isNew && nn.empty()) { gAi.log.push_back("! " + psa.seqs[i].name + ": empty name"); gAi.lastOk = false; continue; }
        AnimImportReport rep = importPSAIntoSequence(gDoc.pk, psa, (int)i, tgt, nn, opt);
        if (!rep.ok) { gAi.log.push_back("! " + psa.seqs[i].name + ": " + rep.err); gAi.lastOk = false; continue; }
        char b[400]; snprintf(b, sizeof b, T(L_AI_DONEROW), psa.seqs[i].name.c_str(), isNew ? nn.c_str() : gAi.setSeqs[r.target].second.c_str(), isNew ? T(L_AI_NEW) : T(L_AI_REPLACED),
            rep.frames, rep.fps, rep.length, rep.matched, rep.tracks, rep.keysR + rep.keysT, rep.rawKeys, rep.bytes / 1024.0);
        gAi.log.push_back(b); if (rep.filledT || rep.filledR || rep.twistRebuilt) { snprintf(b, sizeof b, T(L_AI_FILLED), rep.filledT, rep.filledR, rep.twistRebuilt); gAi.log.push_back(b); } for (auto& w : rep.warnings) gAi.log.push_back("   ! " + w);
        if (!rep.missing.empty()) { std::string m = "   " + std::string(T(L_AI_MISSING)) + ":"; for (size_t k = 0; k < rep.missing.size() && k < 12; k++) m += " " + rep.missing[k]; if (rep.missing.size() > 12) m += " ..."; gAi.log.push_back(m); }
        done++; if (isNew) added = true;
    }
    if (done) { gDoc.dirty = true; if (added) { gDoc.rebuild(); gLastFilterKey = "\x01"; gEd.idx = -1; } gPrev.idx = 0; AnimImpLoadSet();
        for (auto& r : gAi.rows) if (r.target < 0) for (int k = 0; k < (int)gAi.setSeqs.size(); k++) if (gAi.setSeqs[k].second == r.name) r.target = k; }   // just created: next time it replaces
    Status(done ? T(L_AI_SAVEHINT) : T(L_AI_NOTHING));
}
static void AnimImpAutoTest() {   // test: BMS_AUTOANIM=file.psa opens the window on the AnimSet shown; BMS_AUTOANIM_RUN=1 imports
    static bool done = false; if (done || gPrev.kind != 4 || gPrev.setIdx <= 0) return; wchar_t b[1024]; if (!GetEnvironmentVariableW(L"BMS_AUTOANIM", b, 1024)) { done = true; return; }
    done = true; AnimImpBegin(gPrev.setIdx, 0); if (GetEnvironmentVariableW(L"BMS_AUTOANIM_RUN", b, 1024) && gAi.open) { gAi.force30 = true; if (!gAi.rows.empty()) { gAi.rows[0].on = true; gAi.rows[0].target = -1; snprintf(gAi.rows[0].name, sizeof gAi.rows[0].name, "Blender_Test_Anim"); } AnimImpRun(); }
}
static void AnimImpWindow() {
    AnimImpAutoTest();
    if (!gAi.open) return;
    ImGui::SetNextWindowSize(ImVec2(900, 600), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(1.0f);
    if (!ImGui::Begin(T(L_AI_TITLE), &gAi.open)) { ImGui::End(); return; }
    ImGui::TextWrapped("AnimSet:  %s", gDoc.pk.objPath(gAi.setIdx).c_str());
    ImGui::TextWrapped("PSA:  %s", U8(gAi.file).c_str());
    if (!gAi.psa.err.empty()) { ImGui::TextColored(ImVec4(1, .45f, .45f, 1), "%s", gAi.psa.err.c_str()); ImGui::End(); return; }
    if (gAi.cfgEntries) { std::string cn = U8(gAi.cfgFile); size_t sl = cn.find_last_of("\\/"); if (sl != std::string::npos) cn = cn.substr(sl + 1);
        char cb[600]; snprintf(cb, sizeof cb, T(L_AI_CFG), cn.c_str(), gAi.cfgEntries); ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(.55f, .85f, 1, 1)); ImGui::TextWrapped("%s", cb); ImGui::PopStyleColor(); }
    ImGui::Separator();
    // template for new sequences
    ImGui::SetNextItemWidth(320);
    if (ImGui::BeginCombo(T(L_AI_TEMPLATE), gAi.setSeqs.empty() ? "-" : gAi.setSeqs[gAi.tmpl].second.c_str())) {
        for (int k = 0; k < (int)gAi.setSeqs.size(); k++) if (ImGui::Selectable((gAi.setSeqs[k].second + "##t" + std::to_string(k)).c_str(), k == gAi.tmpl)) gAi.tmpl = k; ImGui::EndCombo(); }
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_AI_TEMPLATE_TIP));
    ImGui::Checkbox(T(L_AI_FORCE30), &gAi.force30); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_AI_FORCE30_TIP));
    ImGui::SameLine(); ImGui::Checkbox(T(L_AI_SCALENOT), &gAi.scaleNotifies); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_AI_SCALENOT_TIP));
    ImGui::SameLine(); ImGui::Checkbox(T(L_AI_ROOT), &gAi.rootMotion); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_AI_ROOT_TIP));
    float logH = gAi.log.empty() ? 0.f : 150.f;
    if (ImGui::BeginTable("aitab", 4, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY, ImVec2(0, ImGui::GetContentRegionAvail().y - logH - ImGui::GetFrameHeightWithSpacing() * 2))) {
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, 24); ImGui::TableSetupColumn("PSA", ImGuiTableColumnFlags_WidthStretch, 1.f);
        ImGui::TableSetupColumn(T(L_AI_TARGET), ImGuiTableColumnFlags_WidthStretch, 1.2f); ImGui::TableSetupColumn(T(L_AI_NAME), ImGuiTableColumnFlags_WidthStretch, 1.f);
        ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableHeadersRow();
        for (size_t i = 0; i < gAi.rows.size(); i++) { AnimImpRow& r = gAi.rows[i]; const PsaSeq& s = gAi.psa.seqs[i]; ImGui::PushID((int)i); ImGui::TableNextRow();
            ImGui::TableNextColumn(); ImGui::Checkbox("##on", &r.on);
            ImGui::TableNextColumn(); ImGui::Text("%s  (%d fr, %.0f fps)", s.name.c_str(), s.numFrames, s.fps);
            ImGui::TableNextColumn(); ImGui::SetNextItemWidth(-1);
            std::string cur = r.target < 0 ? std::string(T(L_AI_NEWSEQ)) : std::string(T(L_AI_REPLACE)) + " " + gAi.setSeqs[r.target].second;
            if (ImGui::BeginCombo("##tg", cur.c_str())) { if (ImGui::Selectable(T(L_AI_NEWSEQ), r.target < 0)) r.target = -1;
                for (int k = 0; k < (int)gAi.setSeqs.size(); k++) if (ImGui::Selectable((std::string(T(L_AI_REPLACE)) + " " + gAi.setSeqs[k].second + "##r" + std::to_string(k)).c_str(), k == r.target)) r.target = k; ImGui::EndCombo(); }
            ImGui::TableNextColumn(); ImGui::BeginDisabled(r.target >= 0); ImGui::SetNextItemWidth(-1); ImGui::InputText("##nm", r.name, sizeof r.name); ImGui::EndDisabled();
            ImGui::PopID(); }
        ImGui::EndTable();
    }
    int n = 0; for (auto& r : gAi.rows) if (r.on) n++;
    if (ImGui::SmallButton(T(L_AI_ALL))) for (auto& r : gAi.rows) r.on = true; ImGui::SameLine(); if (ImGui::SmallButton(T(L_AI_NONE))) for (auto& r : gAi.rows) r.on = false;
    ImGui::SameLine(); ImGui::Text("%d / %d", n, (int)gAi.rows.size());
    ImGui::BeginDisabled(n == 0); if (ImGui::Button(T(L_AI_RUN), ImVec2(220, 0))) AnimImpRun(); ImGui::EndDisabled();
    ImGui::SameLine(); ImGui::TextDisabled("%s", T(L_AI_HINT));
    if (!gAi.log.empty()) {   // always EndChild (even when BeginChild returns false: small/clipped window)
        if (ImGui::BeginChild("ailog", ImVec2(0, 0), ImGuiChildFlags_Borders))
            for (auto& l : gAi.log) { bool bad = l.find('!') != std::string::npos; if (bad) ImGui::TextColored(ImVec4(1, .7f, .35f, 1), "%s", l.c_str()); else ImGui::TextUnformatted(l.c_str()); }
        ImGui::EndChild(); }
    ImGui::End();
}
