// BmStudio - 2007 BETA (Xbox 360) -> PC game.
//   * "Convert to game...": mesh/texture/material selected in the beta package -> a chosen game package
//   * "Rebuild beta room...": the whole room (BSP + meshes + lights) -> Beta<Room>.umap, which "Import level"
//     puts into a game map
// Core in ../bmcpp/bmbetaconv.hpp and ../bmcpp/bmbetalevel.hpp. Included by app.cpp after library.hpp.
#pragma once
#include "../bmcpp/bmbetalevel.hpp"
#include "../bmcpp/bmbetaskel.hpp"

struct BetaState {
    bool open = false;
    std::vector<std::string> rooms; int room = -1; std::string roomsFor;
    bool bsp = true, meshes = true, lights = true, hideGrey = false; int maxLights = 160, shadowLights = 0; bool autoLights = true; float bright = 1.f, radius = 1.f;
    char outDir[512] = ""; std::vector<std::string> log; std::wstring lastOut; bool lastOk = false;
    // conversion of one object
    std::string convReport;
    // preview: the converted room in a temporary file, opened in the viewport
    std::wstring betaPath;             // beta package the room list came from
    std::wstring previewFile; std::string previewRoom; std::string pendingPreview; int pendingFrames = 0; int barRoom = -1;
};
static BetaState gBeta;

// CookedPC folder of the PC game (the one of the beta document is no good): CookedDir setting, or ask
static std::wstring BetaGameCooked() {
    std::wstring c = GetSetting(L"CookedDir");
    if (!c.empty() && GetFileAttributesW((c + L"Engine.u").c_str()) != INVALID_FILE_ATTRIBUTES) return c;
    std::wstring f = RimpPickFolder(); if (f.empty()) return L"";
    if (f.back() != L'\\') f += L'\\';
    if (GetFileAttributesW((f + L"Engine.u").c_str()) == INVALID_FILE_ATTRIBUTES) { Status(T(L_BT_NOCOOKED)); return L""; }
    SetSetting(L"CookedDir", f); return f;
}
static bm::betaconv::ReadTfc BetaTfcReader(const std::wstring& betaDir) {
    return [betaDir](const std::string& name, uint64_t off, size_t sz, std::vector<u8>& out) {
        HANDLE h = CreateFileW((betaDir + W(name) + L".tfc").c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); if (h == INVALID_HANDLE_VALUE) return false;
        LARGE_INTEGER li; li.QuadPart = (LONGLONG)off; SetFilePointerEx(h, li, NULL, FILE_BEGIN); out.resize(sz); DWORD rd = 0; BOOL ok = ReadFile(h, out.data(), (DWORD)sz, &rd, NULL); CloseHandle(h); return ok && rd == sz; };
}
static std::wstring BetaDirOf(const std::wstring& p) { size_t s = p.find_last_of(L"\\/"); return s == std::wstring::npos ? L"" : p.substr(0, s + 1); }
static bool BetaLoad(const std::wstring& path, Package& P, std::string& err) {
    std::vector<u8> b; if (!RimpIO().read(U8(path), b)) { err = "cannot read " + U8(path); return false; }
    bm::beta::Info in; if (!bm::beta::load(std::move(b), P, in)) { err = in.err; return false; } return true;
}
// type database with the GAME script packages (Core/Engine/BmGame...), independent of the open document
struct BetaDB { std::wstring dir; std::vector<std::unique_ptr<Doc>> docs; std::unique_ptr<bm::cp::TypeDB> db; };
static BetaDB gBetaDb;
static bm::cp::TypeDB* BetaTypeDB(const std::wstring& cooked, std::string& err) {
    if (gBetaDb.db && gBetaDb.dir == cooked) return gBetaDb.db.get();
    gBetaDb = BetaDB(); gBetaDb.dir = cooked; gBetaDb.db = std::make_unique<bm::cp::TypeDB>();
    for (const char* f : { "Core.u", "Engine.u", "CommonGame.u", "GFxUI.u", "IpDrv.u", "BmGame.u" }) {
        auto d = std::make_unique<Doc>(); std::string e = d->open(cooked + W(f)); if (!e.empty()) { err += std::string(f) + ": " + e + "; "; continue; }
        gBetaDb.db->add(&d->pk); gBetaDb.docs.push_back(std::move(d)); }
    return gBetaDb.db.get();
}
// game support files: empty level (Alley_C1_Fx), MasterShader MIC (Alley_C1_Static), template donor (Admin_A_Static)
static const wchar_t* kBetaBase = L"Maps\\DLC\\Alley\\Alley_C1_Fx.umap";
static const wchar_t* kBetaMat = L"Maps\\DLC\\Alley\\Alley_C1_Static.umap";
static const wchar_t* kBetaDonor = L"Maps\\Admin\\Admin_A_Static.umap";
// makes sure package T has the MasterShader MIC (copied from Alley_C1_Static if missing)
static bool BetaEnsureMaster(Package& T, const std::wstring& cooked, bm::cp::TypeDB& db, std::string& err) {
    if (bm::betaconv::findMasterMIC(T)) return true;
    auto ms = std::make_unique<Doc>(); std::string e = ms->open(cooked + kBetaMat); if (!e.empty()) { err = U8(cooked + kBetaMat) + ": " + e; return false; }
    db.add(&ms->pk); i32 mic = bm::betaconv::findMasterMIC(ms->pk); if (!mic) { err = "MasterShader_Basic_Opacity not found in Alley_C1_Static"; return false; }
    auto cr = bm::cp::copyObjects(T, ms->pk, { mic }, db, false); if (!cr.ok) { err = "copy MasterShader: " + cr.err; return false; }
    gBetaDb.docs.push_back(std::move(ms)); return true;
}

// ------------------------------------------------------------------ selected object -> game package
// character material master (with skeletal mesh shaders): FIT_Plaque_Gardens_Adobe_MAT of Admin_B4_Static
static i32 BetaEnsureSkelMaster(Package& T, const std::wstring& cooked, bm::cp::TypeDB& db, std::string& err) {
    i32 m = bm::betaskel::findSkelMaster(T); if (m) return m;
    auto ms = std::make_unique<Doc>(); std::string e = ms->open(cooked + L"Maps\\Admin\\Admin_B4_Static.umap"); if (!e.empty()) { err = "Admin_B4_Static.umap: " + e; return 0; }
    db.add(&ms->pk); i32 src = bm::betaskel::findSkelMaster(ms->pk); if (!src) { err = "FIT_Plaque_Gardens_Adobe_MAT not found"; return 0; }
    auto cr = bm::cp::copyObjects(T, ms->pk, { src }, db, false); if (!cr.ok) { err = "copy character master: " + cr.err; return 0; }
    gBetaDb.docs.push_back(std::move(ms)); return bm::betaskel::findSkelMaster(T);
}
static bool BetaConvertible(i32 x) { if (!gDoc.pk.bigEndian || x <= 0) return false; std::string c = gDoc.pk.classOf(gDoc.pk.exports[x - 1]); return c == "StaticMesh" || c == "Texture2D" || c == "Material" || c == "MaterialInstanceConstant" || c == "SkeletalMesh" || c == "AnimSet"; }
static std::string gBetaLastConverted; static bool gBetaObjPreview = false;   // path (in the target) of the last converted object
static void BetaConvertSelected(i32 x, std::wstring target = L"", bool backup = true) {
    gBetaLastConverted.clear();
    std::wstring cooked = BetaGameCooked(); if (cooked.empty()) return;
    if (target.empty()) target = FileDialog(false, L""); if (target.empty()) return;
    gBetaDb = BetaDB(); std::string err; bm::cp::TypeDB* db = BetaTypeDB(cooked, err);
    Package Tp; { std::vector<u8> bytes; if (!RimpIO().read(U8(target), bytes)) { Status(std::string(T(L_OPENFAIL)) + ": " + U8(target)); return; }
        if (bm::beta::isBigEndianPackage(bytes.data(), bytes.size())) { Status(T(L_BETA_RO)); return; }
        try { Tp.loadBytes(std::move(bytes)); } catch (std::exception& e) { Status(std::string(T(L_OPENFAIL)) + ": " + e.what()); return; } }
    Package Bn; if (!BetaLoad(gDoc.path, Bn, err)) { Status(err); return; } bm::betaconv::normalize(Bn);
    db->add(&Tp);
    if (!BetaEnsureMaster(Tp, cooked, *db, err)) { Status(err); return; }
    bm::betaconv::Ctx C(Bn, gDoc.pk, Tp); C.readTfc = BetaTfcReader(BetaDirOf(gDoc.path)); bm::betaconv::findTemplates(C);
    std::string cls = gDoc.pk.classOf(gDoc.pk.exports[x - 1]); i32 r = 0;
    try {
        if (cls == "StaticMesh") r = bm::betaconv::convStaticMesh(C, x); else if (cls == "Texture2D") r = bm::betaconv::convTexture(C, x);
        else if (cls == "SkeletalMesh") {
            i32 master = BetaEnsureSkelMaster(Tp, cooked, *db, err); if (!master) throw bm::Err(err);
            auto S = bm::betaskel::readSkel(Bn, x); if (!S.err.empty()) throw bm::Err(S.err);
            std::vector<i32> mats; for (i32 m : S.mats) mats.push_back(bm::betaskel::convSkelMaterial(C, master, m));
            i32 outer = bm::betaconv::destOuter(C, x); std::string nm = Bn.objName(x); if (Tp.findPath(Tp.objPath(outer) + "." + nm)) nm += "_Beta";
            r = bm::betaskel::createSkel(Tp, outer, nm, S, mats); C.meshes++;
        }
        else if (cls == "AnimSet") {
            // preview mesh: the first SkeletalMesh converted in the target with the same bone count
            auto as = bm::parseAnimSet(Bn, x); std::string prev;
            for (size_t k = 0; k < Tp.exports.size() && prev.empty(); k++) if (Tp.classOf(Tp.exports[k]) == "SkeletalMesh" && Tp.objPath((i32)k + 1).rfind("Beta", 0) == 0) { auto sm = bm::parseSkeletalMesh(Tp, (i32)k + 1); if (sm.bones.size() == as.bones.size()) prev = Tp.objName((i32)k + 1); }
            auto R = bm::betaskel::convAnimSet(Bn, Tp, x, bm::betaconv::destOuter(C, x), prev); for (auto& l : R.log) C.L(l); r = R.set;
            if (R.seqs == 0) r = 0; else C.L(std::to_string(R.seqs) + " animations" + (R.failed ? ", " + std::to_string(R.failed) + " failed" : ""));
        }
        else r = bm::betaconv::convMaterial(C, x); }
    catch (std::exception& e) { C.L(e.what()); r = 0; }
    gBeta.convReport.clear(); for (auto& l : C.log) gBeta.convReport += l + "\n";
    if (!r) { Status(std::string(T(L_BT_CONVFAIL)) + (C.log.empty() ? "" : ": " + C.log.back())); return; }
    std::wstring bak = target + L".before_beta"; if (backup && GetFileAttributesW(bak.c_str()) == INVALID_FILE_ATTRIBUTES) CopyFileW(target.c_str(), bak.c_str(), TRUE);
    LvlCtxReleasePath(target);
    std::vector<u8> outb; try { outb = Tp.saveToMemory(); } catch (std::exception& e) { Status(std::string(T(L_SAVEFAIL)) + ": " + e.what()); return; }
    if (!RimpIO().write(U8(target), outb)) { Status(std::string(T(L_SAVEFAIL)) + ": " + U8(target)); return; }
    gBetaLastConverted = Tp.objPath(r);
    char b[600]; snprintf(b, sizeof b, T(L_BT_CONVOK), Tp.objPath(r).c_str(), C.meshes, C.materials, C.textures); Status(b);
    gBetaDb = BetaDB();   // the type database pointed to packages local to this function
}

// ------------------------------------------------------------------ rebuild room
static std::string BetaRoomOf(const std::string& file) {
    std::string b = file; size_t d = b.rfind('.'); if (d != std::string::npos) b = b.substr(0, d);
    std::string l = LvlLower(b);
    for (const char* suf : { "_static_art", "_static", "_clights", "_lights", "_fx", "_audio", "_loc_int" }) { size_t n = strlen(suf); if (l.size() > n && l.compare(l.size() - n, n, suf) == 0) return b.substr(0, b.size() - n); }
    return b;
}
static void BetaScanRooms(const std::wstring& betaPath) {
    std::wstring dir = BetaDirOf(betaPath); if (gBeta.roomsFor == U8(dir)) return; gBeta.roomsFor = U8(dir); gBeta.rooms.clear(); gBeta.room = -1;
    std::set<std::string> all, withStatic;
    WIN32_FIND_DATAW fd; HANDLE h = FindFirstFileW((dir + L"*.xxx").c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) { do { std::string f = U8(fd.cFileName); std::string r = BetaRoomOf(f); std::string l = LvlLower(f);
            if (l.find("_static") != std::string::npos) withStatic.insert(r); all.insert(r); } while (FindNextFileW(h, &fd)); FindClose(h); }
    for (auto& r : withStatic) gBeta.rooms.push_back(r);
    std::string me = BetaRoomOf(U8(betaPath.substr(dir.size())));
    for (int i = 0; i < (int)gBeta.rooms.size(); i++) if (LvlLower(gBeta.rooms[i]) == LvlLower(me)) gBeta.room = i;
    if (!gBeta.outDir[0]) { std::wstring c = GetSetting(L"BetaOutDir"); if (c.empty()) { std::wstring ck = GetSetting(L"CookedDir"); if (!ck.empty()) c = ck + L"..\\..\\_bmtk\\BetaRooms\\"; }
        snprintf(gBeta.outDir, sizeof gBeta.outDir, "%s", U8(c).c_str()); }
}
// builds Beta<room>.umap in 'out' from the .xxx files in the folder of 'betaPath'; returns the file ("" = failed)
static std::wstring BetaBuild(const std::wstring& betaPath, const std::string& room, const std::string& out) {
    gBeta.log.clear(); gBeta.lastOk = false; gBeta.lastOut.clear();
    auto say = [](const std::string& s) { gBeta.log.push_back(s); };
    std::wstring cooked = BetaGameCooked(); if (cooked.empty()) return L"";
    SHCreateDirectoryExW(NULL, W(out).c_str(), NULL);
    std::string err;
    try {
        gBetaDb = BetaDB(); bm::cp::TypeDB* db = BetaTypeDB(cooked, err); if (!err.empty()) say("warning: " + err);
        auto base = std::make_unique<Doc>(); std::string e = base->open(cooked + kBetaBase); if (!e.empty()) throw bm::Err(U8(cooked + kBetaBase) + ": " + e);
        Package Tp; { std::vector<u8> b(base->pk.fp, base->pk.fp + base->pk.fn); Tp.loadBytes(std::move(b)); }
        std::string newName = "Beta" + room; bm::betalevel::makeBlank(Tp, "Alley_C1_Fx", newName);
        db->add(&Tp);
        if (!BetaEnsureMaster(Tp, cooked, *db, err)) throw bm::Err(err);
        auto donor = std::make_unique<Doc>(); e = donor->open(cooked + kBetaDonor); if (!e.empty()) throw bm::Err(U8(cooked + kBetaDonor) + ": " + e);
        Package D; { std::vector<u8> b(donor->pk.fp, donor->pk.fp + donor->pk.fn); D.loadBytes(std::move(b)); } db->add(&D);
        std::vector<bm::betalevel::BetaPkg> pkgs; std::wstring dir = BetaDirOf(betaPath);
        for (const char* suf : { "", "_Static", "_Static_Art", "_Lights", "_CLights", "_Fx", "_FX" }) {
            std::wstring f = dir + W(room + suf) + L".xxx"; if (GetFileAttributesW(f.c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            bool dup = false; for (auto& p : pkgs) if (LvlLower(p.name) == LvlLower(room + suf)) dup = true; if (dup) continue;
            pkgs.emplace_back(); auto& b = pkgs.back(); b.name = room + suf; std::string le;
            if (!BetaLoad(f, b.raw, le) || !BetaLoad(f, b.norm, le)) {
                std::vector<u8> fb; size_t z = 0; if (RimpIO().read(U8(f), fb)) for (u8 c : fb) z += c == 0;   // v0.21: beta dump with a zeroed file
                say(room + suf + ": " + (fb.size() && z * 100 >= fb.size() * 90 ? std::string(T(L_BT_ZEROPKG)) : le) + " (skipped)"); pkgs.pop_back(); continue; }
            bm::betaconv::normalize(b.norm); }
        if (pkgs.empty()) throw bm::Err("none of the room packages could be read");
        bm::betalevel::Options O; O.bsp = gBeta.bsp; O.meshes = gBeta.meshes; O.lights = gBeta.lights; O.maxLights = gBeta.maxLights; O.lightBrightness = gBeta.bright; O.lightRadius = gBeta.radius; O.hideUntextured = gBeta.hideGrey; O.shadowLights = gBeta.shadowLights; O.autoLights = gBeta.autoLights;
        auto R = bm::betalevel::build(Tp, *db, D, pkgs, BetaTfcReader(dir), O, say);
        char b[512]; snprintf(b, sizeof b, T(L_BT_SUMMARY), R.bspMeshes, R.meshActors, R.meshesConverted, R.materials, R.textures, R.lights, R.lightsDropped, R.failed); say(b); snprintf(b, sizeof b, T(L_BT_COLLSUM), R.bspCollision, R.bodies); say(b);
        std::string sk; for (auto& kv : R.skipped) sk += kv.first + " x" + std::to_string(kv.second) + ", "; if (!sk.empty()) say(std::string(T(L_BT_SKIPPED)) + " " + sk.substr(0, sk.size() - 2));
        std::wstring outFile = W(out + newName + ".umap");
        if (gDoc.loaded && _wcsicmp(gDoc.path.c_str(), outFile.c_str()) == 0) { gDoc.close(); gDocGen++; gLevelMode = false; }   // the file is open (mapped)
        LvlCtxReleasePath(outFile);
        if (!RimpIO().write(U8(outFile), Tp.saveToMemory())) throw bm::Err("cannot write " + U8(outFile));
        say(std::string(T(L_BT_WROTE)) + " " + U8(outFile)); gBeta.lastOut = outFile; gBeta.lastOk = true;
    } catch (std::exception& ex) { say(std::string("ERROR: ") + ex.what()); }
    gBetaDb = BetaDB();   // the type database pointed to packages local to this function
    return gBeta.lastOk ? gBeta.lastOut : L"";
}
static void BetaRun() {
    if (gBeta.room < 0) return;
    std::string out = RimpSlash(gBeta.outDir); if (out.size() < 2) { gBeta.log.clear(); gBeta.log.push_back(T(L_BT_NOOUT)); return; }
    SetSetting(L"BetaOutDir", W(out));
    BetaBuild(gDoc.path, gBeta.rooms[gBeta.room], out);
}
static std::string BetaPreviewDir() { wchar_t t[MAX_PATH] = { 0 }; GetTempPathW(MAX_PATH, t); return RimpSlash(U8(t)) + "BmStudio_beta\\"; }
static void BetaPreviewRequest(const std::string& room) { gBeta.pendingPreview = room; gBeta.pendingFrames = 0; }
// runs the requested preview (after drawing 2 frames with the "building..." notice)
static void BetaPreviewPump() {
    if (gBeta.pendingPreview.empty()) return;
    ImGui::SetNextWindowPos(ImGui::GetMainViewport()->GetCenter(), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::Begin("##betagen", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings);
    ImGui::Text(T(L_BT_PREVGEN), gBeta.pendingPreview.c_str()); ImGui::End();
    if (++gBeta.pendingFrames < 3) return;
    std::string room = gBeta.pendingPreview; gBeta.pendingPreview.clear();
    std::wstring bp = gBeta.betaPath;
    std::wstring f = BetaBuild(bp, room, BetaPreviewDir());
    if (f.empty()) { gBeta.open = true; Status(gBeta.log.empty() ? std::string(T(L_BT_CONVFAIL)) : gBeta.log.back()); if (!gDoc.loaded) DoOpen(bp); return; }
    gBeta.previewFile = f; gBeta.previewRoom = room; gBeta.open = false; gBetaObjPreview = false;
    DoOpen(f); if (gDoc.loaded) gLevelMode = PackageHasLevel();
}
// beta room of the open document -> preview (Ctrl+L / View > Viewport on a .xxx)
static void BetaPreviewCurrent() {
    if (!gDoc.loaded || !gDoc.pk.bigEndian) return; gBeta.betaPath = gDoc.path;
    std::wstring dir = BetaDirOf(gDoc.path); BetaPreviewRequest(BetaRoomOf(U8(gDoc.path.substr(dir.size()))));
}
static bool BetaInPreview() { return gDoc.loaded && !gBeta.previewFile.empty() && _wcsicmp(gDoc.path.c_str(), gBeta.previewFile.c_str()) == 0; }
// preview bar: switch room, build the final one, go back to the beta
// ------------------------------------------------------------------ viewing a beta object (mesh, character, animations) in BmStudio
// converts into a temporary package (copy of the game's empty level) and opens it with the object selected in the Preview tab.
// AnimSet: the first beta skeletal mesh with the same bone count goes along (so the animations play on it).
static void BetaPreviewObject(i32 x) {
    if (!gDoc.loaded || !gDoc.pk.bigEndian || x <= 0) return;
    std::wstring cooked = BetaGameCooked(); if (cooked.empty()) return;
    std::wstring dir = W(BetaPreviewDir()); SHCreateDirectoryExW(NULL, dir.c_str(), NULL);
    std::wstring tmp = dir + L"BetaPreview.upk";
    if (gDoc.loaded && RimpSamePath(gDoc.path, tmp)) { gDoc.close(); gDocGen++; }
    LvlCtxReleasePath(tmp);
    if (!CopyFileW((cooked + kBetaBase).c_str(), tmp.c_str(), FALSE)) { Status(std::string(T(L_SAVEFAIL)) + ": " + U8(tmp)); return; }
    SetFileAttributesW(tmp.c_str(), FILE_ATTRIBUTE_NORMAL);
    std::wstring betaPath = gDoc.path; std::string cls = gDoc.pk.classOf(gDoc.pk.exports[x - 1]);
    if (cls == "AnimSet") {   // mesh for the animations
        Package Bn; std::string err; if (BetaLoad(betaPath, Bn, err)) { bm::betaconv::normalize(Bn); auto as = bm::parseAnimSet(Bn, x); i32 best = 0;
            for (size_t k = 0; k < Bn.exports.size() && !best; k++) if (Bn.classOf(Bn.exports[k]) == "SkeletalMesh") { auto S = bm::betaskel::readSkel(Bn, (i32)k + 1); if (S.err.empty() && S.bones.size() == as.bones.size()) best = (i32)k + 1; }
            if (best) BetaConvertSelected(best, tmp, false); }
    }
    BetaConvertSelected(x, tmp, false);
    std::string sel = gBetaLastConverted; if (sel.empty()) return;
    gBeta.betaPath = betaPath; gBeta.previewFile = tmp; gBeta.previewRoom = U8(betaPath.substr(betaPath.find_last_of(L"\\/") + 1)) + " : " + sel; gBetaObjPreview = true;
    DoOpen(tmp); if (!gDoc.loaded) return; i32 y = gDoc.pk.findPath(sel); if (y > 0) { GotoObject(y); gOpenPreviewTab = true; }
}
static void BetaPreviewBar() {
    if (!BetaInPreview()) return;
    if (gBetaObjPreview) {
        ImGui::SetNextWindowPos(ImVec2(ImGui::GetMainViewport()->WorkPos.x + ImGui::GetMainViewport()->WorkSize.x - 20, ImGui::GetMainViewport()->WorkPos.y + 60), ImGuiCond_FirstUseEver, ImVec2(1, 0));
        ImGui::Begin(T(L_BT_PREVTITLE), nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse);
        ImGui::TextColored(ImVec4(1, .8f, .35f, 1), T(L_BT_PREVOBJ), gBeta.previewRoom.c_str());
        if (ImGui::Button(T(L_BT_PREVBACK))) { std::wstring bp = gBeta.betaPath; gBeta.previewFile.clear(); gBetaObjPreview = false; DoOpen(bp); }
        ImGui::End(); return;
    }
    BetaScanRooms(gBeta.betaPath);
    if (gBeta.barRoom < 0 || gBeta.barRoom >= (int)gBeta.rooms.size() || gBeta.rooms[gBeta.barRoom] != gBeta.previewRoom) { gBeta.barRoom = -1; for (int i = 0; i < (int)gBeta.rooms.size(); i++) if (gBeta.rooms[i] == gBeta.previewRoom) gBeta.barRoom = i; }
    ImGui::SetNextWindowPos(ImVec2(ImGui::GetMainViewport()->WorkPos.x + ImGui::GetMainViewport()->WorkSize.x - 20, ImGui::GetMainViewport()->WorkPos.y + 60), ImGuiCond_FirstUseEver, ImVec2(1, 0));
    ImGui::Begin(T(L_BT_PREVTITLE), nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse);
    ImGui::TextColored(ImVec4(1, .8f, .35f, 1), T(L_BT_PREVNOTE), gBeta.previewRoom.c_str());
    ImGui::SetNextItemWidth(200);
    if (ImGui::BeginCombo("##rooms", gBeta.previewRoom.c_str(), ImGuiComboFlags_HeightLarge)) { for (int i = 0; i < (int)gBeta.rooms.size(); i++) if (ImGui::Selectable(gBeta.rooms[i].c_str(), i == gBeta.barRoom)) { gBeta.barRoom = i; if (gBeta.rooms[i] != gBeta.previewRoom) BetaPreviewRequest(gBeta.rooms[i]); } ImGui::EndCombo(); }
    ImGui::SameLine(); if (ImGui::Button(T(L_BT_PREVPREV)) && gBeta.barRoom > 0) BetaPreviewRequest(gBeta.rooms[gBeta.barRoom - 1]);
    ImGui::SameLine(); if (ImGui::Button(T(L_BT_PREVNEXT)) && gBeta.barRoom + 1 < (int)gBeta.rooms.size()) BetaPreviewRequest(gBeta.rooms[gBeta.barRoom + 1]);
    if (!gBeta.outDir[0]) { std::wstring c = GetSetting(L"BetaOutDir"); if (c.empty()) { std::wstring ck = GetSetting(L"CookedDir"); if (!ck.empty()) c = ck + L"..\\..\\_bmtk\\BetaRooms\\"; } snprintf(gBeta.outDir, sizeof gBeta.outDir, "%s", U8(c).c_str()); }
    if (ImGui::Button(T(L_BT_PREVKEEP))) {   // the preview is already the complete level: just copy it to the output folder
        std::string out = RimpSlash(gBeta.outDir); SHCreateDirectoryExW(NULL, W(out).c_str(), NULL); SetSetting(L"BetaOutDir", W(out));
        std::wstring dst = W(out) + gBeta.previewFile.substr(gBeta.previewFile.find_last_of(L"\\") + 1);
        LvlCtxReleasePath(dst);
        if (CopyFileW(gBeta.previewFile.c_str(), dst.c_str(), FALSE)) Status(std::string(T(L_BT_WROTE)) + " " + U8(dst)); else Status(std::string(T(L_SAVEFAIL)) + ": " + U8(dst)); }
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", gBeta.outDir);
    ImGui::SameLine(); if (ImGui::Button(T(L_BT_PREVBACK))) { std::wstring bp = gBeta.betaPath; gBeta.previewFile.clear(); DoOpen(bp); }
    if (!gBeta.log.empty()) { ImGui::SameLine(); ImGui::TextDisabled("(?)"); if (ImGui::IsItemHovered()) { ImGui::BeginTooltip(); for (auto& l : gBeta.log) ImGui::TextUnformatted(l.c_str()); ImGui::EndTooltip(); } }
    ImGui::End();
}

static void BetaWindow() {
    if (!gBeta.open) return;
    if (!gDoc.loaded || !gDoc.pk.bigEndian) { gBeta.open = false; return; }
    gBeta.betaPath = gDoc.path; BetaScanRooms(gDoc.path);
    ImGui::SetNextWindowSize(ImVec2(720, 560), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin(T(L_BT_TITLE), &gBeta.open)) { ImGui::End(); return; }
    ImGui::TextWrapped("%s", T(L_BT_INTRO));
    ImGui::Separator();
    const char* cur = gBeta.room >= 0 ? gBeta.rooms[gBeta.room].c_str() : "-";
    ImGui::SetNextItemWidth(260); if (ImGui::BeginCombo(T(L_BT_ROOM), cur)) { for (int i = 0; i < (int)gBeta.rooms.size(); i++) if (ImGui::Selectable(gBeta.rooms[i].c_str(), i == gBeta.room)) gBeta.room = i; ImGui::EndCombo(); }
    ImGui::Checkbox(T(L_BT_BSP), &gBeta.bsp); if (gBeta.bsp) { ImGui::SameLine(); ImGui::Checkbox(T(L_BT_HIDEGREY), &gBeta.hideGrey); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_BT_HIDEGREY_TIP)); } ImGui::SameLine(); ImGui::Checkbox(T(L_BT_MESHES), &gBeta.meshes); ImGui::SameLine(); ImGui::Checkbox(T(L_BT_LIGHTS), &gBeta.lights);
    if (gBeta.lights) { ImGui::SetNextItemWidth(200); ImGui::SliderInt(T(L_BT_MAXLIGHTS), &gBeta.maxLights, 0, 500); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_BT_MAXLIGHTS_TIP));
        ImGui::SetNextItemWidth(200); ImGui::SliderFloat(T(L_BT_BRIGHT), &gBeta.bright, 0.1f, 4.f, "%.2fx"); ImGui::SameLine(); ImGui::SetNextItemWidth(200); ImGui::SliderFloat(T(L_BT_RADIUS), &gBeta.radius, 0.25f, 3.f, "%.2fx");
        ImGui::SetNextItemWidth(200); ImGui::SliderInt(T(L_BT_SHADOWL), &gBeta.shadowLights, 0, 32); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_BT_SHADOWL_TIP));
        ImGui::Checkbox(T(L_BT_AUTOL), &gBeta.autoLights); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_BT_AUTOL_TIP)); }
    ImGui::SetNextItemWidth(520); ImGui::InputText(T(L_RI_OUTDIR), gBeta.outDir, sizeof gBeta.outDir); ImGui::SameLine(); if (ImGui::SmallButton("...")) { std::wstring f = RimpPickFolder(); if (!f.empty()) snprintf(gBeta.outDir, sizeof gBeta.outDir, "%s", U8(f).c_str()); }
    ImGui::BeginDisabled(gBeta.room < 0);
    if (ImGui::Button(T(L_BT_PREVIEW), ImVec2(220, 0))) BetaPreviewRequest(gBeta.rooms[gBeta.room]);
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_BT_PREVIEW_TIP));
    ImGui::SameLine(); if (ImGui::Button(T(L_BT_RUN), ImVec2(220, 0))) BetaRun();
    ImGui::EndDisabled();
    if (gBeta.lastOk) { ImGui::SameLine(); if (ImGui::Button(T(L_BT_OPENOUT))) { std::wstring p = gBeta.lastOut; gBeta.open = false; DoOpen(p); if (gDoc.loaded) gLevelMode = PackageHasLevel(); ImGui::End(); return; }
        ImGui::TextWrapped("%s", T(L_BT_NEXT)); }
    ImGui::Separator();
    ImGui::BeginChild("btlog", ImVec2(0, 0), true); for (auto& l : gBeta.log) ImGui::TextUnformatted(l.c_str()); ImGui::EndChild();
    ImGui::End();
}

// test: BMS_AUTOBETA=room BMS_AUTOBETA_OUT=folder [BMS_COOKED=game CookedPC] -> builds and opens the result in the viewport
static void BetaAutoTest() {
    static bool done = false; if (done || !gDoc.loaded || !gDoc.pk.bigEndian) return; done = true; wchar_t b[1024];
    if (GetEnvironmentVariableW(L"BMS_AUTOPREVOBJ", b, 1024)) { std::string o = U8(b); if (GetEnvironmentVariableW(L"BMS_COOKED", b, 1024)) SetSetting(L"CookedDir", b); BetaPreviewObject(gDoc.pk.findPath(o)); return; }
    if (GetEnvironmentVariableW(L"BMS_AUTOCONV", b, 1024)) { if (GetEnvironmentVariableW(L"BMS_COOKED", b, 1024)) SetSetting(L"CookedDir", b); GetEnvironmentVariableW(L"BMS_AUTOCONV", b, 1024);   // "object|target package[|object2...]"
        std::wstring all = b; std::vector<std::wstring> parts; size_t st = 0; for (;;) { size_t q = all.find(L'|', st); parts.push_back(all.substr(st, q == std::wstring::npos ? std::wstring::npos : q - st)); if (q == std::wstring::npos) break; st = q + 1; }
        if (parts.size() < 2) return; std::wstring tgt = parts[1]; std::vector<std::string> objs = { U8(parts[0]) }; for (size_t k = 2; k < parts.size(); k++) objs.push_back(U8(parts[k]));
        FILE* f = _wfopen((tgt + L".log").c_str(), L"w");
        for (auto& o : objs) { i32 x = gDoc.pk.findPath(o); if (x > 0) { BetaConvertSelected(x, tgt); if (f) fprintf(f, "%s: %s\n%s\n", o.c_str(), gStatus.c_str(), gBeta.convReport.c_str()); } else if (f) fprintf(f, "%s: not found\n", o.c_str()); }
        if (f) fclose(f); return; }
    if (GetEnvironmentVariableW(L"BMS_AUTOBETA_PREVIEW", b, 1024)) { if (GetEnvironmentVariableW(L"BMS_COOKED", b, 1024)) SetSetting(L"CookedDir", b); BetaPreviewCurrent(); return; }
    if (!GetEnvironmentVariableW(L"BMS_AUTOBETA", b, 1024)) return; std::string room = U8(b);
    if (GetEnvironmentVariableW(L"BMS_COOKED", b, 1024)) SetSetting(L"CookedDir", b);
    gBeta.open = true; gBeta.betaPath = gDoc.path; BetaScanRooms(gDoc.path); for (int i = 0; i < (int)gBeta.rooms.size(); i++) if (LvlLower(gBeta.rooms[i]) == LvlLower(room)) gBeta.room = i;
    if (GetEnvironmentVariableW(L"BMS_AUTOBETA_OUT", b, 1024)) snprintf(gBeta.outDir, sizeof gBeta.outDir, "%s", U8(b).c_str());
    BetaRun(); FILE* f = _wfopen((W(gBeta.outDir) + L"\\betalog.txt").c_str(), L"w"); if (f) { for (auto& l : gBeta.log) fprintf(f, "%s\n", l.c_str()); fclose(f); }
    if (gBeta.lastOk && GetEnvironmentVariableW(L"BMS_AUTOBETA_OPEN", b, 16)) { std::wstring p = gBeta.lastOut; gBeta.open = false; DoOpen(p); if (gDoc.loaded) gLevelMode = PackageHasLevel(); }
}

// ------------------------------------------------------------------ beta enemy (game henchman controller + beta mesh/animations)
// Produces: CookedPC\BmBeta\BI_<Id>.upk (converted mesh, head, materials, textures and AnimSets, all inside the top-level package
// BI_<Id> = file name, as BmModLoader's DynamicLoadObject needs) + CookedPC\BmBosses\BI_<Id>.ini
// (same format as the Joker/Harley ones). Arkham Revival uses it as the 7th field of a spawn point: ...,-,-,-,BI_<Id>
struct BetaEnemyState {
    bool open = false; std::string forPath; std::vector<i32> meshes, sets; int body = -1, head = 0; std::vector<int> setMode;   // 0 off, 1 replace, 2 append
    char id[64] = ""; float health = 1, damage = 1, cooldown = 2; bool mute = false; std::vector<std::string> log; std::string revivalLine;
};
static BetaEnemyState gBE;
static void BetaEnemyScan() {
    if (gBE.forPath == U8(gDoc.path)) return; gBE = BetaEnemyState(); gBE.open = true; gBE.forPath = U8(gDoc.path);
    for (size_t k = 0; k < gDoc.pk.exports.size(); k++) { std::string c = gDoc.pk.classOf(gDoc.pk.exports[k]); if (c == "SkeletalMesh") gBE.meshes.push_back((i32)k + 1); if (c == "AnimSet") gBE.sets.push_back((i32)k + 1); }
    for (i32 s : gBE.sets) { std::string n = LvlLower(gDoc.pk.objName(s)); int m = 2;
        if (n == "thug_anims" || n.find("_unarmed_anims") != std::string::npos || n.find("henchman_anims") != std::string::npos) m = 1;
        if (n.find("speech") != std::string::npos || n.find("grate") != std::string::npos) m = 0;
        gBE.setMode.push_back(m); }
}
static void BetaEnemyAutoPick() {   // when the body is chosen: suggested head and name
    if (gBE.body < 0) return; std::string bn = gDoc.pk.objName(gBE.meshes[gBE.body]); std::string top = gDoc.pk.objPath(gBE.meshes[gBE.body]); top = top.substr(0, top.find('.'));
    gBE.head = 0; for (size_t i = 0; i < gBE.meshes.size(); i++) { std::string p = gDoc.pk.objPath(gBE.meshes[i]); if (p.rfind(top + ".", 0) == 0 && LvlLower(p).find("head") != std::string::npos) { gBE.head = (int)i + 1; break; } }
    std::string id; for (char c : bn) if (isalnum((unsigned char)c)) id += c; size_t sk = LvlLower(id).rfind("skin"); if (sk != std::string::npos && sk + 4 == id.size()) id = id.substr(0, sk);
    snprintf(gBE.id, sizeof gBE.id, "%s", id.substr(0, 40).c_str());
}
static void BetaEnemyBuild() {
    gBE.log.clear(); gBE.revivalLine.clear(); auto say = [](const std::string& s) { gBE.log.push_back(s); };
    if (gBE.body < 0 || !gBE.id[0]) return;
    std::wstring cooked = BetaGameCooked(); if (cooked.empty()) return;
    std::string top = std::string("BI_") + gBE.id;
    std::wstring outDir = cooked + L"BmBeta\\", outFile = outDir + W(top) + L".upk", iniFile = cooked + L"BmBosses\\" + W(top) + L".ini";
    SHCreateDirectoryExW(NULL, outDir.c_str(), NULL); SHCreateDirectoryExW(NULL, (cooked + L"BmBosses").c_str(), NULL);
    gBetaDb = BetaDB(); std::string err;
    try {
        bm::cp::TypeDB* db = BetaTypeDB(cooked, err);
        auto base = std::make_unique<Doc>(); std::string e = base->open(cooked + kBetaBase); if (!e.empty()) throw bm::Err(U8(cooked + kBetaBase) + ": " + e);
        Package Tp; { std::vector<u8> b(base->pk.fp, base->pk.fp + base->pk.fn); Tp.loadBytes(std::move(b)); }
        bm::betalevel::makeBlank(Tp, "Alley_C1_Fx", top); db->add(&Tp);
        i32 master = BetaEnsureSkelMaster(Tp, cooked, *db, err); if (!master) throw bm::Err(err);
        Package Bn; if (!BetaLoad(gDoc.path, Bn, err)) throw bm::Err(err); bm::betaconv::normalize(Bn);
        bm::betaconv::Ctx C(Bn, gDoc.pk, Tp); C.readTfc = BetaTfcReader(BetaDirOf(gDoc.path)); C.prefix = top + ".";
        auto convMesh = [&](i32 x) -> std::string {
            auto S = bm::betaskel::readSkel(Bn, x); if (!S.err.empty()) throw bm::Err(Bn.objPath(x) + ": " + S.err);
            std::vector<i32> mats; for (i32 m : S.mats) mats.push_back(bm::betaskel::convSkelMaterial(C, master, m));
            i32 r = bm::betaskel::createSkel(Tp, bm::betaconv::destOuter(C, x), Bn.objName(x), S, mats); say("  mesh " + Tp.objPath(r)); return Tp.objPath(r); };
        std::string bodyPath = convMesh(gBE.meshes[gBE.body]), headPath = gBE.head > 0 ? convMesh(gBE.meshes[gBE.head - 1]) : "";
        std::vector<std::string> over, tail;
        for (size_t i = 0; i < gBE.sets.size(); i++) { if (!gBE.setMode[i]) continue;
            auto R = bm::betaskel::convAnimSet(Bn, Tp, gBE.sets[i], bm::betaconv::destOuter(C, gBE.sets[i]), Tp.objName(Tp.findPath(bodyPath)));
            for (auto& l : R.log) say(l); if (!R.set || !R.seqs) continue;
            (gBE.setMode[i] == 1 ? over : tail).push_back(Tp.objPath(R.set)); say("  animations " + Tp.objPath(R.set) + ": " + std::to_string(R.seqs)); }
        for (auto& l : C.log) say(l);
        LvlCtxReleasePath(outFile);
        if (!RimpIO().write(U8(outFile), Tp.saveToMemory())) throw bm::Err("could not write " + U8(outFile) + " (is the game running?)");
        auto join = [](const std::vector<std::string>& v) { std::string s; for (auto& x : v) { if (!s.empty()) s += ","; s += x; } return s; };
        std::vector<std::string> keep = { bodyPath }; if (!headPath.empty()) keep.push_back(headPath); for (auto& s : over) keep.push_back(s); for (auto& s : tail) keep.push_back(s);
        char num[64]; std::string ini;
        ini += "; 2007 BETA enemy generated by BmStudio (" + U8(gDoc.path.substr(gDoc.path.find_last_of(L"\\\\/") + 1)) + ")\r\n";
        ini += "; regular game henchman behavior; beta mesh and animations (the beta skeleton is the same as the final henchmen:\r\n";
        ini += "; whatever the beta lacks keeps the final game animation)\r\n[Boss]\r\nName=" + std::string(gBE.id) + " (beta)\r\n";
        ini += "BodyMesh=" + bodyPath + "\r\nHeadMesh=" + headPath + "\r\n"; if (headPath.empty()) ini += "; the body mesh already has the head: hide the henchman one\r\nHideHead=1\r\n";
        ini += "Packages=" + bodyPath + "\r\nKeep=" + join(keep) + "\r\nUseMeshBoneLengths=1\r\n";
        ini += "BaseCharacter=RCharacter_Thug_NFRandom3,RCharacter_Thug_Random4,RCharacter_Thug_Random2,RCharacter_Thug_Random3\r\n";
        ini += "; AnimSets: replace the animations with the same name (walk, run, idle...)\r\nAnimSets=" + join(over) + "\r\n";
        ini += "; AnimSetsTail: only add new names (attacks and counters stay the game ones, with their hit events)\r\nAnimSetsTail=" + join(tail) + "\r\n";
        snprintf(num, sizeof num, "%g", gBE.health); ini += std::string("HealthMultiplier=") + num + "\r\n";
        snprintf(num, sizeof num, "%g", gBE.damage); ini += std::string("DamageMultiplier=") + num + "\r\n";
        snprintf(num, sizeof num, "%g", gBE.cooldown); ini += std::string("AttackCooldown=") + num + "\r\n";
        ini += "TestKey=0\r\nPreload=1\r\nOverworldOnly=1\r\nMute=" + std::string(gBE.mute ? "1" : "0") + "\r\n";
        if (!RimpIO().write(U8(iniFile), std::vector<u8>(ini.begin(), ini.end()))) throw bm::Err("could not write " + U8(iniFile));
        say(std::string(T(L_BT_WROTE)) + " " + U8(outFile)); say(std::string(T(L_BT_WROTE)) + " " + U8(iniFile));
        gBE.revivalLine = "PointN=x,y,z,-,-,-," + top;
    } catch (std::exception& ex) { say(std::string("ERROR: ") + ex.what()); }
    gBetaDb = BetaDB();
}
static void BetaEnemyWindow() {
    if (!gBE.open) return;
    if (!gDoc.loaded || !gDoc.pk.bigEndian) { gBE.open = false; return; }
    BetaEnemyScan();
    ImGui::SetNextWindowSize(ImVec2(760, 600), ImGuiCond_FirstUseEver);
    if (!ImGui::Begin(T(L_BE_TITLE), &gBE.open)) { ImGui::End(); return; }
    ImGui::TextWrapped("%s", T(L_BE_INTRO)); ImGui::Separator();
    auto meshName = [](int i) { return i < 0 ? std::string("-") : gDoc.pk.objPath(gBE.meshes[i]); };
    ImGui::SetNextItemWidth(420); if (ImGui::BeginCombo(T(L_BE_BODY), meshName(gBE.body).c_str())) { for (int i = 0; i < (int)gBE.meshes.size(); i++) if (ImGui::Selectable(meshName(i).c_str(), i == gBE.body)) { gBE.body = i; BetaEnemyAutoPick(); } ImGui::EndCombo(); }
    ImGui::SetNextItemWidth(420); if (ImGui::BeginCombo(T(L_BE_HEAD), gBE.head == 0 ? T(L_BE_NOHEAD) : meshName(gBE.head - 1).c_str())) { if (ImGui::Selectable(T(L_BE_NOHEAD), gBE.head == 0)) gBE.head = 0;
        for (int i = 0; i < (int)gBE.meshes.size(); i++) if (ImGui::Selectable(meshName(i).c_str(), gBE.head == i + 1)) gBE.head = i + 1; ImGui::EndCombo(); }
    ImGui::SetNextItemWidth(220); ImGui::InputText(T(L_BE_ID), gBE.id, sizeof gBE.id);
    ImGui::SetNextItemWidth(90); ImGui::DragFloat(T(L_BE_HEALTH), &gBE.health, 0.05f, 0.1f, 20.f, "%.2fx"); ImGui::SameLine(); ImGui::SetNextItemWidth(90); ImGui::DragFloat(T(L_BE_DAMAGE), &gBE.damage, 0.05f, 0.1f, 10.f, "%.2fx");
    ImGui::SameLine(); ImGui::SetNextItemWidth(90); ImGui::DragFloat(T(L_BE_COOLDOWN), &gBE.cooldown, 0.05f, 0.2f, 10.f, "%.1f s"); ImGui::SameLine(); ImGui::Checkbox(T(L_BE_MUTE), &gBE.mute);
    ImGui::Text("%s", T(L_BE_SETS));
    if (ImGui::BeginTable("besets", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_BordersInnerV, ImVec2(0, 200))) {
        ImGui::TableSetupColumn("AnimSet", ImGuiTableColumnFlags_WidthStretch); ImGui::TableSetupColumn("##m", ImGuiTableColumnFlags_WidthFixed, 260);
        for (size_t i = 0; i < gBE.sets.size(); i++) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(gDoc.pk.objPath(gBE.sets[i]).c_str()); ImGui::TableNextColumn();
            ImGui::PushID((int)i); ImGui::SetNextItemWidth(250); const char* modes[] = { T(L_BE_M0), T(L_BE_M1), T(L_BE_M2) }; ImGui::Combo("##md", &gBE.setMode[i], modes, 3); ImGui::PopID(); }
        ImGui::EndTable(); }
    ImGui::BeginDisabled(gBE.body < 0 || !gBE.id[0]);
    if (ImGui::Button(T(L_BE_RUN), ImVec2(260, 0))) BetaEnemyBuild();
    ImGui::EndDisabled();
    if (!gBE.revivalLine.empty()) { ImGui::TextWrapped("%s", T(L_BE_NEXT)); ImGui::InputText("##rl", (char*)gBE.revivalLine.c_str(), gBE.revivalLine.size() + 1, ImGuiInputTextFlags_ReadOnly); ImGui::SameLine(); if (ImGui::SmallButton(T(L_COPYPATH))) ImGui::SetClipboardText(gBE.revivalLine.c_str()); }
    ImGui::BeginChild("belog", ImVec2(0, 0), true); for (auto& l : gBE.log) ImGui::TextUnformatted(l.c_str()); ImGui::EndChild();
    ImGui::End();
}
static void BetaEnemyAutoTest() {   // test: BMS_AUTOENEMY="body|head or -|id"
    static bool done = false; if (done || !gDoc.loaded || !gDoc.pk.bigEndian) return; wchar_t b[1024];
    if (!GetEnvironmentVariableW(L"BMS_AUTOENEMY", b, 1024)) { done = true; return; } done = true;
    std::wstring all = b; if (GetEnvironmentVariableW(L"BMS_COOKED", b, 1024)) SetSetting(L"CookedDir", b);
    std::vector<std::string> parts; { std::string s = U8(all), cur; for (char c : s + "|") { if (c == '|') { parts.push_back(cur); cur.clear(); } else cur += c; } }
    if (parts.size() < 3) return; gBE.forPath.clear(); BetaEnemyScan();
    for (size_t i = 0; i < gBE.meshes.size(); i++) { std::string p = gDoc.pk.objPath(gBE.meshes[i]); if (p == parts[0]) gBE.body = (int)i; }
    BetaEnemyAutoPick(); if (parts[1] == "-") gBE.head = 0; else for (size_t i = 0; i < gBE.meshes.size(); i++) if (gDoc.pk.objPath(gBE.meshes[i]) == parts[1]) gBE.head = (int)i + 1;
    snprintf(gBE.id, sizeof gBE.id, "%s", parts[2].c_str()); BetaEnemyBuild();
    FILE* f = _wfopen((BetaGameCooked() + L"BmBosses\\autoenemy.log").c_str(), L"w"); if (f) { for (size_t i = 0; i < gBE.meshes.size(); i++) fprintf(f, "mesh %s\n", gDoc.pk.objPath(gBE.meshes[i]).c_str());
        for (size_t i = 0; i < gBE.sets.size(); i++) fprintf(f, "set %s mode %d\n", gDoc.pk.objPath(gBE.sets[i]).c_str(), gBE.setMode[i]); for (auto& l : gBE.log) fprintf(f, "%s\n", l.c_str()); fprintf(f, "%s\n", gBE.revivalLine.c_str()); fclose(f); }
}
// test: BMS_AUTOPREVALL=class1,class2 (+BMS_AUTOPREVALL_LOG=file) -> opens the preview of each object in turn and logs it (finds the object that crashes)
static void BetaPrevAllTest() {
    static int state = -1; static std::vector<std::string> objs; static size_t idx = 0; static int frames = 0; static std::wstring betaPath, logPath; wchar_t b[1024];
    auto L = [&](const std::string& s) { FILE* f = _wfopen(logPath.c_str(), L"a"); if (f) { fprintf(f, "%s\n", s.c_str()); fflush(f); fclose(f); } };
    if (state == -2) return;
    if (state == -1) { if (!gDoc.loaded || !gDoc.pk.bigEndian) return; if (!GetEnvironmentVariableW(L"BMS_AUTOPREVALL", b, 1024)) { state = -2; return; }
        std::string cls = "," + U8(b) + ","; if (GetEnvironmentVariableW(L"BMS_COOKED", b, 1024)) SetSetting(L"CookedDir", b);
        logPath = GetEnvironmentVariableW(L"BMS_AUTOPREVALL_LOG", b, 1024) ? std::wstring(b) : L"prevall.log"; betaPath = gDoc.path;
        size_t skip = GetEnvironmentVariableW(L"BMS_AUTOPREVALL_SKIP", b, 64) ? (size_t)_wtoi(b) : 0;
        for (size_t k = 0; k < gDoc.pk.exports.size(); k++) if (cls.find("," + gDoc.pk.classOf(gDoc.pk.exports[k]) + ",") != std::string::npos) objs.push_back(gDoc.pk.objPath((i32)k + 1));
        idx = skip; L("total " + std::to_string(objs.size())); state = 0; return; }
    if (state == 0) { if (idx >= objs.size()) { L("END"); state = -2; PostQuitMessage(0); return; }
        if (!gDoc.loaded || gDoc.path != betaPath) { DoOpen(betaPath); return; }
        L("[" + std::to_string(idx) + "] " + objs[idx]);
        try { BetaPreviewObject(gDoc.pk.findPath(objs[idx])); } catch (std::exception& e) { L(std::string("  EXCEPTION ") + e.what()); }
        L("  conv: " + gStatus); state = 1; frames = 0; return; }
    if (state == 1) { if (++frames < 8) return; L("  render ok"); idx++; state = 0; if (gDoc.loaded && gDoc.path != betaPath) DoOpen(betaPath); }
}
static void ReleaseHoldsOn(const std::wstring& path) {
    for (auto& l : gCtx.layers) if (l->doc && RimpSamePath(l->path, path)) { LvlCacheRelease(l->c); l->L = Level(); l->doc.reset(); l->loaded = false; }
    for (auto& l : gRi.layers) if (l->doc && RimpSamePath(l->path, path)) { LvlCacheRelease(l->c); l->L = Level(); l->doc.reset(); l->on = false; }
    if (gLib.doc && RimpSamePath(gLib.docPath, path)) { LvlCacheRelease(gLib.cache); gLib.cache = LvlCache(); gLib.meshOk = false; gLib.idx = 0; gLib.doc.reset(); gLib.docPath.clear(); }
    if (gCp.src && RimpSamePath(gCp.src->path, path)) gCp.src.reset();
}
