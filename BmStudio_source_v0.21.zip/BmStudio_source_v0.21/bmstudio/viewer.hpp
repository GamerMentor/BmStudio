// BmStudio - 3D viewer (SkeletalMesh / StaticMesh) and texture viewer + export (PSK/PSKX/OBJ/PNG/DDS)
// Included by app.cpp (uses gDoc, gDev, T(), Status(), SaveDialogEx()).
#pragma once
#include "../bmcpp/bmexport.hpp"
#include "../bmcpp/bmfbx.hpp"
#include "../bmcpp/bmteximp.hpp"
#include <cmath>
#include <memory>

extern "C" void* tdefl_write_image_to_png_file_in_memory(const void* pImage, int w, int h, int num_chans, size_t* pLen_out);

// ------------------------------------------------------------------ .tfc reading
static bool ReadFileRange(const std::string& path, uint64_t off, size_t n, std::vector<u8>& out) {
    HANDLE h = CreateFileW(W(path).c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); if (h == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER li; li.QuadPart = (LONGLONG)off; bool ok = SetFilePointerEx(h, li, NULL, FILE_BEGIN) != 0;
    out.resize(n); DWORD rd = 0; if (ok) ok = ReadFile(h, out.data(), (DWORD)n, &rd, NULL) && rd == n; CloseHandle(h); return ok;
}
static bool WriteBytes(const std::wstring& path, const void* d, size_t n) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL); if (h == INVALID_HANDLE_VALUE) return false;
    DWORD wr = 0; BOOL ok = WriteFile(h, d, (DWORD)n, &wr, NULL); CloseHandle(h); return ok && wr == n;
}

// ------------------------------------------------------------------ matrices (D3D, left-handed; UE: X forward, Y right, Z up)
struct Mat4 { float m[4][4]; };
static Mat4 MatMul(const Mat4& a, const Mat4& b) { Mat4 r; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) { r.m[i][j] = 0; for (int k = 0; k < 4; k++) r.m[i][j] += a.m[i][k] * b.m[k][j]; } return r; }
static Mat4 MatIdentity() { Mat4 r = {}; for (int i = 0; i < 4; i++) r.m[i][i] = 1; return r; }
static Mat4 LookAtLH(const float eye[3], const float at[3], const float up[3]) {
    float z[3] = { at[0] - eye[0], at[1] - eye[1], at[2] - eye[2] }; float l = sqrtf(z[0] * z[0] + z[1] * z[1] + z[2] * z[2]); for (auto& v : z) v /= l;
    float x[3] = { up[1] * z[2] - up[2] * z[1], up[2] * z[0] - up[0] * z[2], up[0] * z[1] - up[1] * z[0] }; l = sqrtf(x[0] * x[0] + x[1] * x[1] + x[2] * x[2]); for (auto& v : x) v /= l;
    float y[3] = { z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0] };
    Mat4 r = MatIdentity();
    for (int i = 0; i < 3; i++) { r.m[i][0] = x[i]; r.m[i][1] = y[i]; r.m[i][2] = z[i]; }
    r.m[3][0] = -(x[0] * eye[0] + x[1] * eye[1] + x[2] * eye[2]); r.m[3][1] = -(y[0] * eye[0] + y[1] * eye[1] + y[2] * eye[2]); r.m[3][2] = -(z[0] * eye[0] + z[1] * eye[1] + z[2] * eye[2]);
    return r;
}
static Mat4 PerspectiveLH(float fovy, float aspect, float zn, float zf) {
    Mat4 r = {}; float ys = 1.0f / tanf(fovy / 2), xs = ys / aspect;
    r.m[0][0] = xs; r.m[1][1] = ys; r.m[2][2] = zf / (zf - zn); r.m[2][3] = 1; r.m[3][2] = -zn * zf / (zf - zn); return r;
}
// quaternion (x,y,z,w) + position -> matrix (row = axis, as in D3D). UE bones: children relative to the parent.
static Mat4 QuatPosMatrix(const float q[4], const float p[3]) {
    float x = q[0], y = q[1], z = q[2], w = q[3]; Mat4 r = MatIdentity();
    r.m[0][0] = 1 - 2 * (y * y + z * z); r.m[0][1] = 2 * (x * y + w * z); r.m[0][2] = 2 * (x * z - w * y);
    r.m[1][0] = 2 * (x * y - w * z); r.m[1][1] = 1 - 2 * (x * x + z * z); r.m[1][2] = 2 * (y * z + w * x);
    r.m[2][0] = 2 * (x * z + w * y); r.m[2][1] = 2 * (y * z - w * x); r.m[2][2] = 1 - 2 * (x * x + y * y);
    r.m[3][0] = p[0]; r.m[3][1] = p[1]; r.m[3][2] = p[2]; return r;
}

// ------------------------------------------------------------------ preview state
struct GpuVert { float x, y, z, nx, ny, nz, u, v; };
#define GPUVERT_FVF (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1)
struct DrawSection { u32 first, tris, minV, maxV; IDirect3DTexture9* tex = nullptr; std::string material; int blend = 0; };
static void AnimImpBegin(i32 setIdx, int templateSeq);
struct Preview {
    int gen = -1; i32 idx = 0; int kind = 0;                       // 0 nothing, 1 texture, 2 skeletal, 3 static
    std::string error;
    // texture
    TextureInfo ti; int mip = -1; int shownW = 0, shownH = 0; IDirect3DTexture9* tex = nullptr; std::vector<u8> mipData; float zoom = 1.f;
    // meshes
    SkeletalMesh sk; StaticMesh st; int lod = 0;
    IDirect3DVertexBuffer9* vb = nullptr; IDirect3DIndexBuffer9* ib = nullptr; u32 numVerts = 0; std::vector<DrawSection> sections;
    std::vector<IDirect3DTexture9*> ownedTex; std::vector<float> boneLines;   // point pairs (x,y,z)
    float center[3] = { 0, 0, 0 }, radius = 100; float yaw = 0.8f, pitch = 0.3f, dist = 300; bool wire = false, bones = false, textured = true;
    IDirect3DTexture9* rt = nullptr; IDirect3DSurface9* rtDepth = nullptr; int rtW = 0, rtH = 0;
    // animation (kind 4): AnimSet or AnimSequence playing on a SkeletalMesh of the package
    i32 setIdx = 0; AnimSetData set; std::vector<AnimSeq> seqs; int seqSel = 0; float frame = 0; bool playing = true, loop = true; float speed = 1.f;
    struct MeshCand { i32 idx; int hits; bool ext; }; std::vector<MeshCand> meshCands; int meshSel = -1;
    std::shared_ptr<Package> extPk; std::shared_ptr<std::vector<u8>> extBytes; std::wstring extPath; std::vector<int> trackOf; std::vector<M4> invRef; std::vector<std::array<uint16_t, 4>> gbones;   // extPk = mesh from ANOTHER package (e.g. Batman in BmSkins)
    std::vector<GpuVert> baseVerts; bool animDirty = true, exportOne = false, exportFbx = false, follow = true, rotOnly = false;
};
static Preview gPrev;
// package/file the shown mesh comes from (the document one or the external package chosen for the AnimSet)
static const Package& MeshPk() { return (gPrev.kind == 4 && gPrev.meshSel >= 0 && gPrev.meshSel < (int)gPrev.meshCands.size() && gPrev.meshCands[gPrev.meshSel].ext && gPrev.extPk) ? *gPrev.extPk : gDoc.pk; }
static const std::wstring& MeshPkPath() { return (&MeshPk() == &gDoc.pk) ? gDoc.path : gPrev.extPath; }

static void ReleaseMeshGpu() {
    if (gPrev.vb) gPrev.vb->Release(); if (gPrev.ib) gPrev.ib->Release(); gPrev.vb = nullptr; gPrev.ib = nullptr;
    for (auto t : gPrev.ownedTex) if (t) t->Release(); gPrev.ownedTex.clear(); gPrev.sections.clear(); gPrev.boneLines.clear();
}
static void ReleaseRT() { if (gPrev.rt) gPrev.rt->Release(); if (gPrev.rtDepth) gPrev.rtDepth->Release(); gPrev.rt = nullptr; gPrev.rtDepth = nullptr; gPrev.rtW = gPrev.rtH = 0; }
static void PreviewClear() { ReleaseMeshGpu(); ReleaseRT(); if (gPrev.tex) gPrev.tex->Release(); gPrev = Preview(); }
static void PreviewOnDeviceLost() { ReleaseRT(); }              // RT and depth live in D3DPOOL_DEFAULT

static IDirect3DTexture9* MakeTexture(const std::vector<u8>& rgba, int w, int h) {
    IDirect3DTexture9* t = nullptr; if (FAILED(gDev->CreateTexture(w, h, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &t, NULL)) || !t) return nullptr;
    D3DLOCKED_RECT lr; if (SUCCEEDED(t->LockRect(0, &lr, NULL, 0))) { for (int y = 0; y < h; y++) { u8* d = (u8*)lr.pBits + y * lr.Pitch; const u8* s = &rgba[(size_t)y * w * 4];
            for (int x = 0; x < w; x++) { d[x * 4 + 0] = s[x * 4 + 2]; d[x * 4 + 1] = s[x * 4 + 1]; d[x * 4 + 2] = s[x * 4 + 0]; d[x * 4 + 3] = s[x * 4 + 3]; } } t->UnlockRect(0); }
    return t;
}
// loads mip 'want' (or the first available one from it on) -> RGBA
static bool LoadTextureRGBA(i32 idx, const TextureInfo& ti, int want, int& gotMip, std::vector<u8>& rgba, std::vector<u8>* raw = nullptr, const Package* pkp = nullptr, const std::wstring* pth = nullptr) {
    const Package& pk = pkp ? *pkp : gDoc.pk; std::string cooked = cookedDirOf(U8(pth ? *pth : gDoc.path)); std::vector<u8> data;
    for (int m = std::max(0, want); m < (int)ti.mips.size(); m++) {
        bool ok = false; try { ok = loadMip(pk, idx, ti, ti.mips[m], cooked, ReadFileRange, data); } catch (...) { ok = false; } if (!ok) continue;
        if (!decodeToRGBA(ti, ti.mips[m].w, ti.mips[m].h, data.data(), data.size(), rgba)) return false;
        gotMip = m; if (raw) raw->swap(data); return true;
    }
    return false;
}
static IDirect3DTexture9* MaterialTexture(i32 mat) {
    const Package& pk = MeshPk();
    i32 t = 0; try { t = findDiffuseTexture(pk, mat); } catch (...) { t = 0; } if (t <= 0 || pk.classOf(pk.exports[t - 1]) != "Texture2D") return nullptr;
    TextureInfo ti; try { ti = parseTexture(pk, t); } catch (...) { return nullptr; } if (ti.mips.empty()) return nullptr;
    int want = 0; while (want + 1 < (int)ti.mips.size() && std::max(ti.mips[want].w, ti.mips[want].h) > 1024) want++;
    int got = -1; std::vector<u8> rgba; if (!LoadTextureRGBA(t, ti, want, got, rgba, nullptr, &pk, &MeshPkPath())) return nullptr;
    IDirect3DTexture9* tx = MakeTexture(rgba, ti.mips[got].w, ti.mips[got].h); if (tx) gPrev.ownedTex.push_back(tx); return tx;
}
static void BuildMeshGpu() {
    ReleaseMeshGpu();
    std::vector<GpuVert> vs; std::vector<uint32_t> is; float mn[3] = { 1e30f, 1e30f, 1e30f }, mx[3] = { -1e30f, -1e30f, -1e30f };
    if (gPrev.kind == 2 || gPrev.kind == 4) {
        if (gPrev.sk.lods.empty()) return; const SkelLOD& l = gPrev.sk.lods[std::min<size_t>(gPrev.lod, gPrev.sk.lods.size() - 1)];
        for (auto& v : l.verts) vs.push_back({ v.pos[0], v.pos[1], v.pos[2], v.normal[0], v.normal[1], v.normal[2], v.uv[0], v.uv[1] }); is = l.indices;
        for (auto& s : l.sections) { DrawSection d; d.first = s.baseIndex; d.tris = s.numTris; d.minV = 0; d.maxV = (u32)l.verts.size() - 1;
            i32 m = (s.material < (int)gPrev.sk.materialRefs.size()) ? gPrev.sk.materialRefs[s.material] : 0; d.material = m ? MeshPk().objPath(m) : "None"; d.tex = MaterialTexture(m); gPrev.sections.push_back(d); }
        // bones (reference pose) in component space
        std::vector<Mat4> world(gPrev.sk.bones.size());
        for (size_t b = 0; b < gPrev.sk.bones.size(); b++) { const Bone& bn = gPrev.sk.bones[b]; Mat4 local = QuatPosMatrix(bn.q, bn.pos);
            world[b] = (b == 0 || bn.parent < 0 || bn.parent >= (int)b) ? local : MatMul(local, world[bn.parent]);
            if (b > 0 && bn.parent >= 0 && bn.parent < (int)b) { for (int k = 0; k < 3; k++) gPrev.boneLines.push_back(world[bn.parent].m[3][k]); for (int k = 0; k < 3; k++) gPrev.boneLines.push_back(world[b].m[3][k]); } }
    } else if (gPrev.kind == 3) {
        if (gPrev.st.lods.empty()) return; const StaticLOD& l = gPrev.st.lods[std::min<size_t>(gPrev.lod, gPrev.st.lods.size() - 1)];
        for (auto& v : l.verts) vs.push_back({ v.pos[0], v.pos[1], v.pos[2], v.normal[0], v.normal[1], v.normal[2], v.uv[0], v.uv[1] }); is = l.indices;
        for (auto& e : l.elements) { DrawSection d; d.first = e.firstIndex; d.tris = e.numTris; d.minV = e.minV; d.maxV = e.maxV; d.material = e.materialPath; d.tex = MaterialTexture(e.material); gPrev.sections.push_back(d); }
    }
    if (vs.empty() || is.empty()) return;
    for (auto& v : vs) { float p[3] = { v.x, v.y, v.z }; for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], p[k]); mx[k] = std::max(mx[k], p[k]); } }
    for (int k = 0; k < 3; k++) gPrev.center[k] = (mn[k] + mx[k]) * 0.5f;
    gPrev.radius = std::max(1.f, 0.5f * sqrtf((mx[0] - mn[0]) * (mx[0] - mn[0]) + (mx[1] - mn[1]) * (mx[1] - mn[1]) + (mx[2] - mn[2]) * (mx[2] - mn[2])));
    gPrev.dist = gPrev.radius * 2.6f; gPrev.numVerts = (u32)vs.size();
    if (FAILED(gDev->CreateVertexBuffer((UINT)(vs.size() * sizeof(GpuVert)), D3DUSAGE_WRITEONLY, GPUVERT_FVF, D3DPOOL_MANAGED, &gPrev.vb, NULL))) { gPrev.error = "CreateVertexBuffer failed"; return; }
    void* p = nullptr; gPrev.vb->Lock(0, 0, &p, 0); memcpy(p, vs.data(), vs.size() * sizeof(GpuVert)); gPrev.vb->Unlock();
    if (FAILED(gDev->CreateIndexBuffer((UINT)(is.size() * 4), D3DUSAGE_WRITEONLY, D3DFMT_INDEX32, D3DPOOL_MANAGED, &gPrev.ib, NULL))) { gPrev.error = "CreateIndexBuffer failed"; return; }
    gPrev.ib->Lock(0, 0, &p, 0); memcpy(p, is.data(), is.size() * 4); gPrev.ib->Unlock();
    gPrev.baseVerts = vs;
}
static void LoadPreviewTexture(int mip) {
    if (gPrev.tex) { gPrev.tex->Release(); gPrev.tex = nullptr; }
    std::vector<u8> rgba; int got = -1;
    if (!LoadTextureRGBA(gPrev.idx, gPrev.ti, mip, got, rgba, &gPrev.mipData)) { gPrev.error = "could not load/decode any mip (TFC missing or unsupported format " + gPrev.ti.format + ")"; return; }
    gPrev.mip = got; gPrev.shownW = gPrev.ti.mips[got].w; gPrev.shownH = gPrev.ti.mips[got].h; gPrev.tex = MakeTexture(rgba, gPrev.shownW, gPrev.shownH); gPrev.error.clear();
}
static void AnimLoad(i32 setIdx, i32 onlySeq);
static void ImportBegin(i32 mesh);
static void PreviewSelect(i32 idx) {
    if (idx == gPrev.idx && gPrev.gen == gDocGen) return;
    PreviewClear(); gPrev.idx = idx; gPrev.gen = gDocGen; if (idx <= 0) return;
    std::string cls = gDoc.pk.classOf(gDoc.pk.exports[idx - 1]);
    try {
    if (cls == "Texture2D") { gPrev.kind = 1; gPrev.ti = parseTexture(gDoc.pk, idx); if (!gPrev.ti.err.empty()) { gPrev.error = gPrev.ti.err; return; }
        int want = 0; while (want + 1 < (int)gPrev.ti.mips.size() && std::max(gPrev.ti.mips[want].w, gPrev.ti.mips[want].h) > 2048) want++; LoadPreviewTexture(want); }
    else if (cls == "SkeletalMesh") { gPrev.kind = 2; gPrev.sk = parseSkeletalMesh(gDoc.pk, idx); gPrev.error = gPrev.sk.err; if (gPrev.error.empty()) BuildMeshGpu(); }
    else if (cls == "AnimSet") AnimLoad(idx, 0);
    else if (cls == "AnimSequence") { i32 o = gDoc.pk.exports[idx - 1].outer; if (o > 0 && gDoc.pk.classOf(gDoc.pk.exports[o - 1]) == "AnimSet") AnimLoad(o, idx); else gPrev.error = "AnimSequence without AnimSet outer"; }
    else if (cls == "StaticMesh") { gPrev.kind = 3; gPrev.st = parseStaticMesh(gDoc.pk, idx); gPrev.error = gPrev.st.err; if (gPrev.error.empty()) BuildMeshGpu(); }
    } catch (std::exception& e) { gPrev.error = e.what(); } catch (...) { gPrev.error = "unexpected error"; }
}
static bool PreviewAvailable(i32 idx) { if (idx <= 0) return false; std::string c = gDoc.pk.classOf(gDoc.pk.exports[idx - 1]); return c == "Texture2D" || c == "SkeletalMesh" || c == "StaticMesh" || c == "AnimSet" || c == "AnimSequence"; }


// ------------------------------------------------------------------ animation
static void AnimPickMesh(int cand) {
    ReleaseMeshGpu(); gPrev.meshSel = cand; gPrev.sk = SkeletalMesh(); gPrev.trackOf.clear(); gPrev.invRef.clear(); gPrev.gbones.clear(); gPrev.animDirty = true;
    if (cand < 0 || cand >= (int)gPrev.meshCands.size()) return;
    gPrev.sk = parseSkeletalMesh(MeshPk(), gPrev.meshCands[cand].idx); if (!gPrev.sk.err.empty()) { gPrev.error = gPrev.sk.err; return; }
    mapTracks(gPrev.sk, gPrev.set, gPrev.trackOf);
    std::vector<M4> ref; poseBones(gPrev.sk, nullptr, gPrev.trackOf, 0, ref); for (auto& m : ref) gPrev.invRef.push_back(m4RigidInverse(m));
    { std::string shown = MeshPk().objPath(gPrev.meshCands[cand].idx), want = gPrev.set.previewMesh;
      auto grp = [](const std::string& x) { size_t d = x.find('.'); return d == std::string::npos ? x : x.substr(0, d); };
      gPrev.rotOnly = !want.empty() && want != "None" && shown != want && grp(shown) != grp(want); }
    gPrev.lod = 0; if (!gPrev.sk.lods.empty()) gPrev.gbones = globalVertexBones(gPrev.sk.lods[0]);
    BuildMeshGpu();
}
static void AnimLoad(i32 setIdx, i32 onlySeq) {
    gPrev.kind = 4; gPrev.setIdx = setIdx; gPrev.set = parseAnimSet(gDoc.pk, setIdx); if (!gPrev.set.err.empty()) { gPrev.error = gPrev.set.err; return; }
    for (i32 r : gPrev.set.seqRefs) { if (r <= 0 || (onlySeq && r != onlySeq)) continue; gPrev.seqs.push_back(parseAnimSequence(gDoc.pk, r, (int)gPrev.set.bones.size())); }
    // candidate meshes: SkeletalMeshes of the package, sorted by matched bones (PreviewSkelMeshName first)
    for (size_t k = 0; k < gDoc.pk.exports.size(); k++) { if (gDoc.pk.classOf(gDoc.pk.exports[k]) != "SkeletalMesh") continue;
        SkeletalMesh sm; try { sm = parseSkeletalMesh(gDoc.pk, (i32)k + 1); } catch (...) { continue; } if (!sm.err.empty()) continue;
        std::vector<int> t; int hits = mapTracks(sm, gPrev.set, t); if (hits < 2 && !gPrev.set.bones.empty()) continue;
        if (gDoc.pk.objPath((i32)k + 1) == gPrev.set.previewMesh) hits += 10000;   // + vertices breaks the tie (full body > head/torso)
        gPrev.meshCands.push_back({ (i32)k + 1, hits * 100000 + (int)std::min<size_t>(99999, sm.lods.empty() ? 0 : sm.lods[0].verts.size()) / 1, false }); }
    std::stable_sort(gPrev.meshCands.begin(), gPrev.meshCands.end(), [](auto& a, auto& b) { return a.hits > b.hits; });
    AnimPickMesh(gPrev.meshCands.empty() ? -1 : 0);
}
// "Mesh from another package...": the Batman/enemy animations live in packages that do not have the mesh (e.g. Batman_V2.Mesh.Batman_Skin_DS1
// is in BmSkins\Default\BatmanDamage0_SF.upk). Without the right mesh the viewer used another character's one -> distorted pose.
static void AnimLoadExternalMesh() {
    std::wstring f = FileDialog(false, L""); if (f.empty()) return;
    auto bytes = std::make_shared<std::vector<u8>>();
    HANDLE h = CreateFileW(f.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); if (h == INVALID_HANDLE_VALUE) { Status("cannot open " + U8(f)); return; }
    LARGE_INTEGER sz; GetFileSizeEx(h, &sz); bytes->resize((size_t)sz.QuadPart); DWORD rd = 0; ReadFile(h, bytes->data(), (DWORD)bytes->size(), &rd, NULL); CloseHandle(h);
    auto pk = std::make_shared<Package>(); try { pk->attach(bytes->data(), bytes->size()); } catch (std::exception& e) { Status(std::string("open failed: ") + e.what()); return; }
    // removes old external candidates
    int keepSel = gPrev.meshSel; std::vector<Preview::MeshCand> keep; for (int i = 0; i < (int)gPrev.meshCands.size(); i++) if (!gPrev.meshCands[i].ext) keep.push_back(gPrev.meshCands[i]); else if (i == keepSel) keepSel = -1;
    gPrev.meshCands = keep; gPrev.extPk = pk; gPrev.extBytes = bytes; gPrev.extPath = f;
    int first = -1, best = -1, bestHits = -1;
    for (size_t k = 0; k < pk->exports.size(); k++) { if (pk->classOf(pk->exports[k]) != "SkeletalMesh") continue;
        SkeletalMesh sm; try { sm = parseSkeletalMesh(*pk, (i32)k + 1); } catch (...) { continue; } if (!sm.err.empty()) continue;
        std::vector<int> t; int hits = mapTracks(sm, gPrev.set, t); if (hits < 2 && !gPrev.set.bones.empty()) continue;
        if (pk->objPath((i32)k + 1) == gPrev.set.previewMesh) hits += 10000;
        hits = hits * 100000 + (int)std::min<size_t>(99999, sm.lods.empty() ? 0 : sm.lods[0].verts.size());
        gPrev.meshCands.push_back({ (i32)k + 1, hits, true }); int i = (int)gPrev.meshCands.size() - 1; if (first < 0) first = i; if (hits > bestHits) { bestHits = hits; best = i; } }
    if (best < 0) { Status(U8(f) + ": no SkeletalMesh with matching bones"); return; }
    AnimPickMesh(best); Status("mesh: " + pk->objPath(gPrev.meshCands[best].idx));
}
static void AnimUpdate() {
    if (!gPrev.vb || gPrev.sk.lods.empty() || gPrev.baseVerts.empty()) return;
    const AnimSeq* seq = (gPrev.seqSel >= 0 && gPrev.seqSel < (int)gPrev.seqs.size() && gPrev.seqs[gPrev.seqSel].err.empty()) ? &gPrev.seqs[gPrev.seqSel] : nullptr;
    if (seq && gPrev.playing) { gPrev.frame += ImGui::GetIO().DeltaTime * seq->fps() * gPrev.speed; float last = (float)std::max(1, seq->numFrames - 1);
        if (gPrev.frame > last) gPrev.frame = gPrev.loop ? fmodf(gPrev.frame, last) : last; gPrev.animDirty = true; }
    if (!gPrev.animDirty) return; gPrev.animDirty = false;
    std::vector<M4> w, skin; poseBones(gPrev.sk, seq, gPrev.trackOf, gPrev.frame, w, gPrev.rotOnly); skin.resize(w.size()); for (size_t b = 0; b < w.size(); b++) skin[b] = m4Mul(gPrev.invRef[b], w[b]);
    std::vector<float> p, n; skinVertices(gPrev.sk.lods[0], gPrev.gbones, skin, p, n);
    if (gPrev.follow && !p.empty()) { float mn[3] = { 1e30f, 1e30f, 1e30f }, mx[3] = { -1e30f, -1e30f, -1e30f };
        for (size_t i = 0; i + 2 < p.size(); i += 3) for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], p[i + k]); mx[k] = std::max(mx[k], p[i + k]); }
        for (int k = 0; k < 3; k++) gPrev.center[k] = (mn[k] + mx[k]) * 0.5f; }
    GpuVert* dst = nullptr; if (FAILED(gPrev.vb->Lock(0, 0, (void**)&dst, 0)) || !dst) return;
    for (size_t v = 0; v < gPrev.baseVerts.size() && v * 3 + 2 < p.size(); v++) { GpuVert g = gPrev.baseVerts[v]; g.x = p[v * 3]; g.y = p[v * 3 + 1]; g.z = p[v * 3 + 2]; g.nx = n[v * 3]; g.ny = n[v * 3 + 1]; g.nz = n[v * 3 + 2]; dst[v] = g; }
    gPrev.vb->Unlock();
    gPrev.boneLines.clear();
    for (size_t b = 1; b < w.size(); b++) { int pa = gPrev.sk.bones[b].parent; if (pa < 0 || pa >= (int)b) continue; for (int k = 0; k < 3; k++) gPrev.boneLines.push_back(w[pa].m[3][k]); for (int k = 0; k < 3; k++) gPrev.boneLines.push_back(w[b].m[3][k]); }
}
static std::vector<u8> AnimExportPSA(bool onlySelected) {
    std::vector<AnimSeq> out; for (int i = 0; i < (int)gPrev.seqs.size(); i++) if (gPrev.seqs[i].err.empty() && (!onlySelected || i == gPrev.seqSel)) out.push_back(gPrev.seqs[i]);
    if (out.empty()) throw Err("no decodable sequences");
    return exportPSA(gDoc.pk, gPrev.set, out);
}

// ------------------------------------------------------------------ drawing the mesh into the render target
static void RenderMesh(int w, int h) {
    if (!gPrev.vb || w < 8 || h < 8) return;
    if (gPrev.rt && (gPrev.rtW != w || gPrev.rtH != h)) ReleaseRT();
    if (!gPrev.rt) {
        if (FAILED(gDev->CreateTexture(w, h, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &gPrev.rt, NULL))) return;
        if (FAILED(gDev->CreateDepthStencilSurface(w, h, D3DFMT_D24S8, D3DMULTISAMPLE_NONE, 0, TRUE, &gPrev.rtDepth, NULL))) gDev->CreateDepthStencilSurface(w, h, D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &gPrev.rtDepth, NULL);
        gPrev.rtW = w; gPrev.rtH = h;
    }
    IDirect3DSurface9 *oldRT = nullptr, *oldDS = nullptr, *surf = nullptr; gDev->GetRenderTarget(0, &oldRT); gDev->GetDepthStencilSurface(&oldDS);
    gPrev.rt->GetSurfaceLevel(0, &surf); gDev->SetRenderTarget(0, surf); gDev->SetDepthStencilSurface(gPrev.rtDepth);
    D3DVIEWPORT9 vp = { 0, 0, (DWORD)w, (DWORD)h, 0, 1 }; gDev->SetViewport(&vp);
    gDev->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(46, 48, 56, 255), 1.0f, 0);
    if (SUCCEEDED(gDev->BeginScene())) {
        float cp = cosf(gPrev.pitch), sp = sinf(gPrev.pitch), cy = cosf(gPrev.yaw), sy = sinf(gPrev.yaw);
        float eye[3] = { gPrev.center[0] + gPrev.dist * cp * cy, gPrev.center[1] + gPrev.dist * cp * sy, gPrev.center[2] + gPrev.dist * sp }; float up[3] = { 0, 0, 1 };
        Mat4 view = LookAtLH(eye, gPrev.center, up), proj = PerspectiveLH(0.9f, (float)w / h, std::max(0.5f, gPrev.dist - gPrev.radius * 3), gPrev.dist + gPrev.radius * 3);
        Mat4 world = MatIdentity();
        // UE (X forward, Y right, Z up) is left-handed like D3D: LookAtLH with up=Z already gives the right orientation, no mirroring
        gDev->SetTransform(D3DTS_WORLD, (D3DMATRIX*)&world); gDev->SetTransform(D3DTS_VIEW, (D3DMATRIX*)&view); gDev->SetTransform(D3DTS_PROJECTION, (D3DMATRIX*)&proj);
        gDev->SetRenderState(D3DRS_ZENABLE, TRUE); gDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE); gDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE); gDev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        gDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE); gDev->SetRenderState(D3DRS_FILLMODE, gPrev.wire ? D3DFILL_WIREFRAME : D3DFILL_SOLID);
        gDev->SetRenderState(D3DRS_LIGHTING, TRUE); gDev->SetRenderState(D3DRS_NORMALIZENORMALS, TRUE); gDev->SetRenderState(D3DRS_AMBIENT, D3DCOLOR_RGBA(70, 70, 76, 255));
        D3DLIGHT9 L = {}; L.Type = D3DLIGHT_DIRECTIONAL; L.Diffuse.r = L.Diffuse.g = L.Diffuse.b = 0.95f; L.Direction.x = -(eye[0] - gPrev.center[0]); L.Direction.y = -(eye[1] - gPrev.center[1]); L.Direction.z = -(eye[2] - gPrev.center[2]) - gPrev.dist * 0.4f;
        gDev->SetLight(0, &L); gDev->LightEnable(0, TRUE);
        D3DMATERIAL9 M = {}; M.Diffuse.r = M.Diffuse.g = M.Diffuse.b = M.Diffuse.a = 1; M.Ambient = M.Diffuse; gDev->SetMaterial(&M);
        gDev->SetFVF(GPUVERT_FVF); gDev->SetStreamSource(0, gPrev.vb, 0, sizeof(GpuVert)); gDev->SetIndices(gPrev.ib);
        gDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR); gDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR); gDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP); gDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
        gDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE); gDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE); gDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
        gDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG2);
        for (auto& s : gPrev.sections) {
            IDirect3DTexture9* t = (gPrev.textured && !gPrev.wire) ? s.tex : nullptr; gDev->SetTexture(0, t);
            gDev->SetTextureStageState(0, D3DTSS_COLOROP, t ? D3DTOP_MODULATE : D3DTOP_SELECTARG2);
            if (s.tris) gDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, gPrev.numVerts, s.first, s.tris);
        }
        gDev->SetTexture(0, nullptr); gDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
        if (gPrev.bones && !gPrev.boneLines.empty()) {
            gDev->SetRenderState(D3DRS_LIGHTING, FALSE); gDev->SetRenderState(D3DRS_ZENABLE, FALSE);
            struct LV { float x, y, z; DWORD c; }; std::vector<LV> lv; for (size_t k = 0; k + 2 < gPrev.boneLines.size(); k += 3) lv.push_back({ gPrev.boneLines[k], gPrev.boneLines[k + 1], gPrev.boneLines[k + 2], D3DCOLOR_RGBA(255, 210, 60, 255) });
            gDev->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE); gDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG2);
            if (!lv.empty()) gDev->DrawPrimitiveUP(D3DPT_LINELIST, (UINT)(lv.size() / 2), lv.data(), sizeof(LV));
        }
        gDev->SetRenderState(D3DRS_LIGHTING, FALSE);
        gDev->EndScene();
    }
    gDev->SetRenderTarget(0, oldRT); gDev->SetDepthStencilSurface(oldDS);
    if (surf) surf->Release(); if (oldRT) oldRT->Release(); if (oldDS) oldDS->Release();
}

// ------------------------------------------------------------------ export
static std::wstring SaveDialogEx(const std::wstring& name, const wchar_t* filter, const wchar_t* ext) {
    wchar_t file[MAX_PATH] = { 0 }; wcsncpy(file, name.c_str(), MAX_PATH - 1);
    OPENFILENAMEW of = {}; of.lStructSize = sizeof(of); of.hwndOwner = gHwnd; of.lpstrFilter = filter; of.lpstrFile = file; of.nMaxFile = MAX_PATH; of.lpstrDefExt = ext; of.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    return GetSaveFileNameW(&of) ? file : L"";
}
static std::vector<u8> ExportOBJ() {
    std::string o = "# BmStudio OBJ export\n"; char b[256]; std::vector<u32> firsts;
    auto addV = [&](float x, float y, float z, float nx, float ny, float nz, float u, float v) { snprintf(b, sizeof b, "v %.6f %.6f %.6f\nvn %.6f %.6f %.6f\nvt %.6f %.6f\n", x, z, -y, nx, nz, -ny, u, 1 - v); o += b; };
    std::vector<uint32_t> idx; std::vector<std::pair<std::string, std::pair<u32, u32>>> secs;
    if (gPrev.kind == 2) { const SkelLOD& l = gPrev.sk.lods[std::min<size_t>(gPrev.lod, gPrev.sk.lods.size() - 1)]; for (auto& v : l.verts) addV(v.pos[0], v.pos[1], v.pos[2], v.normal[0], v.normal[1], v.normal[2], v.uv[0], v.uv[1]); idx = l.indices;
        for (size_t s = 0; s < l.sections.size(); s++) secs.push_back({ gPrev.sections.size() > s ? gPrev.sections[s].material : "mat", { l.sections[s].baseIndex, l.sections[s].numTris } }); }
    else { const StaticLOD& l = gPrev.st.lods[std::min<size_t>(gPrev.lod, gPrev.st.lods.size() - 1)]; for (auto& v : l.verts) addV(v.pos[0], v.pos[1], v.pos[2], v.normal[0], v.normal[1], v.normal[2], v.uv[0], v.uv[1]); idx = l.indices;
        for (auto& e : l.elements) secs.push_back({ e.materialPath, { e.firstIndex, e.numTris } }); }
    for (auto& s : secs) { std::string m = s.first; size_t d = m.rfind('.'); if (d != std::string::npos) m = m.substr(d + 1); o += "usemtl " + m + "\n";
        for (u32 t = 0; t < s.second.second; t++) { u32 a = idx[s.second.first + t * 3] + 1, bb = idx[s.second.first + t * 3 + 1] + 1, c = idx[s.second.first + t * 3 + 2] + 1;
            snprintf(b, sizeof b, "f %u/%u/%u %u/%u/%u %u/%u/%u\n", a, a, a, c, c, c, bb, bb, bb); o += b; } }
    return std::vector<u8>(o.begin(), o.end());
}
// StaticMesh PSKX (no bones, 1 root bone like umodel)
static std::vector<u8> ExportStaticPSK() {
    SkeletalMesh fake; const StaticLOD& l = gPrev.st.lods[std::min<size_t>(gPrev.lod, gPrev.st.lods.size() - 1)];
    SkelLOD sl; for (auto& v : l.verts) { SkelVertex sv = {}; memcpy(sv.pos, v.pos, 12); memcpy(sv.normal, v.normal, 12); memcpy(sv.uv, v.uv, 8); sv.weights[0] = 255; sl.verts.push_back(sv); }
    sl.indices = l.indices; for (size_t k = 0; k < l.elements.size(); k++) { SkelSection s; s.material = (int)k; s.baseIndex = l.elements[k].firstIndex; s.numTris = l.elements[k].numTris; sl.sections.push_back(s); fake.materials.push_back(l.elements[k].materialPath); fake.materialRefs.push_back(l.elements[k].material); }
    SkelChunk ch; ch.baseVertex = 0; ch.numSoft = (i32)sl.verts.size(); ch.boneMap.push_back(0); sl.chunks.push_back(ch);
    Bone root; root.name = "Root"; root.parent = 0; fake.bones.push_back(root); fake.lods.push_back(sl);
    return exportPSK(fake, 0);
}

static bool EndsWithI(const std::wstring& f, const wchar_t* ext) { size_t n = wcslen(ext); return f.size() >= n && _wcsicmp(f.c_str() + f.size() - n, ext) == 0; }
static std::map<std::string, std::string> FbxTextures(const std::wstring& fbxPath, const std::vector<std::pair<std::string, i32>>& mats) {
    std::wstring dir = fbxPath.substr(0, fbxPath.find_last_of(L"\\/") + 1);
    auto wf = [&](const std::string& name, const std::vector<u8>& b) { return WriteBytes(dir + W(name), b.data(), b.size()); };
    return writeMaterialTextures(MeshPk(), mats, cookedDirOf(U8(MeshPkPath())), ReadFileRange, wf, 4096);
}
static std::vector<u8> ExportFBXCurrent(const std::wstring& f, bool withAnim) {
    std::vector<std::pair<std::string, i32>> mats; std::string name = (gPrev.kind == 4 && gPrev.meshSel >= 0) ? MeshPk().objName(gPrev.meshCands[gPrev.meshSel].idx) : gDoc.pk.objName(gPrev.idx);
    if (gPrev.kind == 3) { const StaticLOD& l = gPrev.st.lods[std::min<size_t>(gPrev.lod, gPrev.st.lods.size() - 1)]; for (auto& e : l.elements) mats.push_back({ e.materialPath, e.material });
        return exportFBXStatic(gPrev.st, gPrev.lod, name, FbxTextures(f, mats)); }
    for (size_t i = 0; i < gPrev.sk.materials.size(); i++) mats.push_back({ gPrev.sk.materials[i], i < gPrev.sk.materialRefs.size() ? gPrev.sk.materialRefs[i] : 0 });
    std::vector<fbx::AnimIn> an;
    if (withAnim && gPrev.kind == 4 && gPrev.seqSel >= 0 && gPrev.seqSel < (int)gPrev.seqs.size() && gPrev.seqs[gPrev.seqSel].err.empty()) {
        const AnimSeq& s = gPrev.seqs[gPrev.seqSel]; fbx::AnimIn a; a.name = s.name; a.numFrames = s.numFrames; a.fps = s.fps(); a.seq = &s; a.trackOf = gPrev.trackOf; an.push_back(a); }
    return exportFBXSkeletal(gPrev.sk, gPrev.kind == 4 ? 0 : gPrev.lod, name, an, FbxTextures(f, mats));
}
static void DoExportAsset() {
    std::wstring base = W(gDoc.pk.objName(gPrev.idx)); std::wstring f; std::vector<u8> out; std::string err;
    try {
        if (gPrev.kind == 2) { f = SaveDialogEx(base + L".psk", L"ActorX skeletal mesh (*.psk)\0*.psk\0FBX binary + textures (*.fbx)\0*.fbx\0Wavefront OBJ (*.obj)\0*.obj\0\0", L"psk"); if (f.empty()) return;
            if (EndsWithI(f, L".obj")) out = ExportOBJ(); else if (EndsWithI(f, L".fbx")) out = ExportFBXCurrent(f, false); else out = exportPSK(gPrev.sk, gPrev.lod); }
        else if (gPrev.kind == 3) { f = SaveDialogEx(base + L".pskx", L"ActorX static mesh (*.pskx)\0*.pskx\0FBX binary + textures (*.fbx)\0*.fbx\0Wavefront OBJ (*.obj)\0*.obj\0\0", L"pskx"); if (f.empty()) return;
            if (EndsWithI(f, L".obj")) out = ExportOBJ(); else if (EndsWithI(f, L".fbx")) out = ExportFBXCurrent(f, false); else out = ExportStaticPSK(); }
        else if (gPrev.kind == 4 && gPrev.exportFbx) { if (gPrev.meshSel < 0 || !gPrev.vb) throw Err("no preview mesh");
            std::wstring nm = gPrev.seqSel < (int)gPrev.seqs.size() ? W(gPrev.seqs[gPrev.seqSel].name) : W(gDoc.pk.objName(gPrev.setIdx));
            f = SaveDialogEx(nm + L".fbx", L"FBX binary: mesh + animation + textures (*.fbx)\0*.fbx\0\0", L"fbx"); if (f.empty()) return; out = ExportFBXCurrent(f, true); }
        else if (gPrev.kind == 4) { std::wstring nm = gPrev.exportOne && gPrev.seqSel < (int)gPrev.seqs.size() ? W(gPrev.seqs[gPrev.seqSel].name) : W(gDoc.pk.objName(gPrev.setIdx));
            f = SaveDialogEx(nm + L".psa", L"ActorX animation (*.psa)\0*.psa\0\0", L"psa"); if (f.empty()) return; out = AnimExportPSA(gPrev.exportOne); }
        else if (gPrev.kind == 1) { f = SaveDialogEx(base + L".png", L"PNG image (*.png)\0*.png\0DirectDraw Surface (*.dds)\0*.dds\0\0", L"png"); if (f.empty()) return;
            if (f.size() > 4 && _wcsicmp(f.c_str() + f.size() - 4, L".dds") == 0) out = makeDDS(gPrev.ti, gPrev.shownW, gPrev.shownH, gPrev.mipData);
            else { std::vector<u8> rgba; if (!decodeToRGBA(gPrev.ti, gPrev.shownW, gPrev.shownH, gPrev.mipData.data(), gPrev.mipData.size(), rgba)) throw Err("decode failed");
                size_t len = 0; void* png = tdefl_write_image_to_png_file_in_memory(rgba.data(), gPrev.shownW, gPrev.shownH, 4, &len); if (!png) throw Err("PNG encode failed"); out.assign((u8*)png, (u8*)png + len); free(png); } }
    } catch (std::exception& e) { err = e.what(); }
    if (!err.empty()) { Status(err); return; }
    Status(WriteBytes(f, out.data(), out.size()) ? U8(f) : std::string("write failed: ") + U8(f));
}

// ------------------------------------------------------------------ importing an image into a Texture2D
static int gTexFmtSel = 0;   // 0 = keep the texture format
static void DoImportTexture() {
    wchar_t file[MAX_PATH] = { 0 };
    OPENFILENAMEW of = {}; of.lStructSize = sizeof(of); of.hwndOwner = gHwnd; of.lpstrFile = file; of.nMaxFile = MAX_PATH;
    of.lpstrFilter = L"Images (*.png;*.tga;*.bmp;*.jpg;*.dds)\0*.png;*.tga;*.bmp;*.jpg;*.jpeg;*.dds\0All files\0*.*\0\0"; of.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (!GetOpenFileNameW(&of)) return;
    HANDLE h = CreateFileW(file, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); if (h == INVALID_HANDLE_VALUE) { Status("cannot open " + U8(file)); return; }
    LARGE_INTEGER sz; GetFileSizeEx(h, &sz); std::vector<u8> data((size_t)sz.QuadPart); DWORD rd = 0; ReadFile(h, data.data(), (DWORD)data.size(), &rd, NULL); CloseHandle(h);
    static const char* fmts[] = { "", "PF_DXT1", "PF_DXT5", "PF_A8R8G8B8", "PF_G8" };
    i32 idx = gPrev.idx; TexImportReport r = importTexture2D(gDoc.pk, idx, data, fmts[gTexFmtSel]);
    if (!r.ok) { Status(std::string(T(L_TEX_FAIL)) + ": " + r.err); return; }
    Export& e = gDoc.pk.exports[idx - 1]; std::vector<u8> old = e.data; bool wasOwned = e.owned;
    e.data = r.newData; e.owned = true;
    TextureInfo chk = parseTexture(gDoc.pk, idx);
    if (!chk.err.empty() || chk.mips.empty()) { e.data = old; e.owned = wasOwned; Status("import check failed: " + chk.err); return; }
    gDoc.dirty = true; std::string msg = std::string(T(L_TEX_DONE)) + " " + std::to_string(r.w) + "x" + std::to_string(r.h) + " " + r.format + ", " + std::to_string(r.mips) + " mips";
    for (auto& n : r.notes) msg += " | " + n; Status(msg);
    gPrev.idx = 0;   // reloads the preview
}

// ------------------------------------------------------------------ "Preview" tab
static void PreviewMouse() {
    if (!ImGui::IsItemHovered()) return;
    ImGuiIO& io = ImGui::GetIO();
    if (ImGui::IsMouseDragging(ImGuiMouseButton_Left)) { gPrev.yaw -= io.MouseDelta.x * 0.01f; gPrev.pitch = std::max(-1.5f, std::min(1.5f, gPrev.pitch + io.MouseDelta.y * 0.01f)); }
    if (ImGui::IsMouseDragging(ImGuiMouseButton_Right)) { gPrev.center[2] += io.MouseDelta.y * gPrev.dist * 0.002f; }
    if (io.MouseWheel != 0) gPrev.dist = std::max(gPrev.radius * 0.2f, gPrev.dist * (io.MouseWheel > 0 ? 0.88f : 1.14f));
}
static void PreviewTab() {
    PreviewSelect(gSel);
    if (!gPrev.error.empty()) ImGui::TextColored(ImVec4(1, .45f, .45f, 1), "%s", gPrev.error.c_str());
    if (gPrev.kind == 1) {
        const TextureInfo& ti = gPrev.ti;
        ImGui::Text("%s  %dx%d  mips %zu%s%s", ti.format.c_str(), ti.sizeX, ti.sizeY, ti.mips.size(), ti.tfc.empty() ? "" : "  TFC: ", ti.tfc.c_str());
        if (!ti.mips.empty()) { ImGui::SetNextItemWidth(160); int m = gPrev.mip; if (ImGui::SliderInt("mip", &m, 0, (int)ti.mips.size() - 1)) LoadPreviewTexture(m);
            ImGui::SameLine(); ImGui::Text("%dx%d", gPrev.shownW, gPrev.shownH); ImGui::SameLine(); ImGui::SetNextItemWidth(140); ImGui::SliderFloat("zoom", &gPrev.zoom, 0.1f, 4.f, "%.2fx");
            ImGui::SameLine(); if (ImGui::Button(T(L_EXPORT_ASSET))) DoExportAsset(); }
        { ImGui::SameLine(); if (ImGui::Button(T(L_TEX_IMPORT))) DoImportTexture();
          ImGui::SameLine(); ImGui::SetNextItemWidth(150); const char* items[] = { T(L_TEX_KEEPFMT), "DXT1", "DXT5 (alpha)", "A8R8G8B8", "G8" }; ImGui::Combo("##texfmt", &gTexFmtSel, items, 5);
          if (gPrev.idx > 0 && gDoc.pk.exports[gPrev.idx - 1].owned) { ImGui::SameLine(); if (ImGui::Button(T(L_RESTORE_ORIG))) { Export& e = gDoc.pk.exports[gPrev.idx - 1]; e.owned = false; e.data.clear(); gDoc.dirty = true; gPrev.idx = 0; } } }
        if (gPrev.tex) { ImGui::BeginChild("texview", ImVec2(0, 0), ImGuiChildFlags_Borders, ImGuiWindowFlags_HorizontalScrollbar);
            ImGui::Image((ImTextureID)(intptr_t)gPrev.tex, ImVec2(gPrev.shownW * gPrev.zoom, gPrev.shownH * gPrev.zoom)); ImGui::EndChild(); }
        return;
    }
    if (gPrev.kind == 4) {
        ImGui::Text("AnimSet: %s  |  %zu %s  |  %zu seq", gDoc.pk.objPath(gPrev.setIdx).c_str(), gPrev.set.bones.size(), T(L_BONES), gPrev.seqs.size());
        if (ImGui::Button(T(L_EXPORT_PSA_ALL))) DoExportAsset(); ImGui::SameLine();
        if (ImGui::Button(T(L_EXPORT_PSA_ONE))) { gPrev.exportOne = true; DoExportAsset(); gPrev.exportOne = false; }
        ImGui::SameLine(); if (ImGui::Button(T(L_EXPORT_FBX_ANIM))) { gPrev.exportFbx = true; DoExportAsset(); gPrev.exportFbx = false; }
        ImGui::SameLine(); if (ImGui::Button(T(L_AI_BUTTON))) AnimImpBegin(gPrev.setIdx, gPrev.seqSel);
        ImGui::SetNextItemWidth(260);
        auto candName = [](int i) { const Preview::MeshCand& c = gPrev.meshCands[i]; return c.ext && gPrev.extPk ? gPrev.extPk->objPath(c.idx) + "  [" + U8(gPrev.extPath.substr(gPrev.extPath.find_last_of(L"\\/") + 1)) + "]" : gDoc.pk.objPath(c.idx); };
        std::string curMeshS = (gPrev.meshSel >= 0 && gPrev.meshSel < (int)gPrev.meshCands.size()) ? candName(gPrev.meshSel) : std::string(T(L_NOMESH));
        if (ImGui::BeginCombo("##mesh", curMeshS.c_str())) { for (int i = 0; i < (int)gPrev.meshCands.size(); i++) { std::string n = candName(i); if (ImGui::Selectable((n + "##m" + std::to_string(i)).c_str(), i == gPrev.meshSel)) AnimPickMesh(i); } ImGui::EndCombo(); }
        ImGui::SameLine(); if (ImGui::Button(T(L_ANIM_EXTMESH))) AnimLoadExternalMesh();
        {   // warning: the shown mesh is not the AnimSet one -> proportions may not match
            std::string shown = (gPrev.meshSel >= 0 && gPrev.meshSel < (int)gPrev.meshCands.size()) ? MeshPk().objPath(gPrev.meshCands[gPrev.meshSel].idx) : "";
            std::string want = gPrev.set.previewMesh; size_t d1 = want.rfind('.'), d2 = shown.rfind('.');
            std::string grpW = d1 == std::string::npos ? want : want.substr(0, want.find('.')), grpS = d2 == std::string::npos ? shown : shown.substr(0, shown.find('.'));
            if (ImGui::Checkbox(T(L_ANIM_ROTONLY), &gPrev.rotOnly)) gPrev.animDirty = true;
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_ANIM_ROTONLY_TIP));
            if (!want.empty() && want != "None" && shown != want && grpW != grpS) { ImGui::SameLine();
                ImGui::TextColored(ImVec4(1, .75f, .3f, 1), T(L_ANIM_MESHWARN), want.c_str()); }
        }
        ImVec2 avail = ImGui::GetContentRegionAvail();
        ImGui::BeginChild("seqlist", ImVec2(std::min(300.f, avail.x * 0.35f), 0), ImGuiChildFlags_Borders);
        for (int i = 0; i < (int)gPrev.seqs.size(); i++) { const AnimSeq& s = gPrev.seqs[i]; char lbl[300]; snprintf(lbl, sizeof lbl, "%s##s%d", s.name.c_str(), i);
            if (!s.err.empty()) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, .45f, .45f, 1));
            if (ImGui::Selectable(lbl, i == gPrev.seqSel)) { gPrev.seqSel = i; gPrev.frame = 0; gPrev.animDirty = true; }
            if (!s.err.empty()) { ImGui::PopStyleColor(); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", s.err.c_str()); }
            else if (ImGui::IsItemHovered()) ImGui::SetTooltip("%d frames, %.2fs, %.1f fps\n%s / %s", s.numFrames, s.length, s.fps(), s.keyFmt.c_str(), s.rotFmt.c_str()); }
        ImGui::EndChild(); ImGui::SameLine();
        ImGui::BeginChild("animview", ImVec2(0, 0));
        const AnimSeq* seq = (gPrev.seqSel >= 0 && gPrev.seqSel < (int)gPrev.seqs.size()) ? &gPrev.seqs[gPrev.seqSel] : nullptr;
        if (ImGui::Button(gPrev.playing ? "||" : ">", ImVec2(32, 0))) gPrev.playing = !gPrev.playing; ImGui::SameLine();
        if (seq) { ImGui::SetNextItemWidth(std::max(80.f, ImGui::GetContentRegionAvail().x - 420)); float last = (float)std::max(1, seq->numFrames - 1);
            if (ImGui::SliderFloat("##frame", &gPrev.frame, 0, last, "frame %.1f")) { gPrev.animDirty = true; gPrev.playing = false; } ImGui::SameLine(); }
        ImGui::Checkbox("Loop", &gPrev.loop); ImGui::SameLine(); ImGui::Checkbox(T(L_FOLLOW), &gPrev.follow); ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::SliderFloat("##spd", &gPrev.speed, 0.1f, 2.f, "%.1fx"); ImGui::SameLine();
        ImGui::Checkbox(T(L_WIRE), &gPrev.wire); ImGui::SameLine(); ImGui::Checkbox(T(L_TEXTURED), &gPrev.textured); ImGui::SameLine(); ImGui::Checkbox(T(L_SHOWBONES), &gPrev.bones);
        AnimUpdate();
        ImVec2 av = ImGui::GetContentRegionAvail(); int w = (int)std::max(16.f, av.x), h = (int)std::max(16.f, av.y);
        if (gPrev.vb) { RenderMesh(w, h); if (gPrev.rt) { ImGui::Image((ImTextureID)(intptr_t)gPrev.rt, ImVec2((float)w, (float)h)); PreviewMouse(); } }
        else ImGui::TextDisabled("%s", T(L_NOMESH));
        ImGui::EndChild();
        return;
    }
    if (gPrev.kind == 2 || gPrev.kind == 3) {
        size_t nl = gPrev.kind == 2 ? gPrev.sk.lods.size() : gPrev.st.lods.size();
        if (gPrev.kind == 2) ImGui::Text("%s %zu  |  %s %zu  |  LODs %zu", T(L_BONES), gPrev.sk.bones.size(), T(L_VERTS), gPrev.sk.lods.empty() ? (size_t)0 : gPrev.sk.lods[std::min<size_t>(gPrev.lod, nl - 1)].verts.size(), nl);
        else ImGui::Text("%s %zu  |  LODs %zu", T(L_VERTS), gPrev.st.lods.empty() ? (size_t)0 : gPrev.st.lods[std::min<size_t>(gPrev.lod, nl - 1)].verts.size(), nl);
        if (nl > 1) { ImGui::SameLine(); ImGui::SetNextItemWidth(90); if (ImGui::SliderInt("LOD", &gPrev.lod, 0, (int)nl - 1)) BuildMeshGpu(); }
        ImGui::Checkbox(T(L_WIRE), &gPrev.wire); ImGui::SameLine(); ImGui::Checkbox(T(L_TEXTURED), &gPrev.textured);
        if (gPrev.kind == 2) { ImGui::SameLine(); ImGui::Checkbox(T(L_SHOWBONES), &gPrev.bones); }
        ImGui::SameLine(); if (ImGui::Button(T(L_EXPORT_ASSET))) DoExportAsset();
        if (gPrev.kind == 2) { ImGui::SameLine(); if (ImGui::Button(T(L_IMP_BUTTON))) ImportBegin(gPrev.idx);
            if (gDoc.pk.exports[gPrev.idx - 1].owned) { ImGui::SameLine(); if (ImGui::Button(T(L_IMP_RESTORE))) { Export& e = gDoc.pk.exports[gPrev.idx - 1]; e.owned = false; e.data.clear(); gDoc.dirty = true; gPrev.idx = 0; } } }
        if (ImGui::TreeNode(T(L_MATERIALS))) { for (auto& s : gPrev.sections) { ImGui::BulletText("%s", s.material.c_str()); if (!s.tex) { ImGui::SameLine(); ImGui::TextDisabled("(%s)", T(L_NOTEX)); } } ImGui::TreePop(); }
        ImVec2 avail = ImGui::GetContentRegionAvail(); int w = (int)std::max(16.f, avail.x), h = (int)std::max(16.f, avail.y);
        RenderMesh(w, h);
        if (gPrev.rt) {
            ImGui::Image((ImTextureID)(intptr_t)gPrev.rt, ImVec2((float)w, (float)h)); PreviewMouse();
        }
        return;
    }
    ImGui::TextDisabled("%s", T(L_NOPREVIEW));
}
