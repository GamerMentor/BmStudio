// propedit.hpp - generic property editor (UPK Explorer style): nested structs, arrays of any type
// (with + / x), adding/removing class properties, cooked particle distributions (LookupTable) and the
// object references stored in native data (e.g. textures compiled into a Material).
// Types come from the TypeDB (Core/Engine/BmGame + open package): the same one the copier uses to walk the data.
#pragma once
#include <functional>

using bm::cp::PType; using bm::cp::TypeDB;

static std::map<ImGuiID, std::string> gPeText;    // text being edited (object path, name...) per widget
static const TypeDB* gPeDb = nullptr;
static bool PeOpenAll() { static int v = -1; if (v < 0) { wchar_t b[8]; v = GetEnvironmentVariableW(L"BMS_PEOPEN", b, 8) ? 1 : 0; } if (v) ImGui::SetNextItemOpen(true, ImGuiCond_Once); return true; }   // test: open trees

static i32 PeNoneName() { return gDoc.pk.addName("None"); }
// "empty" value of a type (for new elements and new properties)
static std::vector<u8> PeZero(const PType& t, int depth = 0) {
    std::vector<u8> b; auto i32w = [&](i32 v) { u8 x[4]; memcpy(x, &v, 4); b.insert(b.end(), x, x + 4); };
    switch (t.k) {
    case bm::cp::K_Int: case bm::cp::K_Float: case bm::cp::K_Obj: case bm::cp::K_Str: case bm::cp::K_Array: i32w(0); break;
    case bm::cp::K_Bool: case bm::cp::K_Byte: b.push_back(0); break;
    case bm::cp::K_Enum: case bm::cp::K_Name: i32w(PeNoneName()); i32w(0); break;
    case bm::cp::K_Delegate: i32w(0); i32w(PeNoneName()); i32w(0); break;
    case bm::cp::K_Struct:
        if (bm::Package::strcasecmp_(t.strct, "Guid")) { b.assign(16, 0); break; }
        if (gPeDb && gPeDb->immutable(t.strct) && depth < 8) { std::vector<const bm::cp::PField*> fl; gPeDb->binFields(t.strct, fl);
            for (auto* f : fl) { if (f->flags & (bm::cp::CPF_Native | bm::cp::CPF_Transient | bm::cp::CPF_Deprecated)) continue; for (int k = 0; k < f->dim; k++) { auto z = PeZero(f->t, depth + 1); b.insert(b.end(), z.begin(), z.end()); } } }
        else { i32w(PeNoneName()); i32w(0); }   // tagged struct: only the final "None"
        break;
    default: break;
    }
    return b;
}
// size of an item starting at 'p' (uses the copier's Walker)
static bool PeMeasure(const std::vector<u8>& b, size_t p, const PType& t, size_t& len) {
    if (!gPeDb) return false; bm::cp::Refs r; bm::cp::Walker w(gDoc.pk, *gPeDb, b.data(), b.size(), r); size_t q = p;
    try { w.item(q, t, "item"); } catch (...) { return false; } len = q - p; return true;
}
static std::string PeTypeName(const PType& t) {
    switch (t.k) { case bm::cp::K_Struct: return t.strct; case bm::cp::K_Array: return "array<" + (t.inner ? PeTypeName(*t.inner) : std::string("?")) + ">";
    default: { std::string s = t.pcls; if (s.size() > 8 && s.compare(s.size() - 8, 8, "Property") == 0) s.resize(s.size() - 8); return s; } } }

// ---- leaves
static bool PeObjRef(u8* p) {
    i32 v; memcpy(&v, p, 4); ImGuiID id = ImGui::GetID("##obj"); auto it = gPeText.find(id); bool editing = it != gPeText.end();
    std::string cur = editing ? it->second : ObjStr(v); char buf[512]; snprintf(buf, sizeof buf, "%s", cur.c_str());
    float bw = ImGui::GetFrameHeight() * 1.6f; ImGui::SetNextItemWidth(std::max(80.f, ImGui::GetContentRegionAvail().x - bw - 4)); bool ch = false;
    if (ImGui::InputText("##obj", buf, sizeof buf)) gPeText[id] = buf;
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_OBJHINT));
    if (ImGui::IsItemDeactivated()) { auto f = gPeText.find(id); if (f != gPeText.end()) { std::string s = f->second; gPeText.erase(f);
            i32 nv = (s == "None" || s.empty()) ? 0 : gDoc.pk.findPath(s); if (nv != 0 || s == "None" || s.empty()) { memcpy(p, &nv, 4); ch = nv != v; } else Status(std::string(T(L_NOTFOUND)) + ": " + s); } }
    ImGui::SameLine(); if (ImGui::Button("->", ImVec2(bw, 0)) && v > 0) GotoObject(v);
    return ch;
}
static bool PeNameRef(u8* p) {
    ImGuiID id = ImGui::GetID("##nm"); auto it = gPeText.find(id); std::string cur = it != gPeText.end() ? it->second : FNameStr(p);
    char buf[256]; snprintf(buf, sizeof buf, "%s", cur.c_str()); ImGui::SetNextItemWidth(-FLT_MIN); bool ch = false;
    if (ImGui::InputText("##nm", buf, sizeof buf)) gPeText[id] = buf;
    if (ImGui::IsItemDeactivated()) { auto f = gPeText.find(id); if (f != gPeText.end()) { FName n = ParseFName(f->second); gPeText.erase(f); i32 a, b2; memcpy(&a, p, 4); memcpy(&b2, p + 4, 4);
            if (a != n.idx || b2 != n.num) { memcpy(p, &n.idx, 4); memcpy(p + 4, &n.num, 4); ch = true; } } }
    return ch;
}
static bool PeStr(std::vector<u8>& b) {
    ImGuiID id = ImGui::GetID("##str"); auto it = gPeText.find(id); std::string cur;
    if (it != gPeText.end()) cur = it->second; else { try { bm::Reader r(b.data(), b.size()); cur = r.fstr(); } catch (...) {} }
    char buf[2048]; snprintf(buf, sizeof buf, "%s", cur.c_str()); ImGui::SetNextItemWidth(-FLT_MIN); bool ch = false;
    if (ImGui::InputText("##str", buf, sizeof buf)) gPeText[id] = buf;
    if (ImGui::IsItemDeactivated()) { auto f = gPeText.find(id); if (f != gPeText.end()) { bm::Writer w; w.fstr(f->second); gPeText.erase(f); if (w.b != b) { b = w.b; ch = true; } } }
    return ch;
}

static bool PeBuf(std::vector<u8>& b, const PType& t, int depth);
static bool PeTags(std::vector<Tag>& tags, bool isStruct, const std::string& scope, int depth);

// cooked distribution (RawDistributionFloat/Vector): LookupTable = [min, max, element0, element1...], each element
// with ChunkSize floats (1 = float, 2 = float min/max, 3 = vector, 6 = vector min/max). Editing here changes the value the
// game uses (the Distribution objects were stripped when cooking).
static bool PeRawDist(std::vector<Tag>& sub, bool vec) {
    Tag* lt = nullptr; int chunk = vec ? 3 : 1; float ts = 0, st = 0;
    for (auto& t : sub) { if (t.name == "LookupTable" && t.type == "ArrayProperty") lt = &t; else if (t.name == "LookupTableChunkSize" && t.raw.size() == 1) chunk = t.raw[0];
        else if (t.name == "LookupTableTimeScale" && t.raw.size() == 4) memcpy(&ts, t.raw.data(), 4); else if (t.name == "LookupTableStartTime" && t.raw.size() == 4) memcpy(&st, t.raw.data(), 4); }
    if (!lt || lt->raw.size() < 4) { ImGui::TextDisabled("%s", T(L_PE_NODIST)); return false; }
    i32 n; memcpy(&n, lt->raw.data(), 4); if (n < 2 || chunk <= 0 || (n - 2) % chunk || lt->raw.size() != 4 + (size_t)n * 4) { ImGui::TextDisabled("LookupTable [%d]", n); return false; }
    std::vector<float> v(n); memcpy(v.data(), lt->raw.data() + 4, (size_t)n * 4); int ne = (n - 2) / chunk; bool ch = false;
    bool same = true; for (int e = 1; e < ne && same; e++) for (int c = 0; c < chunk; c++) if (v[2 + e * chunk + c] != v[2 + c]) { same = false; break; }
    static const char* lbl[6] = { "min X", "min Y", "min Z", "max X", "max Y", "max Z" };
    auto label = [&](int c) -> const char* { if (chunk == 1) return "value"; if (chunk == 2) return c ? "max" : "min"; if (chunk == 3) return c == 0 ? "X" : c == 1 ? "Y" : "Z"; return c < 6 ? lbl[c] : "?"; };
    if (same) { ImGui::TextDisabled("%s", chunk == 2 || chunk == 6 ? T(L_PE_UNIFORM) : T(L_PE_CONST));
        for (int c = 0; c < chunk; c++) { float x = v[2 + c]; ImGui::PushID(c); ImGui::SetNextItemWidth(110); if (ImGui::DragFloat(label(c), &x, std::max(0.01f, fabsf(x) * 0.01f), 0, 0, "%.4g")) { for (int e = 0; e < ne; e++) v[2 + e * chunk + c] = x; ch = true; } if (c + 1 < chunk && (c % 3) != 2) ImGui::SameLine(); ImGui::PopID(); } }
    else if (PeOpenAll() && ImGui::TreeNode("##crv", "%s (%d)", T(L_PE_CURVE), ne)) {
        for (int e = 0; e < ne; e++) { ImGui::PushID(e); float tm = ts != 0 ? st + e / ts : (float)e; ImGui::TextDisabled("t=%.3f", tm);
            for (int c = 0; c < chunk; c++) { ImGui::SameLine(); ImGui::PushID(c); ImGui::SetNextItemWidth(70); if (ImGui::DragFloat("##cv", &v[2 + e * chunk + c], std::max(0.01f, fabsf(v[2 + e * chunk + c]) * 0.01f), 0, 0, "%.4g")) ch = true; ImGui::PopID(); }
            ImGui::PopID(); }
        if (ImGui::SmallButton(T(L_PE_SCALEALL))) ImGui::OpenPopup("scl");
        if (ImGui::BeginPopup("scl")) { static float f = 1.f; ImGui::SetNextItemWidth(100); ImGui::InputFloat("x", &f); if (ImGui::Button("OK")) { for (int i = 2; i < n; i++) v[i] *= f; ch = true; ImGui::CloseCurrentPopup(); } ImGui::EndPopup(); }
        ImGui::TreePop(); }
    if (ch) { float mn = 1e30f, mx = -1e30f; for (int i = 2; i < n; i++) { mn = std::min(mn, v[i]); mx = std::max(mx, v[i]); } v[0] = mn; v[1] = mx;
        memcpy(lt->raw.data() + 4, v.data(), (size_t)n * 4); }
    return ch;
}

static bool PeStruct(std::vector<u8>& b, const std::string& st, int depth) {
    bool ch = false;
    if (bm::Package::strcasecmp_(st, "Vector") && b.size() == 12) { float v[3]; memcpy(v, b.data(), 12); ImGui::SetNextItemWidth(-FLT_MIN); if (ImGui::DragFloat3("##v", v, 1.f, 0, 0, "%.3f")) { memcpy(b.data(), v, 12); ch = true; } return ch; }
    if (bm::Package::strcasecmp_(st, "Vector2D") && b.size() == 8) { float v[2]; memcpy(v, b.data(), 8); ImGui::SetNextItemWidth(-FLT_MIN); if (ImGui::DragFloat2("##v2", v, 0.01f, 0, 0, "%.3f")) { memcpy(b.data(), v, 8); ch = true; } return ch; }
    if (bm::Package::strcasecmp_(st, "Rotator") && b.size() == 12) { int v[3]; memcpy(v, b.data(), 12); ImGui::SetNextItemWidth(-FLT_MIN); if (ImGui::InputInt3("##r", v)) { memcpy(b.data(), v, 12); ch = true; } return ch; }
    if (bm::Package::strcasecmp_(st, "LinearColor") && b.size() == 16) { float v[4]; memcpy(v, b.data(), 16); if (ImGui::ColorEdit4("##lc", v, ImGuiColorEditFlags_Float | ImGuiColorEditFlags_HDR)) { memcpy(b.data(), v, 16); ch = true; } return ch; }
    if (bm::Package::strcasecmp_(st, "Color") && b.size() == 4) { float v[4] = { b[2] / 255.f, b[1] / 255.f, b[0] / 255.f, b[3] / 255.f };
        if (ImGui::ColorEdit4("##c", v)) { b[2] = (u8)(v[0] * 255 + .5f); b[1] = (u8)(v[1] * 255 + .5f); b[0] = (u8)(v[2] * 255 + .5f); b[3] = (u8)(v[3] * 255 + .5f); ch = true; } return ch; }
    if (bm::Package::strcasecmp_(st, "Guid") && b.size() == 16) { std::string h; char x[4]; for (u8 c : b) { snprintf(x, 4, "%02X", c); h += x; } ImGui::TextDisabled("%s", h.c_str()); return false; }
    if (gPeDb && gPeDb->immutable(st)) {   // binary struct: fields in sequence
        std::vector<const bm::cp::PField*> fl; if (!gPeDb->binFields(st, fl)) { ImGui::TextDisabled("%s", HexPreview(b).c_str()); return false; }
        if (PeOpenAll() && !ImGui::TreeNode("##bs", "{%s}", st.c_str())) return false;
        size_t p = 0; std::vector<std::pair<size_t, size_t>> parts; std::vector<const bm::cp::PField*> who;
        for (auto* f : fl) { if (f->flags & (bm::cp::CPF_Native | bm::cp::CPF_Transient | bm::cp::CPF_Deprecated)) continue; for (int k = 0; k < f->dim; k++) { size_t len; if (!PeMeasure(b, p, f->t, len)) { ImGui::TextDisabled("?"); ImGui::TreePop(); return false; } parts.push_back({ p, len }); who.push_back(f); p += len; } }
        std::vector<u8> nb; bool any = false;
        for (size_t i = 0; i < parts.size(); i++) { std::vector<u8> sub(b.begin() + parts[i].first, b.begin() + parts[i].first + parts[i].second); ImGui::PushID((int)i);
            ImGui::AlignTextToFramePadding(); ImGui::TextUnformatted(who[i]->name.c_str()); ImGui::SameLine(160); if (PeBuf(sub, who[i]->t, depth + 1)) any = true; ImGui::PopID(); nb.insert(nb.end(), sub.begin(), sub.end()); }
        if (p < b.size()) nb.insert(nb.end(), b.begin() + p, b.end());
        ImGui::TreePop(); if (any) { b = nb; ch = true; } return ch; }
    // tagged struct
    size_t end = 0; std::vector<Tag> sub; bool ok = false;
    try { sub = readProps(gDoc.pk, b.data(), b.size(), 0, &end); ok = end == b.size(); } catch (...) {}
    if (!ok) { ImGui::TextDisabled("%s", HexPreview(b).c_str()); return false; }
    bool rd = st == "RawDistributionFloat" || st == "RawDistributionVector";
    if (rd) { if (PeRawDist(sub, st == "RawDistributionVector")) ch = true; }
    if (PeOpenAll() && ImGui::TreeNode("##ts", rd ? "%s" : "{%s}", rd ? T(L_PE_RAWFIELDS) : st.c_str())) { if (PeTags(sub, true, st, depth + 1)) ch = true; ImGui::TreePop(); }
    if (ch) b = writeProps(gDoc.pk, sub);
    return ch;
}

static bool PeArray(std::vector<u8>& b, const PType& t, int depth) {
    if (b.size() < 4 || !t.inner) { ImGui::TextDisabled("%s", HexPreview(b).c_str()); return false; }
    i32 cnt; memcpy(&cnt, b.data(), 4); std::vector<std::vector<u8>> el; size_t p = 4;
    for (i32 k = 0; k < cnt; k++) { size_t len; if (!PeMeasure(b, p, *t.inner, len)) { ImGui::TextDisabled("[%d] %s", cnt, HexPreview(b, 24).c_str()); return false; } el.emplace_back(b.begin() + p, b.begin() + p + len); p += len; }
    if (p != b.size()) { ImGui::TextDisabled("[%d] ?", cnt); return false; }
    bool ch = false; int del = -1; bool add = false;
    bool simple = t.inner->k == bm::cp::K_Float || t.inner->k == bm::cp::K_Int;
    if (PeOpenAll() && ImGui::TreeNode("##arr", "[%d] %s", cnt, PeTypeName(*t.inner).c_str())) {
        for (i32 k = 0; k < cnt && k < 20000; k++) { ImGui::PushID(k);
            if (ImGui::SmallButton("x")) del = k; ImGui::SameLine(); ImGui::TextDisabled("[%d]", k); ImGui::SameLine();
            if (simple) ImGui::SetNextItemWidth(160);
            if (PeBuf(el[k], *t.inner, depth + 1)) ch = true; ImGui::PopID(); }
        if (ImGui::SmallButton(T(L_PE_ADDELEM))) add = true;
        ImGui::TreePop(); }
    if (del >= 0) { el.erase(el.begin() + del); ch = true; }
    if (add) { el.push_back(el.empty() ? PeZero(*t.inner) : el.back()); ch = true; }
    if (ch) { b.clear(); i32 n = (i32)el.size(); u8 x[4]; memcpy(x, &n, 4); b.insert(b.end(), x, x + 4); for (auto& e : el) b.insert(b.end(), e.begin(), e.end()); }
    return ch;
}

static bool PeBuf(std::vector<u8>& b, const PType& t, int depth) {
    if (depth > 12) { ImGui::TextDisabled("..."); return false; }
    bool ch = false;
    switch (t.k) {
    case bm::cp::K_Int: if (b.size() >= 4) { int v; memcpy(&v, b.data(), 4); if (ImGui::InputInt("##i", &v, 0, 0)) { memcpy(b.data(), &v, 4); ch = true; } } break;
    case bm::cp::K_Float: if (b.size() >= 4) { float v; memcpy(&v, b.data(), 4); if (ImGui::DragFloat("##f", &v, std::max(0.001f, fabsf(v) * 0.01f), 0, 0, "%.6g")) { memcpy(b.data(), &v, 4); ch = true; } } break;
    case bm::cp::K_Bool: if (b.size() >= 1) { bool v = b[0] != 0; if (ImGui::Checkbox("##bo", &v)) { b[0] = v ? 1 : 0; ch = true; } } break;
    case bm::cp::K_Byte: if (b.size() >= 1) { int v = b[0]; if (ImGui::InputInt("##by", &v, 0, 0)) { b[0] = (u8)std::max(0, std::min(255, v)); ch = true; } } break;
    case bm::cp::K_Enum: case bm::cp::K_Name: if (b.size() >= 8) ch = PeNameRef(b.data()); break;
    case bm::cp::K_Str: ch = PeStr(b); break;
    case bm::cp::K_Obj: if (b.size() >= 4) ch = PeObjRef(b.data()); break;
    case bm::cp::K_Struct: ch = PeStruct(b, t.strct, depth); break;
    case bm::cp::K_Array: ch = PeArray(b, t, depth); break;
    default: ImGui::TextDisabled("%s", HexPreview(b).c_str()); break;
    }
    return ch;
}

// type of a tag (from the tag itself; arrays need the class to know the element type)
static PType PeTagType(const Tag& t, bool isStruct, const std::string& scope) {
    PType p; p.pcls = t.type;
    if (t.type == "IntProperty") p.k = bm::cp::K_Int; else if (t.type == "FloatProperty") p.k = bm::cp::K_Float; else if (t.type == "NameProperty") p.k = bm::cp::K_Name;
    else if (t.type == "StrProperty") p.k = bm::cp::K_Str; else if (t.type == "ByteProperty") p.k = t.raw.size() == 8 ? bm::cp::K_Enum : bm::cp::K_Byte;
    else if (t.type == "ObjectProperty" || t.type == "ComponentProperty" || t.type == "ClassProperty" || t.type == "InterfaceProperty") p.k = bm::cp::K_Obj;
    else if (t.type == "StructProperty") { p.k = bm::cp::K_Struct; p.strct = t.strct; }
    else if (t.type == "ArrayProperty") { p.k = bm::cp::K_Array; if (gPeDb) { const bm::cp::PField* f = gPeDb->findProp(isStruct, scope, t.name); if (f && f->t.k == bm::cp::K_Array) p = f->t; } }
    else if (t.type == "BoolProperty") p.k = bm::cp::K_Bool;
    return p;
}

// editable tag list; scope = class (isStruct=false) or struct
static bool PeTags(std::vector<Tag>& tags, bool isStruct, const std::string& scope, int depth) {
    bool ch = false; int del = -1;
    ImVec2 osz = depth == 0 ? ImVec2(0, -ImGui::GetFrameHeightWithSpacing() * 1.3f) : ImVec2(0, 0);
    if (!ImGui::BeginTable("##pt", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_Resizable | ImGuiTableFlags_BordersInnerV | (depth == 0 ? ImGuiTableFlags_ScrollY : 0), osz)) return false;
    if (depth == 0) ImGui::TableSetupScrollFreeze(0, 1);
    ImGui::TableSetupColumn(T(L_NAME), ImGuiTableColumnFlags_WidthStretch, 0.30f); ImGui::TableSetupColumn(T(L_TYPE), ImGuiTableColumnFlags_WidthStretch, 0.16f); ImGui::TableSetupColumn(T(L_VALUE), ImGuiTableColumnFlags_WidthStretch, 0.54f);
    if (depth == 0) ImGui::TableHeadersRow();
    for (size_t k = 0; k < tags.size(); k++) { Tag& t = tags[k]; ImGui::PushID((int)k);
        ImGui::TableNextRow(); ImGui::TableNextColumn();
        if (ImGui::SmallButton("x")) del = (int)k; if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_PE_REMOVE_TIP)); ImGui::SameLine();
        if (t.index) ImGui::Text("%s[%d]", t.name.c_str(), t.index); else ImGui::TextUnformatted(t.name.c_str());
        PType pt = PeTagType(t, isStruct, scope);
        ImGui::TableNextColumn(); ImGui::TextDisabled("%s", t.type == "ArrayProperty" ? PeTypeName(pt).c_str() : (t.strct.empty() ? t.type.c_str() : t.strct.c_str()));
        ImGui::TableNextColumn(); ImGui::SetNextItemWidth(-FLT_MIN);
        if (t.isBool) { bool v = t.boolVal != 0; if (ImGui::Checkbox("##tb", &v)) { t.boolVal = v ? 1 : 0; ch = true; } }
        else if (t.type == "ArrayProperty" && !pt.inner) {   // unknown type: ints/objects as before
            i32 cnt = 0; if (t.raw.size() >= 4) memcpy(&cnt, t.raw.data(), 4);
            if (cnt > 0 && t.raw.size() == 4 + (size_t)cnt * 4) { PType it; it.k = bm::cp::K_Int; PType ar; ar.k = bm::cp::K_Array; ar.inner = std::make_shared<PType>(it); if (PeBuf(t.raw, ar, depth)) ch = true; }
            else ImGui::TextDisabled("[%d] %s", cnt, HexPreview(std::vector<u8>(t.raw.begin() + std::min<size_t>(4, t.raw.size()), t.raw.end()), 24).c_str()); }
        else if (PeBuf(t.raw, pt, depth)) ch = true;
        ImGui::PopID(); }
    ImGui::EndTable();
    if (del >= 0) { tags.erase(tags.begin() + del); ch = true; }
    // add a property that is at its default value (not stored)
    if (gPeDb) { ImGui::PushID("add");
        std::vector<const bm::cp::PField*> cand; std::string s = scope;
        for (int g = 0; !s.empty() && g < 64; g++) { const bm::cp::Scope* sc = gPeDb->scope(isStruct, s); if (!sc->ok) break;
            for (auto& f : sc->fields) { if (f.flags & (bm::cp::CPF_Native | bm::cp::CPF_Transient | bm::cp::CPF_Deprecated)) continue; if (f.t.k == bm::cp::K_Unknown || f.t.k == bm::cp::K_Map || f.t.k == bm::cp::K_Delegate) continue;
                bool have = false; for (auto& t : tags) if (bm::Package::strcasecmp_(t.name, f.name)) { have = f.dim <= 1; } if (!have) cand.push_back(&f); }
            s = sc->super; }
        if (!cand.empty()) { ImGui::SetNextItemWidth(260);
            if (ImGui::BeginCombo("##addp", T(L_PE_ADDPROP), ImGuiComboFlags_HeightLarge)) {
                for (auto* f : cand) if (ImGui::Selectable((f->name + "  (" + PeTypeName(f->t) + ")").c_str())) {
                    Tag nt; nt.name = f->name; nt.type = f->t.pcls.empty() ? "IntProperty" : f->t.pcls;
                    if (f->t.k == bm::cp::K_Bool) { nt.isBool = true; nt.boolVal = 1; }
                    else { nt.raw = PeZero(f->t); if (f->t.k == bm::cp::K_Struct) nt.strct = f->t.strct; }
                    if (f->dim > 1) { int used = 0; for (auto& t : tags) if (bm::Package::strcasecmp_(t.name, f->name)) used = std::max(used, t.index + 1); nt.index = std::min(used, f->dim - 1); }
                    tags.push_back(nt); ch = true; }
                ImGui::EndCombo(); }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_PE_ADDPROP_TIP)); }
        ImGui::PopID(); }
    return ch;
}

// object references in the native data (after the properties): textures of a cooked Material, mesh materials...
static void PeNativeRefs(i32 idx, size_t propsEnd) {
    if (!gPeDb || idx <= 0) return; bm::cp::Refs r; std::string err; if (!bm::cp::analyzeExport(gDoc.pk, *gPeDb, idx, r, err)) { ImGui::TextDisabled("%s", err.c_str()); return; }
    std::vector<size_t> pos; for (size_t p : r.objs) if (p >= propsEnd) pos.push_back(p); if (pos.empty()) { ImGui::TextDisabled("%s", T(L_PE_NONATIVE)); return; }
    ImGui::Text("%s (%zu)", T(L_PE_NATIVE), pos.size());
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_PE_NATIVE_TIP)); ImGui::PopStyleColor();
    Export& e = gDoc.pk.exports[idx - 1];
    for (size_t k = 0; k < pos.size(); k++) { ImGui::PushID((int)k); ImGui::TextDisabled("+%zu", pos[k]); ImGui::SameLine(80);
        u8 v[4]; memcpy(v, gDoc.pk.dataPtr(e) + pos[k], 4);
        if (PeObjRef(v)) { if (!e.owned) { e.data.assign(gDoc.pk.dataPtr(e), gDoc.pk.dataPtr(e) + gDoc.pk.dataLen(e)); e.owned = true; } memcpy(e.data.data() + pos[k], v, 4); gDoc.dirty = true; }
        ImGui::PopID(); }
}

// ---- check before saving: new/changed objects whose properties cannot be read (names from another package,
// wrong size...) crash the game on load with no message. That is what happened with Overworld_A2_Static.umap
// (15 components with name indices from another package).
static std::vector<std::string> ValidateDoc(bool all = false) {
    std::vector<std::string> out; bm::Package& P = gDoc.pk; const TypeDB* db = EnsureTypeDB(); i32 ne = (i32)P.exports.size(), ni = (i32)P.imports.size(), nn = (i32)P.names.size();
    auto refOk = [&](i32 v) { return v == 0 || (v > 0 && v <= ne) || (v < 0 && -v <= ni); };
    for (i32 i = 1; i <= ne && out.size() < 200; i++) { const bm::Export& e = P.exports[i - 1];
        if (e.name.idx < 0 || e.name.idx >= nn) { out.push_back("#" + std::to_string(i) + ": bad name index"); continue; }
        if (!refOk(e.cls) || !refOk(e.outer) || !refOk(e.archetype) || !refOk(e.super_)) { out.push_back(P.objPath(i) + ": bad class/outer/archetype reference"); continue; }
        if (!e.owned && !all) continue;   // only what was touched in this session (or everything, in "Verify")
        long ps = findPropStart(P, i);
        if (ps < 0) { std::string c = P.classOf(e); bool script = c == "Class" || c == "Function" || c == "State" || c == "ScriptStruct" || c == "Enum" || c == "Const" || c == "Package" || (c.size() > 8 && c.compare(c.size() - 8, 8, "Property") == 0);
            if (!script) out.push_back(P.objPath(i) + " [" + c + "]: property list unreadable (names from another package?)"); continue; }
        try { size_t end = 0; auto tags = readProps(P, P.dataPtr(e), P.dataLen(e), (size_t)ps, &end); (void)tags; }
        catch (std::exception& ex) { out.push_back(P.objPath(i) + ": " + ex.what()); continue; }
        if (db) { bm::cp::Refs r; bm::cp::Walker w(P, *db, P.dataPtr(e), P.dataLen(e), r); size_t p = (size_t)ps;
            try { w.tags(p, false, P.classOf(e)); } catch (std::exception& ex) { std::string m = ex.what(); if (m.find("unknown array") == std::string::npos) { out.push_back(P.objPath(i) + ": " + m); continue; } }
            for (size_t q : r.objs) { i32 v; memcpy(&v, P.dataPtr(e) + q, 4); if (!refOk(v)) { out.push_back(P.objPath(i) + ": object reference out of range"); break; } }
            for (size_t q : r.names) { i32 v; memcpy(&v, P.dataPtr(e) + q, 4); if (v < 0 || v >= nn) { out.push_back(P.objPath(i) + ": name index out of range"); break; } } }
    }
    // actor list of the level
    i32 lvl = P.findPath("TheWorld.PersistentLevel");
    if (lvl > 0) { ObjProps op = objProps(P, lvl); if (op.ok) { const u8* d = P.dataPtr(P.exports[lvl - 1]); size_t at = op.end + 4; i32 cnt; memcpy(&cnt, d + at, 4);
        if (cnt < 0 || at + 4 + (size_t)cnt * 4 > P.dataLen(P.exports[lvl - 1])) out.push_back("PersistentLevel: bad actor list");
        else for (i32 k = 0; k < cnt; k++) { i32 a; memcpy(&a, d + at + 4 + 4 * (size_t)k, 4); if (a < 0 || a > ne) { out.push_back("PersistentLevel: actor list entry out of range"); break; } } } }
    return out;
}
static std::vector<std::string> gSaveProblems; static std::wstring gSavePath; static bool gAskSaveProblems = false, gCheckOnly = false;
static bool SaveChecked(const std::wstring& path) {
    if (gDoc.pk.bigEndian) { Status(T(L_BETA_RO)); return false; }
    gSaveProblems = ValidateDoc(); if (gSaveProblems.empty()) return DoSave(path);
    gSavePath = path; gAskSaveProblems = true; gCheckOnly = false; return false;
}
static void CheckPackage() { gSaveProblems = ValidateDoc(true); gCheckOnly = true; gAskSaveProblems = true; }
static void SaveProblemsPopup() {
    if (gAskSaveProblems) { ImGui::OpenPopup("save_problems"); gAskSaveProblems = false; }
    ImGui::SetNextWindowSize(ImVec2(760, 0), ImGuiCond_Appearing);
    if (ImGui::BeginPopupModal("save_problems", nullptr, 0)) {
        if (gSaveProblems.empty()) ImGui::TextColored(ImVec4(.5f, 1, .6f, 1), "%s", T(L_SV_CLEAN));
        else { ImGui::TextColored(ImVec4(1, .55f, .35f, 1), T(L_SV_PROBLEMS), (int)gSaveProblems.size()); ImGui::TextWrapped("%s", T(L_SV_PROBLEMS_TIP)); }
        ImGui::BeginChild("svp", ImVec2(0, 240), ImGuiChildFlags_Borders); for (auto& s : gSaveProblems) ImGui::TextUnformatted(s.c_str()); ImGui::EndChild();
        if (gCheckOnly) { if (ImGui::Button("OK", ImVec2(160, 0))) ImGui::CloseCurrentPopup(); }
        else { if (ImGui::Button(T(L_CANCEL), ImVec2(160, 0))) ImGui::CloseCurrentPopup();
            ImGui::SameLine(); if (ImGui::Button(T(L_SV_SAVEANYWAY), ImVec2(220, 0))) { ImGui::CloseCurrentPopup(); DoSave(gSavePath); } }
        ImGui::EndPopup(); }
}
