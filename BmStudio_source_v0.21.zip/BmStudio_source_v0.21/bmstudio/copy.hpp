// BmStudio - copying objects from another package (with dependencies) and "replace with" (UPK Explorer-like, but remapping
// references and names automatically). Included by app.cpp after import.hpp.
#pragma once
#include "../bmcpp/bmcopy.hpp"
#include <memory>

struct CopyState {
    bool open = false; i32 target = 0;                       // target > 0 = "replace with" mode
    std::unique_ptr<Doc> src; char filter[256] = ""; std::set<i32> sel; bool replaceExisting = true;
    std::vector<i32> rows; std::string rowsKey; std::string lastReport; std::vector<std::string> lastProblems; bool lastOk = false;
};
static CopyState gCp;

// type database: script packages of the document's CookedPC folder (memory-mapped) + source + target
struct ScriptDB { std::string dir; int gen = -1; std::vector<std::unique_ptr<Doc>> docs; std::unique_ptr<bm::cp::TypeDB> db; std::string err; };
static ScriptDB gSdb;
static bm::cp::TypeDB* EnsureTypeDB() {
    std::string dir = cookedDirOf(U8(gDoc.path));
    // package outside the game folder (e.g. a working copy): uses the last valid CookedPC folder
    if (GetFileAttributesW((W(dir) + L"Engine.u").c_str()) == INVALID_FILE_ATTRIBUTES) { std::wstring c = GetSetting(L"CookedDir"); if (!c.empty()) dir = U8(c); }
    else if (GetSetting(L"CookedDir") != W(dir)) SetSetting(L"CookedDir", W(dir));
    const Doc* srcDoc = gCp.src ? gCp.src.get() : nullptr;
    if (gSdb.db && gSdb.dir == dir && gSdb.gen == gDocGen) return gSdb.db.get();
    gSdb = ScriptDB(); gSdb.dir = dir; gSdb.gen = gDocGen; gSdb.db = std::make_unique<bm::cp::TypeDB>();
    for (const char* f : { "Core.u", "Engine.u", "CommonGame.u", "GFxUI.u", "IpDrv.u", "BmGame.u" }) {
        std::wstring p = W(dir) + W(f);
        if (_wcsicmp(p.c_str(), gDoc.path.c_str()) == 0) continue;                         // the document itself goes below
        if (GetFileAttributesW(p.c_str()) == INVALID_FILE_ATTRIBUTES) { gSdb.err += std::string(f) + " not found; "; continue; }
        auto d = std::make_unique<Doc>(); std::string e = d->open(p); if (!e.empty()) { gSdb.err += std::string(f) + ": " + e + "; "; continue; }
        gSdb.db->add(&d->pk); gSdb.docs.push_back(std::move(d));
    }
    if (!gDoc.pk.bigEndian) gSdb.db->add(&gDoc.pk); if (srcDoc && !srcDoc->pk.bigEndian) gSdb.db->add(&srcDoc->pk);
    return gSdb.db.get();
}

static void CopyOpenSource() {
    std::wstring f = FileDialog(false, L""); if (f.empty()) return;
    auto d = std::make_unique<Doc>(); std::string e = d->open(f); if (!e.empty()) { Status(std::string(T(L_OPENFAIL)) + ": " + e); return; }
    gCp.src = std::move(d); gCp.sel.clear(); gCp.rowsKey.clear(); gSdb.gen = -1;   // the type database includes the source
}
static void CopyBegin(i32 target) { gCp.open = true; gCp.target = target; gCp.sel.clear(); gCp.lastReport.clear(); gCp.lastProblems.clear(); gCp.rowsKey.clear(); }

static void CopyRun() {
    if (!gCp.src || gCp.sel.empty()) return;
    bm::cp::TypeDB* db = EnsureTypeDB();
    std::vector<i32> roots(gCp.sel.begin(), gCp.sel.end()); std::map<i32, i32> tf;
    if (gCp.target > 0) { if (roots.size() != 1) { Status(T(L_CP_ONEONLY)); return; } tf[roots[0]] = gCp.target; }
    bm::cp::CopyReport r = bm::cp::copyObjects(gDoc.pk, gCp.src->pk, roots, *db, gCp.replaceExisting, tf);
    gCp.lastOk = r.ok; gCp.lastProblems = r.problems;
    if (!r.ok) { gCp.lastReport = std::string(T(L_CP_FAIL)) + ": " + r.err; Status(gCp.lastReport); return; }
    char b[512]; snprintf(b, sizeof b, T(L_CP_DONE), r.copied, r.replaced, r.reused, r.newImports, r.newNames); gCp.lastReport = b;
    gDoc.dirty = true; gDoc.rebuild(); gLastFilterKey = "\x01"; gPrev.idx = 0; gEd.idx = -1;
    if (!r.roots.empty()) { gSel = r.roots[0]; }
    Status(gCp.lastReport);
    if (gCp.target > 0) gCp.open = false;
}

static void CopyAutoTest() {   // automatic test (only with the environment variable BMS_AUTOCOPY="source|obj1|obj2...")
    static bool done = false; if (done || !gDoc.loaded) return; done = true;
    wchar_t buf[2048]; if (!GetEnvironmentVariableW(L"BMS_AUTOCOPY", buf, 2048)) return;
    std::wstring v = buf; std::vector<std::wstring> parts; size_t a = 0; for (;;) { size_t b = v.find(L'|', a); parts.push_back(v.substr(a, b == std::wstring::npos ? std::wstring::npos : b - a)); if (b == std::wstring::npos) break; a = b + 1; }
    if (parts.size() < 2) return; CopyBegin(0); auto d = std::make_unique<Doc>(); if (!d->open(parts[0]).empty()) return; gCp.src = std::move(d);
    for (size_t k = 1; k < parts.size(); k++) { i32 x = gCp.src->pk.findPath(U8(parts[k])); if (x > 0) gCp.sel.insert(x); }
    CopyRun();
}
static void CopyWindow() {
    CopyAutoTest();
    if (!gCp.open) return;
    ImGui::SetNextWindowSize(ImVec2(820, 620), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(1.0f);
    if (!ImGui::Begin(T(L_CP_TITLE), &gCp.open)) { ImGui::End(); return; }
    if (gCp.target > 0) ImGui::TextColored(ImVec4(1, .8f, .4f, 1), T(L_CP_REPLACING), gDoc.pk.objPath(gCp.target).c_str(), gDoc.pk.classOf(gDoc.pk.exports[gCp.target - 1]).c_str());
    else ImGui::TextWrapped("%s", T(L_CP_HINT));
    if (ImGui::Button(T(L_CP_OPENSRC))) CopyOpenSource();
    ImGui::SameLine(); ImGui::TextDisabled("%s", gCp.src ? U8(gCp.src->path).c_str() : T(L_NOFILE));
    if (!gCp.src) { ImGui::End(); return; }
    ImGui::SetNextItemWidth(320); ImGui::InputTextWithHint("##cpf", T(L_SEARCH), gCp.filter, sizeof gCp.filter);
    std::string wantCls = gCp.target > 0 ? gDoc.pk.classOf(gDoc.pk.exports[gCp.target - 1]) : "";
    std::string key = std::string(gCp.filter) + "|" + wantCls;
    if (key != gCp.rowsKey) {
        gCp.rowsKey = key; gCp.rows.clear(); std::string f = bm::cp::lower(std::string(gCp.filter)); const Package& S = gCp.src->pk;
        for (size_t k = 0; k < S.exports.size(); k++) { std::string c = S.classOf(S.exports[k]);
            if (c == "Class" || c == "Function" || c == "State" || c == "ScriptStruct" || c == "Enum" || c == "Const" || isPropType(c) || c == "Package") continue;
            if (!wantCls.empty() && c != wantCls) continue;
            if (S.objName((i32)k + 1).rfind("Default__", 0) == 0) continue;                       // script CDOs
            if (!f.empty() && bm::cp::lower(S.objPath((i32)k + 1) + " " + c).find(f) == std::string::npos) continue;
            gCp.rows.push_back((i32)k + 1); if (gCp.rows.size() >= 200000) break; }
    }
    ImGui::SameLine(); ImGui::Text("%zu", gCp.rows.size());
    if (gCp.target == 0) { ImGui::SameLine(); ImGui::Checkbox(T(L_CP_REPLACE_SAME), &gCp.replaceExisting); }
    float listH = ImGui::GetContentRegionAvail().y - ImGui::GetFrameHeightWithSpacing() * 3 - (gCp.lastProblems.empty() ? 0 : 90);
    if (ImGui::BeginChild("cplist", ImVec2(0, std::max(120.f, listH)), ImGuiChildFlags_Borders)) {
        ImGuiListClipper clip; clip.Begin((int)gCp.rows.size());
        const Package& S = gCp.src->pk;
        while (clip.Step()) for (int i = clip.DisplayStart; i < clip.DisplayEnd; i++) {
            i32 x = gCp.rows[i]; bool on = gCp.sel.count(x) != 0; ImGui::PushID(x);
            if (gCp.target > 0) { if (ImGui::RadioButton("##r", on)) { gCp.sel.clear(); gCp.sel.insert(x); } }
            else if (ImGui::Checkbox("##c", &on)) { if (on) gCp.sel.insert(x); else gCp.sel.erase(x); }
            ImGui::SameLine(); bool exists = gDoc.pk.findPath(S.objPath(x)) > 0;
            ImGui::TextUnformatted(S.objPath(x).c_str()); ImGui::SameLine(); ImGui::TextDisabled("[%s]%s", S.classOf(S.exports[x - 1]).c_str(), exists ? T(L_CP_EXISTS) : "");
            ImGui::PopID(); }
    }
    ImGui::EndChild();
    ImGui::BeginDisabled(gCp.sel.empty());
    if (ImGui::Button(gCp.target > 0 ? T(L_CP_DOREPLACE) : T(L_CP_DOCOPY), ImVec2(260, 0))) CopyRun();
    ImGui::EndDisabled(); ImGui::SameLine(); ImGui::Text("%zu %s", gCp.sel.size(), T(L_CP_SELECTED));
    if (!gSdb.err.empty()) { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, .75f, .3f, 1), "(%s)", gSdb.err.c_str()); }
    if (!gCp.lastReport.empty()) ImGui::TextColored(gCp.lastOk ? ImVec4(.5f, 1, .6f, 1) : ImVec4(1, .45f, .45f, 1), "%s", gCp.lastReport.c_str());
    if (!gCp.lastProblems.empty()) { if (ImGui::BeginChild("cpprob", ImVec2(0, 80), ImGuiChildFlags_Borders)) for (auto& p : gCp.lastProblems) ImGui::BulletText("%s", p.c_str()); ImGui::EndChild(); }
    ImGui::End();
}
