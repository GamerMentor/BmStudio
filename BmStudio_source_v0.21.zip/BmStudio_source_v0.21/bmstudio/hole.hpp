// BmStudio - "Cut hole" in the level viewport: a box (passage) placed on the wall; the meshes and BSP it
// crosses are clipped. Core in ../bmcpp/bmhole.hpp. Included by app.cpp after beta.hpp.
#pragma once
#include "../bmcpp/bmhole.hpp"

struct HoleState {
    bool open = false, placing = false, meshes = true, bsp = true; bm::hole::Box box; bool loaded = false;
    std::vector<std::string> log; std::unique_ptr<Package> undo; std::wstring undoPath; int undoGen = -1;
};
static HoleState gHole;

static void HoleLoadBox() { if (gHole.loaded) return; gHole.loaded = true; std::wstring s = GetSetting(L"HoleBox"); auto& b = gHole.box;
    if (!s.empty()) swscanf(s.c_str(), L"%f,%f,%f,%f,%f,%f,%f", &b.c[0], &b.c[1], &b.c[2], &b.half[0], &b.half[1], &b.half[2], &b.yaw);
    else { b.half[0] = 96; b.half[1] = 128; b.half[2] = 144; } }
static void HoleSaveBox() { auto& b = gHole.box; wchar_t s[256]; swprintf(s, 256, L"%g,%g,%g,%g,%g,%g,%g", b.c[0], b.c[1], b.c[2], b.half[0], b.half[1], b.half[2], b.yaw); SetSetting(L"HoleBox", s); }
// Package copy: the bytes pointer has to point to the copy's vector (when the package owns the bytes)
static void HoleCopyPkg(Package& dst, const Package& src) { dst = src; if (!dst.file.empty()) { dst.fp = dst.file.data(); dst.fn = dst.file.size(); } }
static bool HolePlacing() { return gHole.open && gHole.placing; }

// ray against the visible geometry (meshes + BSP): point and normal (world)
static bool HoleRaycast(const float o[3], const float d[3], float hit[3], float nrm[3], float maxT = 1e30f) {
    float best = maxT; bool any = false;
    auto test = [&](const float* a, const float* b, const float* c) { float t; if (!RayTri(o, d, a, b, c, t) || t >= best) return;
        best = t; any = true; float e1[3] = { b[0] - a[0], b[1] - a[1], b[2] - a[2] }, e2[3] = { c[0] - a[0], c[1] - a[1], c[2] - a[2] };
        nrm[0] = e1[1] * e2[2] - e1[2] * e2[1]; nrm[1] = e1[2] * e2[0] - e1[0] * e2[2]; nrm[2] = e1[0] * e2[1] - e1[1] * e2[0]; };
    for (auto& m : gLvl.L.meshes) { if (m.hidden) continue; auto it = gLvl.main.meshes.find(m.mesh); if (it == gLvl.main.meshes.end() || !it->second.ok) continue; const LvlGpuMesh& g = it->second;
        M4 inv = m4Inverse(m.world); float lo[3], ld[3];
        for (int k = 0; k < 3; k++) { lo[k] = o[0] * inv.m[0][k] + o[1] * inv.m[1][k] + o[2] * inv.m[2][k] + inv.m[3][k]; ld[k] = d[0] * inv.m[0][k] + d[1] * inv.m[1][k] + d[2] * inv.m[2][k]; }
        if (!RayBox(lo, ld, g.bmin, g.bmax)) continue;
        for (size_t t = 0; t + 2 < g.idx.size(); t += 3) { float w[3][3]; for (int j = 0; j < 3; j++) { const float* p = &g.pos[g.idx[t + j] * 3]; for (int k = 0; k < 3; k++) w[j][k] = p[0] * m.world.m[0][k] + p[1] * m.world.m[1][k] + p[2] * m.world.m[2][k] + m.world.m[3][k]; }
            test(w[0], w[1], w[2]); } }
    if (gLvl.showBsp) for (auto& b : gLvl.main.bsp) { if (!b.ok || !RayBox(o, d, b.bmin, b.bmax)) continue; for (size_t t = 0; t + 2 < b.idx.size(); t += 3) test(&b.pos[b.idx[t] * 3], &b.pos[b.idx[t + 1] * 3], &b.pos[b.idx[t + 2] * 3]); }
    if (!any) return false;
    for (int k = 0; k < 3; k++) hit[k] = o[k] + d[k] * best; float l = sqrtf(nrm[0] * nrm[0] + nrm[1] * nrm[1] + nrm[2] * nrm[2]); if (l > 0) for (int k = 0; k < 3; k++) nrm[k] /= l;
    if (nrm[0] * d[0] + nrm[1] * d[1] + nrm[2] * d[2] > 0) for (int k = 0; k < 3; k++) nrm[k] = -nrm[k];   // normal facing the camera
    return true;
}
// click on the wall: box against it (starts 16 units in front and goes 'depth' in), base on the floor
static void HolePick(float mx, float my) {
    float o[3], d[3]; LvlRay(mx, my, o, d); float hit[3], n[3]; gHole.placing = false;
    if (!HoleRaycast(o, d, hit, n)) { Status(T(L_HO_NOHIT)); return; }
    auto& b = gHole.box; float h2 = sqrtf(n[0] * n[0] + n[1] * n[1]); if (h2 < 0.3f) { Status(T(L_HO_NOTWALL)); return; }
    float nx = n[0] / h2, ny = n[1] / h2;
    b.yaw = atan2f(ny, nx) * 180.f / 3.14159265f + 90.f;
    for (int k = 0; k < 2; k++) b.c[k] = hit[k] - (k == 0 ? nx : ny) * (b.half[1] - 16.f);
    // floor: ray downward from a point in front of the wall
    float fo[3] = { hit[0] + nx * 24, hit[1] + ny * 24, hit[2] }, fd[3] = { 0, 0, -1 }, fh[3], fn[3];
    if (HoleRaycast(fo, fd, fh, fn, 4000)) b.c[2] = fh[2] + b.half[2]; else b.c[2] = hit[2];
    HoleSaveBox(); Status(T(L_HO_PLACED));
}
static void HoleOverlay(ImDrawList* dl, ImVec2 org) {
    if (!gHole.open) return; float c[8][3]; bm::hole::boxCorners(gHole.box, c);
    int E[12][2] = { { 0, 1 }, { 2, 3 }, { 4, 5 }, { 6, 7 }, { 0, 2 }, { 1, 3 }, { 4, 6 }, { 5, 7 }, { 0, 4 }, { 1, 5 }, { 2, 6 }, { 3, 7 } };
    for (auto& e : E) { float ax, ay, bx, by; if (!LvlProject(c[e[0]], ax, ay) || !LvlProject(c[e[1]], bx, by)) continue; dl->AddLine(ImVec2(org.x + ax, org.y + ay), ImVec2(org.x + bx, org.y + by), IM_COL32(255, 210, 40, 255), 2.f); }
    // depth arrow (where the passage goes)
    float ax3[3][3]; bm::hole::boxAxes(gHole.box, ax3); float p0[3], p1[3]; for (int k = 0; k < 3; k++) { p0[k] = gHole.box.c[k] - ax3[1][k] * gHole.box.half[1]; p1[k] = gHole.box.c[k] + ax3[1][k] * gHole.box.half[1]; }
    float a0, b0, a1, b1; if (LvlProject(p0, a0, b0) && LvlProject(p1, a1, b1)) dl->AddLine(ImVec2(org.x + a0, org.y + b0), ImVec2(org.x + a1, org.y + b1), IM_COL32(255, 120, 40, 200), 1.f);
}
static void HoleRun() {
    gHole.log.clear();
    std::wstring cooked = GetSetting(L"CookedDir"); std::string ck = cookedDirOf(U8(gDoc.path)); if (GetFileAttributesW((W(ck) + L"Engine.u").c_str()) != INVALID_FILE_ATTRIBUTES) cooked = W(ck);
    bm::cp::TypeDB* db = EnsureTypeDB();
    std::unique_ptr<Package> donor; { std::vector<u8> b; if (!cooked.empty() && RimpIO().read(U8(cooked + L"Maps\\Admin\\Admin_A_Static.umap"), b)) { donor = std::make_unique<Package>(); try { donor->loadBytes(std::move(b)); } catch (...) { donor.reset(); } } }
    gHole.undo = std::make_unique<Package>(); HoleCopyPkg(*gHole.undo, gDoc.pk); gHole.undoPath = gDoc.path;
    auto R = bm::hole::openHole(gDoc.pk, *db, donor.get(), gHole.box, gHole.meshes, gHole.bsp);
    if (!R.err.empty()) { HoleCopyPkg(gDoc.pk, *gHole.undo); gHole.undo.reset(); gHole.log.push_back(std::string("ERROR: ") + R.err); Status(gHole.log.back()); return; }
    gHole.log = R.log;
    if (R.meshesCut == 0 && R.bspFaces == 0 && R.cells == 0) { HoleCopyPkg(gDoc.pk, *gHole.undo); gHole.undo.reset(); gHole.log.push_back(T(L_HO_NOTHING)); Status(T(L_HO_NOTHING)); return; }
    LibAfterEdit(); gHole.undoGen = gDocGen; gLvl.gen = -1; Status(R.log.empty() ? "" : R.log[0]);
}
static void HoleUndo() {
    if (!gHole.undo || gHole.undoPath != gDoc.path) return;
    HoleCopyPkg(gDoc.pk, *gHole.undo); gHole.undo.reset(); LibAfterEdit(); gLvl.gen = -1; gHole.log.clear(); gHole.log.push_back(T(L_HO_UNDONE)); Status(T(L_HO_UNDONE));
}
static void HolePanel() {
    HoleLoadBox();
    if (!ImGui::CollapsingHeader(T(L_HO_TITLE), gHole.open ? ImGuiTreeNodeFlags_DefaultOpen : 0)) { gHole.open = false; gHole.placing = false; return; }
    gHole.open = true;
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_HO_HINT)); ImGui::PopStyleColor();
    if (gHole.placing) { ImGui::TextColored(ImVec4(1, .85f, .2f, 1), "%s", T(L_HO_CLICKWALL)); ImGui::SameLine(); if (ImGui::SmallButton(T(L_CANCEL))) gHole.placing = false; }
    else if (ImGui::Button(T(L_HO_PLACE))) gHole.placing = true;
    auto& b = gHole.box; bool ch = false;
    ImGui::SetNextItemWidth(260); ch |= ImGui::DragFloat3(T(L_HO_CENTER), b.c, 4.f, -1e6f, 1e6f, "%.0f");
    float size[3] = { b.half[0] * 2, b.half[1] * 2, b.half[2] * 2 }; ImGui::SetNextItemWidth(260);
    if (ImGui::DragFloat3(T(L_HO_SIZE), size, 4.f, 8.f, 8192.f, "%.0f")) { for (int k = 0; k < 3; k++) b.half[k] = std::max(4.f, size[k] / 2); ch = true; }
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_HO_SIZE_TIP));
    ImGui::SetNextItemWidth(120); ch |= ImGui::DragFloat(T(L_HO_YAW), &b.yaw, 1.f, -360.f, 360.f, "%.0f");
    ImGui::SameLine(); if (ImGui::SmallButton("+90")) { b.yaw += 90; ch = true; }
    if (ch) HoleSaveBox();
    ImGui::Checkbox(T(L_HO_MESHES), &gHole.meshes); ImGui::SameLine(); ImGui::Checkbox("BSP", &gHole.bsp);
    if (ImGui::Button(T(L_HO_RUN), ImVec2(200, 0))) HoleRun();
    if (gHole.undo && gHole.undoPath == gDoc.path) { ImGui::SameLine(); if (ImGui::Button(T(L_HO_UNDO))) HoleUndo(); }
    for (auto& l : gHole.log) ImGui::TextWrapped("%s", l.c_str());
}
// test: BMS_AUTOHOLE="cx,cy,cz,hx,hy,hz,yaw" (half sizes) [BMS_AUTOHOLE_SAVE=file] with the level open in the viewport
static void HoleAutoTest() {
    static int fr = 0; static bool done = false; if (done || !gLevelMode || !gDoc.loaded || gLvl.gen != gDocGen) return; wchar_t b[1024];
    if (!GetEnvironmentVariableW(L"BMS_AUTOHOLE", b, 1024)) { done = true; return; } if (++fr < 20) return; done = true;
    auto& x = gHole.box; gHole.loaded = true; swscanf(b, L"%f,%f,%f,%f,%f,%f,%f", &x.c[0], &x.c[1], &x.c[2], &x.half[0], &x.half[1], &x.half[2], &x.yaw); gHole.open = true;
    HoleRun(); if (GetEnvironmentVariableW(L"BMS_AUTOHOLE_SAVE", b, 1024)) DoSave(b);
}
