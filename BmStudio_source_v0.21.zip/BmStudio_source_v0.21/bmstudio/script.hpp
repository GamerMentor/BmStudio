// BmStudio - "Script" tab (Phase 4): reading cooked UnrealScript classes/states/functions, bytecode decompilation
// and edits that do NOT change the bytecode size (constants, disabling a statement, forcing a condition, variable flags).
// Included by app.cpp after level.hpp.
#pragma once
#include "../bmcpp/bmscript.hpp"
using namespace bm::us;

struct ScriptView {
    int gen = -1; i32 idx = 0; FieldInfo f; Script s; std::vector<Line> lines; int sel = -1; std::string err; bool modified = false;
    int editTok = -1; int ival = 0; float fv[3] = { 0, 0, 0 }; int rv[3] = { 0, 0, 0 }; char sbuf[512] = { 0 }; char nbuf[256] = { 0 };
};
static ScriptView gSv;
static bool CodeEditableFwd(i32 idx, std::string* why);   // ucc_ui.hpp
static void OpenCodeEditorFwd(i32 idx);
static void OpenClassEditorFwd(i32 idx, bool sub);
static bool gOpenScriptTab = false;
static NativeTable gNatives; static int gNativesGen = -1;

static bool ScriptTabAvailable(i32 idx) {
    if (idx <= 0) return false; std::string c = gDoc.pk.classOf(gDoc.pk.exports[idx - 1]);
    return c == "Class" || c == "State" || c == "Function" || c == "ScriptStruct" || c == "Enum" || c == "Const" || isPropClass(c);
}
static void EnsureNatives() {
    if (gNativesGen == gDocGen) return; gNativesGen = gDocGen; gNatives.clear();
    std::string dir = cookedDirOf(U8(gDoc.path));
    for (const char* f : { "Core.u", "Engine.u" }) { try { Package p; p.load(dir + f); collectNatives(p, gNatives); } catch (...) {} }
    collectNatives(gDoc.pk, gNatives);
}
static void ScriptLoad(i32 idx) {
    EnsureNatives(); gSv = ScriptView(); gSv.gen = gDocGen; gSv.idx = idx; gSv.f = parseField(gDoc.pk, idx);
    if (!gSv.f.ok) { gSv.err = gSv.f.err; return; }
    if (gSv.f.isStruct && gSv.f.scriptSize > 0) {
        const Export& e = gDoc.pk.exports[idx - 1];
        gSv.s = tokenize(gDoc.pk, gDoc.pk.dataPtr(e) + gSv.f.scriptOff, (u32)gSv.f.scriptSize); if (!gSv.s.err.empty()) { gSv.err = gSv.s.err; return; }
        Decompiler d(gDoc.pk, gSv.s, gNatives); gSv.lines = d.structured();
        gSv.modified = e.owned && e.serialOffset && gDoc.pk.dataLen(e) == (size_t)e.serialSize && memcmp(gDoc.pk.dataPtr(e) + gSv.f.scriptOff, gDoc.pk.fp + e.serialOffset + gSv.f.scriptOff, gSv.f.scriptSize) != 0;
    }
}
static bool LineModified(const Line& L) {
    const Export& e = gDoc.pk.exports[gSv.idx - 1]; if (!e.owned || gDoc.pk.dataLen(e) != (size_t)e.serialSize || L.synthetic || L.end <= L.pos) return false;
    return memcmp(gDoc.pk.dataPtr(e) + gSv.f.scriptOff + L.pos, gDoc.pk.fp + e.serialOffset + gSv.f.scriptOff + L.pos, L.end - L.pos) != 0;
}
// applies a bytecode edit, checks and reloads; undoes it if the bytecode stops being valid
static std::function<bool()> gPendingEdit;
static void ScriptCommit(const std::function<bool()>& edit) { gPendingEdit = edit; }
static void ScriptApplyPending() {
    if (!gPendingEdit) return; auto edit = gPendingEdit; gPendingEdit = nullptr;
    Export& e = gDoc.pk.exports[gSv.idx - 1]; std::vector<u8> backup(gDoc.pk.dataPtr(e), gDoc.pk.dataPtr(e) + gDoc.pk.dataLen(e)); bool wasOwned = e.owned;
    std::string err; bool ok = edit() && verifyScript(gDoc.pk, gSv.idx, &err);
    if (!ok) { e.data = backup; e.owned = wasOwned; Status(std::string(T(L_SC_EDITFAIL)) + (err.empty() ? "" : ": " + err)); }
    else { gDoc.dirty = true; Status(T(L_SC_EDITOK)); }
    int keep = gSv.sel; ScriptLoad(gSv.idx); gSv.sel = keep;
}
static void CollectConsts(int tok, std::vector<int>& out) {
    const Tok& t = gSv.s.toks[tok];
    switch (t.op) { case EX_IntConst: case EX_FloatConst: case EX_ByteConst: case EX_IntConstByte: case EX_NameConst: case EX_VectorConst: case EX_RotationConst: case EX_StringConst: case EX_True: case EX_False: case EX_ObjectConst: out.push_back(tok); break; default: break; }
    for (int k : t.kids) CollectConsts(k, out);
}
static bool Disableable(u8 op) {
    return op == EX_Let || op == EX_LetBool || op == EX_LetDelegate || op == EX_VirtualFunction || op == EX_FinalFunction || op == EX_GlobalFunction || op == EX_Context || op == EX_RSSContext ||
        op == EX_EatReturnValue || op == EX_DelegateFunction || op >= EX_ExtendedNative || op == EX_DynArrayAdd || op == EX_DynArrayAddItem || op == EX_DynArrayRemove || op == EX_DynArrayRemoveItem || op == EX_DynArrayInsert || op == EX_DynArrayInsertItem;
}
static void ScriptEditPanel() {
    if (gSv.sel < 0 || gSv.sel >= (int)gSv.lines.size()) { ImGui::TextDisabled("%s", T(L_SC_PICKLINE)); return; }
    const Line& L = gSv.lines[gSv.sel]; if (L.synthetic || L.tok < 0) { ImGui::TextDisabled("%s", T(L_SC_PICKLINE)); return; }
    const Tok& t = gSv.s.toks[L.tok]; const Export& e = gDoc.pk.exports[gSv.idx - 1];
    ImGui::Text("0x%04X..0x%04X  (%u bytes)", L.pos, L.end, L.end - L.pos);
    // bytes
    if (gMono) ImGui::PushFont(gMono);
    { std::string hx; const u8* p = gDoc.pk.dataPtr(e) + gSv.f.scriptOff; char b[4]; for (u32 k = L.pos; k < L.end && k < L.pos + 96; k++) { snprintf(b, sizeof b, "%02X ", p[k]); hx += b; } if (L.end - L.pos > 96) hx += "..."; ImGui::TextWrapped("%s", hx.c_str()); }
    if (gMono) ImGui::PopFont();
    ImGui::Separator();
    // statement actions
    u8 op = t.op; u32 stPos = L.pos, stEnd = L.end;
    if (op == EX_JumpIfNot) {
        if (ImGui::Button(T(L_SC_FORCE_TRUE))) ScriptCommit([=] { return forceCondition(gDoc.pk, gSv.idx, gSv.f, gSv.s, L.tok, true); }); ImGui::SameLine();
        if (ImGui::Button(T(L_SC_FORCE_FALSE))) ScriptCommit([=] { return forceCondition(gDoc.pk, gSv.idx, gSv.f, gSv.s, L.tok, false); });
        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_SC_FORCE_HINT)); ImGui::PopStyleColor();
    }
    bool eat = false; for (size_t k = 0; k < gSv.s.stmts.size(); k++) if (gSv.s.toks[gSv.s.stmts[k]].pos + gSv.s.toks[gSv.s.stmts[k]].size == L.end && gSv.s.toks[gSv.s.stmts[k]].pos != L.pos) eat = true;
    if (Disableable(op) || eat) {
        if (ImGui::Button(T(L_SC_DISABLE))) { u32 a = stPos, b2 = stEnd; for (int s2 : gSv.s.stmts) { const Tok& x = gSv.s.toks[s2]; if (x.op == EX_EatReturnValue && x.pos + x.size == stPos) a = x.pos; }
            ScriptCommit([=] { return nopRange(gDoc.pk, gSv.idx, gSv.f, a, b2); }); }
        ImGui::SameLine(); ImGui::TextDisabled("%s", T(L_SC_DISABLE_HINT));
    }
    // constants
    std::vector<int> consts; CollectConsts(L.tok, consts);
    if (op == EX_JumpIfNot) { consts.clear(); if (!t.kids.empty()) CollectConsts(t.kids[0], consts); }
    if (!consts.empty()) { ImGui::Separator(); ImGui::TextUnformatted(T(L_SC_CONSTS)); }
    size_t base = gSv.f.scriptOff;
    for (int ci : consts) {
        const Tok& c = gSv.s.toks[ci]; ImGui::PushID(ci); char lbl[64];
        switch (c.op) {
            case EX_IntConst: { int v = c.iv; ImGui::SetNextItemWidth(160); snprintf(lbl, sizeof lbl, "int @%04X", c.pos);
                if (ImGui::InputInt(lbl, &v, 0, 0, ImGuiInputTextFlags_EnterReturnsTrue)) ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.operandPos, &v, 4); }); break; }
            case EX_FloatConst: { float v = c.fv[0]; ImGui::SetNextItemWidth(160); snprintf(lbl, sizeof lbl, "float @%04X", c.pos);
                if (ImGui::InputFloat(lbl, &v, 0, 0, "%.6g", ImGuiInputTextFlags_EnterReturnsTrue)) ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.operandPos, &v, 4); }); break; }
            case EX_ByteConst: case EX_IntConstByte: { int v = c.b; ImGui::SetNextItemWidth(160); snprintf(lbl, sizeof lbl, "byte @%04X (0..255)", c.pos);
                if (ImGui::InputInt(lbl, &v, 0, 0, ImGuiInputTextFlags_EnterReturnsTrue)) { u8 b = (u8)std::max(0, std::min(255, v)); ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.operandPos, &b, 1); }); } break; }
            case EX_VectorConst: { float v[3] = { c.fv[0], c.fv[1], c.fv[2] }; ImGui::SetNextItemWidth(280); snprintf(lbl, sizeof lbl, "vect @%04X", c.pos);
                if (ImGui::InputFloat3(lbl, v, "%.4g", ImGuiInputTextFlags_EnterReturnsTrue)) ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.operandPos, v, 12); }); break; }
            case EX_RotationConst: { int v[3] = { c.rv[0], c.rv[1], c.rv[2] }; ImGui::SetNextItemWidth(280); snprintf(lbl, sizeof lbl, "rot @%04X (65536=360)", c.pos);
                if (ImGui::InputInt3(lbl, v, ImGuiInputTextFlags_EnterReturnsTrue)) ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.operandPos, v, 12); }); break; }
            case EX_True: case EX_False: { bool v = c.op == EX_True; snprintf(lbl, sizeof lbl, "bool @%04X", c.pos);
                if (ImGui::Checkbox(lbl, &v)) { u8 b = v ? EX_True : EX_False; ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.pos, &b, 1); }); } break; }
            case EX_NameConst: { char buf[256]; snprintf(buf, sizeof buf, "%s", gDoc.pk.nm(c.name).c_str()); ImGui::SetNextItemWidth(260); snprintf(lbl, sizeof lbl, "name @%04X", c.pos);
                if (ImGui::InputText(lbl, buf, sizeof buf, ImGuiInputTextFlags_EnterReturnsTrue) && buf[0]) { i32 ni = gDoc.pk.addName(buf); i32 nm[2] = { ni, 0 }; ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.operandPos, nm, 8); }); } break; }
            case EX_StringConst: { char buf[512]; snprintf(buf, sizeof buf, "%s", c.str.c_str()); ImGui::SetNextItemWidth(-FLT_MIN); snprintf(lbl, sizeof lbl, "##s%04X", c.pos);
                ImGui::TextDisabled("string @%04X (max %zu)", c.pos, c.str.size());
                if (ImGui::InputText(lbl, buf, c.str.size() + 1, ImGuiInputTextFlags_EnterReturnsTrue)) { std::string ns = buf; ns.resize(c.str.size(), ' ');   // same size (padded with spaces)
                    ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.operandPos, ns.data(), ns.size()); }); } break; }
            case EX_ObjectConst: { ImGui::TextDisabled("object @%04X: %s", c.pos, c.ref ? gDoc.pk.objPath(c.ref).c_str() : "None");
                char buf[256] = { 0 }; ImGui::SetNextItemWidth(-FLT_MIN); snprintf(lbl, sizeof lbl, "##o%04X", c.pos);
                if (ImGui::InputTextWithHint(lbl, T(L_OBJHINT), buf, sizeof buf, ImGuiInputTextFlags_EnterReturnsTrue)) { i32 o = std::string(buf) == "None" ? 0 : gDoc.pk.findPath(buf);
                    if (o == 0 && std::string(buf) != "None") Status(T(L_NOTFOUND)); else ScriptCommit([=] { return writeAt(gDoc.pk, gSv.idx, base + c.operandPos, &o, 4); }); } break; }
        }
        ImGui::PopID();
    }
}
static void PropFlagsEditor(i32 prop) {
    FieldInfo f = parseField(gDoc.pk, prop); if (!f.isProperty) return;
    ImGui::Text("%s", propDecl(gDoc.pk, prop).c_str());
    ImGui::TextDisabled("flags 0x%016llX", (unsigned long long)f.propFlags);
    static const std::pair<uint64_t, const char*> editable[] = { {0x4000,"config"},{0x40000,"globalconfig"},{0x1,"edit"},{0x2,"const"},{0x2000,"transient"},{0x20000,"editconst"} };
    for (auto& p : editable) { bool v = (f.propFlags & p.first) != 0; if (ImGui::Checkbox(p.second, &v)) { uint64_t nf = v ? (f.propFlags | p.first) : (f.propFlags & ~p.first);
        Export& e = gDoc.pk.exports[prop - 1]; (void)e; if (writeAt(gDoc.pk, prop, f.propFlagsOff, &nf, 8)) { gDoc.dirty = true; Status(T(L_SC_EDITOK)); } } ImGui::SameLine(); }
    ImGui::NewLine();
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_SC_CONFIG_HINT)); ImGui::PopStyleColor();
}
static void ScriptTab() {
    if (gSv.idx != gSel || gSv.gen != gDocGen) ScriptLoad(gSel);
    const FieldInfo& f = gSv.f; const Package& pk = gDoc.pk;
    if (!gSv.err.empty()) ImGui::TextColored(ImVec4(1, .45f, .45f, 1), "%s", gSv.err.c_str());
    if (!f.ok) return;
    if (gMono) ImGui::PushFont(gMono);
    if (f.isClass) {
        std::string decl = "class " + pk.objName(gSel) + (f.superField ? " extends " + pk.objName(f.superField) : std::string()); if (f.within && pk.objName(f.within) != "Object") decl += " within " + pk.objName(f.within);
        std::string cn = pk.nm(f.configName); if (cn != "None") decl += " config(" + cn + ")"; std::string fl = flagsText(f.classFlags, kClassFlags); if (!fl.empty()) decl += "  // " + fl;
        ImGui::TextWrapped("%s;", decl.c_str());
        if (gMono) ImGui::PopFont();
        if (f.cdo > 0) { if (ImGui::Button("defaultproperties")) GotoObject(f.cdo); ImGui::SameLine(); ImGui::TextDisabled("%s", gDoc.pk.objName(f.cdo).c_str()); }
        if (!(f.classFlags & 0x4000)) { if (ImGui::Button(T(L_UC_ADDMEMBERS))) OpenClassEditorFwd(gSel, false); ImGui::SameLine(); if (ImGui::Button(T(L_UC_NEWSUBBTN))) OpenClassEditorFwd(gSel, true); }
        ImGui::Separator();
        ImGui::BeginChild("members", ImVec2(0, 0));
        if (gMono) ImGui::PushFont(gMono);
        for (i32 c : childFields(pk, gSel)) { FieldInfo cf = parseField(pk, c); std::string s;
            if (cf.isProperty) s = propDecl(pk, c); else if (cf.isFunction) s = funcSignature(pk, c); else if (cf.isState) s = "state " + pk.objName(c); else if (cf.isScriptStruct) s = "struct " + pk.objName(c); else if (cf.isEnum) s = "enum " + pk.objName(c); else if (cf.isConst) s = "const " + pk.objName(c) + " = " + cf.constValue; else s = cf.cls + " " + pk.objName(c);
            ImGui::PushID(c); if (ImGui::Selectable(s.c_str(), false, ImGuiSelectableFlags_AllowDoubleClick) && ImGui::IsMouseDoubleClicked(0)) GotoObject(c);
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_SC_DBLCLICK)); ImGui::PopID(); }
        if (gMono) ImGui::PopFont();
        ImGui::EndChild(); return;
    }
    if (f.isProperty) { if (gMono) ImGui::PopFont(); PropFlagsEditor(gSel); return; }
    if (f.isEnum) { ImGui::Text("enum %s {", pk.objName(gSel).c_str()); for (size_t k = 0; k < f.enumNames.size(); k++) ImGui::Text("    %s,   // %zu", pk.nm(f.enumNames[k]).c_str(), k); ImGui::TextUnformatted("};"); if (gMono) ImGui::PopFont(); return; }
    if (f.isConst) { ImGui::Text("const %s = %s;", pk.objName(gSel).c_str(), f.constValue.c_str()); if (gMono) ImGui::PopFont(); return; }
    // function / state / struct
    if (f.isFunction) ImGui::TextWrapped("%s", funcSignature(pk, gSel).c_str());
    else if (f.isState) ImGui::Text("state %s", pk.objName(gSel).c_str());
    else ImGui::Text("struct %s", pk.objName(gSel).c_str());
    if (gMono) ImGui::PopFont();
    if (f.isFunction && f.iNative) ImGui::TextDisabled("native %d", f.iNative);
    { std::string why; if (f.scriptSize > 0 && CodeEditableFwd(gSel, &why)) { if (ImGui::Button(T(L_UC_EDIT))) OpenCodeEditorFwd(gSel); } else if (!why.empty()) ImGui::TextDisabled("%s", why.c_str()); }
    if (gSv.modified) { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, .75f, .3f, 1), "(%s)", T(L_SC_MODIFIED)); ImGui::SameLine();
        if (ImGui::SmallButton(T(L_SC_RESTORE))) { Export& e = gDoc.pk.exports[gSel - 1]; std::vector<u8> d(gDoc.pk.dataPtr(e), gDoc.pk.dataPtr(e) + gDoc.pk.dataLen(e));
            memcpy(d.data() + f.scriptOff, gDoc.pk.fp + e.serialOffset + f.scriptOff, f.scriptSize); e.data = d; gDoc.dirty = true; ScriptLoad(gSel); } }
    // locals
    std::vector<i32> locals; if (f.isFunction) for (i32 c : childFields(pk, gSel)) { FieldInfo cf = parseField(pk, c); if (cf.isProperty && !(cf.propFlags & 0x80)) locals.push_back(c); }
    float editH = 230;
    ImGui::BeginChild("code", ImVec2(0, -editH), ImGuiChildFlags_Borders, ImGuiWindowFlags_HorizontalScrollbar);
    if (gMono) ImGui::PushFont(gMono);
    for (i32 c : locals) ImGui::TextColored(ImVec4(0.6f, 0.75f, 1, 1), "      %s", propDecl(pk, c, true).c_str());
    if (!locals.empty()) ImGui::Spacing();
    if (f.scriptSize == 0) ImGui::TextDisabled("%s", T(L_SC_NOCODE));
    for (int i = 0; i < (int)gSv.lines.size(); i++) {
        const Line& L = gSv.lines[i]; char pre[16]; if (L.synthetic) snprintf(pre, sizeof pre, "      "); else snprintf(pre, sizeof pre, "%04X  ", L.pos);
        std::string txt = std::string(pre) + std::string(L.indent * 4, ' ') + L.text;
        bool mod = LineModified(L); ImVec4 col = L.text.rfind("//", 0) == 0 ? ImVec4(.5f, .6f, .5f, 1) : (L.text.rfind("if ", 0) == 0 || L.text.rfind("while", 0) == 0 || L.text.rfind("}", 0) == 0 || L.text == "{" || L.text.rfind("return", 0) == 0) ? ImVec4(.75f, .8f, 1, 1) : ImVec4(.92f, .92f, .92f, 1);
        if (mod) col = ImVec4(1, .72f, .3f, 1);
        ImGui::PushStyleColor(ImGuiCol_Text, col); ImGui::PushID(i);
        if (ImGui::Selectable(txt.c_str(), gSv.sel == i)) gSv.sel = i;
        ImGui::PopID(); ImGui::PopStyleColor();
    }
    if (gMono) ImGui::PopFont();
    ImGui::EndChild();
    ImGui::BeginChild("edit", ImVec2(0, 0), ImGuiChildFlags_Borders); ScriptEditPanel(); ImGui::EndChild();
    ScriptApplyPending();
}

// ------------------------------------------------------------------ search across every script of the package
struct ScriptSearch { bool open = false; char q[128] = { 0 }; std::vector<std::pair<i32, std::string>> hits; size_t next = 0; bool running = false; std::string qs; int gen = -1; };
static ScriptSearch gSs;
static void ScriptSearchWindow() {
    if (!gSs.open) return;
    ImGui::SetNextWindowSize(ImVec2(820, 520), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(1.0f);
    if (!ImGui::Begin(T(L_SC_SEARCH), &gSs.open)) { ImGui::End(); return; }
    if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
    if (gSs.gen != gDocGen) { gSs.hits.clear(); gSs.running = false; gSs.gen = gDocGen; }
    ImGui::SetNextItemWidth(-120); bool go = ImGui::InputTextWithHint("##q", T(L_SC_SEARCH_HINT), gSs.q, sizeof gSs.q, ImGuiInputTextFlags_EnterReturnsTrue); ImGui::SameLine();
    if ((ImGui::Button(T(L_SEARCH), ImVec2(-FLT_MIN, 0)) || go) && gSs.q[0] && gDoc.loaded) { EnsureNatives(); gSs.hits.clear(); gSs.next = 0; gSs.running = true; gSs.qs = gSs.q; }
    if (gSs.running) {   // decompiles a few at a time
        double t0 = ImGui::GetTime();
        while (gSs.next < gDoc.pk.exports.size() && ImGui::GetTime() - t0 < 0.03) {
            i32 idx = (i32)++gSs.next; std::string c = gDoc.pk.classOf(gDoc.pk.exports[idx - 1]); if (c != "Function" && c != "State") continue;
            FieldInfo f = parseField(gDoc.pk, idx); if (!f.ok || f.scriptSize <= 1) continue;
            Script s = tokenize(gDoc.pk, gDoc.pk.dataPtr(gDoc.pk.exports[idx - 1]) + f.scriptOff, (u32)f.scriptSize); if (!s.err.empty()) continue;
            Decompiler d(gDoc.pk, s, gNatives); for (auto& L : d.lines()) if (icontains(L.text, gSs.qs)) { char b[16]; snprintf(b, sizeof b, "%04X  ", L.pos); gSs.hits.push_back({ idx, b + L.text }); }
        }
        if (gSs.next >= gDoc.pk.exports.size()) gSs.running = false;
        ImGui::ProgressBar((float)gSs.next / std::max<size_t>(1, gDoc.pk.exports.size()), ImVec2(-FLT_MIN, 0));
    }
    ImGui::Text("%zu %s", gSs.hits.size(), T(L_SC_RESULTS));
    ImGui::BeginChild("hits", ImVec2(0, 0), ImGuiChildFlags_Borders, ImGuiWindowFlags_HorizontalScrollbar);
    if (gMono) ImGui::PushFont(gMono);
    ImGuiListClipper clip; clip.Begin((int)gSs.hits.size());
    while (clip.Step()) for (int i = clip.DisplayStart; i < clip.DisplayEnd; i++) { auto& h = gSs.hits[i]; std::string s = gDoc.path_(h.first) + "   " + h.second; ImGui::PushID(i);
        if (ImGui::Selectable(s.c_str())) { gLevelMode = false; GotoObject(h.first); gOpenScriptTab = true; } ImGui::PopID(); }
    if (gMono) ImGui::PopFont();
    ImGui::EndChild(); ImGui::End();
}
