// BmStudio - cooked package editor for Batman: Arkham Asylum (UE3 v576/lic21)
// Phase 2: object browser, editable properties, hex, raw data, faithful save (no re-cooking).
// Win32 + Direct3D 9 + Dear ImGui.
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <commdlg.h>
#include <d3d9.h>
#include <cstdio>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx9.h"
#include "../bmcpp/bmpkg.hpp"
#include "../bmcpp/bmbeta.hpp"
#include "lang.hpp"

using namespace bm;
static int gLang = 0;
static const char* T(L id) { return LTXT[gLang][id]; }

// ------------------------------------------------------------------ utilities
static std::wstring W(const std::string& s) { if (s.empty()) return L""; int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, NULL, 0); std::wstring w(n, 0); MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, &w[0], n); w.resize(n - 1); return w; }
static std::string U8(const std::wstring& w) { if (w.empty()) return ""; int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, NULL, 0, NULL, NULL); std::string s(n, 0); WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &s[0], n, NULL, NULL); s.resize(n - 1); return s; }
static std::wstring SettingsPath() { wchar_t ad[MAX_PATH] = { 0 }; SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, 0, ad); std::wstring d = std::wstring(ad) + L"\\BmStudio"; CreateDirectoryW(d.c_str(), NULL); return d + L"\\settings.ini"; }
static std::wstring GetSetting(const wchar_t* k) { wchar_t v[1024] = { 0 }; GetPrivateProfileStringW(L"Settings", k, L"", v, 1024, SettingsPath().c_str()); return v; }
static void SetSetting(const wchar_t* k, const std::wstring& v) { WritePrivateProfileStringW(L"Settings", k, v.c_str(), SettingsPath().c_str()); }
static bool icontains(const std::string& hay, const std::string& needle) {
    if (needle.empty()) return true;
    auto it = std::search(hay.begin(), hay.end(), needle.begin(), needle.end(), [](char a, char b) { return tolower((unsigned char)a) == tolower((unsigned char)b); });
    return it != hay.end();
}

// ------------------------------------------------------------------ document
struct Doc {
    std::wstring path; Package pk; bool loaded = false; bool dirty = false;
    HANDLE hf = INVALID_HANDLE_VALUE, hm = NULL; const u8* view = NULL; size_t size = 0;
    std::vector<std::vector<i32>> children; std::vector<i32> roots; std::vector<std::string> classes;
    std::vector<std::string> pathCache;
    ~Doc() { close(); }
    void close() {
        pk = Package(); loaded = false; dirty = false; children.clear(); roots.clear(); classes.clear(); pathCache.clear();
        if (view) UnmapViewOfFile(view); if (hm) CloseHandle(hm); if (hf != INVALID_HANDLE_VALUE) CloseHandle(hf);
        view = NULL; hm = NULL; hf = INVALID_HANDLE_VALUE; size = 0;
    }
    std::string open(const std::wstring& p) {
        close(); path = p;
        hf = CreateFileW(p.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
        if (hf == INVALID_HANDLE_VALUE) return "cannot open file";
        LARGE_INTEGER sz; GetFileSizeEx(hf, &sz); size = (size_t)sz.QuadPart;
        hm = CreateFileMappingW(hf, NULL, PAGE_READONLY, 0, 0, NULL); if (!hm) { close(); return "cannot map file"; }
        view = (const u8*)MapViewOfFile(hm, FILE_MAP_READ, 0, 0, 0); if (!view) { close(); return "not enough address space to map the file"; }
        if (bm::beta::isBigEndianPackage(view, size)) {   // console package (Xbox 360 beta): read only
            std::vector<u8> v(view, view + size); UnmapViewOfFile(view); CloseHandle(hm); CloseHandle(hf); view = NULL; hm = NULL; hf = INVALID_HANDLE_VALUE;
            bm::beta::Info in; if (!bm::beta::load(std::move(v), pk, in)) { std::string m = in.err; close(); return m; }
            rebuild(); loaded = true; return "";
        }
        try { pk.attach(view, size); } catch (std::exception& e) { std::string m = e.what(); close(); return m; }
        if (pk.wasCompressed) {   // compressed package (vanilla): the Package already has the decompressed image -> release the file
            UnmapViewOfFile(view); CloseHandle(hm); CloseHandle(hf); view = NULL; hm = NULL; hf = INVALID_HANDLE_VALUE;
        }
        rebuild(); loaded = true; return "";
    }
    void rebuild() {
        size_t n = pk.exports.size(); children.assign(n + 1, {}); roots.clear(); pathCache.assign(n + 1, "");
        std::set<std::string> cls;
        for (size_t k = 0; k < n; k++) { i32 o = pk.exports[k].outer; if (o > 0 && o <= (i32)n) children[o].push_back((i32)k + 1); else roots.push_back((i32)k + 1); cls.insert(pk.classOf(pk.exports[k])); }
        classes.assign(cls.begin(), cls.end());
    }
    const std::string& path_(i32 idx) { if (idx > 0 && idx < (i32)pathCache.size()) { if (pathCache[idx].empty()) pathCache[idx] = pk.objPath(idx); return pathCache[idx]; } static std::string s; s = pk.objPath(idx); return s; }
};
static Doc gDoc;

// ------------------------------------------------------------------ UI state
static bool gOpenPreviewTab = false;       // open the Preview tab on the next frame (command line: BmStudio.exe package object)
static int gDocGen = 0;                    // changes on every open/close (invalidates the preview)
static i32 gSel = 0;                       // selected export (1-based)
static char gSearch[128] = "";
static int gClassFilter = -1;              // index into gDoc.classes, -1 = all
static int gFlat = 0;
static std::vector<i32> gFiltered; static std::string gLastFilterKey;
static std::string gStatus; static double gStatusUntil = 0;
static bool gWantQuit = false, gAskUnsaved = false; static int gPendingAction = 0;   // 1 open, 2 close, 3 exit
static std::wstring gPendingOpen;
static std::function<void()> gDeferred;   // v0.18: actions that swap the document run at the end of the frame (before: reference to the old object -> crash)
static HWND gHwnd;
static ImFont* gMono = nullptr;
static void Status(const std::string& s) { gStatus = s; gStatusUntil = ImGui::GetTime() + 6.0; }

// editing properties of the selected export
struct PropEdit { Tag tag; std::string text; bool init = false; bool bad = false; };
static struct { i32 idx = 0; long start = -1; size_t end = 0; std::vector<PropEdit> props; bool pending = false; std::string err; } gEd;

static void LoadEdit(i32 idx) {
    gEd.idx = idx; gEd.props.clear(); gEd.pending = false; gEd.err.clear(); gEd.start = -1; gEd.end = 0;
    if (idx <= 0) return;
    const Export& e = gDoc.pk.exports[idx - 1];
    if (gDoc.pk.bigEndian) {   // beta (Xbox 360): converted read, no editing
        gEd.start = bm::beta::findPropStartBE(gDoc.pk, idx); if (gEd.start < 0) return;
        try { auto tags = bm::beta::readPropsBE(gDoc.pk, gDoc.pk.dataPtr(e), gDoc.pk.dataLen(e), (size_t)gEd.start, &gEd.end); for (auto& t : tags) { PropEdit pe; pe.tag = t; gEd.props.push_back(pe); } }
        catch (std::exception& ex) { gEd.start = -1; gEd.err = ex.what(); }
        return; }
    gEd.start = findPropStart(gDoc.pk, idx);
    if (gEd.start < 0) return;
    try { auto tags = readProps(gDoc.pk, gDoc.pk.dataPtr(e), gDoc.pk.dataLen(e), (size_t)gEd.start, &gEd.end); for (auto& t : tags) { PropEdit pe; pe.tag = t; gEd.props.push_back(pe); } }
    catch (std::exception& ex) { gEd.start = -1; gEd.err = ex.what(); }
}
static void ApplyEdit() {
    if (gEd.idx <= 0 || gEd.start < 0) return;
    Export& e = gDoc.pk.exports[gEd.idx - 1];
    std::vector<u8> d = gDoc.pk.dataCopy(e);
    std::vector<Tag> tags; for (auto& p : gEd.props) tags.push_back(p.tag);
    std::vector<u8> props = writeProps(gDoc.pk, tags);
    std::vector<u8> nd(d.begin(), d.begin() + gEd.start); nd.insert(nd.end(), props.begin(), props.end()); nd.insert(nd.end(), d.begin() + gEd.end, d.end());
    e.data = nd; e.owned = true; gDoc.dirty = true; LoadEdit(gEd.idx);
}

// ------------------------------------------------------------------ files
static std::wstring FileDialog(bool save, const std::wstring& initial) {
    wchar_t file[MAX_PATH] = { 0 }; if (!initial.empty()) wcsncpy(file, initial.c_str(), MAX_PATH - 1);
    const wchar_t* filter = L"Unreal packages (*.u;*.upk;*.umap;*.xxx)\0*.u;*.upk;*.umap;*.xxx\0All files\0*.*\0\0";
    OPENFILENAMEW of = {}; of.lStructSize = sizeof(of); of.hwndOwner = gHwnd; of.lpstrFilter = filter; of.lpstrFile = file; of.nMaxFile = MAX_PATH;
    of.Flags = save ? (OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST) : (OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST);
    BOOL ok = save ? GetSaveFileNameW(&of) : GetOpenFileNameW(&of); return ok ? file : L"";
}
static std::wstring RawDialog(bool save, const std::wstring& name) {
    wchar_t file[MAX_PATH] = { 0 }; wcsncpy(file, name.c_str(), MAX_PATH - 1);
    const wchar_t* filter = L"Raw data (*.bin)\0*.bin\0All files\0*.*\0\0";
    OPENFILENAMEW of = {}; of.lStructSize = sizeof(of); of.hwndOwner = gHwnd; of.lpstrFilter = filter; of.lpstrFile = file; of.nMaxFile = MAX_PATH; of.lpstrDefExt = L"bin";
    of.Flags = save ? (OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST) : (OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST);
    BOOL ok = save ? GetSaveFileNameW(&of) : GetOpenFileNameW(&of); return ok ? file : L"";
}
static void DoOpen(const std::wstring& p) {
    std::string err = gDoc.open(p); gDocGen++; gSel = 0; LoadEdit(0); gLastFilterKey = "\x01"; gClassFilter = -1;
    if (!err.empty()) Status(std::string(T(L_OPENFAIL)) + ": " + err);
    else { Status(gDoc.pk.wasCompressed ? std::string(T(L_DECOMP)) : U8(p)); SetSetting(L"LastFile", p); }
}
static void LvlCtxReleasePath(const std::wstring& path);   // level.hpp
static void ReleaseHoldsOn(const std::wstring& path);       // beta.hpp
static std::string WhoHolds(const std::wstring& path);      // roomimp.hpp
static bool DoSave(const std::wstring& target) {
    if (!gDoc.loaded) return false;
    if (gDoc.pk.bigEndian) { Status(T(L_BETA_RO)); return false; }
    LvlCtxReleasePath(target); ReleaseHoldsOn(target);
    std::wstring tmp = target + L".bmstudio_tmp";
    HANDLE h = CreateFileW(tmp.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL);
    if (h == INVALID_HANDLE_VALUE) { Status(std::string(T(L_SAVEFAIL)) + ": cannot create temp file"); return false; }
    bool ok = true;
    try { auto sink = [&](const u8* p, size_t n) { while (n && ok) { DWORD chunk = (DWORD)std::min<size_t>(n, 64u << 20), wr = 0; if (!WriteFile(h, p, chunk, &wr, NULL) || wr != chunk) ok = false; p += chunk; n -= chunk; } }; gDoc.pk.save(sink); }
    catch (std::exception& e) { ok = false; Status(std::string(T(L_SAVEFAIL)) + ": " + e.what()); }
    CloseHandle(h);
    if (!ok) { DeleteFileW(tmp.c_str()); if (gStatus.empty()) Status(T(L_SAVEFAIL)); return false; }
    i32 keepSel = gSel; std::wstring src = gDoc.path;
    bool same = _wcsicmp(target.c_str(), src.c_str()) == 0;
    bool backup = false;
    if (same) {
        gDoc.close();
        std::wstring bak = target + L".bak"; if (GetFileAttributesW(bak.c_str()) == INVALID_FILE_ATTRIBUTES) backup = CopyFileW(target.c_str(), bak.c_str(), TRUE) != 0;
    } else { gDoc.close(); }
    { BOOL mv = FALSE; for (int tr = 0; tr < 10 && !mv; tr++) { mv = MoveFileExW(tmp.c_str(), target.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH); if (!mv) Sleep(400); }   // antivirus locks it for a moment
      if (!mv) { DWORD er = GetLastError(); std::string who = WhoHolds(target); DeleteFileW(tmp.c_str()); char eb[48]; snprintf(eb, sizeof eb, " (error %lu)", er);
          Status(std::string(T(L_SAVEFAIL)) + ": " + T(L_RI_LOCKED) + eb + (who.empty() ? "" : " -> " + who)); DoOpen(src); return false; } }
    DoOpen(target); if (keepSel > 0 && keepSel <= (i32)gDoc.pk.exports.size()) { gSel = keepSel; LoadEdit(gSel); }
    Status(std::string(T(L_SAVED)) + (backup ? std::string("  ") + T(L_BACKUP) : ""));
    return true;
}
static void RequestAction(int action, const std::wstring& openPath = L"") {
    gPendingAction = action; gPendingOpen = openPath;
    if (gDoc.loaded && gDoc.dirty) { gAskUnsaved = true; return; }
    if (action == 1) { std::wstring p = openPath.empty() ? FileDialog(false, L"") : openPath; if (!p.empty()) DoOpen(p); }
    else if (action == 2) { gDoc.close(); gDocGen++; gSel = 0; LoadEdit(0); }
    else if (action == 3) gWantQuit = true;
    gPendingAction = 0;
}

// ------------------------------------------------------------------ property values
static std::string FNameStr(const u8* p) { FName f; memcpy(&f.idx, p, 4); memcpy(&f.num, p + 4, 4); return gDoc.pk.nm(f); }
static FName ParseFName(const std::string& s) {
    FName f; f.idx = gDoc.pk.findName(s); f.num = 0; if (f.idx >= 0) return f;
    size_t us = s.rfind('_');
    if (us != std::string::npos && us + 1 < s.size() && s.find_first_not_of("0123456789", us + 1) == std::string::npos) {
        i32 b = gDoc.pk.findName(s.substr(0, us)); if (b >= 0) { f.idx = b; f.num = atoi(s.c_str() + us + 1) + 1; return f; } }
    f.idx = gDoc.pk.addName(s); f.num = 0; return f;
}
static std::string ObjStr(i32 v) { if (v == 0) return "None"; if (v > 0 && v > (i32)gDoc.pk.exports.size()) return "?"; if (v < 0 && -v > (i32)gDoc.pk.imports.size()) return "?"; return gDoc.pk.objPath(v); }
static bool ValidObj(i32 v) { return v == 0 || (v > 0 && v <= (i32)gDoc.pk.exports.size()) || (v < 0 && -v <= (i32)gDoc.pk.imports.size()); }
static std::string HexPreview(const std::vector<u8>& b, size_t max = 32) { std::string s; char t[4]; for (size_t k = 0; k < b.size() && k < max; k++) { snprintf(t, 4, "%02X ", b[k]); s += t; } if (b.size() > max) s += "..."; return s; }

static void GotoObject(i32 idx) { if (idx > 0 && idx <= (i32)gDoc.pk.exports.size()) { gSel = idx; LoadEdit(idx); } }

// one editor per type; returns true if it changed
static bool EditValue(PropEdit& pe, int id) {
    Tag& t = pe.tag; ImGui::PushID(id); bool ch = false;
    ImGui::SetNextItemWidth(-FLT_MIN);
    if (t.isBool) { bool b = t.boolVal != 0; if (ImGui::Checkbox("##b", &b)) { t.boolVal = b ? 1 : 0; ch = true; } }
    else if (t.type == "IntProperty" && t.raw.size() == 4) { int v; memcpy(&v, t.raw.data(), 4); if (ImGui::InputInt("##i", &v, 0, 0)) { memcpy(t.raw.data(), &v, 4); ch = true; } }
    else if (t.type == "FloatProperty" && t.raw.size() == 4) { float v; memcpy(&v, t.raw.data(), 4); if (ImGui::InputFloat("##f", &v, 0, 0, "%.6g")) { memcpy(t.raw.data(), &v, 4); ch = true; } }
    else if (t.type == "ByteProperty" && t.raw.size() == 1) { int v = t.raw[0]; if (ImGui::InputInt("##by", &v, 0, 0)) { t.raw[0] = (u8)std::max(0, std::min(255, v)); ch = true; } }
    else if (t.type == "ByteProperty" && t.raw.size() == 8) {           // enum by name
        if (!pe.init) { pe.text = FNameStr(t.raw.data()); pe.init = true; }
        char buf[256]; snprintf(buf, sizeof buf, "%s", pe.text.c_str());
        if (ImGui::InputText("##en", buf, sizeof buf)) pe.text = buf;
        if (ImGui::IsItemDeactivatedAfterEdit()) { FName f = ParseFName(pe.text); memcpy(t.raw.data(), &f.idx, 4); memcpy(t.raw.data() + 4, &f.num, 4); pe.init = false; ch = true; } }
    else if (t.type == "NameProperty" && t.raw.size() == 8) {
        if (!pe.init) { pe.text = FNameStr(t.raw.data()); pe.init = true; }
        char buf[256]; snprintf(buf, sizeof buf, "%s", pe.text.c_str());
        if (ImGui::InputText("##n", buf, sizeof buf)) pe.text = buf;
        if (ImGui::IsItemDeactivatedAfterEdit()) { FName f = ParseFName(pe.text); memcpy(t.raw.data(), &f.idx, 4); memcpy(t.raw.data() + 4, &f.num, 4); pe.init = false; ch = true; } }
    else if (t.type == "StrProperty") {
        if (!pe.init) { try { Reader r(t.raw.data(), t.raw.size()); pe.text = r.fstr(); } catch (...) { pe.text = ""; } pe.init = true; }
        char buf[1024]; snprintf(buf, sizeof buf, "%s", pe.text.c_str());
        if (ImGui::InputText("##s", buf, sizeof buf)) pe.text = buf;
        if (ImGui::IsItemDeactivatedAfterEdit()) { Writer w; w.fstr(pe.text); t.raw = w.b; pe.init = false; ch = true; } }
    else if ((t.type == "ObjectProperty" || t.type == "ComponentProperty" || t.type == "ClassProperty" || t.type == "InterfaceProperty") && t.raw.size() == 4) {
        i32 v = tagObj(t); if (!pe.init) { pe.text = ObjStr(v); pe.init = true; }
        char buf[512]; snprintf(buf, sizeof buf, "%s", pe.text.c_str());
        float bw = ImGui::GetFrameHeight() * 1.6f; ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - bw - 4);
        if (ImGui::InputText("##o", buf, sizeof buf)) { pe.text = buf; pe.bad = false; }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_OBJHINT));
        if (ImGui::IsItemDeactivatedAfterEdit()) {
            i32 nv = 0; std::string s = pe.text; if (s != "None" && !s.empty()) nv = gDoc.pk.findPath(s);
            if (s == "None" || s.empty() || nv != 0) { memcpy(t.raw.data(), &nv, 4); pe.init = false; pe.bad = false; ch = true; } else pe.bad = true; }
        ImGui::SameLine(); if (ImGui::Button("->", ImVec2(bw, 0)) && v > 0) GotoObject(v);
        if (pe.bad) ImGui::TextColored(ImVec4(1, 0.4f, 0.4f, 1), "%s", T(L_NOTFOUND)); }
    else if (t.type == "StructProperty" && (t.strct == "Vector" && t.raw.size() == 12)) { float v[3]; memcpy(v, t.raw.data(), 12); if (ImGui::InputFloat3("##v", v, "%.3f")) { memcpy(t.raw.data(), v, 12); ch = true; } }
    else if (t.type == "StructProperty" && (t.strct == "Rotator" && t.raw.size() == 12)) { int v[3]; memcpy(v, t.raw.data(), 12); if (ImGui::InputInt3("##r", v)) { memcpy(t.raw.data(), v, 12); ch = true; } }
    else if (t.type == "StructProperty" && (t.strct == "Vector2D" && t.raw.size() == 8)) { float v[2]; memcpy(v, t.raw.data(), 8); if (ImGui::InputFloat2("##v2", v, "%.3f")) { memcpy(t.raw.data(), v, 8); ch = true; } }
    else if (t.type == "StructProperty" && (t.strct == "LinearColor" && t.raw.size() == 16)) { float v[4]; memcpy(v, t.raw.data(), 16); if (ImGui::ColorEdit4("##lc", v, ImGuiColorEditFlags_Float | ImGuiColorEditFlags_HDR)) { memcpy(t.raw.data(), v, 16); ch = true; } }
    else if (t.type == "StructProperty" && (t.strct == "Color" && t.raw.size() == 4)) {
        float v[4] = { t.raw[2] / 255.f, t.raw[1] / 255.f, t.raw[0] / 255.f, t.raw[3] / 255.f };      // BGRA
        if (ImGui::ColorEdit4("##c", v)) { t.raw[2] = (u8)(v[0] * 255 + .5f); t.raw[1] = (u8)(v[1] * 255 + .5f); t.raw[0] = (u8)(v[2] * 255 + .5f); t.raw[3] = (u8)(v[3] * 255 + .5f); ch = true; } }
    else if (t.type == "ArrayProperty" && t.raw.size() >= 4) {
        i32 cnt; memcpy(&cnt, t.raw.data(), 4); size_t body = t.raw.size() - 4;
        if (cnt > 0 && body == (size_t)cnt * 4 && ImGui::TreeNode("##arr", "[%d %s]", cnt, T(L_ELEMENTS))) {
            for (i32 k = 0; k < cnt && k < 4096; k++) { i32 v; memcpy(&v, t.raw.data() + 4 + k * 4, 4);
                ImGui::PushID(k); ImGui::Text("[%d]", k); ImGui::SameLine();
                ImGui::SetNextItemWidth(120); if (ImGui::InputInt("##ai", &v, 0, 0)) { memcpy(t.raw.data() + 4 + k * 4, &v, 4); ch = true; }
                if (ValidObj(v) && v != 0) { ImGui::SameLine(); ImGui::TextDisabled("%s", ObjStr(v).c_str()); if (v > 0) { ImGui::SameLine(); if (ImGui::SmallButton("->")) GotoObject(v); } }
                ImGui::PopID(); }
            ImGui::TreePop(); }
        else if (!(cnt > 0 && body == (size_t)cnt * 4)) ImGui::TextDisabled("[%d %s] %s", cnt, T(L_ELEMENTS), HexPreview(std::vector<u8>(t.raw.begin() + 4, t.raw.end()), 24).c_str());
    }
    else if (t.type == "StructProperty") {
        size_t end = 0; bool nested = false; std::vector<Tag> sub;
        try { sub = readProps(gDoc.pk, t.raw.data(), t.raw.size(), 0, &end); nested = end == t.raw.size() && !sub.empty(); } catch (...) {}
        if (nested && ImGui::TreeNode("##st", "{%zu}", sub.size())) {
            for (auto& s : sub) ImGui::BulletText("%s : %s  %s", s.name.c_str(), s.type.c_str(), s.isBool ? (s.boolVal ? "true" : "false") : HexPreview(s.raw, 16).c_str());
            ImGui::TreePop(); }
        else if (!nested) ImGui::TextDisabled("%s", HexPreview(t.raw).c_str());
    }
    else ImGui::TextDisabled("%s", HexPreview(t.raw).c_str());
    ImGui::PopID(); return ch;
}

// ------------------------------------------------------------------ panels
static void ObjectRow(i32 idx, bool tree) {
    const Export& e = gDoc.pk.exports[idx - 1];
    std::string cls = gDoc.pk.classOf(e), nm = gDoc.pk.nm(e.name);
    ImGuiTreeNodeFlags fl = ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_SpanAvailWidth | ImGuiTreeNodeFlags_OpenOnDoubleClick;
    bool leaf = !tree || gDoc.children[idx].empty(); if (leaf) fl |= ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen;
    if (gSel == idx) fl |= ImGuiTreeNodeFlags_Selected;
    bool edited = e.owned;
    std::string label = (tree ? nm : gDoc.path_(idx)) + "   ";
    bool open = ImGui::TreeNodeEx((void*)(intptr_t)idx, fl, "%s%s", edited ? "* " : "", label.c_str());
    if (ImGui::IsItemClicked() && !ImGui::IsItemToggledOpen()) { gSel = idx; LoadEdit(idx); }
    ImGui::SameLine(); ImGui::TextDisabled("%s", cls.c_str());
    if (open && !leaf) { for (i32 c : gDoc.children[idx]) ObjectRow(c, true); ImGui::TreePop(); }
}
static void LeftPanel() {
    if (!ImGui::BeginTabBar("left")) return;
    if (ImGui::BeginTabItem(T(L_OBJECTS))) {
        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * 0.55f); ImGui::InputTextWithHint("##search", T(L_SEARCH), gSearch, sizeof gSearch);
        ImGui::SameLine(); ImGui::SetNextItemWidth(-FLT_MIN);
        const char* cprev = gClassFilter < 0 ? T(L_ALL) : gDoc.classes[gClassFilter].c_str();
        if (ImGui::BeginCombo("##cls", cprev, ImGuiComboFlags_HeightLarge)) {
            if (ImGui::Selectable(T(L_ALL), gClassFilter < 0)) gClassFilter = -1;
            for (int k = 0; k < (int)gDoc.classes.size(); k++) if (ImGui::Selectable(gDoc.classes[k].c_str(), gClassFilter == k)) gClassFilter = k;
            ImGui::EndCombo(); }
        bool filtering = gSearch[0] || gClassFilter >= 0;
        if (!filtering) { ImGui::RadioButton(T(L_TREE), &gFlat, 0); ImGui::SameLine(); ImGui::RadioButton(T(L_FLAT), &gFlat, 1); }
        ImGui::BeginChild("objs", ImVec2(0, 0), ImGuiChildFlags_Borders);
        if (!filtering && !gFlat) { for (i32 r : gDoc.roots) ObjectRow(r, true); }
        else {
            std::string key = std::string(gSearch) + "|" + std::to_string(gClassFilter) + "|" + std::to_string(gDoc.pk.exports.size());
            if (key != gLastFilterKey) { gLastFilterKey = key; gFiltered.clear();
                const std::string* cf = gClassFilter >= 0 ? &gDoc.classes[gClassFilter] : nullptr;
                for (size_t k = 0; k < gDoc.pk.exports.size(); k++) { i32 idx = (i32)k + 1;
                    if (cf && gDoc.pk.classOf(gDoc.pk.exports[k]) != *cf) continue;
                    if (gSearch[0] && !icontains(gDoc.path_(idx), gSearch)) continue;
                    gFiltered.push_back(idx); } }
            ImGuiListClipper clip; clip.Begin((int)gFiltered.size());
            while (clip.Step()) for (int r = clip.DisplayStart; r < clip.DisplayEnd; r++) ObjectRow(gFiltered[r], false);
        }
        ImGui::EndChild(); ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem(T(L_IMPORTS))) {
        if (ImGui::BeginTable("imp", 3, ImGuiTableFlags_ScrollY | ImGuiTableFlags_RowBg | ImGuiTableFlags_Resizable | ImGuiTableFlags_BordersInnerV)) {
            ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableSetupColumn("#", ImGuiTableColumnFlags_WidthFixed, 60); ImGui::TableSetupColumn(T(L_PATH)); ImGui::TableSetupColumn(T(L_CLASS)); ImGui::TableHeadersRow();
            ImGuiListClipper clip; clip.Begin((int)gDoc.pk.imports.size());
            while (clip.Step()) for (int r = clip.DisplayStart; r < clip.DisplayEnd; r++) { const Import& im = gDoc.pk.imports[r];
                ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::Text("%d", -(r + 1)); ImGui::TableNextColumn(); ImGui::TextUnformatted(gDoc.pk.objPath(-(r + 1)).c_str());
                ImGui::TableNextColumn(); ImGui::TextDisabled("%s.%s", gDoc.pk.nm(im.classPkg).c_str(), gDoc.pk.nm(im.className).c_str()); }
            ImGui::EndTable(); }
        ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem(T(L_NAMES))) {
        static char nbuf[256] = ""; ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - 110); ImGui::InputTextWithHint("##nn", T(L_ADDNAME), nbuf, sizeof nbuf); ImGui::SameLine();
        if (ImGui::Button(T(L_ADD), ImVec2(-FLT_MIN, 0)) && nbuf[0]) { size_t before = gDoc.pk.names.size(); gDoc.pk.addName(nbuf); if (gDoc.pk.names.size() != before) gDoc.dirty = true; nbuf[0] = 0; }
        if (ImGui::BeginTable("nm", 2, ImGuiTableFlags_ScrollY | ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerV)) {
            ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableSetupColumn("#", ImGuiTableColumnFlags_WidthFixed, 60); ImGui::TableSetupColumn(T(L_NAME)); ImGui::TableHeadersRow();
            ImGuiListClipper clip; clip.Begin((int)gDoc.pk.names.size());
            while (clip.Step()) for (int r = clip.DisplayStart; r < clip.DisplayEnd; r++) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::Text("%d", r); ImGui::TableNextColumn(); ImGui::TextUnformatted(gDoc.pk.names[r].first.c_str()); }
            ImGui::EndTable(); }
        ImGui::EndTabItem();
    }
    ImGui::EndTabBar();
}
static LPDIRECT3D9 gD3D = NULL; static LPDIRECT3DDEVICE9 gDev = NULL; static bool gLost = false; static UINT gResW = 0, gResH = 0; static D3DPRESENT_PARAMETERS gPP = {};
#include "viewer.hpp"
#include "level.hpp"
#include "script.hpp"
#include "import.hpp"
#include "copy.hpp"
#include "propedit.hpp"
#include "animimp.hpp"
#include "roomimp.hpp"
#include "collision.hpp"
#include "library.hpp"
#include "beta.hpp"
#include "hole.hpp"
#include "ucc_ui.hpp"
static void HexView(const u8* d, size_t n, size_t absBase, long propStart, size_t propEnd) {
    if (gMono) ImGui::PushFont(gMono);
    ImGuiListClipper clip; clip.Begin((int)((n + 15) / 16));
    while (clip.Step()) for (int row = clip.DisplayStart; row < clip.DisplayEnd; row++) {
        size_t o = (size_t)row * 16; char line[128]; int p = snprintf(line, sizeof line, "%08zX  ", o);
        ImGui::TextDisabled("%08zX", o); ImGui::SameLine();
        for (int k = 0; k < 16; k++) { size_t i = o + k; if (k) ImGui::SameLine(0, (k == 8) ? 10.f : 4.f);
            if (i < n) { bool inProps = propStart >= 0 && i >= (size_t)propStart && i < propEnd;
                if (inProps) ImGui::TextColored(ImVec4(0.55f, 0.85f, 1.f, 1.f), "%02X", d[i]); else ImGui::Text("%02X", d[i]); }
            else ImGui::TextUnformatted("  "); }
        ImGui::SameLine(0, 14); std::string a; for (int k = 0; k < 16 && o + k < n; k++) { u8 c = d[o + k]; a += (c >= 32 && c < 127) ? (char)c : '.'; }
        ImGui::TextDisabled("%s", a.c_str()); (void)p; (void)line; (void)absBase;
    }
    if (gMono) ImGui::PopFont();
}
static void RightPanel() {
    if (gSel <= 0 || gSel > (i32)gDoc.pk.exports.size()) { ImGui::TextDisabled("%s", T(L_SELECT)); return; }
    Export& e = gDoc.pk.exports[gSel - 1];
    ImGui::TextUnformatted(gDoc.path_(gSel).c_str()); ImGui::SameLine();
    if (ImGui::SmallButton(T(L_COPYPATH))) ImGui::SetClipboardText(gDoc.path_(gSel).c_str());
    if (!gDoc.pk.bigEndian) { ImGui::SameLine(); if (ImGui::SmallButton(T(L_CP_REPLACEBY))) CopyBegin(gSel); }
    else { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, .8f, .35f, 1), "[beta Xbox 360]");
        if (BetaConvertible(gSel)) { ImGui::SameLine(); if (ImGui::SmallButton(T(L_BT_VIEWOBJ))) { i32 x = gSel; gDeferred = [x] { BetaPreviewObject(x); }; } if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_BT_VIEWOBJ_TIP));
            ImGui::SameLine(); if (ImGui::SmallButton(T(L_BT_CONVBTN))) { i32 x = gSel; gDeferred = [x] { BetaConvertSelected(x); }; } if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_BT_CONVBTN_TIP)); }
        ImGui::SameLine(); if (ImGui::SmallButton(T(L_BT_VIEWROOM))) gDeferred = [] { BetaPreviewCurrent(); };
        ImGui::SameLine(); if (ImGui::SmallButton(T(L_BT_MENU))) gBeta.open = true; }
    if (e.owned) { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, 0.75f, 0.3f, 1), "(%s)", T(L_EDITED)); }
    ImGui::Separator();
    if (!ImGui::BeginTabBar("right")) return;
    if (ImGui::BeginTabItem(T(L_PROPERTIES))) {
        if (gEd.idx != gSel) LoadEdit(gSel);
        if (gEd.start < 0) { ImGui::TextDisabled("%s", T(L_NOPROPS)); if (!gEd.err.empty()) ImGui::TextColored(ImVec4(1, .4f, .4f, 1), "%s", gEd.err.c_str()); }
        else if (gDoc.pk.bigEndian) {   // beta: read only (values converted from big-endian)
            ImGui::TextColored(ImVec4(1, .8f, .35f, 1), "%s", T(L_BETA_RO));
            if (ImGui::BeginTable("propsbe", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_Resizable | ImGuiTableFlags_BordersInnerV | ImGuiTableFlags_ScrollY)) {
                ImGui::TableSetupScrollFreeze(0, 1);
                ImGui::TableSetupColumn(T(L_NAME), ImGuiTableColumnFlags_WidthStretch, 0.32f); ImGui::TableSetupColumn(T(L_TYPE), ImGuiTableColumnFlags_WidthStretch, 0.2f); ImGui::TableSetupColumn(T(L_VALUE), ImGuiTableColumnFlags_WidthStretch, 0.48f);
                ImGui::TableHeadersRow();
                for (size_t k = 0; k < gEd.props.size(); k++) { PropEdit& pe = gEd.props[k];
                    ImGui::TableNextRow(); ImGui::TableNextColumn();
                    if (pe.tag.index) ImGui::Text("%s[%d]", pe.tag.name.c_str(), pe.tag.index); else ImGui::TextUnformatted(pe.tag.name.c_str());
                    ImGui::TableNextColumn(); ImGui::TextDisabled("%s", pe.tag.strct.empty() ? pe.tag.type.c_str() : pe.tag.strct.c_str());
                    ImGui::TableNextColumn(); PropEdit copy = pe; EditValue(copy, (int)k); }   // copy: nothing is written
                ImGui::EndTable(); }
        }
        else {
            ImGui::BeginDisabled(!gEd.pending);
            if (ImGui::Button(T(L_APPLY))) ApplyEdit();
            ImGui::EndDisabled(); ImGui::SameLine();
            if (ImGui::Button(T(L_REVERT))) { if (gEd.pending) LoadEdit(gSel); else if (e.owned) { e.owned = false; e.data.clear(); LoadEdit(gSel); } }
            if (gEd.pending) { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, .75f, .3f, 1), "%s", T(L_MODIFIED)); }
            gPeDb = EnsureTypeDB();
            if (gPeDb) { std::vector<Tag> tags; for (auto& p : gEd.props) tags.push_back(p.tag);
                if (PeTags(tags, false, gDoc.pk.classOf(e), 0)) { gEd.props.clear(); for (auto& t : tags) { PropEdit pe; pe.tag = t; gEd.props.push_back(pe); } gEd.pending = true; } }
            else if (ImGui::BeginTable("props", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_Resizable | ImGuiTableFlags_BordersInnerV | ImGuiTableFlags_ScrollY)) {
                ImGui::TableSetupScrollFreeze(0, 1);
                ImGui::TableSetupColumn(T(L_NAME), ImGuiTableColumnFlags_WidthStretch, 0.32f); ImGui::TableSetupColumn(T(L_TYPE), ImGuiTableColumnFlags_WidthStretch, 0.2f); ImGui::TableSetupColumn(T(L_VALUE), ImGuiTableColumnFlags_WidthStretch, 0.48f);
                ImGui::TableHeadersRow();
                for (size_t k = 0; k < gEd.props.size(); k++) { PropEdit& pe = gEd.props[k];
                    ImGui::TableNextRow(); ImGui::TableNextColumn();
                    if (pe.tag.index) ImGui::Text("%s[%d]", pe.tag.name.c_str(), pe.tag.index); else ImGui::TextUnformatted(pe.tag.name.c_str());
                    ImGui::TableNextColumn(); ImGui::TextDisabled("%s", pe.tag.strct.empty() ? pe.tag.type.c_str() : pe.tag.strct.c_str());
                    ImGui::TableNextColumn(); if (EditValue(pe, (int)k)) gEd.pending = true; }
                ImGui::EndTable(); }
        }
        ImGui::EndTabItem();
    }
    if (!gDoc.pk.bigEndian && gPeDb && gEd.idx == gSel && gEd.start >= 0 && ImGui::BeginTabItem(T(L_PE_NATIVETAB))) { PeNativeRefs(gSel, gEd.end); ImGui::EndTabItem(); }
    if (!gDoc.pk.bigEndian && PreviewAvailable(gSel) && ImGui::BeginTabItem(T(L_PREVIEW), nullptr, gOpenPreviewTab ? ImGuiTabItemFlags_SetSelected : 0)) { gOpenPreviewTab = false; PreviewTab(); ImGui::EndTabItem(); }
    if (!gDoc.pk.bigEndian && ScriptTabAvailable(gSel) && ImGui::BeginTabItem("Script", nullptr, gOpenScriptTab ? ImGuiTabItemFlags_SetSelected : 0)) { gOpenScriptTab = false; ScriptTab(); ImGui::EndTabItem(); }
    if (ImGui::BeginTabItem(T(L_INFO))) {
        if (ImGui::BeginTable("info", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerV)) {
            ImGui::TableSetupColumn("k", ImGuiTableColumnFlags_WidthFixed, 140);
            auto row = [](const char* k, const std::string& v) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextDisabled("%s", k); ImGui::TableNextColumn(); ImGui::TextUnformatted(v.c_str()); };
            char b[64];
            row(T(L_INDEX), std::to_string(gSel)); row(T(L_CLASS), gDoc.pk.classOf(e) + (e.cls < 0 ? "  (" + gDoc.pk.objPath(e.cls) + ")" : ""));
            row(T(L_OUTER), ObjStr(e.outer)); row(T(L_SUPER), ObjStr(e.super_)); row(T(L_ARCHETYPE), ObjStr(e.archetype));
            snprintf(b, sizeof b, "0x%016llX", (unsigned long long)e.flags); row(T(L_FLAGS), b);
            row(T(L_SIZE), std::to_string(gDoc.pk.dataLen(e)) + (e.owned ? "  (" + std::string(T(L_EDITED)) + ", orig. " + std::to_string(e.serialSize) + ")" : ""));
            snprintf(b, sizeof b, "0x%X (%d)", e.serialOffset, e.serialOffset); row(T(L_OFFSET), b);
            ImGui::EndTable(); }
        ImGui::Spacing();
        if (ImGui::Button(T(L_EXPORTRAW))) { std::wstring f = RawDialog(true, W(gDoc.pk.nm(e.name)) + L".bin"); if (!f.empty()) { std::vector<u8> d = gDoc.pk.dataCopy(e);
            HANDLE h = CreateFileW(f.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL); DWORD wr = 0; if (h != INVALID_HANDLE_VALUE) { WriteFile(h, d.data(), (DWORD)d.size(), &wr, NULL); CloseHandle(h); } Status(U8(f)); } }
        if (!gDoc.pk.bigEndian) ImGui::SameLine();
        if (!gDoc.pk.bigEndian && ImGui::Button(T(L_IMPORTRAW))) { std::wstring f = RawDialog(false, L""); if (!f.empty()) { HANDLE h = CreateFileW(f.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
            if (h != INVALID_HANDLE_VALUE) { DWORD n = GetFileSize(h, NULL), rd = 0; std::vector<u8> d(n); ReadFile(h, d.data(), n, &rd, NULL); CloseHandle(h);
                e.data = d; e.owned = true; gDoc.dirty = true; LoadEdit(gSel); Status(U8(f)); } } }
        ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem(T(L_HEX))) {
        ImGui::BeginChild("hex", ImVec2(0, 0), ImGuiChildFlags_None, ImGuiWindowFlags_HorizontalScrollbar);
        HexView(gDoc.pk.dataPtr(e), gDoc.pk.dataLen(e), (size_t)e.serialOffset, gEd.idx == gSel ? gEd.start : -1, gEd.end);
        ImGui::EndChild(); ImGui::EndTabItem();
    }
    ImGui::EndTabBar();
}
static void Frame() {
    ImGuiViewport* vp = ImGui::GetMainViewport(); ImGui::SetNextWindowPos(vp->WorkPos); ImGui::SetNextWindowSize(vp->WorkSize);
    ImGui::Begin("main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_MenuBar | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoSavedSettings);
    if (ImGui::BeginMenuBar()) {
        if (ImGui::BeginMenu(T(L_FILE))) {
            if (ImGui::MenuItem(T(L_OPEN), "Ctrl+O")) RequestAction(1);
            if (ImGui::MenuItem(T(L_SAVE), "Ctrl+S", false, gDoc.loaded && !gDoc.pk.bigEndian)) SaveChecked(gDoc.path);
            if (ImGui::MenuItem(T(L_SAVEAS), nullptr, false, gDoc.loaded && !gDoc.pk.bigEndian)) { std::wstring p = FileDialog(true, gDoc.path); if (!p.empty()) SaveChecked(p); }
            if (ImGui::MenuItem(T(L_SV_CHECK), nullptr, false, gDoc.loaded && !gDoc.pk.bigEndian)) CheckPackage();
            if (ImGui::MenuItem(T(L_CLOSE), nullptr, false, gDoc.loaded)) RequestAction(2);
            ImGui::Separator(); if (ImGui::MenuItem(T(L_CP_MENU), nullptr, false, gDoc.loaded && !gDoc.pk.bigEndian)) CopyBegin(0);
            if (ImGui::MenuItem(T(L_BT_MENU), nullptr, false, gDoc.loaded && gDoc.pk.bigEndian)) gBeta.open = true;
            if (ImGui::MenuItem(T(L_BE_MENU), nullptr, false, gDoc.loaded && gDoc.pk.bigEndian)) { gBE.forPath.clear(); gBE.open = true; }
            ImGui::Separator(); if (ImGui::MenuItem(T(L_EXIT))) RequestAction(3);
            ImGui::EndMenu(); }
        if (ImGui::BeginMenu(T(L_VIEW))) {
            if (ImGui::MenuItem(T(L_LVL_VIEWPORT), "Ctrl+L", gLevelMode, PackageHasLevel() || (gDoc.loaded && gDoc.pk.bigEndian))) { if (gDoc.pk.bigEndian) BetaPreviewCurrent(); else gLevelMode = !gLevelMode; }
            if (ImGui::MenuItem(T(L_SC_SEARCH), "Ctrl+F", gSs.open, gDoc.loaded)) gSs.open = !gSs.open;
            if (ImGui::MenuItem(T(L_LB_MENU), "Ctrl+B", gLib.open)) { if (gLib.open) gLib.open = false; else LibOpen(); }
            ImGui::EndMenu(); }
        if (ImGui::BeginMenu(T(L_LANGUAGE))) {
#ifdef BM_HAS_PTBR
            if (ImGui::MenuItem(LANG_NAME_PTBR, nullptr, gLang == 0)) { gLang = 0; SetSetting(L"Language", L"pt-BR"); }
#endif
            if (ImGui::MenuItem("English", nullptr, gLang == 1)) { gLang = 1; SetSetting(L"Language", L"en"); }
            ImGui::EndMenu(); }
        if (ImGui::BeginMenu(T(L_HELP))) { if (ImGui::MenuItem(T(L_ABOUT))) ImGui::OpenPopup("about_popup"); ImGui::EndMenu(); }
        ImGui::EndMenuBar(); }
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_O)) RequestAction(1);
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_S) && gDoc.loaded && !gDoc.pk.bigEndian) SaveChecked(gDoc.path);
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_L) && PackageHasLevel()) gLevelMode = !gLevelMode;
    else if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_L) && gDoc.loaded && gDoc.pk.bigEndian) BetaPreviewCurrent();
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_F) && gDoc.loaded) gSs.open = true;
    if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_B)) LibOpen();
    if (gLevelMode && !PackageHasLevel()) gLevelMode = false;
    if (!gLevelMode && gLvl.gen >= 0 && gLvl.gen != gDocGen) { LevelClear(); gLvl.gen = -1; }   // releases the GPU resources of the previous level

    float statusH = ImGui::GetFrameHeightWithSpacing();
    if (!gDoc.loaded) { ImGui::BeginChild("empty", ImVec2(0, -statusH)); ImGui::Dummy(ImVec2(0, 40)); ImGui::TextUnformatted(T(L_NOFILE)); ImGui::TextDisabled("%s", T(L_DROPHINT)); ImGui::EndChild(); }
    else if (gLevelMode) { ImGui::BeginChild("level", ImVec2(0, -statusH)); LevelView(); ImGui::EndChild(); }
    else {
        static float leftW = 460.f; float avail = ImGui::GetContentRegionAvail().x;
        ImGui::BeginChild("left", ImVec2(leftW, -statusH), ImGuiChildFlags_None); LeftPanel(); ImGui::EndChild();
        ImGui::SameLine(); ImGui::InvisibleButton("split", ImVec2(6, ImGui::GetContentRegionAvail().y - statusH));
        if (ImGui::IsItemActive()) leftW = std::max(220.f, std::min(avail - 300.f, leftW + ImGui::GetIO().MouseDelta.x));
        if (ImGui::IsItemHovered() || ImGui::IsItemActive()) ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeEW);
        ImGui::SameLine(); ImGui::BeginChild("right", ImVec2(0, -statusH), ImGuiChildFlags_None); RightPanel(); ImGui::EndChild();
    }
    ImGui::Separator();
    if (gDoc.loaded) { ImGui::Text(T(L_STATUS_OBJS), (int)gDoc.pk.exports.size(), (int)gDoc.pk.imports.size(), (int)gDoc.pk.names.size()); ImGui::SameLine(); ImGui::TextDisabled("| %s%s", U8(gDoc.path).c_str(), gDoc.dirty ? "  *" : ""); }
    if (!gStatus.empty() && ImGui::GetTime() < gStatusUntil) { ImGui::SameLine(); ImGui::TextColored(ImVec4(0.5f, 1, 0.6f, 1), "  %s", gStatus.c_str()); }

    ScriptSearchWindow();
    ImportWindow();
    CopyWindow();
    AnimImpWindow();
    RimpWindow();
    LibWindow();
    if (gDeferred) { auto f = std::move(gDeferred); gDeferred = nullptr; try { f(); } catch (std::exception& ex) { Status(std::string("ERROR: ") + ex.what()); } }
    BetaWindow(); BetaEnemyWindow(); BetaPreviewBar(); BetaPreviewPump(); BetaAutoTest(); BetaEnemyAutoTest(); BetaPrevAllTest(); HoleAutoTest();
    { static bool done = false; wchar_t b[512]; if (!done && gDoc.loaded) { done = true; if (GetEnvironmentVariableW(L"BMS_SELECT", b, 512)) { i32 x = gDoc.pk.findPath(U8(b)); if (x > 0) { gSel = x; LoadEdit(x); if (GetEnvironmentVariableW(L"BMS_PREVIEW", b, 512)) gOpenPreviewTab = true; } } if (GetEnvironmentVariableW(L"BMS_CHECK", b, 512)) CheckPackage(); } }   // test
    CodeEditorWindow();
    SaveProblemsPopup();
    if (ImGui::BeginPopupModal("about_popup", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) { ImGui::TextUnformatted(T(L_ABOUTTEXT)); if (ImGui::Button("OK", ImVec2(120, 0))) ImGui::CloseCurrentPopup(); ImGui::EndPopup(); }
    if (gAskUnsaved) { ImGui::OpenPopup("unsaved"); gAskUnsaved = false; }
    if (ImGui::BeginPopupModal("unsaved", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted(T(L_UNSAVEDQ));
        int act = gPendingAction; std::wstring op = gPendingOpen;
        if (ImGui::Button(T(L_YES), ImVec2(110, 0))) { ImGui::CloseCurrentPopup(); if (SaveChecked(gDoc.path)) { gDoc.dirty = false; RequestAction(act, op); } }
        ImGui::SameLine(); if (ImGui::Button(T(L_NO), ImVec2(110, 0))) { ImGui::CloseCurrentPopup(); gDoc.dirty = false; RequestAction(act, op); }
        ImGui::SameLine(); if (ImGui::Button(T(L_CANCEL), ImVec2(110, 0))) { ImGui::CloseCurrentPopup(); gPendingAction = 0; }
        ImGui::EndPopup(); }
    ImGui::End();
}

// ------------------------------------------------------------------ Win32 + D3D9 (based on the official Dear ImGui example)
static bool CreateDevice(HWND h) {
    if ((gD3D = Direct3DCreate9(D3D_SDK_VERSION)) == NULL) return false;
    ZeroMemory(&gPP, sizeof(gPP)); gPP.Windowed = TRUE; gPP.SwapEffect = D3DSWAPEFFECT_DISCARD; gPP.BackBufferFormat = D3DFMT_UNKNOWN; gPP.EnableAutoDepthStencil = TRUE;
    gPP.AutoDepthStencilFormat = D3DFMT_D16; gPP.PresentationInterval = D3DPRESENT_INTERVAL_ONE;
    if (gD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, h, D3DCREATE_HARDWARE_VERTEXPROCESSING, &gPP, &gDev) < 0 &&
        gD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, h, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &gPP, &gDev) < 0) return false;
    return true;
}
// D3D9 Reset: EVERY D3DPOOL_DEFAULT resource has to be released first, otherwise the Reset fails and the program hangs
// (that was the hang on minimize/restore: the Library render target was not released)
static void LibReleaseRT() { if (gLib.rt) gLib.rt->Release(); if (gLib.ds) gLib.ds->Release(); gLib.rt = nullptr; gLib.ds = nullptr; gLib.rtW = gLib.rtH = 0; }
static bool ResetDevice() {
    ImGui_ImplDX9_InvalidateDeviceObjects(); PreviewOnDeviceLost(); LevelReleaseRT(); LibReleaseRT();
    HRESULT hr = gDev->Reset(&gPP);
    ImGui_ImplDX9_CreateDeviceObjects();
    return SUCCEEDED(hr);
}
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
static LRESULT WINAPI WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (ImGui_ImplWin32_WndProcHandler(h, msg, wp, lp)) return true;
    switch (msg) {
    case WM_SIZE: if (wp == SIZE_MINIMIZED) return 0; gResW = LOWORD(lp); gResH = HIWORD(lp); return 0;
    case WM_SYSCOMMAND: if ((wp & 0xfff0) == SC_KEYMENU) return 0; break;
    case WM_DROPFILES: { wchar_t f[MAX_PATH]; if (DragQueryFileW((HDROP)wp, 0, f, MAX_PATH)) RequestAction(1, f); DragFinish((HDROP)wp); return 0; }
    case WM_CLOSE: RequestAction(3); return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}
int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, LPWSTR cmd, int show) {
    ImGui_ImplWin32_EnableDpiAwareness();
    std::wstring l = GetSetting(L"Language");
#ifdef BM_HAS_PTBR
    if (l.empty()) gLang = (PRIMARYLANGID(GetUserDefaultUILanguage()) == LANG_PORTUGUESE) ? 0 : 1; else gLang = (l == L"en") ? 1 : 0;
#else
    gLang = 1;
#endif
    float scale = ImGui_ImplWin32_GetDpiScaleForMonitor(MonitorFromPoint(POINT{ 0, 0 }, MONITOR_DEFAULTTOPRIMARY));
    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, inst, LoadIconW(inst, MAKEINTRESOURCEW(1)), NULL, NULL, NULL, L"BmStudioWnd", NULL };
    RegisterClassExW(&wc);
    gHwnd = CreateWindowW(wc.lpszClassName, L"BmStudio", WS_OVERLAPPEDWINDOW, 80, 60, (int)(1400 * scale), (int)(860 * scale), NULL, NULL, inst, NULL);
    if (!CreateDevice(gHwnd)) { MessageBoxW(NULL, L"Direct3D 9 not available.", L"BmStudio", MB_ICONERROR); return 1; }
    DragAcceptFiles(gHwnd, TRUE);
    ShowWindow(gHwnd, SW_SHOWDEFAULT); UpdateWindow(gHwnd);
    IMGUI_CHECKVERSION(); ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO(); io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard; io.IniFilename = NULL;
    io.ConfigWindowsMoveFromTitleBarOnly = true;   // windows only move by the title bar (dragging inside them does not move them)
    ImGui::StyleColorsDark(); ImGuiStyle& st = ImGui::GetStyle(); st.FrameRounding = 3; st.WindowRounding = 0; st.ScaleAllSizes(scale);
    ImFontConfig fc; fc.OversampleH = 2;
    static const ImWchar ranges[] = { 0x0020, 0x00FF, 0x2013, 0x2026, 0 };
    auto fontFile = [](const wchar_t* name) { wchar_t win[MAX_PATH] = { 0 }; GetWindowsDirectoryW(win, MAX_PATH); std::wstring p = std::wstring(win) + L"\\Fonts\\" + name; return GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES ? U8(p) : std::string(); };
    std::string fUi = fontFile(L"segoeui.ttf"), fMono = fontFile(L"consola.ttf");
    if (fUi.empty() || !io.Fonts->AddFontFromFileTTF(fUi.c_str(), 17.0f * scale, &fc, ranges)) io.Fonts->AddFontDefault();
    gMono = fMono.empty() ? nullptr : io.Fonts->AddFontFromFileTTF(fMono.c_str(), 15.0f * scale, &fc, ranges);
    ImGui_ImplWin32_Init(gHwnd); ImGui_ImplDX9_Init(gDev);
    SetWindowTextW(gHwnd, W(T(L_APP)).c_str());
    int argc = 0; LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc); if (argc > 1) DoOpen(argv[1]); if (argc > 2 && gDoc.loaded && wcscmp(argv[2], L"--level") == 0) gLevelMode = PackageHasLevel(); else if (argc > 2 && gDoc.loaded) { i32 i = gDoc.pk.findPath(U8(argv[2])); if (i > 0) { GotoObject(i); if (ScriptTabAvailable(i)) gOpenScriptTab = true; else gOpenPreviewTab = true; } } LocalFree(argv);
    int lastLang = gLang;
    bool done = false;
    while (!done) {
        MSG msg; while (PeekMessageW(&msg, NULL, 0U, 0U, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); if (msg.message == WM_QUIT) done = true; }
        if (done || gWantQuit) break;
        // minimized: nothing to draw (the backbuffer would be 0x0); wait without burning CPU
        if (IsIconic(gHwnd)) { Sleep(30); continue; }
        if (gLost) { HRESULT hr = gDev->TestCooperativeLevel(); if (hr == D3DERR_DEVICELOST) { Sleep(10); continue; }
            if (hr == D3DERR_DEVICENOTRESET && !ResetDevice()) { Sleep(50); continue; } gLost = false; }
        if (gResW && gResH) { gPP.BackBufferWidth = gResW; gPP.BackBufferHeight = gResH; gResW = gResH = 0; if (!ResetDevice()) { gLost = true; continue; } }
        ImGui_ImplDX9_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
        Frame();
        if (lastLang != gLang) { lastLang = gLang; SetWindowTextW(gHwnd, W(T(L_APP)).c_str()); }
        ImGui::EndFrame();
        gDev->SetRenderState(D3DRS_ZENABLE, FALSE); gDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE); gDev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        gDev->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(30, 30, 34, 255), 1.0f, 0);
        if (gDev->BeginScene() >= 0) { ImGui::Render(); ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData()); gDev->EndScene(); }
        HRESULT r = gDev->Present(NULL, NULL, NULL, NULL); if (r == D3DERR_DEVICELOST) gLost = true;
    }
    LibShutdown(); LibReleasePreview();
    gDoc.close();
    ImGui_ImplDX9_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
    if (gDev) gDev->Release(); if (gD3D) gD3D->Release();
    DestroyWindow(gHwnd); UnregisterClassW(wc.lpszClassName, wc.hInstance);
    return 0;
}
