// BmStudio - UnrealScript source editor with the built-in compiler (bmcpp/ucc_*.hpp).
// Opens the selected function/state as text (faithful decompiler), compiles and writes the bytecode with any size,
// creating local variables, imports and names when needed. Included by app.cpp after script.hpp.
#pragma once
#include "../bmcpp/ucc_decl.hpp"

struct UccSession {
    std::unique_ptr<bm::ucc::TypeDB> db; std::unique_ptr<bm::ucc::Compiler> C; std::unique_ptr<bm::ucc::Decomp> D; std::unique_ptr<bm::ucc::ScriptEditor> E; std::unique_ptr<bm::ucc::ClassEditor> CE;
    int gen = -1; int docPi = -1; std::string err, loaded;
};
static UccSession gUcc;

static std::string DocPackageName() { std::string p = U8(gDoc.path); size_t s = p.find_last_of("\\/"); if (s != std::string::npos) p = p.substr(s + 1); size_t d = p.rfind('.'); if (d != std::string::npos) p = p.substr(0, d); return p; }

// loads the script packages of the CookedPC folder; the open document comes in through its own object (same indices)
static bool EnsureUcc() {
    if (gUcc.gen == gDocGen && gUcc.E) return true;
    gUcc = UccSession(); gUcc.gen = gDocGen;
    if (!gDoc.loaded) { gUcc.err = "no package"; return false; }
    try {
        auto db = std::make_unique<bm::ucc::TypeDB>();
        std::string dir = cookedDirOf(U8(gDoc.path)), doc = DocPackageName();
        static const char* order[] = { "Core", "Engine", "GameFramework", "CommonGame", "GFxUI", "IpDrv", "OnlineSubsystemSteamworks", "BmGame", nullptr };
        bool docIn = false;
        for (int k = 0; order[k]; k++) {
            if (Package::strcasecmp_(doc, order[k])) { gUcc.docPi = db->addExternal(&gDoc.pk, order[k]); docIn = true; gUcc.loaded += std::string(order[k]) + "* "; continue; }
            std::string f = dir + order[k] + ".u";
            if (GetFileAttributesW(W(f).c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            try { db->add(f); gUcc.loaded += std::string(order[k]) + " "; } catch (std::exception& e) { gUcc.err += std::string(order[k]) + ": " + e.what() + "  "; }
        }
        if (!docIn) { gUcc.docPi = db->addExternal(&gDoc.pk, doc); gUcc.loaded += doc + "*"; }
        gUcc.db = std::move(db);
        gUcc.C = std::make_unique<bm::ucc::Compiler>(*gUcc.db);
        gUcc.D = std::make_unique<bm::ucc::Decomp>(*gUcc.db, *gUcc.C);
        gUcc.E = std::make_unique<bm::ucc::ScriptEditor>(*gUcc.db, *gUcc.C, *gUcc.D);
        gUcc.CE = std::make_unique<bm::ucc::ClassEditor>(*gUcc.db, *gUcc.C, *gUcc.E);
        return true;
    } catch (std::exception& e) { gUcc.err = e.what(); gUcc.E.reset(); return false; }
}

// mode: 0 = function/state body, 1 = add members/defaults to a class, 2 = new subclass
struct CodeEditor { bool open = false; i32 idx = 0; int gen = -1, mode = 0; std::string text, orig, title; bm::ucc::EditResult last; bm::ucc::ClassEditor::Result lastC; bool haveResult = false, lastApplied = false; bool focus = false; i32 newClass = 0; };
static CodeEditor gCe;

static int CodeResizeCB(ImGuiInputTextCallbackData* d) {
    if (d->EventFlag == ImGuiInputTextFlags_CallbackResize) { auto* s = (std::string*)d->UserData; s->resize((size_t)d->BufTextLen); d->Buf = s->data(); }
    return 0;
}
static bool CodeEditable(i32 idx, std::string* why) {
    if (idx <= 0) return false; std::string c = gDoc.pk.classOf(gDoc.pk.exports[idx - 1]);
    if (c != "Function" && c != "State") return false;
    FieldInfo f = parseField(gDoc.pk, idx); if (!f.ok) return false;
    if (c == "Function" && (f.funcFlags & 0x400)) { if (why) *why = T(L_UC_NATIVE); return false; }
    return true;
}
static void OpenCodeEditor(i32 idx) {
    if (!EnsureUcc()) { Status(std::string(T(L_UC_LOADFAIL)) + ": " + gUcc.err); return; }
    bm::ucc::Ref r{ gUcc.docPi, idx };
    gCe = CodeEditor(); gCe.open = true; gCe.idx = idx; gCe.gen = gDocGen; gCe.title = gDoc.pk.objPath(idx); gCe.focus = true;
    try { gCe.text = gUcc.E->source(r); } catch (std::exception& e) { gCe.text = std::string("// ") + e.what() + "\n"; }
    gCe.orig = gCe.text;
}
static void OpenClassEditor(i32 classIdx, bool newSub) {
    if (!EnsureUcc()) { Status(std::string(T(L_UC_LOADFAIL)) + ": " + gUcc.err); return; }
    gCe = CodeEditor(); gCe.open = true; gCe.idx = classIdx; gCe.gen = gDocGen; gCe.focus = true; gCe.mode = newSub ? 2 : 1;
    std::string cn = gDoc.pk.objName(classIdx);
    gCe.title = (newSub ? std::string(T(L_UC_NEWSUB)) + " " : std::string(T(L_UC_MEMBERS)) + " ") + cn;
    gCe.text = newSub ? "class " + cn + "_New extends " + cn + ";\n\n" + T(L_UC_TPL_CLASS) : std::string(T(L_UC_TPL_MEMBERS));
    gCe.orig = gCe.text;
}
static void RunCompile(bool apply) {
    if (!EnsureUcc()) { Status(std::string(T(L_UC_LOADFAIL)) + ": " + gUcc.err); return; }
    if (gCe.mode != 0) {
        bm::ucc::Ref nc;
        if (gCe.mode == 1) gCe.lastC = gUcc.CE->addMembers(bm::ucc::Ref{ gUcc.docPi, gCe.idx }, gCe.text, apply);
        else gCe.lastC = gUcc.CE->createClass(gUcc.docPi, gCe.text, apply, &nc);
        gCe.haveResult = true; gCe.lastApplied = apply && gCe.lastC.ok;
        gCe.last = bm::ucc::EditResult(); gCe.last.ok = gCe.lastC.ok; gCe.last.err = gCe.lastC.err; gCe.last.line = gCe.lastC.line;
        if (gCe.lastApplied) {
            gDoc.dirty = true; gDoc.rebuild(); gLastFilterKey = "\x01";
            if (gCe.mode == 2 && nc) { gCe.newClass = nc.idx; gCe.mode = 1; gCe.idx = nc.idx; gCe.title = std::string(T(L_UC_MEMBERS)) + " " + gDoc.pk.objName(nc.idx); gCe.text = T(L_UC_TPL_MEMBERS); gCe.orig = gCe.text; GotoObject(nc.idx); }
            if (gSv.idx == gCe.idx) ScriptLoad(gCe.idx);
            Status(T(L_UC_APPLIED));
        }
        return;
    }
    bm::ucc::Ref r{ gUcc.docPi, gCe.idx };
    gCe.last = gUcc.E->compile(r, gCe.text, apply); gCe.haveResult = true; gCe.lastApplied = apply && gCe.last.ok;
    if (gCe.lastApplied) {
        gDoc.dirty = true; gDoc.rebuild(); gLastFilterKey = "\x01";
        if (gSv.idx == gCe.idx) ScriptLoad(gCe.idx);
        Status(T(L_UC_APPLIED));
    }
}
// test hook: BMS_AUTOCODE=1 opens the editor on the selected object; BMS_AUTOCODE_EDIT="text" inserts before the 1st line
// of code; BMS_AUTOCODE_RUN=check|apply|save compiles (save = apply and save the package)
static bool DoSave(const std::wstring& target);
static void CodeEditorAutoTest() {
    static bool done = false; if (done || !gDoc.loaded || gSel <= 0) return; wchar_t b[4096];
    if (GetEnvironmentVariableW(L"BMS_AUTOCLASS", b, 4096)) {   // test: sub|members + BMS_AUTOCLASS_TEXT + BMS_AUTOCODE_RUN
        done = true; bool sub = std::wstring(b) == L"sub"; OpenClassEditor(gSel, sub); if (!gCe.open) return;
        if (GetEnvironmentVariableW(L"BMS_AUTOCLASS_TEXT", b, 4096)) { std::string t = U8(b); for (size_t q; (q = t.find("\\n")) != std::string::npos;) t.replace(q, 2, "\n"); gCe.text = t; }
        if (GetEnvironmentVariableW(L"BMS_AUTOCODE_RUN", b, 4096)) { std::wstring m = b; RunCompile(m != L"check"); if (m == L"save" && gCe.last.ok) DoSave(gDoc.path); }
        return;
    }
    if (!GetEnvironmentVariableW(L"BMS_AUTOCODE", b, 4096)) { done = true; return; }
    done = true; OpenCodeEditor(gSel); if (!gCe.open) return;
    if (GetEnvironmentVariableW(L"BMS_AUTOCODE_EDIT", b, 4096)) { std::string ins = U8(b); size_t p = 0, at = std::string::npos;
        while (p < gCe.text.size()) { size_t e = gCe.text.find('\n', p); std::string ln = gCe.text.substr(p, e - p); size_t k = ln.find_first_not_of(" \t");
            if (k != std::string::npos && ln.compare(k, 2, "//") != 0 && ln.compare(k, 6, "local ") != 0) { at = p; break; } if (e == std::string::npos) break; p = e + 1; }
        for (size_t q; (q = ins.find("\\n")) != std::string::npos;) ins.replace(q, 2, "\n");
        gCe.text.insert(at == std::string::npos ? gCe.text.size() : at, ins + "\n"); }
    if (GetEnvironmentVariableW(L"BMS_AUTOCODE_RUN", b, 4096)) { std::wstring m = b; RunCompile(m != L"check"); if (m == L"save" && gCe.last.ok) DoSave(gDoc.path); }
}
static void CodeEditorWindow() {
    CodeEditorAutoTest();
    if (!gCe.open) return;
    if (gCe.gen != gDocGen) { gCe.open = false; return; }   // package closed/reloaded
    ImGui::SetNextWindowSize(ImVec2(980, 720), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(1.0f);
    std::string wt = std::string(T(L_UC_TITLE)) + ": " + gCe.title + "###codeeditor";
    if (gCe.focus) { ImGui::SetNextWindowFocus(); gCe.focus = false; }
    if (!ImGui::Begin(wt.c_str(), &gCe.open)) { ImGui::End(); return; }
    if (ImGui::Button(T(L_UC_CHECK))) RunCompile(false);
    ImGui::SameLine(); if (ImGui::Button(T(L_UC_APPLY))) RunCompile(true);
    if (gCe.mode == 0) { ImGui::SameLine(); if (ImGui::Button(T(L_UC_RELOAD))) OpenCodeEditor(gCe.idx); }
    ImGui::SameLine(); ImGui::TextDisabled("(?)"); if (ImGui::IsItemHovered()) { ImGui::BeginTooltip(); ImGui::PushTextWrapPos(560); ImGui::TextUnformatted(T(L_UC_HINT)); ImGui::PopTextWrapPos(); ImGui::EndTooltip(); }
    if (gCe.text != gCe.orig) { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, .75f, .3f, 1), "%s", T(L_UC_EDITED)); }
    if (gCe.haveResult) {
        const auto& R = gCe.last;
        if (R.ok && gCe.mode != 0 || (R.ok && gCe.lastC.funcs + gCe.lastC.vars > 0)) {
            const auto& RC = gCe.lastC; char b[256]; snprintf(b, sizeof b, T(L_UC_CLASSOK), RC.vars, RC.funcs, RC.overrides);
            std::string s = std::string(gCe.lastApplied ? T(L_UC_APPLIEDP) : T(L_UC_CHECKP)) + b; for (auto& n : RC.notes) s += " | " + n;
            ImGui::TextColored(ImVec4(0.5f, 1, 0.6f, 1), "%s", s.c_str());
        } else if (R.ok) {
            char b[256]; snprintf(b, sizeof b, T(gCe.lastApplied ? L_UC_OKAPPLIED : L_UC_OK), R.oldSize, R.newSize);
            std::string s = b; if (R.newLocals || R.newImports || R.newNames) { char c2[128]; snprintf(c2, sizeof c2, T(L_UC_NEWSTUFF), R.newLocals, R.newImports, R.newNames); s += c2; }
            ImGui::TextColored(ImVec4(0.5f, 1, 0.6f, 1), "%s", s.c_str());
        } else {
            char b[64]; snprintf(b, sizeof b, T(L_UC_ERRLINE), R.line);
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, .45f, .45f, 1)); ImGui::TextWrapped("%s%s", R.line > 0 ? b : "", R.err.c_str()); ImGui::PopStyleColor();
        }
    } else if (!gUcc.loaded.empty()) ImGui::TextDisabled("%s %s", T(L_UC_PACKAGES), gUcc.loaded.c_str());
    if (gMono) ImGui::PushFont(gMono);
    ImGui::InputTextMultiline("##code", (char*)gCe.text.c_str(), gCe.text.capacity() + 1, ImVec2(-FLT_MIN, -FLT_MIN),
        ImGuiInputTextFlags_CallbackResize | ImGuiInputTextFlags_AllowTabInput, CodeResizeCB, &gCe.text);
    if (gMono) ImGui::PopFont();
    ImGui::End();
}
static bool CodeEditableFwd(i32 idx, std::string* why) { return CodeEditable(idx, why); }
static void OpenCodeEditorFwd(i32 idx) { OpenCodeEditor(idx); }
static void OpenClassEditorFwd(i32 idx, bool sub) { OpenClassEditor(idx, sub); }
