// BmStudio - Asset library: every model, mesh, texture, material, particle system, animation and sound of the game
// in one place (index of the tables of every CookedPC package, in the background, with a disk cache).
// Actions: preview; ADD to the open package as a new object (nothing is replaced); PLACE a static mesh
// in the open level (new actor, positioned with the gizmo). Included by app.cpp after collision.hpp.
#pragma once
#include "../bmcpp/bmassetindex.hpp"
#include "../bmcpp/bmplace.hpp"
#include <thread>
#include <atomic>
#include <mutex>

struct LibAsset { std::string path, cls; i32 size = 0; std::vector<int> files; };
struct LibFileRec { std::wstring path; std::string rel; uint64_t size = 0, mtime = 0; std::vector<bm::aidx::Entry> entries; bool scanned = false; std::string err; };
struct LibState {
    bool open = false; std::wstring cooked;
    std::thread th; std::atomic<bool> busy{ false }, cancel{ false }; std::atomic<int> done{ 0 }, total{ 0 }; std::mutex mx;
    std::vector<LibFileRec> files; std::vector<LibAsset> assets; bool ready = false; std::string status;
    char filter[160] = ""; int cat = 0; std::vector<int> rows; std::string rowsKey; int sel = -1, selFile = 0;
    // preview
    std::unique_ptr<Doc> doc; std::wstring docPath; i32 idx = 0; std::string err; LvlCache cache; bool meshOk = false;
    IDirect3DTexture9* tex = nullptr; int texW = 0, texH = 0; IDirect3DTexture9* rt = nullptr; IDirect3DSurface9* ds = nullptr; int rtW = 0, rtH = 0;
    float yaw = 0.7f, pitch = -0.35f, dist = 300; std::string lastReport; bool lastOk = false; i32 pendingComp = 0, pendingActor = 0; int pendingGen = -1;
    float lRadius = 512, lBright = 2, lColor[3] = { 1.f, .9f, .75f }, lCone = 44; bool lShadows = false;
};
static LibState gLib;

static const char* LibCats[] = { "*", "StaticMesh", "SkeletalMesh", "Texture2D", "Material", "ParticleSystem", "AnimSet", "SoundCue", "PhysicsAsset" };
static bool LibCatMatch(int cat, const std::string& c) {
    if (cat == 0) return true; std::string k = LibCats[cat];
    if (k == "StaticMesh") return c == "StaticMesh" || c == "FracturedStaticMesh"; if (k == "Texture2D") return c == "Texture2D" || c == "TextureCube";
    if (k == "Material") return c == "Material" || c == "MaterialInstanceConstant" || c == "MaterialInstanceTimeVarying"; return c == k;
}
static std::wstring LibCachePath() { wchar_t ad[MAX_PATH] = { 0 }; SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, 0, ad); std::wstring d = std::wstring(ad) + L"\\BmStudio"; CreateDirectoryW(d.c_str(), NULL); return d + L"\\asset_index.bin"; }

// ---- disk cache: per file (relative path, size, date) -> entries
static void LibSaveCache() {
    std::vector<u8> b; auto wi = [&](uint64_t v, int n) { for (int k = 0; k < n; k++) b.push_back((u8)(v >> (8 * k))); };
    auto ws = [&](const std::string& s) { wi(s.size(), 4); b.insert(b.end(), s.begin(), s.end()); };
    wi(0x4249534D, 4); wi(3, 4); wi(gLib.files.size(), 4);
    for (auto& f : gLib.files) { ws(f.rel); wi(f.size, 8); wi(f.mtime, 8); wi(f.entries.size(), 4); for (auto& e : f.entries) { ws(e.path); ws(e.cls); wi((u32)e.size, 4); } }
    HANDLE h = CreateFileW(LibCachePath().c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, 0, NULL); if (h == INVALID_HANDLE_VALUE) return; DWORD wr; WriteFile(h, b.data(), (DWORD)b.size(), &wr, NULL); CloseHandle(h);
}
static std::map<std::string, LibFileRec> LibLoadCache() {
    std::map<std::string, LibFileRec> out; HANDLE h = CreateFileW(LibCachePath().c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL); if (h == INVALID_HANDLE_VALUE) return out;
    LARGE_INTEGER sz; GetFileSizeEx(h, &sz); std::vector<u8> b((size_t)sz.QuadPart); DWORD rd; ReadFile(h, b.data(), (DWORD)b.size(), &rd, NULL); CloseHandle(h);
    size_t p = 0; auto ri = [&](int n) { uint64_t v = 0; if (p + n > b.size()) throw 1; for (int k = 0; k < n; k++) v |= (uint64_t)b[p + k] << (8 * k); p += n; return v; };
    auto rs = [&]() { size_t n = (size_t)ri(4); if (p + n > b.size()) throw 1; std::string s((const char*)b.data() + p, n); p += n; return s; };
    try { if (ri(4) != 0x4249534D || ri(4) != 3) return out; size_t nf = (size_t)ri(4);
        for (size_t i = 0; i < nf; i++) { LibFileRec f; f.rel = rs(); f.size = ri(8); f.mtime = ri(8); size_t ne = (size_t)ri(4);
            for (size_t k = 0; k < ne; k++) { bm::aidx::Entry e; e.path = rs(); e.cls = rs(); e.size = (i32)ri(4); f.entries.push_back(e); } f.scanned = true; out[LvlLower(f.rel)] = std::move(f); } }
    catch (...) { out.clear(); }
    return out;
}
static void LibIndexThread(std::wstring cooked) {
    std::vector<LibFileRec> files; std::vector<std::wstring> stack{ cooked };
    while (!stack.empty()) { std::wstring d = stack.back(); stack.pop_back(); WIN32_FIND_DATAW fd; HANDLE h = FindFirstFileW((d + L"*").c_str(), &fd); if (h == INVALID_HANDLE_VALUE) continue;
        do { std::wstring n = fd.cFileName; if (n == L"." || n == L"..") continue;
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) { stack.push_back(d + n + L"\\"); continue; }
            size_t dot = n.rfind(L'.'); if (dot == std::wstring::npos) continue; std::wstring ext = n.substr(dot); for (auto& c : ext) c = towlower(c);
            if (ext != L".u" && ext != L".upk" && ext != L".umap") continue;
            LibFileRec f; f.path = d + n; f.rel = U8(f.path.substr(cooked.size())); f.size = ((uint64_t)fd.nFileSizeHigh << 32) | fd.nFileSizeLow; f.mtime = ((uint64_t)fd.ftLastWriteTime.dwHighDateTime << 32) | fd.ftLastWriteTime.dwLowDateTime;
            files.push_back(std::move(f)); } while (FindNextFileW(h, &fd)); FindClose(h); }
    std::sort(files.begin(), files.end(), [](const LibFileRec& a, const LibFileRec& b) { return a.rel < b.rel; });
    auto cache = LibLoadCache(); gLib.total = (int)files.size(); gLib.done = 0;
    for (auto& f : files) {
        if (gLib.cancel) return;
        auto it = cache.find(LvlLower(f.rel)); if (it != cache.end() && it->second.size == f.size && it->second.mtime == f.mtime) { f.entries = std::move(it->second.entries); f.scanned = true; gLib.done++; continue; }
        HANDLE h = CreateFileW(f.path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
        if (h != INVALID_HANDLE_VALUE) {
            auto rd = [&](uint64_t off, size_t n, std::vector<u8>& o) { o.resize(n); LARGE_INTEGER li; li.QuadPart = (LONGLONG)off; if (!SetFilePointerEx(h, li, NULL, FILE_BEGIN)) return false; DWORD got = 0; return ReadFile(h, o.data(), (DWORD)n, &got, NULL) && got == n; };
            f.entries = bm::aidx::scan(rd, f.size, 0, f.err); CloseHandle(h); f.scanned = true; }
        gLib.done++;
    }
    // merge: same path+class in several packages = one asset (BmGame.u first: always loaded)
    std::vector<LibAsset> assets; std::unordered_map<std::string, size_t> key;
    std::vector<int> order(files.size()); for (size_t i = 0; i < files.size(); i++) order[i] = (int)i;
    std::stable_sort(order.begin(), order.end(), [&](int a, int b) { bool ga = LvlLower(files[a].rel) == "bmgame.u", gb = LvlLower(files[b].rel) == "bmgame.u"; if (ga != gb) return ga; return files[a].size < files[b].size; });
    for (int fi : order) for (auto& e : files[fi].entries) { if (!e.cls.empty() && e.cls[0] == '@') continue; std::string k = LvlLower(e.cls + "|" + e.path); auto it = key.find(k);
        if (it == key.end()) { key[k] = assets.size(); LibAsset a; a.path = e.path; a.cls = e.cls; a.size = e.size; a.files.push_back(fi); assets.push_back(std::move(a)); } else assets[it->second].files.push_back(fi); }
    std::sort(assets.begin(), assets.end(), [](const LibAsset& a, const LibAsset& b) { return a.path < b.path; });
    { std::lock_guard<std::mutex> lk(gLib.mx); gLib.files = std::move(files); gLib.assets = std::move(assets); gLib.ready = true; gLib.rowsKey = "\x01"; }
    LibSaveCache(); gLib.busy = false;
}
static void LibStartIndex() {
    if (gLib.busy) return; if (gLib.th.joinable()) gLib.th.join();
    std::string ck = cookedDirOf(U8(gDoc.loaded ? gDoc.path : std::wstring())); for (auto& c : ck) if (c == '/') c = '\\';
    if (!gDoc.loaded) { std::wstring last = GetSetting(L"LastFile"); if (!last.empty()) { ck = cookedDirOf(U8(last)); for (auto& c : ck) if (c == '/') c = '\\'; } }
    gLib.cooked = W(ck); gLib.busy = true; gLib.cancel = false; gLib.ready = false; gLib.th = std::thread(LibIndexThread, gLib.cooked);
}
static void LibOpen() { gLib.open = true; if (!gLib.ready && !gLib.busy) LibStartIndex(); }

// ---- preview
static void LibReleasePreview() { LvlCacheRelease(gLib.cache); if (gLib.tex) gLib.tex->Release(); gLib.tex = nullptr; gLib.meshOk = false; gLib.idx = 0; gLib.err.clear(); }
static void LibSelect(int a, int fileSlot) {
    LibReleasePreview(); gLib.sel = a; gLib.selFile = fileSlot; if (a < 0) return; const LibAsset& as = gLib.assets[a];
    const LibFileRec& f = gLib.files[as.files[std::min(fileSlot, (int)as.files.size() - 1)]];
    if (gLib.docPath != f.path) { gLib.doc = std::make_unique<Doc>(); std::string e = gLib.doc->open(f.path); if (!e.empty()) { gLib.err = e; gLib.doc.reset(); gLib.docPath.clear(); return; } gLib.docPath = f.path; }
    Package& P = gLib.doc->pk; i32 idx = 0;
    for (size_t k = 0; k < P.exports.size() && !idx; k++) { if (P.classOf(P.exports[k]) != as.cls) continue; std::string p = P.objPath((i32)k + 1); if (p == as.path || (p.size() > as.path.size() && p.compare(p.size() - as.path.size(), as.path.size(), as.path) == 0 && p[p.size() - as.path.size() - 1] == '.')) idx = (i32)k + 1; }
    if (!idx) { gLib.err = "object not found in " + f.rel; return; }
    gLib.idx = idx; gLib.cache.pk = &P; gLib.cache.path = f.path;
    if (as.cls == "StaticMesh" || as.cls == "FracturedStaticMesh" || as.cls == "SkeletalMesh") {
        LvlBuildMesh(gLib.cache, idx); auto it = gLib.cache.meshes.find(idx); gLib.meshOk = it != gLib.cache.meshes.end() && it->second.ok; if (!gLib.meshOk && it != gLib.cache.meshes.end()) gLib.err = it->second.err;
        if (gLib.meshOk) { const LvlGpuMesh& g = it->second; float r = 0; for (int k = 0; k < 3; k++) r = std::max(r, g.bmax[k] - g.bmin[k]); gLib.dist = std::max(40.f, r * 1.4f); }
    } else if (as.cls == "Texture2D") {
        try { TextureInfo ti = parseTexture(P, idx); int want = 0; while (want + 1 < (int)ti.mips.size() && std::max(ti.mips[want].w, ti.mips[want].h) > 512) want++; int got = -1; std::vector<u8> rgba;
            if (LoadTextureRGBA(idx, ti, want, got, rgba, nullptr, &P, &gLib.docPath)) { gLib.tex = MakeTexture(rgba, ti.mips[got].w, ti.mips[got].h); gLib.texW = ti.mips[got].w; gLib.texH = ti.mips[got].h; } else gLib.err = T(L_LB_NOTEX); }
        catch (std::exception& e) { gLib.err = e.what(); }
    }
}
static void LibRenderMesh(int w, int h) {
    auto it = gLib.cache.meshes.find(gLib.idx); if (it == gLib.cache.meshes.end() || !it->second.ok || w < 8 || h < 8) return; const LvlGpuMesh& g = it->second;
    if (gLib.rt && (gLib.rtW != w || gLib.rtH != h)) { gLib.rt->Release(); gLib.rt = nullptr; if (gLib.ds) gLib.ds->Release(); gLib.ds = nullptr; }
    if (!gLib.rt) { if (FAILED(gDev->CreateTexture(w, h, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &gLib.rt, NULL))) return; gDev->CreateDepthStencilSurface(w, h, D3DFMT_D24S8, D3DMULTISAMPLE_NONE, 0, TRUE, &gLib.ds, NULL); gLib.rtW = w; gLib.rtH = h; }
    float c[3]; for (int k = 0; k < 3; k++) c[k] = (g.bmin[k] + g.bmax[k]) * 0.5f;
    float eye[3] = { c[0] - cosf(gLib.pitch) * cosf(gLib.yaw) * gLib.dist, c[1] - cosf(gLib.pitch) * sinf(gLib.yaw) * gLib.dist, c[2] - sinf(gLib.pitch) * gLib.dist }, up[3] = { 0, 0, 1 };
    Mat4 view = LookAtLH(eye, c, up), proj = PerspectiveLH(0.9f, (float)w / h, std::max(1.f, gLib.dist * 0.01f), gLib.dist * 20);
    IDirect3DSurface9 *oldRT = nullptr, *oldDS = nullptr, *surf = nullptr; gDev->GetRenderTarget(0, &oldRT); gDev->GetDepthStencilSurface(&oldDS);
    gLib.rt->GetSurfaceLevel(0, &surf); gDev->SetRenderTarget(0, surf); if (gLib.ds) gDev->SetDepthStencilSurface(gLib.ds);
    D3DVIEWPORT9 vp = { 0, 0, (DWORD)w, (DWORD)h, 0, 1 }; gDev->SetViewport(&vp); gDev->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(48, 52, 62, 255), 1.0f, 0);
    if (SUCCEEDED(gDev->BeginScene())) {
        M4 I = m4Identity(); gDev->SetTransform(D3DTS_WORLD, (D3DMATRIX*)&I); gDev->SetTransform(D3DTS_VIEW, (D3DMATRIX*)&view); gDev->SetTransform(D3DTS_PROJECTION, (D3DMATRIX*)&proj);
        gDev->SetRenderState(D3DRS_ZENABLE, TRUE); gDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE); gDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE); gDev->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);
        gDev->SetRenderState(D3DRS_LIGHTING, TRUE); gDev->SetRenderState(D3DRS_NORMALIZENORMALS, TRUE); gDev->SetRenderState(D3DRS_AMBIENT, D3DCOLOR_RGBA(95, 95, 100, 255));
        D3DLIGHT9 L = {}; L.Type = D3DLIGHT_DIRECTIONAL; L.Diffuse.r = L.Diffuse.g = L.Diffuse.b = 0.85f; L.Direction.x = cosf(gLib.yaw) * 0.6f; L.Direction.y = sinf(gLib.yaw) * 0.6f; L.Direction.z = -0.6f; gDev->SetLight(0, &L); gDev->LightEnable(0, TRUE);
        D3DMATERIAL9 M = {}; M.Diffuse.r = M.Diffuse.g = M.Diffuse.b = M.Diffuse.a = 1; M.Ambient = M.Diffuse; gDev->SetMaterial(&M); gDev->SetFVF(GPUVERT_FVF);
        gDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR); gDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR); gDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP); gDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
        gDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE); gDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
        gDev->SetStreamSource(0, g.vb, 0, sizeof(GpuVert)); gDev->SetIndices(g.ib);
        for (int pass = 0; pass < 2; pass++) for (auto& s : g.secs) { if ((pass == 0) == (s.blend >= 2)) continue;
            gDev->SetTexture(0, s.tex); gDev->SetTextureStageState(0, D3DTSS_COLOROP, s.tex ? D3DTOP_MODULATE : D3DTOP_SELECTARG2); LvlSetBlend(s.blend, s.tex != nullptr);
            if (s.tris) gDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, g.numVerts, s.first, s.tris); }
        LvlSetBlend(0, false); gDev->EndScene();
    }
    gDev->SetRenderTarget(0, oldRT); gDev->SetDepthStencilSurface(oldDS); if (surf) surf->Release(); if (oldRT) oldRT->Release(); if (oldDS) oldDS->Release();
}

// ---- actions
// types: Core/Engine/.../BmGame + open document (EnsureTypeDB, cached) + the library source package (once per cache)
static bm::cp::TypeDB* LibTypeDB() { bm::cp::TypeDB* db = EnsureTypeDB(); if (!db || !gLib.doc) return db;
    static const void* addedDb = nullptr; static const Package* addedPk = nullptr; static int addedGen = -2;
    if (addedDb == db && addedPk == &gLib.doc->pk && addedGen == gSdb.gen) return db;
    db->add(&gLib.doc->pk); addedDb = db; addedPk = &gLib.doc->pk; addedGen = gSdb.gen; return db; }
static std::string LibDbErr(const std::string& e) { return gSdb.err.empty() ? e : e + "  [" + gSdb.err + "]"; }
static void LibAfterEdit() { gDoc.dirty = true; gDoc.rebuild(); gDocGen++; gLastFilterKey = "\x01"; gPrev.idx = 0; gEd.idx = -1; gSdb.gen = -1; }
// reference to the asset in the open package: import (BmGame.u asset, always loaded) or copy (map asset)
static i32 LibEnsureInDoc(std::string& report) {
    const LibAsset& as = gLib.assets[gLib.sel]; const LibFileRec& f = gLib.files[as.files[std::min(gLib.selFile, (int)as.files.size() - 1)]];
    if (_wcsicmp(f.path.c_str(), gDoc.path.c_str()) == 0) return gLib.idx;
    if (LvlLower(f.rel) == "bmgame.u" && as.path.find('.') != std::string::npos) { i32 r = gDoc.pk.ensureRef(as.path, "Engine", as.cls); report = std::string(T(L_LB_IMPORTED)) + " " + as.path; return r; }
    bm::cp::TypeDB* db = LibTypeDB(); bm::cp::CopyReport r = bm::cp::copyObjects(gDoc.pk, gLib.doc->pk, { gLib.idx }, *db, false);
    if (!r.ok || r.roots.empty()) { report = std::string(T(L_CP_FAIL)) + ": " + LibDbErr(r.err); return 0; }
    char b[300]; snprintf(b, sizeof b, T(L_CP_DONE), r.copied, r.replaced, r.reused, r.newImports, r.newNames); report = b; return r.roots[0];
}
static void LibAddToPackage() {
    gLib.lastReport.clear(); gLib.lastOk = false; if (!gDoc.loaded || gLib.sel < 0 || !gLib.idx) return;
    const LibAsset& as = gLib.assets[gLib.sel]; const LibFileRec& f = gLib.files[as.files[std::min(gLib.selFile, (int)as.files.size() - 1)]];
    if (_wcsicmp(f.path.c_str(), gDoc.path.c_str()) == 0) { gLib.lastReport = T(L_LB_ALREADY); return; }
    bm::cp::TypeDB* db = LibTypeDB(); bm::cp::CopyReport r = bm::cp::copyObjects(gDoc.pk, gLib.doc->pk, { gLib.idx }, *db, false);
    if (!r.ok) { gLib.lastReport = std::string(T(L_CP_FAIL)) + ": " + LibDbErr(r.err); return; }
    char b[300]; snprintf(b, sizeof b, T(L_CP_DONE), r.copied, r.replaced, r.reused, r.newImports, r.newNames); gLib.lastReport = b; gLib.lastOk = true;
    LibAfterEdit(); if (!r.roots.empty()) gSel = r.roots[0]; Status(gLib.lastReport);
}
// template from another map (level with no actor of that kind, e.g. Alley): the smallest indexed package that has one ("@Class")
static std::unique_ptr<Doc> LibFindDonor(bm::place::Kind k, std::wstring& used) {
    static std::map<int, std::wstring> cached; std::unique_ptr<Doc> donor;
    auto tryLoad = [&](const std::wstring& pth) { try { auto t = std::make_unique<Doc>(); if (!t->open(pth).empty() || !bm::place::findTemplateK(t->pk, k).actor) return false; donor = std::move(t); used = pth; return true; } catch (...) { return false; } };
    auto it = cached.find((int)k); if (it != cached.end() && tryLoad(it->second)) return donor;
    std::vector<const char*> want; switch (k) { case bm::place::Kind::Mesh: want = { "@InterpActor", "@StaticMeshActor" }; break; case bm::place::Kind::Emitter: want = { "@Emitter" }; break;
        default: want = { "@PointLightToggleable", "@PointLightMovable", "@SpotLightToggleable", "@SpotLightMovable" }; }
    std::vector<const LibFileRec*> c; for (auto& f : gLib.files) { if (_wcsicmp(f.path.c_str(), gDoc.path.c_str()) == 0) continue; bool has = false; for (auto& e : f.entries) for (auto w : want) if (e.cls == w) has = true; if (has) c.push_back(&f); }
    std::sort(c.begin(), c.end(), [](const LibFileRec* a, const LibFileRec* b) { return a->size < b->size; });
    int tries = 0; for (auto* f : c) { if (++tries > 40) break; if (tryLoad(f->path)) { cached[(int)k] = f->path; return donor; } }
    return nullptr;
}
static std::string LibKindName(bm::place::Kind k) { switch (k) { case bm::place::Kind::Mesh: return "mesh"; case bm::place::Kind::PointLight: return "point light"; case bm::place::Kind::SpotLight: return "spotlight"; default: return "emitter"; } }
// places a new actor (mesh, light or emitter) 5 m in front of the camera
static void LibPlace(bm::place::Kind k, i32 asset, std::string rep, size_t ne0, size_t ni0, size_t nn0) {
    float d[3]; LvlDir(d); bm::place::PlaceSpec S; S.kind = k; S.asset = asset; for (int q = 0; q < 3; q++) S.loc[q] = gLvl.eye[q] + d[q] * 500.f;
    S.lp.radius = gLib.lRadius; S.lp.brightness = gLib.lBright; S.lp.r = (u8)(gLib.lColor[0] * 255 + .5f); S.lp.g = (u8)(gLib.lColor[1] * 255 + .5f); S.lp.b = (u8)(gLib.lColor[2] * 255 + .5f); S.lp.shadows = gLib.lShadows; S.lp.outer = gLib.lCone; S.lp.inner = gLib.lCone * 0.5f;
    bm::cp::TypeDB* db = LibTypeDB(); bm::place::Result r; std::unique_ptr<Doc> donor; std::wstring donorPath;
    if (bm::place::findTemplateK(gDoc.pk, k).actor) r = bm::place::placeActor(gDoc.pk, *db, S, nullptr);
    else { donor = LibFindDonor(k, donorPath);
        if (!donor) r.err = "this level has no " + LibKindName(k) + " actor and no other map in the library has one to use as a template";
        else { db->add(&donor->pk); r = bm::place::placeActor(gDoc.pk, *db, S, &donor->pk); gSdb.gen = -1;
            if (r.ok) rep += (rep.empty() ? "" : "  |  ") + std::string("template: ") + U8(donorPath.substr(donorPath.find_last_of(L"\\/") + 1)); } }
    if (!r.ok) { gLib.lastReport = std::string(T(L_LB_PLACEFAIL)) + ": " + LibDbErr(r.err);
        if (gDoc.pk.exports.size() >= ne0) gDoc.pk.exports.resize(ne0); if (gDoc.pk.imports.size() >= ni0) gDoc.pk.imports.resize(ni0); if (gDoc.pk.names.size() >= nn0) gDoc.pk.names.resize(nn0);
        gDoc.rebuild(); gSdb.gen = -1; Status(gLib.lastReport); return; }
    gLib.lastReport = std::string(T(L_LB_PLACED)) + " " + gDoc.pk.objName(r.actor) + (rep.empty() ? "" : "  |  " + rep); gLib.lastOk = true;
    LibAfterEdit(); if (k == bm::place::Kind::Mesh) gLib.pendingComp = r.comp; else gLib.pendingActor = r.actor; gLib.pendingGen = gDocGen; gLevelMode = true; Status(gLib.lastReport);
}
static void LibPlaceInLevel() {
    gLib.lastReport.clear(); gLib.lastOk = false; if (!gDoc.loaded || gLib.sel < 0 || !gLib.idx || !PackageHasLevel()) return;
    size_t ne0 = gDoc.pk.exports.size(), ni0 = gDoc.pk.imports.size(), nn0 = gDoc.pk.names.size();   // for undo on failure
    const LibAsset& as = gLib.assets[gLib.sel]; bm::place::Kind k = as.cls == "ParticleSystem" ? bm::place::Kind::Emitter : bm::place::Kind::Mesh;
    std::string rep; i32 asset = LibEnsureInDoc(rep); if (!asset) { gLib.lastReport = rep; return; }
    LibPlace(k, asset, rep, ne0, ni0, nn0);
}
static void LibAddLight(bool spot) {
    gLib.lastReport.clear(); gLib.lastOk = false; if (!gDoc.loaded || !PackageHasLevel()) return;
    LibPlace(spot ? bm::place::Kind::SpotLight : bm::place::Kind::PointLight, 0, "", gDoc.pk.exports.size(), gDoc.pk.imports.size(), gDoc.pk.names.size());
}

// test: BMS_AUTOLIB=part of the path (e.g. fx_secret_box) [BMS_AUTOLIB_CAT=1] -> opens, waits for the index, selects, places/adds; BMS_AUTOLIB_SAVE=file
static void LibAutoTest() {
    static int st = 0, fr = 0; if (st < 0) return; wchar_t b[1024]; if (!GetEnvironmentVariableW(L"BMS_AUTOLIB", b, 1024)) { st = -1; return; }
    if (++fr < 10) return;
    if (st == 0) { LibOpen(); st = 1; return; }
    if (st == 1) { if (!gLib.ready) return; std::string f = LvlLower(U8(b)); wchar_t c[64]; int cat = GetEnvironmentVariableW(L"BMS_AUTOLIB_CAT", c, 64) ? _wtoi(c) : 1;
        snprintf(gLib.filter, sizeof gLib.filter, "%s", f.c_str()); gLib.cat = cat; int pick = -1;
        for (size_t i = 0; i < gLib.assets.size() && pick < 0; i++) if (LibCatMatch(cat, gLib.assets[i].cls) && LvlLower(gLib.assets[i].path).find(f) != std::string::npos) pick = (int)i;
        if (pick < 0) { gLib.lastReport = "AUTOLIB: nothing found"; st = -1; return; } LibSelect(pick, 0); st = 2; fr = 0; return; }
    if (st == 2 && fr > 30) { const LibAsset& a = gLib.assets[gLib.sel]; if ((a.cls == "StaticMesh" || a.cls == "ParticleSystem") && PackageHasLevel()) LibPlaceInLevel(); else LibAddToPackage();
        wchar_t lb[16]; if (gLib.lastOk && GetEnvironmentVariableW(L"BMS_AUTOLIGHT", lb, 16)) { int n = _wtoi(lb); if (n & 1) LibAddLight(false); if (n & 2) LibAddLight(true); }
        st = 3; fr = 0; return; }
    if (st == 3 && fr > 60) { if (GetEnvironmentVariableW(L"BMS_AUTOLIB_SAVE", b, 1024)) DoSave(b); st = -1; }
}
static void LibWindow() {
    LibAutoTest();
    // select the freshly placed actor in the viewport (when the level reloads)
    if (gLib.pendingComp && gLvl.gen == gDocGen) { for (size_t i = 0; i < gLvl.L.meshes.size(); i++) if (gLvl.L.meshes[i].comp == gLib.pendingComp) { gLvl.sel = (int)i; gLvl.selActor = -1; gLvl.mode = 0; } gLib.pendingComp = 0; }
    if (gLib.pendingActor && gLvl.gen == gDocGen) { for (size_t i = 0; i < gLvl.actors.size(); i++) if (gLvl.actors[i].idx == gLib.pendingActor) { gLvl.selActor = (int)i; gLvl.sel = -1; gLvl.mode = 0; } gLib.pendingActor = 0; }
    if (!gLib.open) return;
    ImGui::SetNextWindowSize(ImVec2(1040, 660), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(1.0f);
    if (!ImGui::Begin(T(L_LB_TITLE), &gLib.open)) { ImGui::End(); return; }
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_LB_HINT)); ImGui::PopStyleColor();
    if (gLib.busy) { ImGui::ProgressBar(gLib.total ? (float)gLib.done / gLib.total : 0.f, ImVec2(300, 0)); ImGui::SameLine(); ImGui::Text("%s %d/%d", T(L_LB_INDEXING), (int)gLib.done, (int)gLib.total); }
    else { if (ImGui::Button(T(L_LB_REINDEX))) LibStartIndex(); ImGui::SameLine(); ImGui::TextDisabled("%zu assets, %zu %s  |  %s", gLib.assets.size(), gLib.files.size(), T(L_LB_PACKAGES), U8(gLib.cooked).c_str()); }
    if (!gLib.ready) { ImGui::End(); return; }
    std::lock_guard<std::mutex> lk(gLib.mx);
    // real lights (PointLight/SpotLight actor, not just the lamp mesh)
    if (ImGui::CollapsingHeader(T(L_LB_LIGHTS))) {
        ImGui::BeginDisabled(!gDoc.loaded || gDoc.pk.bigEndian || !PackageHasLevel());
        if (ImGui::Button(T(L_LB_ADDPOINT))) LibAddLight(false); ImGui::SameLine(); if (ImGui::Button(T(L_LB_ADDSPOT))) LibAddLight(true); ImGui::EndDisabled();
        ImGui::SameLine(); ImGui::SetNextItemWidth(90); ImGui::DragFloat(T(L_LB_LRADIUS), &gLib.lRadius, 4, 16, 8192, "%.0f");
        ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::DragFloat(T(L_LB_LBRIGHT), &gLib.lBright, 0.05f, 0, 50, "%.2f");
        ImGui::SameLine(); ImGui::ColorEdit3("##lbcol", gLib.lColor, ImGuiColorEditFlags_NoInputs); ImGui::SameLine(); ImGui::SetNextItemWidth(60); ImGui::DragFloat(T(L_LB_LCONE), &gLib.lCone, 0.5f, 1, 89, "%.0f");
        ImGui::SameLine(); ImGui::Checkbox(T(L_LB_LSHADOW), &gLib.lShadows);
        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_LB_LIGHTS_TIP)); ImGui::PopStyleColor();
        if (gLib.sel < 0 && !gLib.lastReport.empty()) ImGui::TextColored(gLib.lastOk ? ImVec4(.5f, 1, .6f, 1) : ImVec4(1, .5f, .4f, 1), "%s", gLib.lastReport.c_str());
    }
    ImGui::SetNextItemWidth(320); ImGui::InputTextWithHint("##lbf", T(L_SEARCH), gLib.filter, sizeof gLib.filter); ImGui::SameLine();
    for (int c = 0; c < (int)(sizeof LibCats / sizeof LibCats[0]); c++) { if (c) ImGui::SameLine(); if (ImGui::RadioButton(c == 0 ? T(L_ALL) : LibCats[c], gLib.cat == c)) gLib.cat = c; }
    std::string key = std::string(gLib.filter) + "|" + std::to_string(gLib.cat);
    if (key != gLib.rowsKey) { gLib.rowsKey = key; gLib.rows.clear(); std::string f = LvlLower(gLib.filter);
        for (size_t i = 0; i < gLib.assets.size(); i++) { const LibAsset& a = gLib.assets[i]; if (!LibCatMatch(gLib.cat, a.cls)) continue; if (!f.empty() && LvlLower(a.path).find(f) == std::string::npos) continue; gLib.rows.push_back((int)i); } }
    ImGui::BeginChild("lblist", ImVec2(560, 0), ImGuiChildFlags_Borders | ImGuiChildFlags_ResizeX);
    ImGui::TextDisabled("%zu", gLib.rows.size());
    if (ImGui::BeginTable("lbt", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_Resizable)) {
        ImGui::TableSetupColumn(T(L_NAME), ImGuiTableColumnFlags_WidthStretch, 1.f); ImGui::TableSetupColumn(T(L_CLASS), ImGuiTableColumnFlags_WidthFixed, 130); ImGui::TableSetupColumn(T(L_LB_WHERE), ImGuiTableColumnFlags_WidthFixed, 150);
        ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableHeadersRow();
        ImGuiListClipper clip; clip.Begin((int)gLib.rows.size());
        while (clip.Step()) for (int r = clip.DisplayStart; r < clip.DisplayEnd; r++) { int i = gLib.rows[r]; const LibAsset& a = gLib.assets[i]; ImGui::TableNextRow(); ImGui::TableNextColumn();
            if (ImGui::Selectable((a.path + "##lb" + std::to_string(i)).c_str(), gLib.sel == i, ImGuiSelectableFlags_SpanAllColumns)) LibSelect(i, 0);
            ImGui::TableNextColumn(); ImGui::TextDisabled("%s", a.cls.c_str());
            ImGui::TableNextColumn(); std::string w = gLib.files[a.files[0]].rel; size_t sl = w.find_last_of('\\'); if (sl != std::string::npos) w = w.substr(sl + 1);
            if (a.files.size() > 1) w += " +" + std::to_string(a.files.size() - 1); ImGui::TextDisabled("%s", w.c_str()); }
        ImGui::EndTable(); }
    ImGui::EndChild(); ImGui::SameLine();
    ImGui::BeginChild("lbprev", ImVec2(0, 0), ImGuiChildFlags_Borders);
    if (gLib.sel >= 0 && gLib.sel < (int)gLib.assets.size()) { const LibAsset& a = gLib.assets[gLib.sel];
        ImGui::TextWrapped("%s", a.path.c_str()); ImGui::TextDisabled("%s, %.1f KB", a.cls.c_str(), a.size / 1024.0);
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::BeginCombo("##lbfile", gLib.files[a.files[std::min(gLib.selFile, (int)a.files.size() - 1)]].rel.c_str())) {
            for (int k = 0; k < (int)a.files.size(); k++) if (ImGui::Selectable((gLib.files[a.files[k]].rel + "##f" + std::to_string(k)).c_str(), k == gLib.selFile)) LibSelect(gLib.sel, k); ImGui::EndCombo(); }
        if (!gLib.err.empty()) ImGui::TextColored(ImVec4(1, .5f, .4f, 1), "%s", gLib.err.c_str());
        // actions
        bool canAdd = gDoc.loaded && !gDoc.pk.bigEndian && gLib.idx; bool isMesh = a.cls == "StaticMesh" || a.cls == "ParticleSystem"; bool canPlace = canAdd && isMesh && PackageHasLevel();
        ImGui::BeginDisabled(!canAdd); if (ImGui::Button(T(L_LB_ADD))) LibAddToPackage(); ImGui::EndDisabled(); if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("%s", T(L_LB_ADD_TIP));
        if (isMesh) { ImGui::SameLine(); ImGui::BeginDisabled(!canPlace); if (ImGui::Button(T(L_LB_PLACE))) LibPlaceInLevel(); ImGui::EndDisabled(); if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("%s", T(L_LB_PLACE_TIP)); }
        if (!gLib.lastReport.empty()) ImGui::TextColored(gLib.lastOk ? ImVec4(.5f, 1, .6f, 1) : ImVec4(1, .5f, .4f, 1), "%s", gLib.lastReport.c_str());
        ImGui::Separator();
        ImVec2 av = ImGui::GetContentRegionAvail();
        if (gLib.meshOk) { int w = (int)av.x, h = (int)std::max(64.f, av.y); LibRenderMesh(w, h); ImVec2 org = ImGui::GetCursorScreenPos(); (void)org;
            ImVec2 p0 = ImGui::GetCursorScreenPos();
            if (gLib.rt) ImGui::Image((ImTextureID)(intptr_t)gLib.rt, ImVec2((float)w, (float)h)); else ImGui::Dummy(ImVec2((float)w, (float)h));
            ImGui::SetCursorScreenPos(p0); ImGui::InvisibleButton("##lbdrag", ImVec2((float)w, (float)h));   // captures the drag (the window does not move with it)
            if (ImGui::IsItemHovered() || ImGui::IsItemActive()) { ImGuiIO& io = ImGui::GetIO(); if (ImGui::IsItemActive()) { gLib.yaw += io.MouseDelta.x * 0.01f; gLib.pitch = std::max(-1.5f, std::min(1.5f, gLib.pitch - io.MouseDelta.y * 0.01f)); } if (io.MouseWheel) gLib.dist *= io.MouseWheel > 0 ? 0.85f : 1.18f; } }
        else if (gLib.tex) { float s = std::min(av.x / std::max(1, gLib.texW), av.y / std::max(1, gLib.texH)); s = std::min(s, 1.5f); ImGui::Image((ImTextureID)(intptr_t)gLib.tex, ImVec2(gLib.texW * s, gLib.texH * s)); ImGui::TextDisabled("%dx%d", gLib.texW, gLib.texH); }
        else ImGui::TextDisabled("%s", T(L_NOPREVIEW));
    } else ImGui::TextDisabled("%s", T(L_SELECT));
    ImGui::EndChild();
    ImGui::End();
}
static void LibShutdown() { gLib.cancel = true; if (gLib.th.joinable()) gLib.th.join(); }
