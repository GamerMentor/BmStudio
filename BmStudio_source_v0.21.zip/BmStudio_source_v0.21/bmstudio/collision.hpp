// BmStudio - "Collision" mode of the level viewport: shows and removes invisible walls.
//  - blocking volumes (RTotalBlockingVolume, RPlayerBlockingVolume...): colored boxes; "Remove from level" takes the actor out of the ULevel list
//  - BSP collision: each convex solid cell (LeafHull) has a box used for extent collision (Batman/enemies).
//    "Disable" moves the box away (+1e7, reversible); optional: hide the cell faces and NotCsg (camera/projectiles).
//    It is the same thing that opened the Admin_C8 passage (tested in game on 2026-10-03).
//  - meshes: "No collision" (stays visible) is in the regular selection panel.
// Included by app.cpp after roomimp.hpp.
#pragma once

struct CollVol { i32 actor = 0; int slot = -1; std::string cls; int cat = 3; M4 W; float lmn[3], lmx[3], c[8][3]; };
struct CollHull { i32 model = 0; size_t at = 0; float mn[3], mx[3]; std::vector<int> nodes; bool off = false; };
struct CollUndo { int kind; i32 exp; std::vector<u8> data; int slot; i32 actor; };   // 0 export data, 1 actor removed
struct CollState {
    bool on = false; int gen = -1; std::vector<CollVol> vols; std::vector<CollHull> hulls;
    int selVol = -1, selHull = -1; bool showVols = true, showHulls = true, showAllVols = false, hideFaces = true, notCsg = true; float range = 5000;
    std::vector<CollUndo> undo; std::string err;
};
static CollState gCol;
static void CollBuild();
static bool CollIsOn() { return gCol.on; }
static void CollSetOn(bool on) { gCol.on = on; gCol.selVol = gCol.selHull = -1; gLvl.sel = gLvl.selActor = -1; gGhost.sel = false; if (on) CollBuild(); }
static const float COLL_OFF = 1e7f;

// category by what the class blocks (class defaults in BmGame.u/Engine.u)
static int CollCategory(const std::string& c) {
    if (c == "RTotalBlockingVolume" || c == "RPlayerBlockingVolume" || c == "BlockingVolume" || c == "DynamicBlockingVolume") return 0;   // blocks Batman
    if (c == "RThugBlockingVolume") return 1;                                                                                           // enemies only
    if (c.find("Blocking") != std::string::npos) return 2;                                                                               // physics/camera/gadgets/AI
    return 3;
}
static const char* CollCatText(int cat) { return cat == 0 ? T(L_CO_CAT0) : cat == 1 ? T(L_CO_CAT1) : cat == 2 ? T(L_CO_CAT2) : T(L_CO_CAT3); }
static ImU32 CollCatColor(int cat, bool sel) { if (sel) return IM_COL32(255, 230, 70, 255); return cat == 0 ? IM_COL32(255, 70, 70, 230) : cat == 1 ? IM_COL32(255, 150, 40, 200) : cat == 2 ? IM_COL32(90, 160, 255, 170) : IM_COL32(160, 160, 160, 110); }

static void CollBuild() {
    gCol.vols.clear(); gCol.hulls.clear(); gCol.err.clear(); gCol.gen = gDocGen; Package& P = gDoc.pk;
    try {
        if (P.findPath("TheWorld.PersistentLevel") <= 0) return;
        rimp::ActorList A = rimp::actorList(P);
        for (i32 i = 0; i < A.count; i++) { i32 a = rimp::actorAt(P, A, i); if (a <= 0) continue; std::string cls = P.classOf(P.exports[a - 1]); if (cls.find("Volume") == std::string::npos) continue;
            ObjProps op = objProps(P, a); if (!op.ok) continue; rimp::Box wb, lb; if (!rimp::brushBox(P, op.tags, wb, lb)) continue;
            CollVol v; v.actor = a; v.slot = i; v.cls = cls; v.cat = CollCategory(cls); v.W = actorMatrix(op.tags); memcpy(v.lmn, lb.mn, 12); memcpy(v.lmx, lb.mx, 12);
            for (auto& t : op.tags) if (t.name == "bCollideActors" && t.isBool && !t.boolVal && v.cat < 2) v.cat = 3;
            for (int c = 0; c < 8; c++) { float q[3]; for (int k = 0; k < 3; k++) q[k] = (c >> k) & 1 ? lb.mx[k] : lb.mn[k];
                for (int j = 0; j < 3; j++) v.c[c][j] = q[0] * v.W.m[0][j] + q[1] * v.W.m[1][j] + q[2] * v.W.m[2][j] + v.W.m[3][j]; }
            gCol.vols.push_back(v); }
        for (i32 m : levelModels(P)) { ModelLayout L = modelLayout(P, m); if (!L.ok || !L.nHulls) continue; const u8* b = P.dataPtr(P.exports[m - 1]); const i32* h = (const i32*)(b + L.hullsAt); i32 i = 0;
            while (i < L.nHulls) { CollHull hu; hu.model = m; while (i < L.nHulls && h[i] != -1) { hu.nodes.push_back(h[i] & 0x3FFFFFFF); i++; } i++; if (i + 6 > L.nHulls) break;
                hu.at = L.hullsAt + 4 * (size_t)i; memcpy(hu.mn, h + i, 12); memcpy(hu.mx, h + i + 3, 12); i += 6;
                hu.off = hu.mn[0] > COLL_OFF * 0.5f; if (hu.off) for (int k = 0; k < 3; k++) { hu.mn[k] -= COLL_OFF; hu.mx[k] -= COLL_OFF; }
                gCol.hulls.push_back(hu); } }
    } catch (std::exception& e) { gCol.err = e.what(); }
    if (gCol.selVol >= (int)gCol.vols.size()) gCol.selVol = -1; if (gCol.selHull >= (int)gCol.hulls.size()) gCol.selHull = -1;
}
static void CollRebuildBsp() { for (auto& b : gLvl.main.bsp) { if (b.vb) b.vb->Release(); if (b.ib) b.ib->Release(); } gLvl.main.bsp.clear(); for (i32 mdl : levelModels(gDoc.pk)) LvlBuildBsp(gLvl.main, mdl); }
static void CollSnapshot(i32 exp) { rimp::ownData(gDoc.pk, exp); CollUndo u; u.kind = 0; u.exp = exp; u.data = gDoc.pk.exports[exp - 1].data; u.slot = -1; u.actor = 0; gCol.undo.push_back(u); }

static void CollRemoveVol(int v) {
    CollVol vol = gCol.vols[v]; rimp::ActorList A = rimp::actorList(gDoc.pk); if (vol.slot < 0 || vol.slot >= A.count || rimp::actorAt(gDoc.pk, A, vol.slot) != vol.actor) { Status("edit failed"); return; }
    CollUndo u; u.kind = 1; u.exp = 0; u.slot = vol.slot; u.actor = vol.actor; gCol.undo.push_back(u);
    rimp::setActorAt(gDoc.pk, A, vol.slot, 0); gDoc.dirty = true; gCol.selVol = -1; CollBuild(); Status(gDoc.pk.objName(vol.actor) + ": " + T(L_CO_REMOVED));
}
// cell faces: polygons of the cell nodes that lie entirely inside its box
static std::vector<int> CollHullFaces(const CollHull& hu) {
    std::vector<int> out; ModelLayout L = modelLayout(gDoc.pk, hu.model); if (!L.ok) return out; const u8* b = gDoc.pk.dataPtr(gDoc.pk.exports[hu.model - 1]);
    for (int n : hu.nodes) { if (n < 0 || n >= L.nNodes) continue; BspNodeV nd = readNode(b, L, n); if (nd.nv < 3) continue; bool inside = true;
        for (int k = 0; k < nd.nv && inside; k++) { const float* p = (const float*)(b + L.vbAt + (size_t)L.vbes * (nd.iVertexIndex + k)); for (int j = 0; j < 3; j++) if (p[j] < hu.mn[j] - 1 || p[j] > hu.mx[j] + 1) inside = false; }
        if (inside) out.push_back(n); }
    return out;
}
static void CollSetHull(int hi, bool off) {
    CollHull hu = gCol.hulls[hi]; CollSnapshot(hu.model); u8* d = gDoc.pk.exports[hu.model - 1].data.data();
    float bx[6]; memcpy(bx, d + hu.at, 24); for (auto& f : bx) f += off ? COLL_OFF : -COLL_OFF; memcpy(d + hu.at, bx, 24);
    int faces = 0;
    if (off && (gCol.hideFaces || gCol.notCsg)) { std::vector<int> fs = CollHullFaces(hu); ModelLayout L = modelLayout(gDoc.pk, hu.model);
        for (int n : fs) { BspNodeV nd = readNode(d, L, n);
            if (gCol.notCsg) d[L.nodesAt + 64 * (size_t)n + 55] |= NF_NotCsg;
            if (gCol.hideFaces) { const float* p0 = (const float*)(d + L.vbAt + (size_t)L.vbes * nd.iVertexIndex); float c[3] = { p0[0], p0[1], p0[2] };
                for (int k = 1; k < nd.nv; k++) memcpy(d + L.vbAt + (size_t)L.vbes * (nd.iVertexIndex + k), c, 12); }
            faces++; } }
    gDoc.dirty = true; CollBuild(); CollRebuildBsp();
    char b[200]; snprintf(b, sizeof b, off ? T(L_CO_HULLOFF) : T(L_CO_HULLON), hi, faces); Status(b);
}
static void CollUndoLast() {
    if (gCol.undo.empty()) return; CollUndo u = gCol.undo.back(); gCol.undo.pop_back();
    if (u.kind == 0) { gDoc.pk.exports[u.exp - 1].data = u.data; gDoc.pk.exports[u.exp - 1].owned = true; CollRebuildBsp(); }
    else { rimp::ActorList A = rimp::actorList(gDoc.pk); if (u.slot < A.count && rimp::actorAt(gDoc.pk, A, u.slot) == 0) rimp::setActorAt(gDoc.pk, A, u.slot, u.actor); }
    gDoc.dirty = true; CollBuild();
}

// ---- picking: ray against volume boxes (oriented) and BSP cells; the closest one wins
static bool CollRayBoxT(const float o[3], const float d[3], const float mn[3], const float mx[3], float& tin) {
    float t0 = 0, t1 = 1e30f; for (int k = 0; k < 3; k++) { if (fabsf(d[k]) < 1e-12f) { if (o[k] < mn[k] || o[k] > mx[k]) return false; continue; }
        float a = (mn[k] - o[k]) / d[k], b = (mx[k] - o[k]) / d[k]; if (a > b) std::swap(a, b); t0 = std::max(t0, a); t1 = std::min(t1, b); if (t0 > t1) return false; }
    tin = t0; return t0 > 0;   // camera inside the box: does not count
}
static bool CollVolVisible(const CollVol& v) { return gCol.showVols && (gCol.showAllVols || v.cat < 3); }
static bool CollHullNear(const CollHull& h) { float c[3]; for (int k = 0; k < 3; k++) c[k] = (h.mn[k] + h.mx[k]) * 0.5f - gLvl.eye[k]; return sqrtf(c[0] * c[0] + c[1] * c[1] + c[2] * c[2]) < gCol.range; }
static void CollPick(float mx, float my) {
    float o[3], d[3]; LvlRay(mx, my, o, d); float best = 1e30f; int bv = -1, bh = -1;
    for (size_t i = 0; i < gCol.vols.size(); i++) { const CollVol& v = gCol.vols[i]; if (!CollVolVisible(v)) continue; M4 inv = m4Inverse(v.W); float lo[3], ld[3];
        for (int k = 0; k < 3; k++) { lo[k] = o[0] * inv.m[0][k] + o[1] * inv.m[1][k] + o[2] * inv.m[2][k] + inv.m[3][k]; ld[k] = d[0] * inv.m[0][k] + d[1] * inv.m[1][k] + d[2] * inv.m[2][k]; }
        float t; if (CollRayBoxT(lo, ld, v.lmn, v.lmx, t) && t < best) { best = t; bv = (int)i; } }
    if (gCol.showHulls) for (size_t i = 0; i < gCol.hulls.size(); i++) { const CollHull& h = gCol.hulls[i]; float t; if (CollRayBoxT(o, d, h.mn, h.mx, t) && t < best) { best = t; bh = (int)i; bv = -1; } }
    gCol.selVol = bv; gCol.selHull = bh; gLvl.sel = -1; gLvl.selActor = -1; gGhost.sel = false;
}
static void CollBoxEdges(ImDrawList* dl, ImVec2 org, const float c[8][3], ImU32 col, float th) {
    for (int i = 0; i < 8; i++) for (int k = 0; k < 3; k++) { int j = i | (1 << k); if (j == i) continue; float a[2], b[2];
        if (!LvlProject(c[i], a[0], a[1]) || !LvlProject(c[j], b[0], b[1])) continue; dl->AddLine(ImVec2(org.x + a[0], org.y + a[1]), ImVec2(org.x + b[0], org.y + b[1]), col, th); }
}
static void CollAutoTest() {   // test: BMS_AUTOCOLL=name of the volume to remove | #cell to disable ; BMS_AUTOCOLL_SAVE=file
    static int fr = 0; static bool done = false; if (done) return; wchar_t b[1024]; if (!GetEnvironmentVariableW(L"BMS_AUTOCOLL", b, 1024)) { done = true; return; } if (++fr < 20) return; done = true;
    CollSetOn(true); std::string w = U8(b);
    if (w[0] == '#') { int h = atoi(w.c_str() + 1); if (h >= 0 && h < (int)gCol.hulls.size()) { gCol.selHull = h; CollSetHull(h, true); gCol.selHull = h; } }
    else for (size_t i = 0; i < gCol.vols.size(); i++) if (gDoc.pk.objName(gCol.vols[i].actor) == w) { float p[3] = { 0, 0, 0 }; for (auto& c : gCol.vols[i].c) for (int k = 0; k < 3; k++) p[k] += c[k] / 8;
        gLvl.yaw = 0.6f; gLvl.pitch = -0.35f; float d[3]; LvlDir(d); for (int k = 0; k < 3; k++) gLvl.eye[k] = p[k] - d[k] * 1100; gCol.selVol = (int)i; if (GetEnvironmentVariableW(L"BMS_AUTOCOLL_SAVE", b, 1024)) CollRemoveVol((int)i); break; }
    if (GetEnvironmentVariableW(L"BMS_AUTOCOLL_SAVE", b, 1024)) DoSave(b);
}
static void CollOverlay(ImDrawList* dl, ImVec2 org) {
    CollAutoTest();
    if (!gCol.on) return; if (gCol.gen != gDocGen) CollBuild();
    if (gCol.showHulls) for (size_t i = 0; i < gCol.hulls.size(); i++) { const CollHull& h = gCol.hulls[i]; bool sel = (int)i == gCol.selHull; if (!sel && !CollHullNear(h)) continue;
        float c[8][3]; for (int q = 0; q < 8; q++) for (int k = 0; k < 3; k++) c[q][k] = (q >> k) & 1 ? h.mx[k] : h.mn[k];
        CollBoxEdges(dl, org, c, sel ? IM_COL32(255, 230, 70, 255) : h.off ? IM_COL32(255, 90, 200, 200) : IM_COL32(120, 220, 200, 60), sel ? 2.5f : 1.f); }
    for (size_t i = 0; i < gCol.vols.size(); i++) { const CollVol& v = gCol.vols[i]; bool sel = (int)i == gCol.selVol; if (!sel && !CollVolVisible(v)) continue; CollBoxEdges(dl, org, v.c, CollCatColor(v.cat, sel), sel ? 2.5f : 1.5f); }
}
static void CollPanel() {
    if (gCol.gen != gDocGen) CollBuild();
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled)); ImGui::TextWrapped("%s", T(L_CO_HINT)); ImGui::PopStyleColor();
    if (!gCol.err.empty()) ImGui::TextColored(ImVec4(1, .45f, .45f, 1), "%s", gCol.err.c_str());
    ImGui::Checkbox(T(L_CO_VOLS), &gCol.showVols); ImGui::SameLine(); ImGui::Checkbox(T(L_CO_ALLVOLS), &gCol.showAllVols); ImGui::SameLine(); ImGui::Checkbox(T(L_CO_HULLS), &gCol.showHulls);
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat(T(L_CO_RANGE), &gCol.range, 500, 30000, "%.0f");
    { auto key = [](ImU32 c, const char* t) { ImGui::ColorButton(t, ImGui::ColorConvertU32ToFloat4(c), ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoAlpha, ImVec2(12, 12)); ImGui::SameLine(); ImGui::TextUnformatted(t); };
      key(CollCatColor(0, false), T(L_CO_CAT0)); ImGui::SameLine(); key(CollCatColor(1, false), T(L_CO_CAT1)); key(CollCatColor(2, false), T(L_CO_CAT2)); ImGui::SameLine(); key(IM_COL32(120, 220, 200, 255), T(L_CO_HULLS)); }
    ImGui::BeginDisabled(gCol.undo.empty()); if (ImGui::Button(T(L_CO_UNDO))) CollUndoLast(); ImGui::EndDisabled();
    ImGui::Separator();
    if (gCol.selVol >= 0) { const CollVol& v = gCol.vols[gCol.selVol];
        ImGui::TextWrapped("%s", gDoc.pk.objPath(v.actor).c_str()); ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(CollCatColor(v.cat, false)), "%s  -  %s", v.cls.c_str(), CollCatText(v.cat));
        float mn[3] = { 1e30f, 1e30f, 1e30f }, mx[3] = { -1e30f, -1e30f, -1e30f }; for (auto& c : v.c) for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], c[k]); mx[k] = std::max(mx[k], c[k]); }
        ImGui::TextDisabled("x[%.0f..%.0f] y[%.0f..%.0f] z[%.0f..%.0f]", mn[0], mx[0], mn[1], mx[1], mn[2], mx[2]);
        if (ImGui::Button(T(L_CO_REMOVE))) CollRemoveVol(gCol.selVol); ImGui::SameLine(); if (ImGui::Button(T(L_GOTO))) { gLevelMode = false; GotoObject(v.actor); } }
    else if (gCol.selHull >= 0) { const CollHull& h = gCol.hulls[gCol.selHull];
        ImGui::Text("%s #%d  (%s)", T(L_CO_HULL), gCol.selHull, gDoc.pk.objName(h.model).c_str()); ImGui::TextDisabled("x[%.0f..%.0f] y[%.0f..%.0f] z[%.0f..%.0f]", h.mn[0], h.mx[0], h.mn[1], h.mx[1], h.mn[2], h.mx[2]);
        std::string ns; for (int n : h.nodes) ns += " " + std::to_string(n); ImGui::TextDisabled("%s:%s", T(L_CO_NODES), ns.c_str());
        if (h.off) { ImGui::TextColored(ImVec4(1, .5f, .8f, 1), "%s", T(L_CO_ISOFF)); if (ImGui::Button(T(L_CO_ON))) CollSetHull(gCol.selHull, false); }
        else { ImGui::Checkbox(T(L_CO_HIDEFACES), &gCol.hideFaces); ImGui::SameLine(); ImGui::Checkbox(T(L_CO_NOTCSG), &gCol.notCsg); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", T(L_CO_NOTCSG_TIP));
            if (ImGui::Button(T(L_CO_OFF))) CollSetHull(gCol.selHull, true); } }
    else ImGui::TextDisabled("%s", T(L_LVL_NOSEL));
    ImGui::Separator();
    ImGui::BeginChild("colllist", ImVec2(0, 0), ImGuiChildFlags_Borders);
    for (size_t i = 0; i < gCol.vols.size(); i++) { const CollVol& v = gCol.vols[i]; if (!CollVolVisible(v)) continue;
        ImGui::PushStyleColor(ImGuiCol_Text, ImGui::ColorConvertU32ToFloat4(CollCatColor(v.cat, false)));
        if (ImGui::Selectable((gDoc.pk.objName(v.actor) + "##v" + std::to_string(i)).c_str(), (int)i == gCol.selVol)) { gCol.selVol = (int)i; gCol.selHull = -1; }
        ImGui::PopStyleColor();
        if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0)) { float p[3] = { 0, 0, 0 }; for (auto& c : v.c) for (int k = 0; k < 3; k++) p[k] += c[k] / 8; float d[3]; LvlDir(d); for (int k = 0; k < 3; k++) gLvl.eye[k] = p[k] - d[k] * 900; } }
    for (size_t i = 0; i < gCol.hulls.size(); i++) if (gCol.hulls[i].off) { char b[64]; snprintf(b, sizeof b, "%s #%zu (%s)##h%zu", T(L_CO_HULL), i, T(L_CO_ISOFF), i); if (ImGui::Selectable(b, (int)i == gCol.selHull)) { gCol.selHull = (int)i; gCol.selVol = -1; } }
    ImGui::EndChild();
}

// mesh: remove/restore collision without hiding
static bool LvlMeshNoCollision(int i) { ObjProps cp = objProps(gDoc.pk, gLvl.L.meshes[i].comp); if (!cp.ok) return false; for (auto& t : cp.tags) if (t.name == "BlockActors" && t.isBool && !t.boolVal) return true; return false; }
static void LvlSetNoCollision(int i, bool nc) {
    LevelMesh& m = gLvl.L.meshes[i]; ObjProps cp = objProps(gDoc.pk, m.comp); if (!cp.ok) { Status("edit failed"); return; } std::vector<Tag> tags = cp.tags;
    for (const char* b : { "CollideActors", "BlockActors", "BlockZeroExtent", "BlockNonZeroExtent", "BlockRigidBody" }) { if (nc) setBoolTag(tags, b, false); else for (size_t k = 0; k < tags.size(); k++) if (tags[k].name == b && !tags[k].boolVal) { tags.erase(tags.begin() + k); break; } }
    if (replaceProps(gDoc.pk, m.comp, tags)) gDoc.dirty = true; else Status("edit failed");
}
