#!/bin/sh
# Builds BmStudio.exe (32-bit Windows) and the command-line tools.
#  Linux:   sudo apt install g++-mingw-w64-i686 mingw-w64-tools   -> ./build.sh
#  Windows: MSYS2, terminal "MINGW32", pacman -S mingw-w64-i686-gcc  -> CROSS= ./build.sh
set -e
cd "$(dirname "$0")"
CROSS=${CROSS-i686-w64-mingw32-}
CXX=${CXX:-${CROSS}g++}; CC=${CC:-${CROSS}gcc}; WINDRES=${WINDRES:-${CROSS}windres}
IM=third_party/imgui; OBJ=build/obj; mkdir -p $OBJ
FLAGS="-O2 -std=gnu++17 -DNDEBUG"
echo "== libraries (ImGui, miniz, LZX)"
for f in imgui imgui_draw imgui_tables imgui_widgets; do [ -f $OBJ/$f.o ] || $CXX $FLAGS -I$IM -c $IM/$f.cpp -o $OBJ/$f.o; done
[ -f $OBJ/impl_dx9.o ]   || $CXX $FLAGS -I$IM -c $IM/backends/imgui_impl_dx9.cpp   -o $OBJ/impl_dx9.o
[ -f $OBJ/impl_win32.o ] || $CXX $FLAGS -I$IM -c $IM/backends/imgui_impl_win32.cpp -o $OBJ/impl_win32.o
for f in miniz miniz_tdef miniz_tinfl; do [ -f $OBJ/mz_$f.o ] || $CC -O2 -Ibmcpp/mz -c bmcpp/mz/$f.c -o $OBJ/mz_$f.o; done
[ -f $OBJ/lzxd.o ]  || $CC -O2 -Ibmcpp/mspack -c bmcpp/mspack/lzxd.c  -o $OBJ/lzxd.o
[ -f $OBJ/bmlzx.o ] || $CC -O2 -Ibmcpp/mspack -c bmcpp/mspack/bmlzx.c -o $OBJ/bmlzx.o
echo "== BmStudio"
(cd bmstudio && $WINDRES app.rc -O coff -o ../$OBJ/app.res)
$CXX $FLAGS -I$IM -I$IM/backends -c bmstudio/app.cpp -o $OBJ/app.o
$CXX -municode -mwindows -O2 -s -static -static-libgcc -static-libstdc++ -Wl,--large-address-aware \
  $OBJ/app.o $OBJ/imgui*.o $OBJ/impl_*.o $OBJ/mz_*.o $OBJ/lzxd.o $OBJ/bmlzx.o $OBJ/app.res -o build/BmStudio.exe \
  -ld3d9 -ldwmapi -lgdi32 -lcomdlg32 -lshell32 -lole32 -luuid -lcomctl32 -lrstrtmgr
echo "== tools"
for t in betaroomfix betatexfix; do
  $CXX $FLAGS -s -static -static-libgcc -static-libstdc++ -Wl,--large-address-aware -Ibmcpp tools/$t.cpp $OBJ/mz_*.o -o build/$t.exe
done
ls -la build/*.exe
