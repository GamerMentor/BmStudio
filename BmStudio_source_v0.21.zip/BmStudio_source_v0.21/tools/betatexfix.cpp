// betatexfix - fixes the texture settings of the beta Batman in BmGame.u.
// Problem found (2026-10-11): Batman.Maps.Batman_Body_N (content = normal map) was MISSING the normal map
// settings (SRGB=False, UnpackMin=-1, CompressionSettings=TC_Normalmap) and Batman_Body_S (specular) HAD them. The shader
// read the normal as a color (0..1, sRGB) -> bent normals: one side shiny, the other matte.
// Rule: classify by CONTENT (average color of the small mip: normal map ~ 127,127,250) and copy the settings of the
// equivalent textures of the final Batman (V2_Batman_Body_N for normals, V2_Batman_Body_D for the others).
// Usage: betatexfix <BmGame.u> [prefix=Batman.Maps.]   (writes in place, backup .before_texfix)
#include "bmasset.hpp"
#include "bmlevel.hpp"
#include <cstdio>
#ifdef _WIN32
#define BTF_SEEK(f, o) _fseeki64(f, (long long)(o), SEEK_SET)
#else
#define BTF_SEEK(f, o) fseeko(f, (off_t)(o), SEEK_SET)
#endif
using namespace bm;

static bool readAll(const std::string& p, std::vector<u8>& out) { FILE* f = fopen(p.c_str(), "rb"); if (!f) return false; fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); out.resize((size_t)n); bool ok = fread(out.data(), 1, (size_t)n, f) == (size_t)n; fclose(f); return ok; }
static bool writeAll(const std::string& p, const std::vector<u8>& d) { FILE* f = fopen(p.c_str(), "wb"); if (!f) return false; bool ok = fwrite(d.data(), 1, d.size(), f) == d.size(); fclose(f); return ok; }

int main(int argc, char** argv) {
    if (argc < 2) { printf("usage: betatexfix BmGame.u [prefix]\n"); return 1; }
    std::string path = argv[1], prefix = argc > 2 ? argv[2] : "Batman.Maps.";
    std::string dir = path.substr(0, path.find_last_of("\\/") + 1);
    Package P; try { P.load(path); } catch (std::exception& e) { printf("ERROR while opening: %s\n", e.what()); return 1; }
    i32 refN = P.findPath("Batman_V2.Maps.V2_Batman_Body_N"), refD = P.findPath("Batman_V2.Maps.V2_Batman_Body_D");
    if (refN <= 0 || refD <= 0) { printf("ERROR: reference textures of the final Batman not found\n"); return 1; }
    auto settings = [&](i32 x) { std::vector<Tag> out; for (auto& t : objProps(P, x).tags) if (t.name == "SRGB" || t.name == "UnpackMin" || t.name == "UnpackMax" || t.name == "CompressionSettings" || t.name == "LODGroup") out.push_back(t); return out; };
    auto sN = settings(refN), sD = settings(refD);
    int fixed = 0;
    for (size_t k = 0; k < P.exports.size(); k++) {
        i32 x = (i32)k + 1; if (P.classOf(P.exports[k]) != "Texture2D") continue; std::string path2 = P.objPath(x); if (path2.rfind(prefix, 0) != 0) continue;
        TextureInfo ti = parseTexture(P, x); if (!ti.err.empty() || ti.mips.empty()) { printf("  %s: %s (skipped)\n", path2.c_str(), ti.err.c_str()); continue; }
        int pick = (int)ti.mips.size() - 1; for (int m = (int)ti.mips.size() - 1; m >= 0; m--) if (ti.mips[m].w >= 32) { pick = m; break; }
        std::vector<u8> data, rgba;
        bool ok = loadMip(P, x, ti, ti.mips[pick], dir, [&](const std::string& p, uint64_t off, size_t sz, std::vector<u8>& o) { FILE* f = fopen(p.c_str(), "rb"); if (!f) return false; BTF_SEEK(f, off); o.resize(sz); bool r = fread(o.data(), 1, sz, f) == sz; fclose(f); return r; }, data);
        if (!ok || !decodeToRGBA(ti, ti.mips[pick].w, ti.mips[pick].h, data.data(), data.size(), rgba)) { printf("  %s: could not read the pixels (skipped)\n", path2.c_str()); continue; }
        double s[3] = { 0, 0, 0 }; size_t n = rgba.size() / 4; for (size_t q = 0; q < rgba.size(); q += 4) for (int j = 0; j < 3; j++) s[j] += rgba[q + j];
        for (auto& v : s) v /= n;
        bool isNormal = s[2] > 200 && fabs(s[0] - 127) < 25 && fabs(s[1] - 127) < 25;
        auto tags = objProps(P, x).tags; bool hadNormal = false; for (auto& t : tags) if (t.name == "CompressionSettings" || t.name == "UnpackMin") hadNormal = true;
        if (isNormal == hadNormal) { printf("  %-34s ok (%s)\n", path2.c_str(), isNormal ? "normal map" : "color"); continue; }
        std::vector<Tag> nt; for (auto& t : tags) if (!(t.name == "SRGB" || t.name == "UnpackMin" || t.name == "UnpackMax" || t.name == "CompressionSettings" || t.name == "LODGroup")) nt.push_back(t);
        for (auto& t : (isNormal ? sN : sD)) nt.push_back(t);
        if (!replaceProps(P, x, nt)) { printf("  %s: failed to rewrite\n", path2.c_str()); continue; }
        printf("  %-34s FIXED -> %s (average %.0f,%.0f,%.0f)\n", path2.c_str(), isNormal ? "normal map" : "regular texture", s[0], s[1], s[2]); fixed++;
    }
    if (!fixed) { printf("Nothing to fix.\n"); return 0; }
    std::vector<u8> out; try { out = P.saveToMemory(); } catch (std::exception& e) { printf("ERROR while saving: %s\n", e.what()); return 1; }
    { Package R; try { R.loadBytes(std::vector<u8>(out)); } catch (std::exception& e) { printf("ERROR: the result does not reload (%s) - nothing was written\n", e.what()); return 1; } }
    std::vector<u8> orig; std::string bak = path + ".before_texfix";
    { FILE* f = fopen(bak.c_str(), "rb"); if (f) fclose(f); else { if (!readAll(path, orig) || !writeAll(bak, orig)) { printf("ERROR while creating the backup %s\n", bak.c_str()); return 1; } } }
    P = Package();
    if (!writeAll(path, out)) { printf("ERROR while writing %s (is the game running?)\n", path.c_str()); return 1; }
    printf("%d texture(s) fixed. Backup of the original: %s\n", fixed, bak.c_str());
    return 0;
}
