// bmlevel.hpp - reading/editing Batman: Arkham Asylum levels (.umap) "within the cooked limits".
// Sources of static meshes placed in the level:
//  1) StaticMeshCollectionActor: the cooker merges StaticMeshActors; each component stores CachedParentToWorld
//     (FMatrix, 64 bytes) serialized AFTER the actor properties (AStaticMeshCollectionActor::Serialize).
//     Editing = overwriting those 64 bytes: the export size does not change.
//  2) Regular actors (StaticMeshActor, InterpActor, R*...) with a StaticMeshComponent: transform =
//     component (Translation/Rotation/Scale/Scale3D) * actor (DrawScale/DrawScale3D, Rotation, Location).
//     Editing = rewriting the actor's Location/Rotation/DrawScale3D tags (known types, no new objects).
#pragma once
#include "bmanim.hpp"
#include <cmath>

namespace bm {

struct Rot { i32 pitch = 0, yaw = 0, roll = 0; };
inline M4 rotationMatrix(const Rot& r) {       // FRotationMatrix (UE3), 65536 = 360 degrees
    const float k = 3.14159265358979f / 32768.f;
    float SP = sinf(r.pitch * k), CP = cosf(r.pitch * k), SY = sinf(r.yaw * k), CY = cosf(r.yaw * k), SR = sinf(r.roll * k), CR = cosf(r.roll * k);
    M4 m = m4Identity();
    m.m[0][0] = CP * CY; m.m[0][1] = CP * SY; m.m[0][2] = SP;
    m.m[1][0] = SR * SP * CY - CR * SY; m.m[1][1] = SR * SP * SY + CR * CY; m.m[1][2] = -SR * CP;
    m.m[2][0] = -(CR * SP * CY + SR * SY); m.m[2][1] = CY * SR - CR * SP * SY; m.m[2][2] = CR * CP;
    return m;
}
// matrix without scale -> rotator (FMatrix::Rotator)
inline Rot matrixRotator(const M4& m) {
    auto norm = [](const float* v) { float l = sqrtf(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); return l > 0 ? l : 1.f; };
    float X[3] = { m.m[0][0], m.m[0][1], m.m[0][2] }, Y[3] = { m.m[1][0], m.m[1][1], m.m[1][2] }, Z[3] = { m.m[2][0], m.m[2][1], m.m[2][2] };
    float lx = norm(X), ly = norm(Y), lz = norm(Z); for (int i = 0; i < 3; i++) { X[i] /= lx; Y[i] /= ly; Z[i] /= lz; }
    const float k = 32768.f / 3.14159265358979f; Rot r;
    r.pitch = (i32)lroundf(atan2f(X[2], sqrtf(X[0] * X[0] + X[1] * X[1])) * k);
    r.yaw = (i32)lroundf(atan2f(X[1], X[0]) * k);
    M4 noRoll = rotationMatrix(Rot{ r.pitch, r.yaw, 0 });
    float SY[3] = { noRoll.m[1][0], noRoll.m[1][1], noRoll.m[1][2] };
    r.roll = (i32)lroundf(atan2f(Z[0] * SY[0] + Z[1] * SY[1] + Z[2] * SY[2], Y[0] * SY[0] + Y[1] * SY[1] + Y[2] * SY[2]) * k);
    return r;
}
inline M4 m4Inverse(const M4& a) {   // general 4x4 inverse (Gauss-Jordan)
    double m[4][8]; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) { m[i][j] = a.m[i][j]; m[i][j + 4] = (i == j); }
    for (int c = 0; c < 4; c++) { int p = c; for (int r = c + 1; r < 4; r++) if (fabs(m[r][c]) > fabs(m[p][c])) p = r; if (fabs(m[p][c]) < 1e-12) return m4Identity();
        for (int j = 0; j < 8; j++) std::swap(m[c][j], m[p][j]); double d = m[c][c]; for (int j = 0; j < 8; j++) m[c][j] /= d;
        for (int r = 0; r < 4; r++) if (r != c) { double f = m[r][c]; for (int j = 0; j < 8; j++) m[r][j] -= f * m[c][j]; } }
    M4 r; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) r.m[i][j] = (float)m[i][j + 4]; return r; }
inline M4 scaleMatrix(float x, float y, float z) { M4 m = m4Identity(); m.m[0][0] = x; m.m[1][1] = y; m.m[2][2] = z; return m; }
inline M4 translationMatrix(float x, float y, float z) { M4 m = m4Identity(); m.m[3][0] = x; m.m[3][1] = y; m.m[3][2] = z; return m; }
// scale/rotation/position from a world matrix (for display/editing)
inline void decompose(const M4& m, float loc[3], Rot& rot, float scale[3]) {
    for (int i = 0; i < 3; i++) { loc[i] = m.m[3][i]; scale[i] = sqrtf(m.m[i][0] * m.m[i][0] + m.m[i][1] * m.m[i][1] + m.m[i][2] * m.m[i][2]); }
    float det = m.m[0][0] * (m.m[1][1] * m.m[2][2] - m.m[1][2] * m.m[2][1]) - m.m[0][1] * (m.m[1][0] * m.m[2][2] - m.m[1][2] * m.m[2][0]) + m.m[0][2] * (m.m[1][0] * m.m[2][1] - m.m[1][1] * m.m[2][0]);
    if (det < 0) scale[0] = -scale[0];
    M4 r = m; for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) r.m[i][j] /= (scale[i] != 0 ? scale[i] : 1.f);
    rot = matrixRotator(r);
}
inline M4 compose(const float loc[3], const Rot& rot, const float scale[3]) { return m4Mul(m4Mul(scaleMatrix(scale[0], scale[1], scale[2]), rotationMatrix(rot)), translationMatrix(loc[0], loc[1], loc[2])); }

// ------------------------------------------------------------------ known struct tags
inline bool tagVec(const std::vector<Tag>& t, const char* n, float v[3]) { const Tag* x = findTag(t, n); if (!x || x->raw.size() < 12) return false; memcpy(v, x->raw.data(), 12); return true; }
inline bool tagRot(const std::vector<Tag>& t, const char* n, Rot& r) { const Tag* x = findTag(t, n); if (!x || x->raw.size() < 12) return false; memcpy(&r.pitch, x->raw.data(), 4); memcpy(&r.yaw, x->raw.data() + 4, 4); memcpy(&r.roll, x->raw.data() + 8, 4); return true; }
inline float tagFloat(const std::vector<Tag>& t, const char* n, float def) { const Tag* x = findTag(t, n); if (!x || x->raw.size() < 4) return def; float f; memcpy(&f, x->raw.data(), 4); return f; }
inline void setStructTag(std::vector<Tag>& tags, const std::string& name, const std::string& strct, const void* data, size_t n) {
    for (auto& t : tags) if (t.name == name) { t.raw.assign((const u8*)data, (const u8*)data + n); return; }
    Tag t; t.name = name; t.type = "StructProperty"; t.strct = strct; t.raw.assign((const u8*)data, (const u8*)data + n); tags.push_back(t);
}
inline void setFloatTag(std::vector<Tag>& tags, const std::string& name, float v) {
    for (auto& t : tags) if (t.name == name) { t.raw.resize(4); memcpy(t.raw.data(), &v, 4); return; }
    Tag t; t.name = name; t.type = "FloatProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); tags.push_back(t);
}
inline void setBoolTag(std::vector<Tag>& tags, const std::string& name, bool v) {
    for (auto& t : tags) if (t.name == name) { t.boolVal = v; return; }
    Tag t; t.name = name; t.type = "BoolProperty"; t.isBool = true; t.boolVal = v; tags.push_back(t);
}
// replaces the property list of an export, keeping what comes before and after (native data)
inline bool replaceProps(Package& pk, i32 idx, const std::vector<Tag>& tags) {
    Export& e = pk.exports[idx - 1]; long st = findPropStart(pk, idx); if (st < 0) return false;
    size_t end = 0; try { readProps(pk, pk.dataPtr(e), pk.dataLen(e), (size_t)st, &end); } catch (...) { return false; }
    std::vector<u8> nd(pk.dataPtr(e), pk.dataPtr(e) + st); auto np = writeProps(pk, tags); nd.insert(nd.end(), np.begin(), np.end());
    nd.insert(nd.end(), pk.dataPtr(e) + end, pk.dataPtr(e) + pk.dataLen(e));
    e.data = nd; e.owned = true; return true;
}

// ------------------------------------------------------------------ mesh instances of the level
struct LevelMesh {
    i32 comp = 0, owner = 0, mesh = 0;        // StaticMeshComponent, owning actor, StaticMesh
    int src = 0;                              // 0 = collection (matrix in the actor), 1 = regular actor (tags)
    size_t matOff = 0;                        // src 0: offset of the matrix in the actor data
    M4 world = m4Identity(); M4 compLocal = m4Identity();   // src 1: world = compLocal * actorMatrix
    bool hidden = false;
    int kind = 0;                             // 0 StaticMesh (includes Fractured), 1 SkeletalMesh (reference pose)
};
struct Level { std::vector<LevelMesh> meshes; std::vector<i32> actors; std::vector<i32> terrains; std::vector<M4> trees; std::string err; int collections = 0; };

inline M4 actorMatrix(const std::vector<Tag>& t) {
    float loc[3] = { 0, 0, 0 }, s3[3] = { 1, 1, 1 }, pp[3] = { 0, 0, 0 }; Rot r; tagVec(t, "Location", loc); tagRot(t, "Rotation", r); tagVec(t, "DrawScale3D", s3); tagVec(t, "PrePivot", pp);
    float ds = tagFloat(t, "DrawScale", 1.f);
    return m4Mul(m4Mul(m4Mul(translationMatrix(-pp[0], -pp[1], -pp[2]), scaleMatrix(s3[0] * ds, s3[1] * ds, s3[2] * ds)), rotationMatrix(r)), translationMatrix(loc[0], loc[1], loc[2]));
}
inline M4 componentLocal(const std::vector<Tag>& t) {
    float tr[3] = { 0, 0, 0 }, s3[3] = { 1, 1, 1 }; Rot r; tagVec(t, "Translation", tr); tagRot(t, "Rotation", r); tagVec(t, "Scale3D", s3); float s = tagFloat(t, "Scale", 1.f);
    return m4Mul(m4Mul(scaleMatrix(s3[0] * s, s3[1] * s, s3[2] * s), rotationMatrix(r)), translationMatrix(tr[0], tr[1], tr[2]));
}
inline bool isInPersistentLevel(const Package& pk, i32 idx) {
    for (int g = 0; idx > 0 && g < 64; g++) { const Export& e = pk.exports[idx - 1]; if (pk.nm(e.name) == "PersistentLevel") return true; idx = e.outer; } return false;
}

inline Level parseLevel(const Package& pk) {
    Level L; std::map<i32, size_t> collectionComp;   // comp -> matrix offset
    try {
        for (size_t k = 0; k < pk.exports.size(); k++) {
            i32 idx = (i32)k + 1; const Export& e = pk.exports[k]; std::string cls = pk.classOf(e);
            if (cls != "StaticMeshCollectionActor") continue;
            ObjProps op = objProps(pk, idx); if (!op.ok) continue; const Tag* t = findTag(op.tags, "StaticMeshComponents"); if (!t) continue;
            Reader r(t->raw.data(), t->raw.size()); i32 n = r.i(); if (n < 0 || op.end + (size_t)n * 64 > pk.dataLen(e)) continue;
            L.collections++;
            for (i32 c = 0; c < n; c++) { i32 comp = r.i(); size_t off = op.end + (size_t)c * 64; if (comp > 0) collectionComp[comp] = off;
                if (comp <= 0) continue;
                LevelMesh m; m.comp = comp; m.owner = idx; m.src = 0; m.matOff = off; M4 ptw; memcpy(&ptw, pk.dataPtr(e) + off, 64);
                ObjProps cp = objProps(pk, comp); m.world = ptw; if (cp.ok) { m.compLocal = componentLocal(cp.tags); m.world = m4Mul(m.compLocal, ptw); const Tag* sm = findTag(cp.tags, "StaticMesh"); m.mesh = sm ? tagObj(*sm) : 0; m.hidden = findTag(cp.tags, "HiddenGame") && findTag(cp.tags, "HiddenGame")->boolVal; }
                L.meshes.push_back(m); }
        }
        for (size_t k = 0; k < pk.exports.size(); k++) {
            i32 idx = (i32)k + 1; const Export& e = pk.exports[k];
            std::string ccls = pk.classOf(e);
            bool skel = ccls == "SkeletalMeshComponent" || ccls == "RDepthBiasSkeletalMeshComponent";
            if (ccls == "SpeedTreeComponent" && !isTemplateObj(pk, idx) && e.outer > 0 && isInPersistentLevel(pk, e.outer) && !isTemplateObj(pk, e.outer)) {   // trees: position only (placeholder)
                ObjProps cp = objProps(pk, idx), ap = objProps(pk, e.outer); if (cp.ok && ap.ok) L.trees.push_back(m4Mul(componentLocal(cp.tags), actorMatrix(ap.tags))); continue; }
            if ((ccls != "StaticMeshComponent" && ccls != "FracturedStaticMeshComponent" && !skel) || collectionComp.count(idx) || isTemplateObj(pk, idx)) continue;
            i32 owner = e.outer; if (owner <= 0 || !isInPersistentLevel(pk, owner) || isTemplateObj(pk, owner)) continue;
            ObjProps cp = objProps(pk, idx), ap = objProps(pk, owner); if (!cp.ok || !ap.ok) continue;
            const Tag* sm = findTag(cp.tags, skel ? "SkeletalMesh" : "StaticMesh"); LevelMesh m; m.comp = idx; m.owner = owner; m.src = 1; m.mesh = sm ? tagObj(*sm) : 0; m.kind = skel ? 1 : 0;
            if (!m.mesh) continue;
            m.compLocal = componentLocal(cp.tags); m.world = m4Mul(m.compLocal, actorMatrix(ap.tags));
            m.hidden = (findTag(ap.tags, "bHidden") && findTag(ap.tags, "bHidden")->boolVal) || (findTag(cp.tags, "HiddenGame") && findTag(cp.tags, "HiddenGame")->boolVal);
            L.meshes.push_back(m);
        }
        for (size_t k = 0; k < pk.exports.size(); k++) if (pk.classOf(pk.exports[k]) == "Terrain" && !isTemplateObj(pk, (i32)k + 1)) L.terrains.push_back((i32)k + 1);
        // actors with a position (for markers/inspection)
        for (size_t k = 0; k < pk.exports.size(); k++) { i32 idx = (i32)k + 1; const Export& e = pk.exports[k]; if (e.outer <= 0 || pk.nm(pk.exports[e.outer - 1].name) != "PersistentLevel") continue; if (isTemplateObj(pk, idx)) continue; L.actors.push_back(idx); }
    } catch (std::exception& ex) { L.err = ex.what(); }
    return L;
}

// writes the new world matrix of an instance (collection: overwrites the 64 bytes; regular actor: actor tags)
inline bool setInstanceWorld(Package& pk, LevelMesh& m, const M4& world) {
    if (m.src == 0) {
        Export& e = pk.exports[m.owner - 1]; if (!e.owned) { e.data.assign(pk.dataPtr(e), pk.dataPtr(e) + pk.dataLen(e)); e.owned = true; }
        if (m.matOff + 64 > e.data.size()) return false;
        M4 ptw = m4Mul(m4Inverse(m.compLocal), world); memcpy(e.data.data() + m.matOff, &ptw, 64); m.world = world; return true;
    }
    // actor: actorMatrix = inv(compLocal) * world; decomposed into Location/Rotation/DrawScale3D (DrawScale and PrePivot preserved)
    ObjProps ap = objProps(pk, m.owner); if (!ap.ok) return false;
    M4 cl = m.compLocal; float cloc[3], cs[3]; Rot cr; decompose(cl, cloc, cr, cs);
    M4 inv = m4RigidInverse(m4Mul(rotationMatrix(cr), translationMatrix(cloc[0], cloc[1], cloc[2])));
    M4 a = m4Mul(inv, world); for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) a.m[i][j] /= (cs[i] != 0 ? cs[i] : 1.f);
    float pp[3] = { 0, 0, 0 }; tagVec(ap.tags, "PrePivot", pp); float ds = tagFloat(ap.tags, "DrawScale", 1.f);
    float loc[3], sc[3]; Rot r; decompose(a, loc, r, sc);
    // actorMatrix = T(-pp) * S * R * T(loc)  =>  a.translation = (-pp*S*R) + loc
    M4 sr = m4Mul(scaleMatrix(sc[0], sc[1], sc[2]), rotationMatrix(r)); for (int i = 0; i < 3; i++) loc[i] += pp[0] * sr.m[0][i] + pp[1] * sr.m[1][i] + pp[2] * sr.m[2][i];
    float s3[3] = { sc[0] / ds, sc[1] / ds, sc[2] / ds }; i32 rr[3] = { r.pitch, r.yaw, r.roll };
    std::vector<Tag> tags = ap.tags; setStructTag(tags, "Location", "Vector", loc, 12); setStructTag(tags, "Rotation", "Rotator", rr, 12);
    if (fabsf(s3[0] - 1) > 1e-4f || fabsf(s3[1] - 1) > 1e-4f || fabsf(s3[2] - 1) > 1e-4f || findTag(tags, "DrawScale3D")) setStructTag(tags, "DrawScale3D", "Vector", s3, 12);
    if (!replaceProps(pk, m.owner, tags)) return false;
    ObjProps ap2 = objProps(pk, m.owner); m.world = m4Mul(m.compLocal, actorMatrix(ap2.tags)); return true;
}


// ------------------------------------------------------------------ BSP (UModel) for display
// Layout BM (v576): Bounds, Vectors/Points/Nodes (bulk), int extra (BM), Surfs (TArray FBspSurf 56 bytes), Verts (bulk),
// NumSharedSides, NumZones, Zones[24], Polys, LeafHulls, Leaves, RootOutside, Linked, PortalNodes, Edges (bulk),
// NumVertices, VertexBuffer (bulk FModelVertex), + 3 DWORDs (BM).
struct BspVert { float pos[3]; float uv[2]; };
struct BspModel { std::vector<BspVert> verts; std::vector<uint32_t> idx; std::vector<std::pair<i32, std::pair<u32, u32>>> secs; /* material, first, tris */ std::string err; };
inline BspModel parseModel(const Package& pk, i32 idx) {
    BspModel m; const Export& e = pk.exports[idx - 1];
    try {
        long ps = findPropStart(pk, idx); if (ps < 0) throw Err("no props"); size_t st = 0; readProps(pk, pk.dataPtr(e), pk.dataLen(e), (size_t)ps, &st);
        Reader r(pk.dataPtr(e), pk.dataLen(e), st); r.p += 28;
        skipBulkArray(r); skipBulkArray(r);
        i32 nes = r.i(), nn = r.i(); if (nes != 64 || nn < 0) throw Err("unexpected BSP node size"); size_t nodesAt = r.p; r.need((size_t)nn * 64); r.p += (size_t)nn * 64;
        r.i();   // BM
        i32 ns = r.i(); if (ns < 0) throw Err("bad surfs"); size_t surfsAt = r.p; r.need((size_t)ns * 56); r.p += (size_t)ns * 56;
        skipBulkArray(r); r.i(); i32 nz = r.i(); if (nz < 0 || nz > 64) throw Err("bad zones"); r.p += (size_t)nz * 24; r.i();
        skipBulkArray(r); skipBulkArray(r); r.i(); r.i(); skipBulkArray(r); skipBulkArray(r); r.i();
        i32 ves = r.i(), vn = r.i(); if (ves < 20 || vn < 0) throw Err("bad model vertex buffer"); size_t vbAt = r.p; r.need((size_t)ves * vn);
        const u8* d = pk.dataPtr(e);
        std::map<i32, std::vector<uint32_t>> byMat;
        for (i32 n = 0; n < nn; n++) {
            const u8* nd = d + nodesAt + (size_t)n * 64; i32 iSurf, iVertexIndex; memcpy(&iSurf, nd + 20, 4); memcpy(&iVertexIndex, nd + 24, 4); u8 nv = nd[54];
            if (nv < 3 || iSurf < 0 || iSurf >= ns || iVertexIndex < 0 || iVertexIndex + nv > vn) continue;
            const u8* sd = d + surfsAt + (size_t)iSurf * 56; i32 mat; u32 flags; memcpy(&mat, sd, 4); memcpy(&flags, sd + 4, 4);
            if (flags & 1) continue;   // PF_Invisible
            u32 base = (u32)m.verts.size();
            for (int k = 0; k < nv; k++) { const u8* vd = d + vbAt + (size_t)(iVertexIndex + k) * ves; BspVert bv; memcpy(bv.pos, vd, 12); memcpy(bv.uv, vd + 20, 8); m.verts.push_back(bv); }
            auto& ix = byMat[mat]; for (int k = 1; k + 1 < nv; k++) { ix.push_back(base); ix.push_back(base + k); ix.push_back(base + k + 1); }
        }
        for (auto& kv : byMat) { u32 first = (u32)m.idx.size(); m.idx.insert(m.idx.end(), kv.second.begin(), kv.second.end()); m.secs.push_back({ kv.first, { first, (u32)kv.second.size() / 3 } }); }
    } catch (std::exception& ex) { m.err = ex.what(); }
    return m;
}
// the level BSP: the Model whose outer is the PersistentLevel itself (the brush/volume ones live inside the actors)
// (Models referenced by the Brush property of some actor = volumes/triggers/blocking -> excluded; they are not visible geometry)
inline std::set<i32> brushModels(const Package& pk) {
    std::set<i32> s; for (size_t k = 0; k < pk.exports.size(); k++) { const Export& e = pk.exports[k]; std::string c = pk.classOf(e);
        if (c == "Model" || c == "Polys" || c.find("Component") != std::string::npos || c == "Class") continue;
        try { ObjProps op = objProps(pk, (i32)k + 1); if (!op.ok) continue; const Tag* b = findTag(op.tags, "Brush"); if (b) { i32 r = tagObj(*b); if (r > 0) s.insert(r); } } catch (...) {} }
    return s;
}
inline std::vector<i32> levelModels(const Package& pk) {
    std::set<i32> skip = brushModels(pk);
    std::vector<i32> out; for (size_t k = 0; k < pk.exports.size(); k++) { const Export& e = pk.exports[k]; if (pk.classOf(e) != "Model" || e.outer <= 0) continue;
        if (skip.count((i32)k + 1)) continue;
        if (pk.nm(pk.exports[e.outer - 1].name) == "PersistentLevel") out.push_back((i32)k + 1); } return out;
}

// ------------------------------------------------------------------ Terrain (grid heights; actor LocalToWorld; Z = (h-32768)/128)
struct TerrainMesh { std::vector<float> pos; std::vector<uint32_t> idx; std::string err; };
inline TerrainMesh parseTerrain(const Package& pk, i32 idx, const float defScale3D[3]) {
    TerrainMesh t; const Export& e = pk.exports[idx - 1];
    try {
        ObjProps op = objProps(pk, idx); if (!op.ok) throw Err("no props");
        i32 nx = tagInt(op.tags, "NumVerticesX"), ny = tagInt(op.tags, "NumVerticesY"); if (nx < 2 || ny < 2 || nx > 8192 || ny > 8192) throw Err("bad terrain size");
        Reader r(pk.dataPtr(e), pk.dataLen(e), op.end); i32 hc = r.i(); if (hc != nx * ny) throw Err("height count mismatch"); r.need((size_t)hc * 2);
        const u8* hp = r.d + r.p; r.p += (size_t)hc * 2; i32 ic = r.i(); r.need((size_t)std::max(0, ic)); const u8* info = ic == hc ? r.d + r.p : nullptr;
        std::vector<Tag> tags = op.tags;
        if (!findTag(tags, "DrawScale3D")) setStructTag(tags, "DrawScale3D", "Vector", defScale3D, 12);
        M4 w = actorMatrix(tags); t.pos.resize((size_t)hc * 3);
        for (i32 y = 0; y < ny; y++) for (i32 x = 0; x < nx; x++) { uint16_t h; memcpy(&h, hp + ((size_t)y * nx + x) * 2, 2); float l[3] = { (float)x, (float)y, (h - 32768.f) / 128.f };
            float* o = &t.pos[((size_t)y * nx + x) * 3]; for (int k = 0; k < 3; k++) o[k] = l[0] * w.m[0][k] + l[1] * w.m[1][k] + l[2] * w.m[2][k] + w.m[3][k]; }
        for (i32 y = 0; y + 1 < ny; y++) for (i32 x = 0; x + 1 < nx; x++) {
            if (info && (info[(size_t)y * nx + x] & 1)) continue;                       // hole (TID_Visibility_Off)
            uint32_t a = (uint32_t)(y * nx + x), b = a + 1, c = a + nx, d = c + 1; t.idx.insert(t.idx.end(), { a, c, b, b, c, d }); }
    } catch (std::exception& ex) { t.err = ex.what(); }
    return t;
}

} // namespace bm
