// bmscript.hpp - UnrealScript of Batman: Arkham Asylum (UE3 v576 / lic 21): reading the script structures
// (Class/State/Function/ScriptStruct/Property/Enum/Const), bytecode tokenization (port of the engine's
// ScriptSerialization.h), decompilation to pseudo-UnrealScript and edits that preserve the bytecode size.
// 32-bit PC: pointers in the bytecode = 4 bytes (package index), FName = 8 bytes -> jump offsets = on-disk offsets.
#pragma once
#include "bmasset.hpp"
#include <functional>
#include <sstream>

namespace bm {
namespace us {

// ------------------------------------------------------------------ flags
inline std::string flagsText(uint64_t f, const std::vector<std::pair<uint64_t, const char*>>& t) { std::string s; for (auto& p : t) if (f & p.first) { if (!s.empty()) s += " "; s += p.second; } return s; }
static const std::vector<std::pair<uint64_t, const char*>> kFuncFlags = { {0x1,"final"},{0x4,"iterator"},{0x8,"latent"},{0x10,"preoperator"},{0x20,"singular"},{0x40,"net"},{0x80,"reliable"},{0x100,"simulated"},{0x200,"exec"},{0x400,"native"},{0x800,"event"},{0x1000,"operator"},{0x2000,"static"},{0x8000,"const"},{0x40000,"private"},{0x80000,"protected"},{0x100000,"delegate"},{0x1000000,"client"},{0x200000,"server"} };
static const std::vector<std::pair<uint64_t, const char*>> kPropFlags = { {0x1,"edit"},{0x2,"const"},{0x4,"input"},{0x8,"export"},{0x10,"optional"},{0x20,"net"},{0x40,"editfixedsize"},{0x80,"parm"},{0x100,"out"},{0x200,"skip"},{0x400,"return"},{0x800,"coerce"},{0x1000,"native"},{0x2000,"transient"},{0x4000,"config"},{0x8000,"localized"},{0x20000,"editconst"},{0x40000,"globalconfig"},{0x80000,"component"},{0x200000,"duplicatetransient"},{0x800000,"noexport"},{0x1000000,"noimport"},{0x2000000,"noclear"},{0x4000000,"editinline"},{0x20000000,"deprecated"},{0x100000000ull,"repnotify"},{0x200000000ull,"interp"},{0x800000000ull,"editoronly"} };
static const std::vector<std::pair<uint64_t, const char*>> kClassFlags = { {0x1,"abstract"},{0x4,"config"},{0x8,"transient"},{0x80,"native"},{0x200,"placeable"},{0x400,"perobjectconfig"},{0x1000,"editinlinenew"},{0x2000,"collapsecategories"},{0x4000,"interface"},{0x1000000,"hidden"},{0x2000000,"deprecated"} };

// ------------------------------------------------------------------ fields
struct FieldInfo {
    std::string cls; bool ok = false; std::string err;
    i32 superField = 0, next = 0;
    bool isStruct = false; i32 scriptText = 0, children = 0, cppText = 0, line = 0, textPos = 0, scriptSize = 0; size_t scriptOff = 0;
    bool isFunction = false; uint16_t iNative = 0; u8 operPrec = 0; u32 funcFlags = 0; size_t funcFlagsOff = 0; uint16_t repOffset = 0; FName friendly;
    bool isState = false; uint64_t probeMask = 0, ignoreMask = 0; uint16_t labelTableOffset = 0xFFFF; u32 stateFlags = 0; std::vector<std::pair<FName, i32>> funcMap;
    bool isClass = false; u32 classFlags = 0; size_t classFlagsOff = 0; i32 within = 0, cdo = 0; FName configName; std::vector<FName> hideCats; std::vector<i32> interfaces;
    bool isScriptStruct = false; u32 structFlags = 0;
    bool isProperty = false; i32 arrayDim = 1; uint64_t propFlags = 0; size_t propFlagsOff = 0; FName category; i32 arraySizeEnum = 0; i32 ref1 = 0, ref2 = 0;
    bool isEnum = false; std::vector<FName> enumNames;
    bool isConst = false; std::string constValue;
    size_t end = 0; size_t superOff = 0, nextOff = 0, childrenOff = 0, labelTableOffsetOff = 0, funcMapOff = 0, funcFlagsOff2 = 0;
};
inline bool isPropClass(const std::string& c) { static const char* k[] = { "IntProperty", "FloatProperty", "BoolProperty", "ByteProperty", "NameProperty", "StrProperty", "ObjectProperty", "ClassProperty",
    "ComponentProperty", "InterfaceProperty", "StructProperty", "ArrayProperty", "MapProperty", "DelegateProperty" }; for (auto x : k) if (c == x) return true; return false; }

inline FieldInfo parseField(const Package& pk, i32 idx) {
    FieldInfo f; const Export& e = pk.exports[idx - 1]; f.cls = pk.classOf(e);
    const u8* d = pk.dataPtr(e); size_t n = pk.dataLen(e);
    try {
        Reader r(d, n, 0);
        r.i();                                                   // NetIndex
        if (r.p + 8 <= n) { FName nf; memcpy(&nf.idx, d + r.p, 4); memcpy(&nf.num, d + r.p + 4, 4); if (nf.idx >= 0 && nf.idx < (i32)pk.names.size() && pk.nm(nf) == "None") r.p += 8; }
        auto rname = [&]() { FName x; x.idx = r.i(); x.num = r.i(); return x; };
        const std::string& c = f.cls;
        bool field = c == "Class" || c == "State" || c == "Function" || c == "ScriptStruct" || c == "Struct" || c == "Enum" || c == "Const" || isPropClass(c);
        if (!field) throw Err("not a script field");
        f.superOff = r.p; f.superField = r.i(); f.nextOff = r.p; f.next = r.i();
        if (c == "Class" || c == "State" || c == "Function" || c == "ScriptStruct" || c == "Struct") {
            f.isStruct = true; f.scriptText = r.i(); f.childrenOff = r.p; f.children = r.i(); f.cppText = r.i(); f.line = r.i(); f.textPos = r.i(); f.scriptSize = r.i();
            if (f.scriptSize < 0 || r.p + (size_t)f.scriptSize > n) throw Err("bad ScriptSize");
            f.scriptOff = r.p; r.p += (size_t)f.scriptSize;
            if (c == "Function") { f.isFunction = true; memcpy(&f.iNative, d + r.p, 2); r.p += 2; f.operPrec = d[r.p++]; f.funcFlagsOff = r.p; f.funcFlags = r.u();
                if (f.funcFlags & 0x40) { memcpy(&f.repOffset, d + r.p, 2); r.p += 2; } f.friendly = rname(); }
            else if (c == "ScriptStruct") { f.isScriptStruct = true; f.structFlags = r.u(); /* defaults (tagged) follow */ }
            else if (c == "State" || c == "Class") {
                f.isState = true; f.probeMask = r.q(); f.ignoreMask = r.q(); f.labelTableOffsetOff = r.p; memcpy(&f.labelTableOffset, d + r.p, 2); r.p += 2; f.stateFlags = r.u();
                f.funcMapOff = r.p; i32 nm = r.i(); if (nm < 0 || nm > 100000) throw Err("bad FuncMap"); for (i32 k = 0; k < nm; k++) { FName a = rname(); i32 o = r.i(); f.funcMap.push_back({ a, o }); }
                if (c == "Class") { f.isClass = true; f.classFlagsOff = r.p; f.classFlags = r.u(); f.within = r.i(); f.configName = rname();
                    i32 nc = r.i(); if (nc < 0 || nc > 10000) throw Err("bad component map"); r.p += (size_t)nc * 12;
                    i32 ni = r.i(); if (ni < 0 || ni > 10000) throw Err("bad interfaces"); for (i32 k = 0; k < ni; k++) { f.interfaces.push_back(r.i()); r.i(); }
                    for (int a = 0; a < 3; a++) { i32 cnt = r.i(); if (cnt < 0 || cnt > 10000) throw Err("bad categories"); for (i32 k = 0; k < cnt; k++) { FName x = rname(); if (a == 0) f.hideCats.push_back(x); } }
                    f.cdo = r.i(); }
            }
        } else if (c == "Enum") { f.isEnum = true; i32 cnt = r.i(); for (i32 k = 0; k < cnt; k++) f.enumNames.push_back(rname()); }
        else if (c == "Const") { f.isConst = true; i32 len = r.i(); if (len > 0) { r.need((size_t)len); f.constValue.assign((const char*)d + r.p, (size_t)len - 1); r.p += (size_t)len; } else if (len < 0) { r.need((size_t)-len * 2); std::string s; for (i32 k = 0; k < -len - 1; k++) s += (char)d[r.p + k * 2]; f.constValue = s; r.p += (size_t)-len * 2; } }
        else {
            f.isProperty = true; f.arrayDim = r.i(); f.propFlagsOff = r.p; f.propFlags = r.q(); f.category = rname(); f.arraySizeEnum = r.i();
            if (f.propFlags & 0x20) { memcpy(&f.repOffset, d + r.p, 2); r.p += 2; }
            if (c == "ByteProperty" || c == "ObjectProperty" || c == "ComponentProperty" || c == "StructProperty" || c == "ArrayProperty" || c == "InterfaceProperty" || c == "ClassProperty" || c == "DelegateProperty" || c == "MapProperty") f.ref1 = r.i();
            if (c == "ClassProperty" || c == "DelegateProperty" || c == "MapProperty") f.ref2 = r.i();
        }
        f.end = r.p; f.ok = true;
    } catch (std::exception& ex) { f.err = ex.what(); }
    return f;
}

// ------------------------------------------------------------------ tokens
enum : u8 {
    EX_LocalVariable = 0x00, EX_InstanceVariable = 0x01, EX_DefaultVariable = 0x02, EX_Return = 0x04, EX_Switch = 0x05, EX_Jump = 0x06, EX_JumpIfNot = 0x07, EX_Stop = 0x08,
    EX_Assert = 0x09, EX_Case = 0x0A, EX_Nothing = 0x0B, EX_LabelTable = 0x0C, EX_GotoLabel = 0x0D, EX_EatReturnValue = 0x0E, EX_Let = 0x0F, EX_DynArrayElement = 0x10,
    EX_New = 0x11, EX_ClassContext = 0x12, EX_MetaCast = 0x13, EX_LetBool = 0x14, EX_EndParmValue = 0x15, EX_EndFunctionParms = 0x16, EX_Self = 0x17, EX_Skip = 0x18,
    EX_Context = 0x19, EX_ArrayElement = 0x1A, EX_VirtualFunction = 0x1B, EX_FinalFunction = 0x1C, EX_IntConst = 0x1D, EX_FloatConst = 0x1E, EX_StringConst = 0x1F,
    EX_ObjectConst = 0x20, EX_NameConst = 0x21, EX_RotationConst = 0x22, EX_VectorConst = 0x23, EX_ByteConst = 0x24, EX_IntZero = 0x25, EX_IntOne = 0x26, EX_True = 0x27,
    EX_False = 0x28, EX_NativeParm = 0x29, EX_NoObject = 0x2A, EX_IntConstByte = 0x2C, EX_BoolVariable = 0x2D, EX_DynamicCast = 0x2E, EX_Iterator = 0x2F,
    EX_IteratorPop = 0x30, EX_IteratorNext = 0x31, EX_StructCmpEq = 0x32, EX_StructCmpNe = 0x33, EX_UnicodeStringConst = 0x34, EX_StructMember = 0x35,
    EX_DynArrayLength = 0x36, EX_GlobalFunction = 0x37, EX_PrimitiveCast = 0x38, EX_DynArrayInsert = 0x39, EX_ReturnNothing = 0x3A, EX_EqualEqual_DelDel = 0x3B,
    EX_NotEqual_DelDel = 0x3C, EX_EqualEqual_DelFunc = 0x3D, EX_NotEqual_DelFunc = 0x3E, EX_EmptyDelegate = 0x3F, EX_DynArrayRemove = 0x40, EX_DebugInfo = 0x41,
    EX_DelegateFunction = 0x42, EX_DelegateProperty = 0x43, EX_LetDelegate = 0x44, EX_Conditional = 0x45, EX_DynArrayFind = 0x46, EX_DynArrayFindStruct = 0x47,
    EX_LocalOutVariable = 0x48, EX_DefaultParmValue = 0x49, EX_EmptyParmValue = 0x4A, EX_InstanceDelegate = 0x4B, EX_InterfaceContext = 0x51, EX_InterfaceCast = 0x52,
    EX_EndOfScript = 0x53, EX_DynArrayAdd = 0x54, EX_DynArrayAddItem = 0x55, EX_DynArrayRemoveItem = 0x56, EX_DynArrayInsertItem = 0x57, EX_DynArrayIterator = 0x58,
    EX_RSSContext = 0x50, EX_ExtendedNative = 0x60, EX_FirstNative = 0x70
};
struct Tok {
    u8 op = 0; u32 pos = 0, size = 0;       // pos relative to the start of the bytecode
    int native = -1;                         // native index (>=0) for native calls
    std::vector<int> kids;                   // indices into Script::toks
    // operands
    i32 ref = 0, ref2 = 0; FName name; uint16_t w = 0, w2 = 0; u8 b = 0, b2 = 0; i32 iv = 0; float fv[3] = { 0, 0, 0 }; i32 rv[3] = { 0, 0, 0 }; std::string str;
    std::vector<std::pair<FName, i32>> labels;
    u32 operandPos = 0;                      // where the editable value starts (constants)
};
struct Script { std::vector<Tok> toks; std::vector<int> stmts; std::string err; const u8* code = nullptr; u32 size = 0; };

class Tokenizer {
public:
    const u8* c; u32 n; u32 p = 0; Script& S;
    Tokenizer(const u8* code, u32 size, Script& s) : c(code), n(size), S(s) {}
    void need(u32 k) { if (p + k > n) throw Err("bytecode truncated at " + std::to_string(p)); }
    u8 rb() { need(1); return c[p++]; }
    uint16_t rw() { need(2); uint16_t v; memcpy(&v, c + p, 2); p += 2; return v; }
    i32 ri() { need(4); i32 v; memcpy(&v, c + p, 4); p += 4; return v; }
    float rf() { need(4); float v; memcpy(&v, c + p, 4); p += 4; return v; }
    FName rn() { FName f; f.idx = ri(); f.num = ri(); return f; }
    void debugInfo() {   // HANDLE_OPTIONAL_DEBUG_INFO (version 100 only)
        if (p + 5 <= n && c[p] == EX_DebugInfo) { i32 ver; memcpy(&ver, c + p + 1, 4); if (ver == 100) expr(); }
    }
    int expr() {
        int id = (int)S.toks.size(); S.toks.emplace_back(); u32 start = p; u8 op = rb(); S.toks[id].op = op; S.toks[id].pos = start;
        auto kid = [&]() { int k = expr(); S.toks[id].kids.push_back(k); return k; };
        auto parms = [&]() { for (int g = 0; g < 1000; g++) { int k = kid(); if (S.toks[k].op == EX_EndFunctionParms) break; } debugInfo(); };
        Tok* t = &S.toks[id];
        if (op >= EX_FirstNative) { t->native = op; parms(); }
        else if (op >= EX_ExtendedNative) { u8 lo = rb(); S.toks[id].native = ((op - EX_ExtendedNative) << 8) + lo; parms(); }
        else switch (op) {
            case EX_PrimitiveCast: t->b = rb(); kid(); break;
            case EX_InterfaceCast: t->ref = ri(); kid(); break;
            case EX_Let: case EX_LetBool: case EX_LetDelegate: kid(); kid(); break;
            case EX_Jump: t->w = rw(); break;
            case EX_LocalVariable: case EX_InstanceVariable: case EX_DefaultVariable: case EX_LocalOutVariable: case EX_NativeParm: t->ref = ri(); break;
            case EX_DebugInfo: t->operandPos = p; t->iv = ri(); ri(); ri(); rb(); break;
            case EX_BoolVariable: case EX_InterfaceContext: kid(); break;
            case EX_Nothing: case EX_EndOfScript: case EX_EndFunctionParms: case EX_EmptyParmValue: case EX_IntZero: case EX_IntOne: case EX_True: case EX_False:
            case EX_NoObject: case EX_EmptyDelegate: case EX_Self: case EX_IteratorPop: case EX_Stop: case EX_IteratorNext: case EX_EndParmValue: break;
            case EX_ReturnNothing: case EX_EatReturnValue: t->ref = ri(); break;
            case EX_Return: kid(); break;
            case EX_FinalFunction: t->ref = ri(); parms(); break;
            case EX_VirtualFunction: case EX_GlobalFunction: t->name = rn(); parms(); break;
            case EX_DelegateFunction: t->b = rb(); t->ref = ri(); t->name = rn(); parms(); break;
            case EX_ClassContext: case EX_Context: case EX_RSSContext: kid(); S.toks[id].w = rw(); S.toks[id].w2 = rw(); kid(); break;
            case EX_DynArrayIterator: kid(); kid(); S.toks[id].b = rb(); kid(); S.toks[id].w = rw(); break;
            case EX_ArrayElement: case EX_DynArrayElement: kid(); kid(); break;
            case EX_DynArrayLength: kid(); break;
            case EX_DynArrayAdd: kid(); kid(); break;
            case EX_DynArrayInsert: case EX_DynArrayRemove: kid(); kid(); kid(); break;
            case EX_DynArrayAddItem: case EX_DynArrayRemoveItem: case EX_DynArrayFind: kid(); S.toks[id].w = rw(); kid(); break;
            case EX_DynArrayInsertItem: kid(); S.toks[id].w = rw(); kid(); kid(); break;
            case EX_DynArrayFindStruct: kid(); S.toks[id].w = rw(); kid(); kid(); break;
            case EX_Conditional: kid(); S.toks[id].w = rw(); kid(); S.toks[id].w2 = rw(); kid(); break;
            case EX_New: kid(); kid(); kid(); kid(); kid(); break;   // outer, name, flags, class, template
            case EX_IntConst: t->operandPos = p; t->iv = ri(); break;
            case EX_FloatConst: t->operandPos = p; t->fv[0] = rf(); break;
            case EX_StringConst: { t->operandPos = p; std::string s; for (;;) { u8 ch = rb(); if (!ch) break; s += (char)ch; } S.toks[id].str = s; break; }
            case EX_UnicodeStringConst: { t->operandPos = p; std::string s; for (;;) { uint16_t ch = rw(); if (!ch) break; s += ch < 128 ? (char)ch : '?'; } S.toks[id].str = s; break; }
            case EX_ObjectConst: t->operandPos = p; t->ref = ri(); break;
            case EX_NameConst: t->operandPos = p; t->name = rn(); break;
            case EX_RotationConst: t->operandPos = p; t->rv[0] = ri(); t->rv[1] = ri(); t->rv[2] = ri(); break;
            case EX_VectorConst: t->operandPos = p; t->fv[0] = rf(); t->fv[1] = rf(); t->fv[2] = rf(); break;
            case EX_ByteConst: case EX_IntConstByte: t->operandPos = p; t->b = rb(); break;
            case EX_MetaCast: case EX_DynamicCast: t->ref = ri(); kid(); break;
            case EX_JumpIfNot: t->w = rw(); kid(); break;
            case EX_Iterator: kid(); S.toks[id].w = rw(); break;
            case EX_Switch: t->w2 = rw(); kid(); break;
            case EX_Assert: t->w = rw(); t->b = rb(); kid(); break;
            case EX_Case: { uint16_t w = rw(); S.toks[id].w = w; if (w != 0xFFFF) kid(); break; }
            case EX_LabelTable: for (int g = 0; g < 10000; g++) { FName nm = rn(); i32 off = ri(); S.toks[id].labels.push_back({ nm, off }); if (nm.idx == noneIdx) break; } break;
            case EX_GotoLabel: kid(); break;
            case EX_Skip: t->w = rw(); kid(); break;
            case EX_DefaultParmValue: t->w = rw(); debugInfo(); kid(); debugInfo(); rb(); break;
            case EX_StructCmpEq: case EX_StructCmpNe: t->ref = ri(); kid(); kid(); break;
            case EX_StructMember: t->ref = ri(); t->ref2 = ri(); t->b = rb(); t->b2 = rb(); kid(); break;
            case EX_DelegateProperty: case EX_InstanceDelegate: t->name = rn(); break;
            case EX_EqualEqual_DelDel: case EX_NotEqual_DelDel: case EX_EqualEqual_DelFunc: case EX_NotEqual_DelFunc: parms(); break;
            default: throw Err("unknown token 0x" + [&] { char b[8]; snprintf(b, sizeof b, "%02X", op); return std::string(b); }() + " at " + std::to_string(start));
        }
        S.toks[id].size = p - start; return id;
    }
    i32 noneIdx = -1;
};
inline Script tokenize(const Package& pk, const u8* code, u32 size) {
    Script s; s.code = code; s.size = size; Tokenizer t(code, size, s); t.noneIdx = pk.findName("None");
    try { while (t.p < size) { int id = t.expr(); s.stmts.push_back(id); } } catch (std::exception& e) { s.err = e.what(); }
    return s;
}

// ------------------------------------------------------------------ native function table (iNative -> name/operator)
struct NativeInfo { std::string name, friendly; u32 flags = 0; u8 prec = 0; };
using NativeTable = std::map<int, NativeInfo>;
inline void collectNatives(const Package& pk, NativeTable& out) {
    for (size_t k = 0; k < pk.exports.size(); k++) { if (pk.classOf(pk.exports[k]) != "Function") continue; FieldInfo f = parseField(pk, (i32)k + 1); if (!f.ok || !f.iNative) continue;
        NativeInfo ni; ni.name = pk.objName((i32)k + 1); ni.friendly = pk.nm(f.friendly); ni.flags = f.funcFlags; ni.prec = f.operPrec; out[f.iNative] = ni; }
}

// ------------------------------------------------------------------ decompilation
struct Line { u32 pos = 0, end = 0; int indent = 0; std::string text; int stmt = -1; int tok = -1; bool synthetic = false; };
class Decompiler {
public:
    const Package& pk; const Script& S; const NativeTable& natives;
    std::map<u32, std::string> labelAt;
    Decompiler(const Package& p, const Script& s, const NativeTable& n) : pk(p), S(s), natives(n) {}
    std::string obj(i32 r) { return r ? pk.objName(r) : "None"; }
    static std::string fstr(float f) { char b[48]; snprintf(b, sizeof b, "%.6g", f); std::string s = b; if (s.find('.') == std::string::npos && s.find('e') == std::string::npos && s.find("inf") == std::string::npos && s.find("nan") == std::string::npos) s += ".0"; return s; }
    std::string args(const Tok& t, size_t from = 0) {
        std::string s; bool first = true;
        size_t last = from; for (size_t k = from; k < t.kids.size(); k++) { const Tok& a = S.toks[t.kids[k]]; if (a.op == EX_EndFunctionParms) break; if (a.op != EX_EmptyParmValue) last = k + 1; }
        for (size_t k = from; k < last; k++) { const Tok& a = S.toks[t.kids[k]]; if (!first) s += ", "; first = false; if (a.op != EX_EmptyParmValue) s += e(t.kids[k]); }
        return s;
    }
    std::string castName(u8 c) {
        static const std::map<u8, const char*> m = { {0x36,"Object"},{0x37,"string"},{0x38,"bool"},{0x39,"vector"},{0x3A,"int"},{0x3B,"bool"},{0x3C,"float"},{0x3D,"byte"},{0x3E,"bool"},{0x3F,"float"},{0x40,"byte"},{0x41,"int"},{0x42,"float"},
            {0x43,"byte"},{0x44,"int"},{0x45,"bool"},{0x46,"interface"},{0x47,"bool"},{0x48,"bool"},{0x49,"byte"},{0x4A,"int"},{0x4B,"bool"},{0x4C,"float"},{0x4D,"vector"},{0x4E,"rotator"},{0x4F,"bool"},{0x50,"rotator"},
            {0x51,"bool"},{0x52,"string"},{0x53,"string"},{0x54,"string"},{0x55,"string"},{0x56,"string"},{0x57,"string"},{0x58,"string"},{0x59,"string"},{0x5A,"string"},{0x60,"name"} };
        auto it = m.find(c); return it != m.end() ? it->second : "cast";
    }
    std::string callNative(const Tok& t) {
        auto it = natives.find(t.native); std::string nm = it != natives.end() ? it->second.name : ("native" + std::to_string(t.native));
        if (it != natives.end() && (it->second.flags & 0x1000)) {   // operator
            std::string op = it->second.friendly.empty() || it->second.friendly == "None" ? nm : it->second.friendly;
            std::vector<int> a; for (int k : t.kids) if (S.toks[k].op != EX_EndFunctionParms) a.push_back(k);
            if (a.size() == 2) return "(" + e(a[0]) + " " + op + " " + e(a[1]) + ")";
            if (a.size() == 1) return (it->second.flags & 0x10) ? op + e(a[0]) : e(a[0]) + op;
        }
        return nm + "(" + args(t) + ")";
    }
    std::string e(int id) {
        const Tok& t = S.toks[id];
        if (t.native >= 0) return callNative(t);
        switch (t.op) {
            case EX_LocalVariable: case EX_InstanceVariable: case EX_LocalOutVariable: case EX_NativeParm: return obj(t.ref);
            case EX_DefaultVariable: return "default." + obj(t.ref);
            case EX_Return: return (S.toks[t.kids[0]].op == EX_Nothing || S.toks[t.kids[0]].op == EX_ReturnNothing) ? "return" : "return " + e(t.kids[0]);
            case EX_ReturnNothing: return "return";
            case EX_Jump: { char b[40]; snprintf(b, sizeof b, "goto 0x%04X", t.w); return b; }
            case EX_JumpIfNot: { char b[40]; snprintf(b, sizeof b, " goto 0x%04X", t.w); return "if (!" + e(t.kids[0]) + ")" + b; }
            case EX_Stop: return "stop";
            case EX_Assert: return "assert(" + e(t.kids[0]) + ")";
            case EX_Case: { if (t.w == 0xFFFF) return "default:"; return "case " + e(t.kids[0]) + ":"; }
            case EX_Nothing: return "";
            case EX_LabelTable: return "// label table";
            case EX_GotoLabel: return "goto " + e(t.kids[0]);
            case EX_EatReturnValue: return "";
            case EX_Let: case EX_LetBool: case EX_LetDelegate: return e(t.kids[0]) + " = " + e(t.kids[1]);
            case EX_DynArrayElement: case EX_ArrayElement: return e(t.kids[1]) + "[" + e(t.kids[0]) + "]";
            case EX_New: return "new(" + e(t.kids[0]) + ", " + e(t.kids[1]) + ", " + e(t.kids[2]) + ") " + e(t.kids[3]);
            case EX_ClassContext: return e(t.kids[0]) + ".static." + e(t.kids[1]);
            case EX_MetaCast: return "class<" + obj(t.ref) + ">(" + e(t.kids[0]) + ")";
            case EX_EndParmValue: case EX_EndFunctionParms: return "";
            case EX_Self: return "self";
            case EX_Skip: return e(t.kids[0]);
            case EX_Context: case EX_RSSContext: return e(t.kids[0]) + "." + e(t.kids[1]);
            case EX_VirtualFunction: return pk.nm(t.name) + "(" + args(t) + ")";
            case EX_GlobalFunction: return "global." + pk.nm(t.name) + "(" + args(t) + ")";
            case EX_FinalFunction: return obj(t.ref) + "(" + args(t) + ")";
            case EX_IntConst: return std::to_string(t.iv);
            case EX_FloatConst: return fstr(t.fv[0]);
            case EX_StringConst: case EX_UnicodeStringConst: return "\"" + t.str + "\"";
            case EX_ObjectConst: return t.ref ? "'" + pk.objPath(t.ref) + "'" : "None";
            case EX_NameConst: return "'" + pk.nm(t.name) + "'";
            case EX_RotationConst: return "rot(" + std::to_string(t.rv[0]) + ", " + std::to_string(t.rv[1]) + ", " + std::to_string(t.rv[2]) + ")";
            case EX_VectorConst: return "vect(" + fstr(t.fv[0]) + ", " + fstr(t.fv[1]) + ", " + fstr(t.fv[2]) + ")";
            case EX_ByteConst: case EX_IntConstByte: return std::to_string(t.b);
            case EX_IntZero: return "0"; case EX_IntOne: return "1"; case EX_True: return "true"; case EX_False: return "false";
            case EX_NoObject: return "None"; case EX_EmptyDelegate: return "None";
            case EX_BoolVariable: case EX_InterfaceContext: return e(t.kids[0]);
            case EX_DynamicCast: return obj(t.ref) + "(" + e(t.kids[0]) + ")";
            case EX_InterfaceCast: return obj(t.ref) + "(" + e(t.kids[0]) + ")";
            case EX_Iterator: return "foreach " + e(t.kids[0]);
            case EX_IteratorPop: return "// iterator pop"; case EX_IteratorNext: return "// iterator next";
            case EX_StructCmpEq: return "(" + e(t.kids[0]) + " == " + e(t.kids[1]) + ")";
            case EX_StructCmpNe: return "(" + e(t.kids[0]) + " != " + e(t.kids[1]) + ")";
            case EX_StructMember: return e(t.kids[0]) + "." + obj(t.ref);
            case EX_DynArrayLength: return e(t.kids[0]) + ".Length";
            case EX_PrimitiveCast: return castName(t.b) + "(" + e(t.kids[0]) + ")";
            case EX_DynArrayInsert: return e(t.kids[0]) + ".Insert(" + e(t.kids[1]) + ", " + e(t.kids[2]) + ")";
            case EX_DynArrayRemove: return e(t.kids[0]) + ".Remove(" + e(t.kids[1]) + ", " + e(t.kids[2]) + ")";
            case EX_DynArrayAdd: return e(t.kids[0]) + ".Add(" + e(t.kids[1]) + ")";
            case EX_DynArrayAddItem: return e(t.kids[0]) + ".AddItem(" + e(t.kids[1]) + ")";
            case EX_DynArrayRemoveItem: return e(t.kids[0]) + ".RemoveItem(" + e(t.kids[1]) + ")";
            case EX_DynArrayInsertItem: return e(t.kids[0]) + ".InsertItem(" + e(t.kids[1]) + ", " + e(t.kids[2]) + ")";
            case EX_DynArrayFind: return e(t.kids[0]) + ".Find(" + e(t.kids[1]) + ")";
            case EX_DynArrayFindStruct: return e(t.kids[0]) + ".Find(" + e(t.kids[1]) + ", " + e(t.kids[2]) + ")";
            case EX_DynArrayIterator: return "foreach " + e(t.kids[0]) + "(" + e(t.kids[1]) + (t.b ? ", " + e(t.kids[2]) : "") + ")";
            case EX_Conditional: return "(" + e(t.kids[0]) + " ? " + e(t.kids[1]) + " : " + e(t.kids[2]) + ")";
            case EX_EqualEqual_DelDel: case EX_EqualEqual_DelFunc: return "(" + args(t) + ") /*==*/";
            case EX_NotEqual_DelDel: case EX_NotEqual_DelFunc: return "(" + args(t) + ") /*!=*/";
            case EX_DelegateFunction: return obj(t.ref) + "(" + args(t) + ")";
            case EX_DelegateProperty: case EX_InstanceDelegate: return pk.nm(t.name);
            case EX_DefaultParmValue: return "// default value of optional parameter: " + e(t.kids[0]);
            case EX_EmptyParmValue: return "";
            case EX_Switch: return "switch (" + e(t.kids[0]) + ")";
            case EX_DebugInfo: return "";
            case EX_EndOfScript: return "";
        }
        char b[32]; snprintf(b, sizeof b, "/*op %02X*/", t.op); return b;
    }
    // statement list (EatReturnValue + call = one statement)
    std::vector<Line> lines() {
        std::vector<Line> out;
        for (size_t i = 0; i < S.stmts.size(); i++) {
            const Tok& t = S.toks[S.stmts[i]]; Line L; L.pos = t.pos; L.end = t.pos + t.size; L.stmt = (int)i;
            if (t.op == EX_EndOfScript) continue;
            if (t.op == EX_EatReturnValue && i + 1 < S.stmts.size()) { i++; const Tok& n = S.toks[S.stmts[i]]; L.end = n.pos + n.size; L.text = e(S.stmts[i]); }
            else if (t.op == EX_Nothing) { L.text = "// (nothing)"; u32 e2 = L.end; while (i + 1 < S.stmts.size() && S.toks[S.stmts[i + 1]].op == EX_Nothing) { i++; e2 = S.toks[S.stmts[i]].pos + 1; } L.end = e2; }
            else L.text = e(S.stmts[i]);
            if (L.text.empty()) L.text = "//"; L.tok = S.stmts[L.stmt]; if (t.op == EX_EatReturnValue) L.tok = S.stmts[i]; out.push_back(L);
        }
        return out;
    }
    // if/else/while structure from the jumps (if something does not fit, it falls back to "goto")
    std::vector<Line> structured() {
        std::vector<Line> flat = lines(), out;
        auto idxAt = [&](u32 pos, size_t from, size_t to) -> long { for (size_t k = from; k < to; k++) if (flat[k].pos == pos) return (long)k; if (to < flat.size() && flat[to].pos == pos) return (long)to; return -1; };
        std::function<void(size_t, size_t, int)> emit = [&](size_t a, size_t b, int ind) {
            for (size_t k = a; k < b; k++) {
                const Line& L = flat[k]; const Tok& t = S.toks[L.tok];
                if (t.op == EX_JumpIfNot && t.w > L.pos) {
                    long m = idxAt(t.w, k + 1, b);
                    if (m < 0 && t.w == (b < flat.size() ? flat[b].pos : 0xFFFFFFFF)) m = (long)b;
                    if (m < 0 && b == flat.size() && t.w >= (flat.empty() ? 0 : flat.back().end)) m = (long)b;
                    if (m > (long)k) {
                        std::string cond = e(t.kids[0]);
                        const Line* lastL = (m - 1 > (long)k) ? &flat[m - 1] : nullptr; const Tok* lt = lastL ? &S.toks[lastL->tok] : nullptr;
                        if (lt && lt->op == EX_Jump && lt->w <= L.pos && lt->w >= (k ? flat[0].pos : 0) && idxAt(lt->w, 0, k + 1) >= 0 && lt->w == L.pos) {   // while
                            Line h = L; h.indent = ind; h.text = "while (" + cond + ")"; out.push_back(h); Line o; o.synthetic = true; o.indent = ind; o.text = "{"; out.push_back(o);
                            emit(k + 1, (size_t)m - 1, ind + 1); Line j = *lastL; j.indent = ind + 1; j.text = "// continue"; j.synthetic = false; out.push_back(j);
                            Line cl; cl.synthetic = true; cl.indent = ind; cl.text = "}"; out.push_back(cl); k = (size_t)m - 1; continue;
                        }
                        if (lt && lt->op == EX_Jump && lt->w > t.w) {   // else
                            long m2 = idxAt(lt->w, (size_t)m, b); if (m2 < 0 && lt->w == (b < flat.size() ? flat[b].pos : 0xFFFFFFFF)) m2 = (long)b;
                            if (m2 >= m) {
                                Line h = L; h.indent = ind; h.text = "if (" + cond + ")"; out.push_back(h); Line o; o.synthetic = true; o.indent = ind; o.text = "{"; out.push_back(o);
                                emit(k + 1, (size_t)m - 1, ind + 1);
                                Line el = *lastL; el.indent = ind; el.text = "}  else  {"; out.push_back(el);
                                emit((size_t)m, (size_t)m2, ind + 1); Line cl; cl.synthetic = true; cl.indent = ind; cl.text = "}"; out.push_back(cl); k = (size_t)m2 - 1; continue;
                            }
                        }
                        Line h = L; h.indent = ind; h.text = "if (" + cond + ")"; out.push_back(h); Line o; o.synthetic = true; o.indent = ind; o.text = "{"; out.push_back(o);
                        emit(k + 1, (size_t)m, ind + 1); Line cl; cl.synthetic = true; cl.indent = ind; cl.text = "}"; out.push_back(cl); k = (size_t)m - 1; continue;
                    }
                }
                Line o = L; o.indent = ind; out.push_back(o);
            }
        };
        emit(0, flat.size(), 0);
        return out;
    }
};

// ------------------------------------------------------------------ size-preserving edits
inline bool writeAt(Package& pk, i32 idx, size_t off, const void* src, size_t n) {
    Export& e = pk.exports[idx - 1]; if (!e.owned) { e.data.assign(pk.dataPtr(e), pk.dataPtr(e) + pk.dataLen(e)); e.owned = true; }
    if (off + n > e.data.size()) return false; memcpy(e.data.data() + off, src, n); return true;
}
// replaces [pos,end) of the bytecode with EX_Nothing (disabled statement: offsets and jumps stay valid)
inline bool nopRange(Package& pk, i32 idx, const FieldInfo& f, u32 pos, u32 end) {
    if (end <= pos || end > (u32)f.scriptSize) return false; std::vector<u8> b(end - pos, EX_Nothing); return writeAt(pk, idx, f.scriptOff + pos, b.data(), b.size());
}
// if(cond): replaces the condition with true/false (+ Nothing). always = true -> never jumps; never = false -> always jumps
inline bool forceCondition(Package& pk, i32 idx, const FieldInfo& f, const Script& s, int jumpTok, bool value) {
    const Tok& t = s.toks[jumpTok]; if (t.op != EX_JumpIfNot || t.kids.empty()) return false; const Tok& c = s.toks[t.kids[0]];
    std::vector<u8> b(c.size, EX_Nothing); b[0] = value ? EX_True : EX_False;
    // the Nothings go AFTER the JumpIfNot, executed as empty statements before the if body
    return writeAt(pk, idx, f.scriptOff + c.pos, b.data(), b.size());
}
// post-edit check: the bytecode still tokenizes exactly
inline bool verifyScript(const Package& pk, i32 idx, std::string* err = nullptr) {
    FieldInfo f = parseField(pk, idx); if (!f.ok) { if (err) *err = f.err; return false; }
    Script s = tokenize(pk, pk.dataPtr(pk.exports[idx - 1]) + f.scriptOff, (u32)f.scriptSize); if (!s.err.empty()) { if (err) *err = s.err; return false; } return true;
}


// ------------------------------------------------------------------ declarations
inline std::string typeName(const Package& pk, i32 prop, int depth = 0) {
    if (prop <= 0 || depth > 4) return "?"; FieldInfo f = parseField(pk, prop); const std::string& c = f.cls;
    if (c == "IntProperty") return "int"; if (c == "FloatProperty") return "float"; if (c == "BoolProperty") return "bool"; if (c == "NameProperty") return "name"; if (c == "StrProperty") return "string";
    if (c == "ByteProperty") return f.ref1 ? pk.objName(f.ref1) : "byte";
    if (c == "ObjectProperty" || c == "ComponentProperty" || c == "InterfaceProperty") return f.ref1 ? pk.objName(f.ref1) : "Object";
    if (c == "ClassProperty") return "class<" + (f.ref2 ? pk.objName(f.ref2) : std::string("Object")) + ">";
    if (c == "StructProperty") return f.ref1 ? pk.objName(f.ref1) : "struct";
    if (c == "ArrayProperty") return "array<" + (f.ref1 > 0 ? typeName(pk, f.ref1, depth + 1) : std::string("?")) + ">";
    if (c == "DelegateProperty") return "delegate<" + (f.ref1 ? pk.objName(f.ref1) : std::string("?")) + ">";
    if (c == "MapProperty") return "map<...>";
    return c;
}
inline std::vector<i32> childFields(const Package& pk, i32 structIdx) {
    std::vector<i32> out; FieldInfo f = parseField(pk, structIdx); i32 c = f.children;
    for (int g = 0; c > 0 && g < 20000; g++) { out.push_back(c); FieldInfo cf = parseField(pk, c); if (!cf.ok) break; c = cf.next; } return out;
}
inline std::string propDecl(const Package& pk, i32 prop, bool asLocal = false) {
    FieldInfo f = parseField(pk, prop); std::string s = asLocal ? "local " : "var";
    if (!asLocal) { std::string fl = flagsText(f.propFlags & ~(0x80ull | 0x400ull | 0x1000ull | 0x400000ull), kPropFlags); if (!fl.empty()) s += " " + fl; }
    s += (asLocal ? "" : " ") + typeName(pk, prop) + " " + pk.objName(prop); if (f.arrayDim > 1) s += "[" + std::to_string(f.arrayDim) + "]"; return s + ";";
}
inline std::string funcSignature(const Package& pk, i32 fn) {
    FieldInfo f = parseField(pk, fn); std::string ret = "", params;
    for (i32 c : childFields(pk, fn)) { FieldInfo p = parseField(pk, c); if (!p.isProperty || !(p.propFlags & 0x80)) continue;
        if (p.propFlags & 0x400) { ret = typeName(pk, c) + " "; continue; }
        if (!params.empty()) params += ", "; if (p.propFlags & 0x10) params += "optional "; if (p.propFlags & 0x100) params += "out "; params += typeName(pk, c) + " " + pk.objName(c); }
    std::string fl = flagsText(f.funcFlags & ~(0x2u | 0x20000u), kFuncFlags);
    return (fl.empty() ? "" : fl + " ") + std::string((f.funcFlags & 0x800) ? "" : "function ") + ret + pk.objName(fn) + "(" + params + ")";
}

} // namespace us
} // namespace bm
