// bmbetalevel.hpp - rebuilds a room of the 2007 BETA as a PC level (a .umap that BmStudio's "Import level"
// puts inside a game map).
//
// Input: the beta room packages (Max_B6.xxx, Max_B6_Static.xxx, _Lights, _Fx...).
// Output: <Prefix><Room>.umap, built on top of an "empty" PC level (the DLC Alley_C1_Fx, without its actors), with:
//   - the BSP of each package converted to StaticMesh (one mesh per block of up to ~60k vertices, sections per material,
//     kDOP tree built here -> per-polygon collision)
//   - every beta static mesh (collections + actors) converted (bmbetaconv) and placed as a StaticMeshActor
//   - beta lights (collections + actors) as PointLightToggleable/SpotLightToggleable (no lightmap: dynamic light)
// Left out (reported): decals, emitters, volumes, Kismet, gameplay actors, skeletal meshes.
#pragma once
#include "bmbetaconv.hpp"
#include "bmplace.hpp"
#include "bmbspedit.hpp"
#include "bmbetafix.hpp"

namespace bm { namespace betalevel {

using betaconv::Mesh; using betaconv::Section;

struct BetaPkg { std::string name; Package raw, norm; };

// ------------------------------------------------------------------ beta BSP -> meshes
inline uint16_t floatToHalf(float f) {
    u32 x; memcpy(&x, &f, 4); u32 s = (x >> 16) & 0x8000; i32 e = (i32)((x >> 23) & 0xFF) - 127 + 15; u32 m = x & 0x7FFFFF;
    if (e <= 0) return (uint16_t)s; if (e >= 31) return (uint16_t)(s | 0x7C00);
    u32 h = s | ((u32)e << 10) | (m >> 13); if (m & 0x1000) h++; return (uint16_t)h;
}
// returns 1+ meshes (sections with the beta material in Section::mat)
inline std::vector<Mesh> readModelMeshes(const Package& B, i32 model, std::string& err) {
    std::vector<Mesh> out;
    try {
        ObjProps op = objProps(B, model); if (!op.ok) throw Err("unreadable Model properties");
        const u8* d = B.dataPtr(B.exports[model - 1]); size_t n = B.dataLen(B.exports[model - 1]);
        beta::BE r(d, n, op.end); r.p += 28;
        auto arr = [&](int wantEs) { i32 es = r.i(), c = r.i(); if (es < 0 || c < 0 || (wantEs && c && es != wantEs)) throw Err("BSP: unexpected list"); size_t at = r.p; r.need((size_t)es * c); r.p += (size_t)es * c; return std::make_pair(at, c); };
        arr(12); arr(12); auto nodes = arr(64);
        r.i(); i32 ns = r.i(); if (ns < 0) throw Err("BSP: surfaces"); size_t surfs = r.p; r.need((size_t)ns * 56); r.p += (size_t)ns * 56;
        arr(0); r.i(); i32 nz = r.i(); if (nz < 0 || nz > 64) throw Err("BSP: zones"); r.p += (size_t)nz * 24; r.i();
        arr(0); arr(0); r.i(); r.i(); arr(0); arr(0);
        i32 numV = r.i(); auto vb = arr(36); if (vb.second != numV) throw Err("BSP: unexpected vertex buffer");
        // polygons per material
        std::map<i32, std::vector<std::vector<i32>>> byMat;   // material -> triangles (VB indices)
        auto vpos = [&](i32 v, float o[3]) { for (int k = 0; k < 3; k++) o[k] = betaconv::rbef(d + vb.first + (size_t)v * 36 + k * 4); };
        auto vnorm = [&](i32 v, float o[3]) { const u8* p = d + vb.first + (size_t)v * 36 + 16; for (int k = 0; k < 3; k++) o[k] = (p[3 - k] - 127.5f) / 127.5f; };   // TangentZ (BE: bytes reversed)
        for (i32 q = 0; q < nodes.second; q++) {
            const u8* nd = d + nodes.first + (size_t)q * 64; i32 iSurf = (i32)beta::rbe(nd + 20), iv = (i32)beta::rbe(nd + 24); int nv = nd[54];
            if (nv < 3 || iSurf < 0 || iSurf >= ns || iv < 0 || iv + nv > numV) continue;
            const u8* sd = d + surfs + (size_t)iSurf * 56; i32 mat = (i32)beta::rbe(sd); u32 flags = beta::rbe(sd + 4);
            if (flags & 1) continue;                                          // PF_Invisible
            auto& tris = byMat[mat];
            for (int k = 1; k + 1 < nv; k++) {
                i32 a = iv, b = iv + k, c = iv + k + 1; float A[3], Bp[3], Cp[3], N[3]; vpos(a, A); vpos(b, Bp); vpos(c, Cp); vnorm(a, N);
                float e1[3] = { Bp[0] - A[0], Bp[1] - A[1], Bp[2] - A[2] }, e2[3] = { Cp[0] - A[0], Cp[1] - A[1], Cp[2] - A[2] };
                float cr[3] = { e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0] };
                if (cr[0] * N[0] + cr[1] * N[1] + cr[2] * N[2] > 0) std::swap(b, c);   // game mesh convention: normal opposite to the cross product
                tris.push_back({ a, b, c });
                if (flags & 0x100) tris.push_back({ a, c, b });                // PF_TwoSided
            }
        }
        // builds the meshes (blocks of up to 60000 vertices / triangles)
        Mesh cur; std::map<i32, uint16_t> remap;
        auto vtx = [&](i32 v) -> uint16_t {
            auto it = remap.find(v); if (it != remap.end()) return it->second;
            const u8* p = d + vb.first + (size_t)v * 36; uint16_t idx = (uint16_t)(cur.pos.size() / 3);
            for (int k = 0; k < 3; k++) cur.pos.push_back(betaconv::rbef(p + k * 4));
            u8 rec[20]; for (int t = 0; t < 2; t++) for (int k = 0; k < 4; k++) rec[t * 4 + k] = p[12 + t * 4 + 3 - k];
            rec[8] = rec[9] = rec[10] = rec[11] = 0xFF;
            for (int u = 0; u < 4; u++) { uint16_t h = floatToHalf(betaconv::rbef(p + 20 + u * 4)); memcpy(rec + 12 + u * 2, &h, 2); }
            cur.vtx.insert(cur.vtx.end(), rec, rec + 20); remap[v] = idx; return idx; };
        auto flush = [&]() { if (cur.idx.empty()) return; cur.ntc = 2; cur.stride = 20; cur.fullUV = false;
            float mn[3] = { 1e30f, 1e30f, 1e30f }, mx[3] = { -1e30f, -1e30f, -1e30f };
            for (size_t k = 0; k < cur.pos.size(); k += 3) for (int a = 0; a < 3; a++) { mn[a] = std::min(mn[a], cur.pos[k + a]); mx[a] = std::max(mx[a], cur.pos[k + a]); }
            float rad = 0; for (int a = 0; a < 3; a++) { cur.bounds[a] = (mn[a] + mx[a]) / 2; cur.bounds[3 + a] = (mx[a] - mn[a]) / 2; rad += cur.bounds[3 + a] * cur.bounds[3 + a]; } cur.bounds[6] = sqrtf(rad);
            cur.lightMapRes = 0; cur.lightMapCoord = 1; betaconv::buildKDop(cur); out.push_back(std::move(cur)); cur = Mesh(); remap.clear(); };
        for (auto& [mat, tris] : byMat) {
            size_t t0 = 0;
            while (t0 < tris.size()) {
                Section S; S.mat = mat; S.first = (u32)cur.idx.size(); u32 mnv = 0xFFFFFFFF, mxv = 0;
                for (; t0 < tris.size(); t0++) {
                    if (cur.pos.size() / 3 + 3 > 60000 || cur.idx.size() / 3 + 1 > 60000) break;
                    for (int k = 0; k < 3; k++) { uint16_t ix = vtx(tris[t0][k]); cur.idx.push_back(ix); mnv = std::min<u32>(mnv, ix); mxv = std::max<u32>(mxv, ix); }
                }
                S.ntris = (u32)(cur.idx.size() - S.first) / 3; S.minV = mnv == 0xFFFFFFFF ? 0 : mnv; S.maxV = mxv;
                if (S.ntris) cur.secs.push_back(S);
                if (t0 < tris.size()) flush();
            }
        }
        flush();
    } catch (std::exception& e) { err = e.what(); }
    return out;
}

// ------------------------------------------------------------------ v0.19: beta BSP -> level collision BSP (PC)
// The game collides Batman with the level BSP through the tree (Nodes + LeafHulls), with no need for ModelComponents: the visible
// geometry stays in the BSP_* meshes; this Model is only for collision (walls, floor, stairs of the beta BSP).
// Same layout as PC (checked beta Max_B6_Static vs Admin_A_Static); this only swaps the byte order field by field,
// clears the references to beta objects (materials, actors, Polys) and points the zones to the WorldInfo of the new level.
inline std::vector<u8> betaModelToPc(const Package& B, i32 model, i32 worldInfo, std::string& err, int* nodesOut = nullptr, i32 selfIndex = 0) {
    Writer w;
    try {
        ObjProps op = objProps(B, model); if (!op.ok) throw Err("unreadable Model properties");
        const u8* d = B.dataPtr(B.exports[model - 1]); size_t n = B.dataLen(B.exports[model - 1]);
        beta::BE r(d, n, op.end);
        auto f32 = [&]() { r.need(4); w.u(beta::rbe(d + r.p)); r.p += 4; };
        auto dwords = [&](size_t cnt) { r.need(cnt * 4); for (size_t k = 0; k < cnt; k++) w.u(beta::rbe(d + r.p + k * 4)); r.p += cnt * 4; };
        auto bulkDw = [&](int wantEs) { i32 es = r.i(), c = r.i(); if (es < 0 || c < 0 || (c && wantEs && es != wantEs)) throw Err("BSP: unexpected list"); if (es % 4) throw Err("BSP: unaligned element"); w.i(es); w.i(c); dwords((size_t)es / 4 * c); return c; };
        for (int k = 0; k < 7; k++) f32();                                     // Bounds
        bulkDw(12); bulkDw(12);                                                // Vectors, Points
        { i32 es = r.i(), c = r.i(); if (c && es != 64) throw Err("BSP: node with unexpected size"); w.i(64); w.i(c); if (nodesOut) *nodesOut = c;
          for (i32 q = 0; q < c; q++) { r.need(64); const u8* p = d + r.p; u8 o[64];
              for (int k = 0; k < 7; k++) { u32 v = beta::rbe(p + k * 4); memcpy(o + k * 4, &v, 4); }                       // plane, iVertPool, iSurf, iVertexIndex
              uint16_t a = (uint16_t)(p[28] << 8 | p[29]), b = (uint16_t)(p[30] << 8 | p[31]); memcpy(o + 28, &a, 2); memcpy(o + 30, &b, 2);   // ComponentIndex/NodeIndex
              for (int k = 8; k < 13; k++) { u32 v = beta::rbe(p + k * 4); memcpy(o + k * 4, &v, 4); }                      // ComponentElementIndex, iBack, iFront, iPlane, iCollisionBound
              memcpy(o + 52, p + 52, 4);                                                                                   // iZone[2], NumVertices, NodeFlags
              for (int k = 14; k < 16; k++) { u32 v = beta::rbe(p + k * 4); memcpy(o + k * 4, &v, 4); }                     // iLeaf[2]
              w.raw(o, 64); r.p += 64; } }
        r.i(); w.i(selfIndex);                                                 // owner of the surfaces TTransArray (the Model itself)
        { i32 ns = r.i(); if (ns < 0) throw Err("BSP: surfaces"); w.i(ns); r.need((size_t)ns * 56);
          for (i32 q = 0; q < ns; q++) { const u8* p = d + r.p + (size_t)q * 56; for (int k = 0; k < 14; k++) { u32 v = beta::rbe(p + k * 4);
                  if (k == 0 || k == 7) v = 0;                                  // Material, Actor (beta objects)
                  if (k == 13) v = 3;                                           // LightingChannels: bInitialized|BSP (as in the game)
                  w.u(v); } }
          r.p += (size_t)ns * 56; }
        bulkDw(24);                                                            // Verts
        w.i(r.i());                                                            // NumSharedSides
        { i32 nz = r.i(); if (nz < 0 || nz > 64) throw Err("BSP: zones"); w.i(nz); r.need((size_t)nz * 24);
          for (i32 q = 0; q < nz; q++) { const u8* p = d + r.p + (size_t)q * 24; w.i(worldInfo); w.u(beta::rbe(p + 4));
              for (int k = 0; k < 2; k++) { u8 b8[8]; for (int j = 0; j < 8; j++) b8[j] = p[8 + k * 8 + 7 - j]; w.raw(b8, 8); } }
          r.p += (size_t)nz * 24; }
        r.i(); w.i(0);                                                         // Polys (editor only)
        bulkDw(4); bulkDw(4);                                                  // LeafHulls, Leaves
        w.i(r.i()); w.i(r.i());                                                // RootOutside, Linked
        bulkDw(4);                                                             // PortalNodes
        { i32 es = r.i(), c = r.i(); r.need((size_t)std::max(0, es) * std::max(0, c)); r.p += (size_t)std::max(0, es) * std::max(0, c); w.i(8); w.i(0); }   // Edges (not used by collision)
        { r.i(); i32 es = r.i(), c = r.i(); if (c && es != 36) throw Err("BSP: unexpected vertex buffer"); r.need((size_t)c * 36); r.p += (size_t)c * 36;
          // v0.19b: no render vertices (NumVertices 0 and empty list). With vertices and no ModelComponents the game tries to rebuild the
          // BSP render data when loading the level and stops at "NumVertices == VertexBuffer.Vertices.Num()" (UnModel.cpp 516).
          // Collision only uses the nodes/planes/LeafHulls; the visible part is already in the BSP_* meshes.
          w.i(0); w.i(36); w.i(0); }
        w.i(0); w.i(0); w.i(0);                                                // (BM) 3 empty lists at the end, as in the game's newer levels
    } catch (std::exception& e) { err = e.what(); return {}; }
    return w.b;
}

// only the chosen sections (all vertices stay; kDOP and bounds are rebuilt)
inline Mesh subsetMesh(const Mesh& M, const std::function<bool(const Section&)>& keep) {
    Mesh o = M; o.secs.clear(); o.idx.clear();
    for (auto& s : M.secs) if (keep(s)) { Section t = s; t.first = (u32)o.idx.size(); o.idx.insert(o.idx.end(), M.idx.begin() + s.first, M.idx.begin() + s.first + s.ntris * 3); o.secs.push_back(t); }
    if (o.secs.empty()) return o;
    float mn[3] = { 1e30f, 1e30f, 1e30f }, mx[3] = { -1e30f, -1e30f, -1e30f };
    for (auto i : o.idx) for (int a = 0; a < 3; a++) { mn[a] = std::min(mn[a], o.pos[i * 3 + a]); mx[a] = std::max(mx[a], o.pos[i * 3 + a]); }
    float rad = 0; for (int a = 0; a < 3; a++) { o.bounds[a] = (mn[a] + mx[a]) / 2; o.bounds[3 + a] = (mx[a] - mn[a]) / 2; rad += o.bounds[3 + a] * o.bounds[3 + a]; } o.bounds[6] = sqrtf(rad);
    betaconv::buildKDop(o); return o;
}

// ------------------------------------------------------------------ what is in the room (normalized beta package)
struct MeshInst { i32 mesh = 0; M4 world = m4Identity(); i32 comp = 0; std::vector<Tag> flags; std::vector<i32> mats; };
struct LightInst { bool spot = false; M4 world = m4Identity(); float radius = 512, brightness = 1, inner = 20, outer = 40, falloff = 2; u8 rgb[3] = { 255, 255, 255 }; bool shadows = false; std::string name; };
struct Content { std::vector<MeshInst> meshes; std::vector<LightInst> lights; std::vector<i32> models; std::map<std::string, int> skipped; };

inline M4 matBE(const u8* p) { M4 m; for (int i = 0; i < 16; i++) m.m[i / 4][i % 4] = betaconv::rbef(p + i * 4); return m; }

// collision/shadow/materials of the beta component (bools pass as they are; Materials = list of beta objects)
inline void compExtras(const std::vector<Tag>& tags, MeshInst& m) {
    for (auto& t : tags) {
        if (t.isBool && (t.name == "CollideActors" || t.name == "BlockActors" || t.name == "BlockRigidBody" || t.name == "BlockZeroExtent" || t.name == "BlockNonZeroExtent" || t.name == "CastShadow")) m.flags.push_back(t);
        if (t.name == "Materials" && t.raw.size() >= 4) { i32 n; memcpy(&n, t.raw.data(), 4); for (i32 k = 0; k < n && 4 + (size_t)k * 4 + 4 <= t.raw.size(); k++) { i32 o; memcpy(&o, t.raw.data() + 4 + k * 4, 4); m.mats.push_back(o); } }
    }
}
inline Content scan(const Package& B) {
    Content C; std::set<i32> inCollection;
    auto levelActor = [&](i32 a) { return a > 0 && B.exports[a - 1].outer > 0 && B.nm(B.exports[B.exports[a - 1].outer - 1].name) == "PersistentLevel" && !isTemplateObj(B, a); };
    auto lightFrom = [&](i32 comp, const M4& world) {
        ObjProps cp = objProps(B, comp); if (!cp.ok) return; std::string cls = B.classOf(B.exports[comp - 1]);
        if (findTag(cp.tags, "bEnabled") && !findTag(cp.tags, "bEnabled")->boolVal) return;
        LightInst L; L.spot = cls.find("Spot") != std::string::npos; L.world = world; L.name = B.objName(comp);
        L.radius = tagFloat(cp.tags, "Radius", 1024); L.brightness = tagFloat(cp.tags, "Brightness", 1); L.falloff = tagFloat(cp.tags, "FalloffExponent", 2);
        L.inner = tagFloat(cp.tags, "InnerConeAngle", 0); L.outer = tagFloat(cp.tags, "OuterConeAngle", 44);
        if (const Tag* c = findTag(cp.tags, "LightColor")) if (c->raw.size() >= 4) { L.rgb[0] = c->raw[2]; L.rgb[1] = c->raw[1]; L.rgb[2] = c->raw[0]; }   // FColor = B,G,R,A
        const Tag* cs = findTag(cp.tags, "CastShadows"); L.shadows = cs ? cs->boolVal != 0 : false;
        C.lights.push_back(L); };
    for (size_t k = 0; k < B.exports.size(); k++) {
        i32 x = (i32)k + 1; std::string cls = B.classOf(B.exports[k]);
        if ((cls == "StaticMeshCollectionActor" || cls == "StaticLightCollectionActor") && levelActor(x)) {
            ObjProps op = objProps(B, x); const Tag* t = op.ok ? findTag(op.tags, cls == "StaticMeshCollectionActor" ? "StaticMeshComponents" : "LightComponents") : nullptr; if (!t) continue;
            i32 n; memcpy(&n, t->raw.data(), 4); const u8* d = B.dataPtr(B.exports[k]); if (op.end + (size_t)n * 64 > B.dataLen(B.exports[k])) continue;
            for (i32 c = 0; c < n; c++) { i32 comp; memcpy(&comp, t->raw.data() + 4 + c * 4, 4); if (comp <= 0) continue; inCollection.insert(comp);
                M4 ptw = matBE(d + op.end + (size_t)c * 64);
                if (cls == "StaticMeshCollectionActor") { ObjProps cp = objProps(B, comp); if (!cp.ok) continue; const Tag* sm = findTag(cp.tags, "StaticMesh"); if (!sm || tagObj(*sm) <= 0) continue;
                    if (findTag(cp.tags, "HiddenGame") && findTag(cp.tags, "HiddenGame")->boolVal) continue;
                    MeshInst m; m.mesh = tagObj(*sm); m.world = m4Mul(componentLocal(cp.tags), ptw); m.comp = comp; compExtras(cp.tags, m); C.meshes.push_back(m); }
                else lightFrom(comp, ptw); }
        }
    }
    for (size_t k = 0; k < B.exports.size(); k++) {
        i32 x = (i32)k + 1; const Export& e = B.exports[k]; std::string cls = B.classOf(e);
        if (inCollection.count(x) || isTemplateObj(B, x)) continue;
        if ((cls == "StaticMeshComponent" || cls.find("LightComponent") != std::string::npos) && levelActor(e.outer)) {
            std::string acls = B.classOf(B.exports[e.outer - 1]); if (acls == "StaticMeshCollectionActor" || acls == "StaticLightCollectionActor") continue;
            ObjProps cp = objProps(B, x), ap = objProps(B, e.outer); if (!cp.ok || !ap.ok) continue;
            if (findTag(ap.tags, "bHidden") && findTag(ap.tags, "bHidden")->boolVal) continue;
            M4 w = m4Mul(componentLocal(cp.tags), actorMatrix(ap.tags));
            if (cls == "StaticMeshComponent") { const Tag* sm = findTag(cp.tags, "StaticMesh"); if (!sm || tagObj(*sm) <= 0) continue; if (findTag(cp.tags, "HiddenGame") && findTag(cp.tags, "HiddenGame")->boolVal) continue; MeshInst m; m.mesh = tagObj(*sm); m.world = w; m.comp = x; compExtras(cp.tags, m); C.meshes.push_back(m); }
            else if (cls == "PointLightComponent" || cls == "SpotLightComponent") lightFrom(x, w);
            else C.skipped[cls]++;
            continue;
        }
        if (levelActor(x) && cls != "StaticMeshCollectionActor" && cls != "StaticLightCollectionActor" && cls != "WorldInfo" && cls != "StaticMeshActor" && cls != "InterpActor"
            && cls.find("Light") == std::string::npos && cls != "Model" && cls != "Polys" && cls != "ModelComponent" && cls != "Sequence" && cls != "MacroReachSpecInfo" && cls.find("ReachSpec") == std::string::npos) C.skipped[cls]++;
    }
    for (i32 m : levelModels(B)) C.models.push_back(m);
    return C;
}

// ------------------------------------------------------------------ empty PC level
// removes the actors (WorldInfo and the navigation info stay), removes the Kismet from the level list, renames the package
inline void makeBlank(Package& T, const std::string& oldName, const std::string& newName) {
    i32 L = T.findPath("TheWorld.PersistentLevel"); if (L <= 0) throw Err("the base level has no PersistentLevel");
    ObjProps op = objProps(T, L); place::own(T, L); auto& d = T.exports[L - 1].data;
    Reader r(d.data(), d.size(), op.end); r.i(); i32 cnt = r.i(); size_t at = r.p;
    for (i32 k = 0; k < cnt; k++) { i32 a; memcpy(&a, &d[at + 4 * (size_t)k], 4); if (a <= 0) continue; std::string c = T.classOf(T.exports[a - 1]);
        if (c == "WorldInfo" || c == "MacroReachSpecInfo") continue; i32 z = 0; memcpy(&d[at + 4 * (size_t)k], &z, 4); }
    r.p = at + 4 * (size_t)cnt; for (int k = 0; k < 4; k++) r.fstr(); i32 no = r.i(); for (i32 k = 0; k < no; k++) r.fstr(); r.i(); r.i();
    r.i(); i32 mc = r.i(); r.p += 4 * (size_t)std::max(0, mc);
    size_t gsAt = r.p; i32 gs = r.i(); if (gs > 0 && gs < 64) { d.erase(d.begin() + gsAt + 4, d.begin() + gsAt + 4 + 4 * (size_t)gs); i32 z = 0; memcpy(&d[gsAt], &z, 4); }
    for (auto& nm : T.names) if (nm.first == oldName) nm.first = newName;
}

// ------------------------------------------------------------------ assembly
struct Options {
    bool bsp = true, meshes = true, lights = true;
    bool hideUntextured = false;         // BSP with no material: false = visible grey (as in the beta), true = collision only (hidden)
    int maxLights = 160;                 // too many dynamic lights are expensive: the ones with the largest radius x brightness are kept
    float lightBrightness = 1.f, lightRadius = 1.f;
    int shadowLights = 0;
    bool autoLights = true;              // v0.21: room with no lights (beta _Lights package damaged/empty): creates fill lights                // v0.18: the N strongest lights cast dynamic shadows (without a lightmap there are no baked shadows; expensive)
    std::string prefix = "Beta";
};
struct Report { int bspCollision = 0, bodies = 0, bspMeshes = 0, meshActors = 0, lights = 0, lightsDropped = 0, meshesConverted = 0, materials = 0, textures = 0, failed = 0, skippedFx = 0; std::map<std::string, int> skipped; std::vector<std::string> log; };

// T: empty level (makeBlank) that already has the MasterShader MIC (copied); donor: PC map with a StaticMeshActor and a PointLightToggleable
inline Report build(Package& T, const cp::TypeDB& db, Package& donor, std::vector<BetaPkg>& pkgs, const betaconv::ReadTfc& readTfc, const Options& O,
                    std::function<void(const std::string&)> progress = nullptr) {
    Report R; auto say = [&](const std::string& s) { R.log.push_back(s); if (progress) progress(s); };
    // mesh template: the donor's StaticMeshActor (no dynamic light environment: static geometry, lit by the dynamic lights)
    place::Template meshT, pointT, spotT;
    auto findSMA = [&](const Package& P) { place::Template best; for (size_t k = 0; k < P.exports.size(); k++) { if (P.classOf(P.exports[k]) != "StaticMeshActor" || P.objPath(P.exports[k].outer) != "TheWorld.PersistentLevel" || (P.exports[k].flags & 0x600ull)) continue;
        auto set = place::actorSet(P, (i32)k + 1); i32 comp = 0; for (i32 s : set) if (P.classOf(P.exports[s - 1]) == "StaticMeshComponent") comp = s; if (!comp) continue; best.actor = (i32)k + 1; best.comp = comp; best.cls = "StaticMeshActor"; break; } return best; };
    { place::Template D = findSMA(T); if (!D.actor) { D = findSMA(donor); if (!D.actor) throw Err("the donor map has no StaticMeshActor"); auto ac = place::importFromDonor(T, db, donor, D, place::Kind::Mesh); meshT.actor = ac.first; meshT.comp = ac.second; meshT.cls = "StaticMeshActor"; } else meshT = D; }
    auto lightTemplate = [&](place::Kind k) { place::Template D = place::findTemplateK(T, k); if (D.actor) return D; D = place::findTemplateK(donor, k); if (!D.actor) throw Err("the donor map has no light to use as a template");
        auto ac = place::importFromDonor(T, db, donor, D, k); place::Template t; t.actor = ac.first; t.comp = ac.second; t.cls = T.classOf(T.exports[ac.first - 1]); return t; };
    auto placeMesh = [&](i32 mesh, const M4& world) {
        auto ac = place::cloneInLevel(T, db, meshT, true); float loc[3] = { world.m[3][0], world.m[3][1], world.m[3][2] };
        place::configurePlaced(T, ac.first, ac.second, mesh, loc);
        LevelMesh lm; lm.comp = ac.second; lm.owner = ac.first; lm.src = 1; lm.compLocal = m4Identity(); setInstanceWorld(T, lm, world);
        place::addActorToLevel(T, ac.first); R.meshActors++; return ac.first; };

    std::vector<LightInst> allLights;
    const BetaPkg* bestBspPkg = nullptr; i32 bestBsp = 0; i32 bestNodes = 0;   // v0.19: level collision BSP
    struct Spot { float p[3]; std::string mesh; }; std::vector<Spot> spots;            // v0.21: placed meshes (for automatic lights)
    for (auto& bp : pkgs) {
        say("== " + bp.name);
        betaconv::Ctx C(bp.norm, bp.raw, T); C.readTfc = readTfc; C.prefix = O.prefix; std::string miss = betaconv::findTemplates(C); if (!miss.empty()) throw Err("missing in the base level:" + miss);
        Content K = scan(bp.norm);
        for (auto& kv : K.skipped) R.skipped[kv.first] += kv.second;
        if (O.bsp) for (i32 m : K.models) {
            { std::string e2; int nn = 0; betaModelToPc(bp.norm, m, 0, e2, &nn); if (e2.empty() && nn > bestNodes) { bestNodes = nn; bestBsp = m; bestBspPkg = &bp; } }
            std::string err; auto meshes = readModelMeshes(bp.norm, m, err); if (!err.empty()) { say("  BSP: " + err); continue; }
            int part = 0;
            for (auto& M0 : meshes) {
                // surfaces with no material (DefaultMaterial / another package): kept as collision only, in a hidden actor
                for (int hidden = 0; hidden < 2; hidden++) {
                    Mesh M = subsetMesh(M0, [&](const Section& s) { bool def = s.mat <= 0; return hidden ? def : !def; });
                    if (M.secs.empty()) continue;
                    std::vector<i32> mats; for (auto& s : M.secs) mats.push_back(hidden ? (O.hideUntextured ? 0 : betaconv::greyboxMIC(C)) : betaconv::convMaterial(C, s.mat));
                    std::string nm = "BSP_" + bp.name + (hidden ? "_NoMaterial" : "") + (meshes.size() > 1 ? "_" + std::to_string(part) : "");
                    try { i32 sm = betaconv::createStaticMesh(T, betaconv::ensurePackageExport(T, O.prefix + "BSP"), nm, M, mats); i32 a = placeMesh(sm, m4Identity());
                          if (hidden && O.hideUntextured) { ObjProps ap = objProps(T, a); std::vector<Tag> at = ap.tags; place::setTag(at, place::boolT("bHidden", true)); replaceProps(T, a, at); }
                          R.bspMeshes++;
                          say("  BSP -> " + nm + ": " + std::to_string(M.idx.size() / 3) + " triangles, " + std::to_string(M.secs.size()) + " materials" + (hidden ? (O.hideUntextured ? " (hidden, collision only)" : " (no material in the beta: grey)") : "")); }
                    catch (std::exception& e) { say(std::string("  BSP: ") + e.what()); R.failed++; }
                }
                part++;
            }
        }
        if (O.meshes) {
            int placed = 0;
            int fxSkipped = 0;
            for (auto& mi : K.meshes) {
                { bool fx = false; for (i32 m_ : mi.mats) if (m_ > 0 && materialBlendMode(bp.norm, m_) >= 2) fx = true; if (fx) { fxSkipped++; continue; } }   // translucent effect applied to the component
                i32 sm = betaconv::convStaticMesh(C, mi.mesh); if (!sm) continue;
                { Spot sp; for (int k = 0; k < 3; k++) sp.p[k] = mi.world.m[3][k]; sp.mesh = bp.norm.objPath(mi.mesh); spots.push_back(sp); }
                try { i32 a = placeMesh(sm, mi.world); placed++;
                    if (!mi.flags.empty() || !mi.mats.empty()) {
                        i32 comp = 0; for (size_t q = 0; q < T.exports.size(); q++) if (T.exports[q].outer == a && T.classOf(T.exports[q]) == "StaticMeshComponent") { comp = (i32)q + 1; break; }
                        if (comp) { ObjProps cp = objProps(T, comp); std::vector<Tag> tags = cp.tags; for (auto& f : mi.flags) place::setTag(tags, f);
                            if (!mi.mats.empty()) { Writer w; w.i((i32)mi.mats.size()); for (i32 bm_ : mi.mats) { i32 tm = 0; if (bm_ > 0 && materialBlendMode(bp.norm, bm_) < 2) tm = betaconv::convMaterial(C, bm_); w.i(tm); }
                                Tag t; t.name = "Materials"; t.type = "ArrayProperty"; t.raw = w.b; place::setTag(tags, t); }
                            replaceProps(T, comp, tags); } }
                } catch (std::exception& e) { say(std::string("  place: ") + e.what()); R.failed++; } }
            say("  meshes placed: " + std::to_string(placed) + " of " + std::to_string(K.meshes.size()) + (fxSkipped ? " (" + std::to_string(fxSkipped) + " with a translucent effect material were left out)" : ""));
        }
        for (auto& l : K.lights) allLights.push_back(l);
        for (auto& s : C.log) say(s);
        R.meshesConverted += C.meshes; R.bodies += C.bodies; R.materials += C.materials; R.textures += C.textures; R.failed += C.failed; R.skippedFx += C.skippedFx;
    }
    if (O.bsp && bestBspPkg) {
        // the Model of the new (empty) level receives the beta BSP for collision only
        i32 tm = 0, wi = 0; for (size_t k = 0; k < T.exports.size(); k++) { const Export& e = T.exports[k]; if (e.outer <= 0 || T.nm(T.exports[e.outer - 1].name) != "PersistentLevel") continue;
            std::string c = T.classOf(e); if (c == "WorldInfo") wi = (i32)k + 1; }
        { i32 lvl = T.findPath("TheWorld.PersistentLevel"); ObjProps lp = objProps(T, lvl); (void)lp; }
        for (i32 m : levelModels(T)) { tm = m; break; }
        std::string err; auto nat = betaModelToPc(bestBspPkg->norm, bestBsp, wi, err, nullptr, tm);
        if (!tm) say("  BSP collision: the base level has no Model");
        else if (!err.empty()) say("  BSP collision: " + err);
        else { long ps = findPropStart(T, tm); size_t st = 0; readProps(T, T.dataPtr(T.exports[tm - 1]), T.dataLen(T.exports[tm - 1]), (size_t)ps, &st);
            std::vector<u8> d(T.dataPtr(T.exports[tm - 1]), T.dataPtr(T.exports[tm - 1]) + st); d.insert(d.end(), nat.begin(), nat.end());
            T.exports[tm - 1].data = std::move(d); T.exports[tm - 1].owned = true;
            ModelLayout L = modelLayout(T, tm);
            if (!L.ok) { say("  BSP collision: unreadable result (" + L.err + ")"); }
            else { R.bspCollision = L.nNodes; say("  BSP collision (" + bestBspPkg->name + "): " + std::to_string(L.nNodes) + " nodes, " + std::to_string(L.nSurfs) + " surfaces"); } }
    }
    // v0.21: automatic lights. Several beta *_Lights.xxx packages are zeroed/damaged (the dump does not have the room lights):
    // without this the room is 100% dark. One light at each lamp (LIGHTS_/Lamp/Bulb meshes) + fill where there is geometry.
    if (O.lights && O.autoLights && (int)allLights.size() < 8 && !spots.empty()) {
        auto lc = [](std::string x) { for (auto& c : x) c = (char)tolower((unsigned char)c); return x; };
        int lamps = 0, fill = 0;
        for (auto& sp : spots) { std::string m = lc(sp.mesh);
            if (m.find("lights_") == std::string::npos && m.find("lamp") == std::string::npos && m.find("bulb") == std::string::npos && m.find("lantern") == std::string::npos && m.find("light_") == std::string::npos) continue;
            LightInst L; L.world = translationMatrix(sp.p[0], sp.p[1], sp.p[2] - 24); L.radius = 900; L.brightness = 1.6f; L.rgb[0] = 255; L.rgb[1] = 226; L.rgb[2] = 190; L.name = "AutoLamp"; allLights.push_back(L); lamps++; }
        // fill: 1024 cells with at least 3 meshes -> a light at their center, a little above
        std::map<std::array<int, 3>, std::pair<std::array<double, 3>, int>> cells;
        for (auto& sp : spots) { std::array<int, 3> k = { (int)floorf(sp.p[0] / 1024.f), (int)floorf(sp.p[1] / 1024.f), (int)floorf(sp.p[2] / 1024.f) }; auto& c = cells[k]; for (int q = 0; q < 3; q++) c.first[q] += sp.p[q]; c.second++; }
        for (auto& [k, c] : cells) { if (c.second < 3) continue; LightInst L; L.world = translationMatrix((float)(c.first[0] / c.second), (float)(c.first[1] / c.second), (float)(c.first[2] / c.second) + 160);
            L.radius = 1400; L.brightness = 0.9f; L.rgb[0] = 230; L.rgb[1] = 232; L.rgb[2] = 240; L.name = "AutoFill"; allLights.push_back(L); fill++; }
        say("  automatic lights (the beta has no lights for this room): " + std::to_string(lamps) + " at lamps + " + std::to_string(fill) + " fill");
    }
    if (O.lights && !allLights.empty()) {
        std::stable_sort(allLights.begin(), allLights.end(), [](const LightInst& a, const LightInst& b) { return a.radius * a.brightness > b.radius * b.brightness; });
        if ((int)allLights.size() > O.maxLights) { R.lightsDropped = (int)allLights.size() - O.maxLights; allLights.resize(O.maxLights); }
        bool anySpot = false, anyPoint = false; for (auto& l : allLights) (l.spot ? anySpot : anyPoint) = true;
        if (anyPoint) pointT = lightTemplate(place::Kind::PointLight);
        if (anySpot) spotT = lightTemplate(place::Kind::SpotLight);
        for (auto& l : allLights) {
            try {
                place::PlaceSpec S; S.kind = l.spot ? place::Kind::SpotLight : place::Kind::PointLight; for (int k = 0; k < 3; k++) S.loc[k] = l.world.m[3][k];
                S.lp.radius = l.radius * O.lightRadius; S.lp.brightness = l.brightness * O.lightBrightness; S.lp.r = l.rgb[0]; S.lp.g = l.rgb[1]; S.lp.b = l.rgb[2]; S.lp.shadows = R.lights < O.shadowLights; S.lp.inner = l.inner; S.lp.outer = l.outer;
                auto ac = place::cloneInLevel(T, db, l.spot ? spotT : pointT, false);
                place::configureLight(T, ac.first, ac.second, S);
                // real orientation (spotlight) and component matrix
                { float loc[3]; Rot rr; float sc[3]; decompose(l.world, loc, rr, sc);
                  M4 w = m4Mul(rotationMatrix(rr), translationMatrix(loc[0], loc[1], loc[2]));
                  ObjProps cp = objProps(T, ac.second); std::vector<Tag> tags = cp.tags; setStructTag(tags, "CachedParentToWorld", "Matrix", &w, 64);
                  if (findTag(tags, "FalloffExponent") || l.falloff != 2) place::setTag(tags, place::floatT("FalloffExponent", l.falloff));
                  replaceProps(T, ac.second, tags);
                  if (l.spot) { ObjProps ap = objProps(T, ac.first); std::vector<Tag> at = ap.tags; i32 rot[3] = { rr.pitch, rr.yaw, rr.roll }; setStructTag(at, "Rotation", "Rotator", rot, 12); replaceProps(T, ac.first, at); } }
                place::addActorToLevel(T, ac.first); R.lights++;
            } catch (std::exception& e) { say(std::string("  light: ") + e.what()); R.failed++; }
        }
        say("lights: " + std::to_string(R.lights) + (R.lightsDropped ? " (+" + std::to_string(R.lightsDropped) + " weaker ones left out)" : ""));
    }
    betafix::sanitize(T);   // lights only in the room, collision BSP without render vertices, materials
    return R;
}

} }
