// bmbetafix - "sanitizing" an already converted beta room (PC package with the BetaBSP package inside).
// Used in 3 places: at the end of the conversion (BmStudio), on every room import (BmStudio, any target map)
// and in betaroomfix (rooms already installed, one at a time or the whole CookedPC folder).
//  1) level collision BSP without render vertices and with the right surface owner
//     (with vertices and no ModelComponents the game stops at "NumVertices == VertexBuffer.Vertices.Num()", UnModel.cpp 516)
//  2) materials with NormalMapMultiplier Z=0 -> 1 ("lying down" normal: lighting all wrong)
//  3) room lights only light the room itself (bOnlyAffectSameAndSpecifiedLevels): without this the ~160 dynamic beta lights
//     also lit the surrounding original map and its floor/walls flickered black
#pragma once
#include "bmasset.hpp"
#include "bmlevel.hpp"
#include "bmbspedit.hpp"
#include <string>
#include <vector>

namespace bm { namespace betafix {

inline bool isBetaRoom(const Package& P) { return P.findPath("BetaBSP") > 0; }

struct Result { int bsp = 0, mics = 0, lights = 0; int total() const { return bsp + mics + lights; } };

// "parent" levels of an installed room: Max_B6_D1 -> Max_B6, Max (Batman and the enemies spawn in the persistent map)
inline std::vector<std::string> parentLevels(const std::string& room, const std::vector<std::string>& extra = {}) {
    std::vector<std::string> out; std::string s = room;
    for (;;) { size_t u = s.rfind('_'); if (u == std::string::npos || u == 0) break; s = s.substr(0, u); out.push_back(s); }
    for (auto& e : extra) { bool have = false; for (auto& o : out) if (o == e) have = true; if (!have && !e.empty() && e != room) out.push_back(e); }
    return out;
}
// levels: extra levels the room lights also light (OtherLevelsToAffect). Empty = leave the list alone.
inline Result sanitize(Package& P, const std::vector<std::string>& levels = {}) {
    Result R; if (!isBetaRoom(P)) return R;
    // 1) BSP
    for (i32 m : levelModels(P)) {
        ModelLayout L = modelLayout(P, m); if (!L.ok) continue; const u8* d = P.dataPtr(P.exports[m - 1]); size_t n = P.dataLen(P.exports[m - 1]);
        size_t ownerAt = L.nodesAt + (size_t)L.nNodes * 64; i32 owner; memcpy(&owner, d + ownerAt, 4);
        if (L.vbn == 0 && owner == m) continue;
        std::vector<u8> nd(d, d + n); memcpy(nd.data() + ownerAt, &m, 4);
        if (L.vbn > 0) { size_t numAt = L.vbAt - 12, vbEnd = L.vbAt + (size_t)L.vbes * L.vbn; std::vector<u8> out(nd.begin(), nd.begin() + numAt); i32 z[3] = { 0, 36, 0 };
            out.insert(out.end(), (u8*)z, (u8*)z + 12); out.insert(out.end(), nd.begin() + vbEnd, nd.end()); nd.swap(out); }
        P.exports[m - 1].data = std::move(nd); P.exports[m - 1].owned = true; R.bsp++;
    }
    // 2) materials
    for (size_t k = 0; k < P.exports.size(); k++) {
        if (P.classOf(P.exports[k]) != "MaterialInstanceConstant") continue; i32 x = (i32)k + 1; if (P.objPath(x).rfind("Beta", 0) != 0) continue;
        ObjProps op = objProps(P, x); if (!op.ok) continue; std::vector<Tag> tg = op.tags; bool ch = false;
        for (auto& t : tg) { if (t.name != "VectorParameterValues") continue; Reader r(t.raw.data(), t.raw.size()); i32 cnt = r.i(); Writer w; w.i(cnt);
            for (i32 q = 0; q < cnt; q++) { size_t end = 0; auto sub = readProps(P, t.raw.data(), t.raw.size(), r.p, &end); r.p = end; std::string pn = tagName(P, sub, "ParameterName");
                for (auto& sv : sub) if (sv.name == "ParameterValue" && sv.raw.size() >= 16 && pn == "NormalMapMultiplier") { float v[4]; memcpy(v, sv.raw.data(), 16); if (v[2] == 0.f) { v[2] = 1.f; memcpy(sv.raw.data(), v, 16); ch = true; } }
                w.raw(writeProps(P, sub)); }
            t.raw = w.b; }
        if (ch && replaceProps(P, x, tg)) R.mics++;
    }
    // 3) lights: the room itself only
    for (size_t k = 0; k < P.exports.size(); k++) {
        std::string c = P.classOf(P.exports[k]); if (c != "PointLightComponent" && c != "SpotLightComponent") continue;
        i32 x = (i32)k + 1; if (P.exports[k].flags & 0x600ull) continue; if (P.objPath(x).rfind("TheWorld.PersistentLevel.", 0) != 0) continue;
        ObjProps op = objProps(P, x); if (!op.ok) continue; std::vector<Tag> tg = op.tags; Tag* t = nullptr;
        for (auto& q : tg) if (q.name == "bOnlyAffectSameAndSpecifiedLevels") t = &q;
        bool ch = false;
        if (!t || !t->boolVal) { if (t) t->boolVal = 1; else { Tag nt; nt.name = "bOnlyAffectSameAndSpecifiedLevels"; nt.type = "BoolProperty"; nt.isBool = true; nt.boolVal = 1; tg.push_back(nt); } ch = true; }
        // v0.21: Batman/enemies (persistent level) also receive the room light; the rest of the original map stays out
        if (!levels.empty()) {
            Writer w; w.i((i32)levels.size()); for (auto& l : levels) { w.i(P.addName(l)); w.i(0); }
            Tag* o = nullptr; for (auto& q : tg) if (q.name == "OtherLevelsToAffect") o = &q;
            if (!o || o->raw != w.b) { if (o) o->raw = w.b; else { Tag nt; nt.name = "OtherLevelsToAffect"; nt.type = "ArrayProperty"; nt.raw = w.b; tg.push_back(nt); } ch = true; }
        }
        if (ch && replaceProps(P, x, tg)) R.lights++;
    }
    return R;
}

} }
