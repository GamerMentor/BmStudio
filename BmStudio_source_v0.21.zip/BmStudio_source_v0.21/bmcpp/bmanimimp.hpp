// bmanimimp.hpp - "cooking" animations: PSA (ActorX / Blender psk-psa / umodel) -> cooked BAA AnimSequence.
// Generated format = the same as the game's original sequences: AKF_VariableKeyLerp + ACF_Fixed48Max (rotation) + ACF_None (translation),
// CompressedTrackOffsets (offT, nT, offR, nR per track) and CompressedByteStream padded with 0x55 (AnimationPadSentinel) every 4 bytes.
// Error-based key reduction (Douglas-Peucker): a constant track becomes 1 key; otherwise only the keys that are needed stay.
#pragma once
#include "bmanim.hpp"
#include <functional>

namespace bm {

// ------------------------------------------------------------------ PSA
struct PsaSeq { std::string name; float fps = 30; int numFrames = 0; std::vector<std::array<float, 7>> keys;
    std::vector<u8> removed; };   // per PSA bone: 0 = has data, 1 = no translation, 2 = no rotation, 3 = nothing (umodel .config [RemoveTracks])   // keys[frame*nb+b] = px py pz qx qy qz qw (file convention)
struct PsaFile { std::vector<std::string> bones; std::vector<PsaSeq> seqs; std::string err; };

inline PsaFile parsePSA(const std::vector<u8>& f) {
    PsaFile p;
    try {
        Reader r(f.data(), f.size()); i32 totalKeys = 0; std::vector<std::array<i32, 3>> info;   // first, count, bones
        while (r.p + 32 <= f.size()) {
            char id[21] = { 0 }; memcpy(id, f.data() + r.p, 20); r.p += 20; r.i(); i32 sz = r.i(), cnt = r.i();
            if (sz < 0 || cnt < 0 || r.p + (size_t)sz * cnt > f.size()) throw Err(std::string("bad chunk ") + id);
            size_t next = r.p + (size_t)sz * cnt; std::string sid = id;
            if (sid.rfind("BONENAMES", 0) == 0) { for (i32 k = 0; k < cnt; k++) { const char* n = (const char*)f.data() + r.p + (size_t)k * sz; std::string s(n, strnlen(n, 64)); while (!s.empty() && s.back() == ' ') s.pop_back(); p.bones.push_back(s); } }
            else if (sid.rfind("ANIMINFO", 0) == 0) {
                for (i32 k = 0; k < cnt; k++) { const u8* d = f.data() + r.p + (size_t)k * sz; PsaSeq s; const char* n = (const char*)d; s.name.assign(n, strnlen(n, 64));
                    i32 tb; memcpy(&tb, d + 128, 4); float rate; memcpy(&rate, d + 128 + 24, 4); i32 first, num; memcpy(&first, d + 128 + 32, 4); memcpy(&num, d + 128 + 36, 4);
                    s.fps = rate > 0 ? rate : 30.f; s.numFrames = num; p.seqs.push_back(s); info.push_back({ first, num, tb }); } }
            else if (sid.rfind("ANIMKEYS", 0) == 0) {
                if (sz != 32) throw Err("ANIMKEYS size " + std::to_string(sz)); totalKeys = cnt; int nb = (int)p.bones.size(); if (!nb) throw Err("ANIMKEYS before BONENAMES");
                for (size_t s = 0; s < p.seqs.size(); s++) { i32 first = info[s][0], num = info[s][1];
                    if ((size_t)(first + num) * nb > (size_t)cnt) throw Err("sequence " + p.seqs[s].name + " out of key range");
                    for (i32 fr = 0; fr < num; fr++) for (int b = 0; b < nb; b++) { const u8* d = f.data() + r.p + ((size_t)(first + fr) * nb + b) * 32; std::array<float, 7> k; memcpy(&k[0], d, 12); memcpy(&k[3], d + 12, 16); p.seqs[s].keys.push_back(k); } }
            }
            r.p = next;
        }
        if (p.bones.empty()) throw Err("no BONENAMES chunk (not a PSA?)");
        if (p.seqs.empty() || !totalKeys) throw Err("no animations in the PSA");
    } catch (std::exception& e) { p.err = e.what(); }
    return p;
}

// umodel writes, next to the .psa, a .config with the tracks that do NOT exist in the original animation ([RemoveTracks] Seq.N=trans|rot|all;
// N = track index = bone index in the PSA). On those tracks the PSA carries zeros/identity, not the real pose: the source game
// (e.g. Arkham City, bAnimRotationOnly) uses the reference pose or controllers. Returns how many entries were applied.
inline int applyUmodelConfig(PsaFile& p, const std::string& text) {
    int n = 0; bool inSec = false; size_t pos = 0;
    while (pos < text.size()) {
        size_t e = text.find('\n', pos); std::string ln = text.substr(pos, e == std::string::npos ? std::string::npos : e - pos); pos = e == std::string::npos ? text.size() : e + 1;
        while (!ln.empty() && (ln.back() == '\r' || ln.back() == ' ')) ln.pop_back();
        if (ln.empty()) continue; if (ln[0] == '[') { inSec = _bmieq(ln, "[RemoveTracks]"); continue; } if (!inSec) continue;
        size_t eq = ln.find('='), dot = ln.rfind('.', eq); if (eq == std::string::npos || dot == std::string::npos) continue;
        std::string seq = ln.substr(0, dot), what = ln.substr(eq + 1); int idx = atoi(ln.substr(dot + 1, eq - dot - 1).c_str());
        u8 m = _bmieq(what, "trans") ? 1 : _bmieq(what, "rot") ? 2 : _bmieq(what, "all") ? 3 : 0; if (!m) continue;
        for (auto& s : p.seqs) if (s.name == seq && idx >= 0 && idx < (int)p.bones.size()) { if (s.removed.empty()) s.removed.assign(p.bones.size(), 0); s.removed[idx] |= m; n++; }
    }
    return n;
}

// ------------------------------------------------------------------ encoding
namespace animenc {
inline void put(std::vector<u8>& b, const void* p, size_t n) { b.insert(b.end(), (const u8*)p, (const u8*)p + n); }
inline void putf(std::vector<u8>& b, float v) { put(b, &v, 4); }
inline void pad4(std::vector<u8>& b) { while (b.size() & 3) b.push_back(0x55); }
// inverse of animdetail::fixed48Max ("smallest three": index of the largest component in 2 bits, the other 3 in 15 bits)
inline void fixed48Max(const float q0[4], u8 out[6]) {
    float q[4] = { q0[0], q0[1], q0[2], q0[3] }; int S = 0; for (int k = 1; k < 4; k++) if (fabsf(q[k]) > fabsf(q[S])) S = k;
    if (q[S] < 0) for (float& v : q) v = -v;
    const float shift = 0.70710678118f, scale = 1.41421356237f; unsigned c[3]; int j = 0;
    for (int k = 0; k < 4; k++) { if (k == S) continue; float v = (q[k] + shift) / scale * 32767.f + 0.5f; long iv = lroundf(v); c[j++] = (unsigned)std::max(0L, std::min(32767L, iv)); }
    uint64_t v = (uint64_t)S | ((uint64_t)c[0] << 2) | ((uint64_t)c[1] << 17) | ((uint64_t)c[2] << 32);
    for (int k = 0; k < 6; k++) out[k] = (u8)(v >> (8 * k));
}
inline void qnorm(std::array<float, 4>& q) { float n = sqrtf(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]); if (n < 1e-12f) { q = { 0, 0, 0, 1 }; return; } for (float& v : q) v /= n; }
inline float qdot(const std::array<float, 4>& a, const std::array<float, 4>& b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]; }
inline float qangle(const std::array<float, 4>& a, const std::array<float, 4>& b) { float d = std::min(1.f, fabsf(qdot(a, b))); return 2.f * acosf(d); }
inline std::array<float, 4> qlerp(const std::array<float, 4>& a, const std::array<float, 4>& b, float t) {
    float bias = qdot(a, b) >= 0 ? 1.f : -1.f; std::array<float, 4> r; for (int k = 0; k < 4; k++) r[k] = a[k] * (1 - t) + b[k] * t * bias; qnorm(r); return r; }
// Douglas-Peucker over the frames: returns the kept frames (always the first and the last)
template <class E> inline std::vector<int> reduce(int n, float tol, E err) {
    std::vector<char> keep(n, 0); keep[0] = keep[n - 1] = 1;
    std::function<void(int, int)> rec = [&](int a, int b) { if (b - a < 2) return; float worst = 0; int wi = -1;
        for (int i = a + 1; i < b; i++) { float e = err(a, b, i); if (e > worst) { worst = e; wi = i; } }
        if (wi >= 0 && worst > tol) { keep[wi] = 1; rec(a, wi); rec(wi, b); } };
    rec(0, n - 1); std::vector<int> out; for (int i = 0; i < n; i++) if (keep[i]) out.push_back(i); return out;
}
}

struct RawTrack { std::vector<std::array<float, 3>> pos; std::vector<std::array<float, 4>> rot; };   // one value per frame (or 1 = constant)
struct EncodedSeq { int numFrames = 0; float fps = 30, length = 0; std::vector<i32> offsets; std::vector<u8> stream; int keysT = 0, keysR = 0, rawKeys = 0; };

// tolT in units (UE cm), tolR in radians
inline EncodedSeq encodeSequence(const std::vector<RawTrack>& tracks, int numFrames, float fps, float tolT = 0.01f, float tolR = 0.0005f) {
    using namespace animenc; EncodedSeq e; e.numFrames = std::max(1, numFrames); e.fps = fps > 0 ? fps : 30.f; e.length = e.numFrames > 1 ? (e.numFrames - 1) / e.fps : 1.f / e.fps;
    bool wide = e.numFrames > 0xFF; auto& b = e.stream;
    auto frameTable = [&](const std::vector<int>& fr) { pad4(b); for (int f : fr) { if (wide) { uint16_t v = (uint16_t)f; put(b, &v, 2); } else b.push_back((u8)f); } pad4(b); };
    for (const RawTrack& t : tracks) {
        // --- translation
        int nP = (int)t.pos.size(); std::vector<int> kp;
        if (nP <= 1) kp = { 0 };
        else { bool cst = true; for (int i = 1; i < nP && cst; i++) for (int k = 0; k < 3; k++) if (fabsf(t.pos[i][k] - t.pos[0][k]) > tolT) cst = false;
            kp = cst ? std::vector<int>{ 0 } : reduce(nP, tolT, [&](int a, int c, int i) { float al = (float)(i - a) / (c - a), m = 0; for (int k = 0; k < 3; k++) m = std::max(m, fabsf(t.pos[a][k] + (t.pos[c][k] - t.pos[a][k]) * al - t.pos[i][k])); return m; }); }
        e.offsets.push_back((i32)b.size()); e.offsets.push_back((i32)kp.size());
        for (int f : kp) for (int k = 0; k < 3; k++) putf(b, t.pos[std::min(f, nP - 1)][k]);
        if (kp.size() > 1) frameTable(kp); else pad4(b);
        e.keysT += (int)kp.size();
        // --- rotation (sign continuity so interpolation takes the short path)
        std::vector<std::array<float, 4>> q = t.rot; if (q.empty()) q.push_back({ 0, 0, 0, 1 });
        for (auto& x : q) qnorm(x); for (size_t i = 1; i < q.size(); i++) if (qdot(q[i - 1], q[i]) < 0) for (float& v : q[i]) v = -v;
        int nR = (int)q.size(); std::vector<int> kr;
        if (nR <= 1) kr = { 0 };
        else { bool cst = true; for (int i = 1; i < nR && cst; i++) if (qangle(q[i], q[0]) > tolR) cst = false;
            kr = cst ? std::vector<int>{ 0 } : reduce(nR, tolR, [&](int a, int c, int i) { return qangle(qlerp(q[a], q[c], (float)(i - a) / (c - a)), q[i]); }); }
        e.offsets.push_back((i32)b.size()); e.offsets.push_back((i32)kr.size());
        if (kr.size() == 1) { std::array<float, 4> c = q[0]; if (c[3] < 0) for (float& v : c) v = -v; putf(b, c[0]); putf(b, c[1]); putf(b, c[2]); }   // 1 key: Float96NoW (w >= 0)
        else {
            float mn[3] = { 1e9f, 1e9f, 1e9f }, mx[3] = { -1e9f, -1e9f, -1e9f };
            for (int f : kr) for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], q[f][k]); mx[k] = std::max(mx[k], q[f][k]); }
            for (int k = 0; k < 3; k++) putf(b, mn[k]); for (int k = 0; k < 3; k++) putf(b, mx[k] - mn[k]);
            for (int f : kr) { u8 o[6]; fixed48Max(q[f].data(), o); put(b, o, 6); }
            frameTable(kr);
        }
        pad4(b);
        e.keysR += (int)kr.size(); e.rawKeys += nP + nR;
    }
    return e;
}

// ------------------------------------------------------------------ apply to an existing AnimSequence (replace) or a new one (clone a template)
struct AnimImportReport {
    bool ok = false; std::string err; std::vector<std::string> warnings;
    int matched = 0, tracks = 0, frames = 0, keysT = 0, keysR = 0, rawKeys = 0; float fps = 30, length = 0; size_t bytes = 0;
    std::vector<std::string> missing, extra;   // AnimSet bones with no data in the PSA (they keep the template pose) / PSA bones ignored
    int filledT = 0, filledR = 0, twistRebuilt = 0;   // tracks with no data in the source (umodel .config) that were filled
    i32 seqIdx = 0;                            // export written (new or replaced)
};
struct AnimImportOptions { bool scaleNotifies = true; float tolT = 0.01f, tolR = 0.0005f; bool keepRootMotion = true; };

namespace animenc {
inline Tag floatTag(const std::string& n, float v) { Tag t; t.name = n; t.type = "FloatProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); return t; }
inline Tag intTag(const std::string& n, i32 v) { Tag t; t.name = n; t.type = "IntProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); return t; }
inline Tag byteEnumTag(Package& pk, const std::string& n, const std::string& v) { Tag t; t.name = n; t.type = "ByteProperty"; i32 a = pk.addName(v), z = 0; t.raw.resize(8); memcpy(t.raw.data(), &a, 4); memcpy(t.raw.data() + 4, &z, 4); return t; }
inline void setTag(std::vector<Tag>& tags, const Tag& nt, const char* after = nullptr) {
    for (auto& t : tags) if (t.name == nt.name && t.index == nt.index) { t.raw = nt.raw; t.type = nt.type; return; }
    if (after) for (size_t i = 0; i < tags.size(); i++) if (tags[i].name == after) { tags.insert(tags.begin() + i + 1, nt); return; }
    tags.push_back(nt);
}
inline std::array<float, 4> qmul(const std::array<float, 4>& a, const std::array<float, 4>& b) {
    return { a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1], a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
             a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3], a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2] }; }
inline std::array<float, 4> qconj(const std::array<float, 4>& a) { return { -a[0], -a[1], -a[2], a[3] }; }
// Biped twist bones with no rotation in the source: rotation rebuilt from the main bone (same direction; the spin
// around the bone axis is not reproduced). Rules measured on the Asylum AnimSets, in track space:
//   Foretwist/UpArmTwist/CalfTwist have the same parent as the main bone -> copy; ThighTwist (parent Spine, thigh parent Pelvis) -> Thigh * conj(Spine)
struct TwistRule { const char* twist; const char* main; const char* parentFix; };
inline const TwistRule* bipedTwistRules() { static const TwistRule r[] = {
    { "Bip01_L_Foretwist", "Bip01_L_Forearm", nullptr }, { "Bip01_R_Foretwist", "Bip01_R_Forearm", nullptr },
    { "Bip01_LUpArmTwist", "Bip01_L_UpperArm", nullptr }, { "Bip01_RUpArmTwist", "Bip01_R_UpperArm", nullptr },
    { "Bip01_LCalfTwist", "Bip01_L_Calf", nullptr }, { "Bip01_RCalfTwist", "Bip01_R_Calf", nullptr },
    { "Bip01_LThighTwist", "Bip01_L_Thigh", "Bip01_Spine" }, { "Bip01_RThighTwist", "Bip01_R_Thigh", "Bip01_Spine" }, { nullptr, nullptr, nullptr } }; return r; }
// Notifies: array of AnimNotifyEvent (tagged structs) -> scale Time/Duration
inline void scaleNotifies(Package& pk, std::vector<Tag>& tags, float ratio) {
    for (auto& t : tags) { if (t.name != "Notifies" || t.type != "ArrayProperty") continue;
        Reader r(t.raw.data(), t.raw.size()); i32 n = r.i(); size_t pos = 4; Writer w; w.i(n);
        for (i32 i = 0; i < n; i++) { size_t end = 0; std::vector<Tag> el = readProps(pk, t.raw.data(), t.raw.size(), pos, &end); pos = end;
            for (auto& x : el) if ((x.name == "Time" || x.name == "Duration") && x.type == "FloatProperty") { float v; memcpy(&v, x.raw.data(), 4); v *= ratio; memcpy(x.raw.data(), &v, 4); }
            w.raw(writeProps(pk, el)); }
        t.raw = w.b; }
}
}

// psaSeq: PSA sequence; targetSeq: AnimSequence to overwrite (or the TEMPLATE to clone when newName != "")
inline AnimImportReport importPSAIntoSequence(Package& pk, const PsaFile& psa, int psaSeq, i32 targetSeq, const std::string& newName, const AnimImportOptions& opt = {}) {
    using namespace animenc; AnimImportReport rep;
    try {
        if (psaSeq < 0 || psaSeq >= (int)psa.seqs.size()) throw Err("bad PSA sequence index");
        if (targetSeq <= 0 || targetSeq > (i32)pk.exports.size() || pk.classOf(pk.exports[targetSeq - 1]) != "AnimSequence") throw Err("target is not an AnimSequence");
        i32 setIdx = pk.exports[targetSeq - 1].outer; if (setIdx <= 0 || pk.classOf(pk.exports[setIdx - 1]) != "AnimSet") throw Err("the AnimSequence is not inside an AnimSet");
        AnimSetData set = parseAnimSet(pk, setIdx); if (!set.err.empty()) throw Err("AnimSet: " + set.err);
        int nt = (int)set.bones.size(); rep.tracks = nt;
        AnimSeq base = parseAnimSequence(pk, targetSeq, nt); if (!base.err.empty()) throw Err("template sequence: " + base.err);
        const PsaSeq& ps = psa.seqs[psaSeq]; int nb = (int)psa.bones.size(), nf = ps.numFrames; if (nf < 1) throw Err("empty PSA sequence");
        // tracks by name
        std::vector<int> src(nt, -1); std::vector<char> used(nb, 0);
        for (int t = 0; t < nt; t++) for (int b = 0; b < nb; b++) if (_bmieq(set.bones[t], psa.bones[b])) { src[t] = b; used[b] = 1; break; }
        std::vector<RawTrack> tr(nt);
        auto rem = [&](int t) -> u8 { return (src[t] >= 0 && !ps.removed.empty()) ? ps.removed[src[t]] : 0; };
        for (int t = 0; t < nt; t++) {
            float bp[3], bq[4]; sampleTrack(base.tracks[t], base.numFrames, 0, bp, bq);   // template pose (frame 0): Asylum bone lengths
            if (src[t] < 0) { tr[t].pos.push_back({ bp[0], bp[1], bp[2] }); tr[t].rot.push_back({ bq[0], bq[1], bq[2], bq[3] }); rep.missing.push_back(set.bones[t]); continue; }
            rep.matched++; u8 m = rem(t);
            if (m & 1) { tr[t].pos.push_back({ bp[0], bp[1], bp[2] }); rep.filledT++; }
            if (m & 2) { tr[t].rot.push_back({ bq[0], bq[1], bq[2], bq[3] }); rep.filledR++; }
            for (int f = 0; f < nf; f++) { const auto& k = ps.keys[(size_t)f * nb + src[t]];
                if (!(m & 1)) tr[t].pos.push_back({ k[0], -k[1], k[2] });
                if (!(m & 2)) tr[t].rot.push_back({ k[3], -k[4], k[5], -k[6] }); }   // inverse of exportPSA (mirrors Y)
        }
        // Biped twist with no rotation in the source: follows the main bone
        auto tix = [&](const char* n) { for (int t = 0; t < nt; t++) if (_bmieq(set.bones[t], n)) return t; return -1; };
        for (const TwistRule* r = bipedTwistRules(); r->twist; r++) {
            int tw = tix(r->twist), mn = tix(r->main), pf = r->parentFix ? tix(r->parentFix) : -2;
            if (tw < 0 || mn < 0 || pf == -1 || !(rem(tw) & 2) || (rem(mn) & 2) || src[mn] < 0) continue;
            if (pf >= 0 && ((rem(pf) & 2) || src[pf] < 0)) continue;
            auto& out = tr[tw].rot; out.clear();
            for (int f = 0; f < nf; f++) { std::array<float, 4> q = tr[mn].rot[std::min<size_t>(f, tr[mn].rot.size() - 1)];
                if (pf >= 0) q = qmul(q, qconj(tr[pf].rot[std::min<size_t>(f, tr[pf].rot.size() - 1)])); qnorm(q); out.push_back(q); }
            rep.twistRebuilt++;
        }
        for (int b = 0; b < nb; b++) if (!used[b]) rep.extra.push_back(psa.bones[b]);
        if (rep.matched == 0) throw Err("no PSA bone matches the AnimSet bones (wrong skeleton?)");
        if (!opt.keepRootMotion && nt > 0 && src[0] >= 0) { auto p0 = tr[0].pos[0]; for (auto& p : tr[0].pos) p = p0; }
        EncodedSeq e = encodeSequence(tr, nf, ps.fps, opt.tolT, opt.tolR);
        rep.frames = e.numFrames; rep.fps = e.fps; rep.length = e.length; rep.keysT = e.keysT; rep.keysR = e.keysR; rep.rawKeys = e.rawKeys; rep.bytes = e.stream.size();
        // properties: keep everything from the template (notifies, cancel points, collision... are normalized 0..1) and change what is needed
        ObjProps op = objProps(pk, targetSeq); if (!op.ok) throw Err("cannot read the sequence properties");
        long st = findPropStart(pk, targetSeq); const Export& te = pk.exports[targetSeq - 1]; const u8* td = pk.dataPtr(te);
        std::vector<Tag> tags = op.tags;
        if (opt.scaleNotifies && base.length > 0 && fabsf(e.length - base.length) > 1e-4f) scaleNotifies(pk, tags, e.length / base.length);
        setTag(tags, intTag("NumFrames", e.numFrames), "SequenceLength");
        setTag(tags, floatTag("SequenceLength", e.length), "SequenceName");
        if (findTag(tags, "FramesPerSecond")) setTag(tags, floatTag("FramesPerSecond", e.fps));
        setTag(tags, byteEnumTag(pk, "RotationCompressionFormat", "ACF_Fixed48Max"), "RateScale");
        setTag(tags, byteEnumTag(pk, "KeyEncodingFormat", "AKF_VariableKeyLerp"), "RotationCompressionFormat");
        if (findTag(tags, "TranslationCompressionFormat")) setTag(tags, byteEnumTag(pk, "TranslationCompressionFormat", "ACF_None"));
        { Tag t; t.name = "CompressedTrackOffsets"; t.type = "ArrayProperty"; Writer w; w.i((i32)e.offsets.size()); for (i32 v : e.offsets) w.i(v); t.raw = w.b; setTag(tags, t, "KeyEncodingFormat"); }
        if (!newName.empty()) { Tag t; t.name = "SequenceName"; t.type = "NameProperty"; i32 a = pk.addName(newName), z = 0; t.raw.resize(8); memcpy(t.raw.data(), &a, 4); memcpy(t.raw.data() + 4, &z, 4); setTag(tags, t); }
        // data: object header + tags + CompressedByteStream (+ whatever follows in the original)
        Reader rr(td, pk.dataLen(te), op.end); i32 oldNb = rr.i(); size_t afterStream = op.end + 4 + (size_t)std::max(0, oldNb);
        std::vector<u8> nd(td, td + st); std::vector<u8> pb = writeProps(pk, tags); nd.insert(nd.end(), pb.begin(), pb.end());
        i32 nbytes = (i32)e.stream.size(); put(nd, &nbytes, 4); nd.insert(nd.end(), e.stream.begin(), e.stream.end());
        if (afterStream < pk.dataLen(te)) nd.insert(nd.end(), td + afterStream, td + pk.dataLen(te));
        // check: decode what was just written and compare it with the input
        if (newName.empty()) {
            Export& x = pk.exports[targetSeq - 1]; Export backup = x; x.data = nd; x.owned = true;
            AnimSeq chk = parseAnimSequence(pk, targetSeq, nt); if (!chk.err.empty()) { x = backup; throw Err("verification failed: " + chk.err); }
            rep.seqIdx = targetSeq;
        } else {
            // unique name (SequenceName) inside the AnimSet
            for (i32 r : set.seqRefs) if (r > 0) { ObjProps o2 = objProps(pk, r); if (o2.ok && _bmieq(tagName(pk, o2.tags, "SequenceName"), newName)) throw Err("the AnimSet already has a sequence named " + newName); }
            Export ne = te; ne.owned = true; ne.data = nd; ne.netObjects.clear(); memset(ne.guid, 0, 16);
            i32 nm = pk.addName("AnimSequence"); int maxNum = 0; for (auto& x : pk.exports) if (x.name.idx == nm) maxNum = std::max(maxNum, x.name.num); ne.name.idx = nm; ne.name.num = maxNum + 1;
            pk.exports.push_back(ne); i32 ni = (i32)pk.exports.size();
            AnimSeq chk = parseAnimSequence(pk, ni, nt); if (!chk.err.empty()) { pk.exports.pop_back(); throw Err("verification failed: " + chk.err); }
            // AnimSet.Sequences += new
            ObjProps so = objProps(pk, setIdx); long sst = findPropStart(pk, setIdx); Export& se = pk.exports[setIdx - 1]; const u8* sd = pk.dataPtr(se);
            std::vector<Tag> stg = so.tags; bool found = false;
            for (auto& t : stg) if (t.name == "Sequences" && t.type == "ArrayProperty") { Reader q(t.raw.data(), t.raw.size()); i32 n = q.i(); Writer w; w.i(n + 1); w.raw(std::vector<u8>(t.raw.begin() + 4, t.raw.end())); w.i(ni); t.raw = w.b; found = true; }
            if (!found) { pk.exports.pop_back(); throw Err("AnimSet has no Sequences array"); }
            std::vector<u8> sn(sd, sd + sst); std::vector<u8> spb = writeProps(pk, stg); sn.insert(sn.end(), spb.begin(), spb.end()); sn.insert(sn.end(), sd + so.end, sd + pk.dataLen(se));
            se.data = sn; se.owned = true; rep.seqIdx = ni;
        }
        // reconstruction error (samples every frame of the result vs. the input)
        AnimSeq chk = parseAnimSequence(pk, rep.seqIdx, nt); float worstR = 0, worstT = 0;
        for (int t = 0; t < nt; t++) if (src[t] >= 0) for (int f = 0; f < nf; f++) { float p[3], q[4]; sampleTrack(chk.tracks[t], chk.numFrames, (float)f, p, q);
            std::array<float, 4> a = { q[0], q[1], q[2], q[3] }, b = tr[t].rot[std::min<size_t>(f, tr[t].rot.size() - 1)]; qnorm(b); worstR = std::max(worstR, qangle(a, b));
            for (int k = 0; k < 3; k++) worstT = std::max(worstT, fabsf(p[k] - tr[t].pos[std::min<size_t>(f, tr[t].pos.size() - 1)][k])); }
        if (worstR > 0.02f || worstT > 0.5f) rep.warnings.push_back("reconstruction error: rot " + std::to_string(worstR) + " rad, pos " + std::to_string(worstT));
        rep.ok = true;
    } catch (std::exception& ex) { rep.err = ex.what(); }
    return rep;
}

} // namespace bm
