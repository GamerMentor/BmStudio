/* bmlzx.c - LZX decompression (Xbox 360 / XMemCompress) for the beta packages. Uses lzxd.c from libmspack (LGPL),
   like UE Viewer. bm_lzx_decompress: 0 = ok. */
#include <string.h>
#include <stdlib.h>
#include "mspack.h"
#include "lzx.h"
struct mspack_file { unsigned char* buf; int bufSize, pos, rest; };
static int bm_read(struct mspack_file* f, void* buffer, int bytes) {
    if (!f->rest) {
        if (f->pos >= f->bufSize) return 0;
        if (f->buf[f->pos] == 0xFF) { if (f->pos + 5 > f->bufSize) return 0; f->rest = (f->buf[f->pos + 3] << 8) | f->buf[f->pos + 4]; f->pos += 5; }
        else { if (f->pos + 2 > f->bufSize) return 0; f->rest = (f->buf[f->pos] << 8) | f->buf[f->pos + 1]; f->pos += 2; }
        if (f->rest > f->bufSize - f->pos) f->rest = f->bufSize - f->pos;
    }
    if (bytes > f->rest) bytes = f->rest; if (bytes <= 0) return 0;
    memcpy(buffer, f->buf + f->pos, bytes); f->pos += bytes; f->rest -= bytes; return bytes;
}
static int bm_write(struct mspack_file* f, void* buffer, int bytes) { if (f->pos + bytes > f->bufSize) return -1; memcpy(f->buf + f->pos, buffer, bytes); f->pos += bytes; return bytes; }
static void* bm_alloc(struct mspack_system* s, size_t n) { (void)s; return malloc(n); }
static void bm_free(void* p) { free(p); }
static void bm_copy(void* src, void* dst, size_t n) { memcpy(dst, src, n); }
static struct mspack_system bmSys = { NULL, NULL, bm_read, bm_write, NULL, NULL, NULL, bm_alloc, bm_free, bm_copy };
int bm_lzx_decompress(const unsigned char* src, int srcSize, unsigned char* dst, int dstSize) {
    struct mspack_file s, d; s.buf = (unsigned char*)src; s.bufSize = srcSize; s.pos = 0; s.rest = 0; d.buf = dst; d.bufSize = dstSize; d.pos = 0; d.rest = 0;
    struct lzxd_stream* z = lzxd_init(&bmSys, &s, &d, 17, 0, 256 * 1024, dstSize); if (!z) return -1;
    int r = lzxd_decompress(z, dstSize); lzxd_free(z); return r;
}
