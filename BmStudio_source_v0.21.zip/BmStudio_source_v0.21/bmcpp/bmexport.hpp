// bmexport.hpp - asset export: SkeletalMesh -> PSK (ActorX), texture -> DDS/PNG
#pragma once
#include "bmasset.hpp"
#include "bmanim.hpp"
#include <unordered_map>

namespace bm {

struct PskWriter {
    Writer w;
    void chunk(const char* id, i32 size, i32 count) { char n[20] = { 0 }; strncpy(n, id, 19); w.raw((const u8*)n, 20); w.i(1999801); w.i(size); w.i(count); }
    void name64(const std::string& s) { char n[64] = { 0 }; strncpy(n, s.c_str(), 63); w.raw((const u8*)n, 64); }
    void f(float v) { u32 x; memcpy(&x, &v, 4); w.u(x); }
    void h(uint16_t v) { w.b.push_back((u8)v); w.b.push_back((u8)(v >> 8)); }
};

// PSK of one LOD. Points welded by exact position (same as umodel); materials by object name.
inline std::vector<u8> exportPSK(const SkeletalMesh& sm, int lodIndex = 0) {
    if (sm.lods.empty()) throw Err("mesh has no LODs");
    const SkelLOD& lod = sm.lods[std::min<size_t>(lodIndex, sm.lods.size() - 1)];
    // points
    struct Key { float x, y, z; bool operator==(const Key& o) const { return memcmp(this, &o, sizeof(Key)) == 0; } };
    struct KH { size_t operator()(const Key& k) const { u32 a, b, c; memcpy(&a, &k.x, 4); memcpy(&b, &k.y, 4); memcpy(&c, &k.z, 4); return a * 73856093u ^ b * 19349663u ^ c * 83492791u; } };
    std::unordered_map<Key, u32, KH> ptMap; std::vector<Key> pts; std::vector<u32> vtxPoint(lod.verts.size());
    for (size_t k = 0; k < lod.verts.size(); k++) { Key kk{ lod.verts[k].pos[0], lod.verts[k].pos[1], lod.verts[k].pos[2] };
        auto it = ptMap.find(kk); if (it == ptMap.end()) { u32 id = (u32)pts.size(); ptMap[kk] = id; pts.push_back(kk); vtxPoint[k] = id; } else vtxPoint[k] = it->second; }
    // material of each vertex (by the section that uses it)
    // like umodel: one material per SECTION (MATT), vertices/faces point to the section index
    std::vector<u8> vtxMat(lod.verts.size(), 0);
    for (size_t si = 0; si < lod.sections.size(); si++) { auto& s = lod.sections[si]; for (u32 t = 0; t < s.numTris * 3; t++) { u32 i = lod.indices[s.baseIndex + t]; if (i < vtxMat.size()) vtxMat[i] = (u8)si; } }
    bool bigIdx = lod.verts.size() > 65535 || pts.size() > 65535;
    PskWriter p;
    p.chunk("ACTRHEAD", 0, 0);
    p.chunk("PNTS0000", 12, (i32)pts.size()); for (auto& q : pts) { p.f(q.x); p.f(-q.y); p.f(q.z); }      // mirrors Y (umodel / PSK importer convention)
    p.chunk("VTXW0000", 16, (i32)lod.verts.size());
    for (size_t k = 0; k < lod.verts.size(); k++) { if (bigIdx) p.w.u(vtxPoint[k]); else { p.h((uint16_t)vtxPoint[k]); p.h(0); } p.f(lod.verts[k].uv[0]); p.f(lod.verts[k].uv[1]); p.w.b.push_back(vtxMat[k]); p.w.b.push_back(0); p.h(0); }
    size_t nf = 0; for (auto& s : lod.sections) nf += s.numTris;
    static const int ord[3] = { 1, 0, 2 };                        // mirroring flips the face winding
    if (bigIdx) { p.chunk("FACE3200", 18, (i32)nf); for (size_t si = 0; si < lod.sections.size(); si++) { auto& s = lod.sections[si]; for (u32 t = 0; t < s.numTris; t++) { for (int j = 0; j < 3; j++) p.w.u(lod.indices[s.baseIndex + t * 3 + ord[j]]); p.w.b.push_back((u8)si); p.w.b.push_back(0); p.w.u(1); } } }
    else { p.chunk("FACE0000", 12, (i32)nf); for (size_t si = 0; si < lod.sections.size(); si++) { auto& s = lod.sections[si]; for (u32 t = 0; t < s.numTris; t++) { for (int j = 0; j < 3; j++) p.h((uint16_t)lod.indices[s.baseIndex + t * 3 + ord[j]]); p.w.b.push_back((u8)si); p.w.b.push_back(0); p.w.u(1); } } }
    p.chunk("MATT0000", 88, (i32)lod.sections.size());
    for (size_t si = 0; si < lod.sections.size(); si++) { int m = lod.sections[si].material; std::string n = (m >= 0 && m < (int)sm.materials.size()) ? sm.materials[m] : "None";
        size_t d = n.rfind('.'); if (d != std::string::npos) n = n.substr(d + 1); if (n == "None") n = "material_" + std::to_string(si); p.name64(n); p.w.i((i32)si); for (int j = 0; j < 5; j++) p.w.i(0); }
    p.chunk("REFSKELT", 120, (i32)sm.bones.size());
    for (size_t k = 0; k < sm.bones.size(); k++) { const Bone& b = sm.bones[k]; int nch = 0; for (size_t j = 0; j < sm.bones.size(); j++) if (j != k && sm.bones[j].parent == (i32)k) nch++;
        p.name64(b.name); p.w.u(0); p.w.i(nch); p.w.i(b.parent);
        p.f(b.q[0]); p.f(-b.q[1]); p.f(b.q[2]); p.f(k == 0 ? -b.q[3] : b.q[3]); p.f(b.pos[0]); p.f(-b.pos[1]); p.f(b.pos[2]); p.f(0); p.f(0); p.f(0); p.f(0); }
    // weights per POINT (like ActorX): uses the first vertex of each point
    std::vector<i32> pointVtx(pts.size(), -1); for (size_t k = 0; k < lod.verts.size(); k++) if (pointVtx[vtxPoint[k]] < 0) pointVtx[vtxPoint[k]] = (i32)k;
    Writer ww; i32 nw = 0;
    for (size_t pi = 0; pi < pts.size(); pi++) { i32 v = pointVtx[pi]; if (v < 0) continue; int c = chunkOfVertex(lod, (u32)v); const SkelVertex& sv = lod.verts[v];
        for (int j = 0; j < 4; j++) { if (!sv.weights[j]) continue; int bone = sv.bones[j]; if (c >= 0 && bone < (int)lod.chunks[c].boneMap.size()) bone = lod.chunks[c].boneMap[bone];
            float wt = sv.weights[j] / 255.f; u32 x; memcpy(&x, &wt, 4); ww.u(x); ww.i((i32)pi); ww.i(bone); nw++; } }
    p.chunk("RAWWEIGHTS", 12, nw); p.w.raw(ww.b);
    return p.w.b;
}


// PSA (ActorX) of an AnimSet: every sequence (or only 'only' if >0), sampled per frame. umodel convention (mirrors Y).
inline std::vector<u8> exportPSA(const Package& pk, const AnimSetData& set, const std::vector<AnimSeq>& seqs) {
    PskWriter p; int nb = (int)set.bones.size();
    p.chunk("ANIMHEAD", 0, 0); p.w.b.resize(p.w.b.size() - 12); p.w.i(20100422); p.w.i(0); p.w.i(0);   // TypeFlag = version
    p.chunk("BONENAMES", 120, nb);
    for (int i = 0; i < nb; i++) { p.name64(set.bones[i]); p.w.u(0); p.w.i(0); p.w.i(i > 0 ? 0 : -1); p.f(0); p.f(0); p.f(0); p.f(0); p.f(0); p.f(0); p.f(0); p.f(1); p.f(0); p.f(0); p.f(0); }
    p.chunk("ANIMINFO", 168, (i32)seqs.size()); int first = 0;
    for (auto& s : seqs) { p.name64(s.name); p.name64("None"); p.w.i(nb); p.w.i(0); p.w.i(0); p.w.i(s.numFrames * nb); p.f(0); p.f((float)s.numFrames); p.f(s.rawFps()); p.w.i(0); p.w.i(first); p.w.i(s.numFrames); first += s.numFrames; }
    p.chunk("ANIMKEYS", 32, first * nb);
    for (auto& s : seqs) for (int f = 0; f < s.numFrames; f++) for (int b = 0; b < nb; b++) {
        float pos[3] = { 0, 0, 0 }, q[4] = { 0, 0, 0, 1 }; if (b < (int)s.tracks.size()) sampleTrack(s.tracks[b], s.numFrames, (float)f, pos, q);
        p.f(pos[0]); p.f(-pos[1]); p.f(pos[2]); p.f(q[0]); p.f(-q[1]); p.f(q[2]); p.f(-q[3]); p.f(1); }
    p.chunk("SCALEKEYS", 16, 0);
    (void)pk; return p.w.b;
}

} // namespace bm
