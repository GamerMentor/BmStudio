// bmcopy.hpp - copying objects between cooked Batman: Arkham Asylum packages (UE3 v576/lic21), with dependencies.
//
// To remap an object we have to find ALL the object references (i32 indices) and names (FName) inside its bytes:
//   * UObject header: StateFrame (actors), TemplateOwnerClass/TemplateName (components), NetIndex
//   * tagged properties: the type comes in the tag; arrays need the element type -> read from the classes in the script packages
//     (Core.u, Engine.u, BmGame.u...). "Immutable" structs (STRUCT_Immutable / ImmutableWhenCooked) are binary:
//     fields of the struct itself and then of the parent, skipping Native/Transient/Deprecated (UStruct::SerializeBin).
//     Enum = FName (8 bytes), binary bool = 1 byte, Guid = 16 bytes (BATMAN).
//   * native data after the tags: handled per class (Texture2D, Material, ...). A class with unknown native data
//     is refused (nothing is copied "blindly").
// The remaps swap values of the same size (i32 -> i32, FName -> FName): the bytes do not change size.
#pragma once
#include "bmscript.hpp"
#include "bmskelimp.hpp"
#include <memory>
#include <functional>
#include <map>
#include <set>

namespace bm { namespace cp {
using namespace bm::us;

enum Kind { K_Int, K_Float, K_Bool, K_Byte, K_Enum, K_Name, K_Str, K_Obj, K_Delegate, K_Struct, K_Array, K_Map, K_Unknown };
struct PType { Kind k = K_Unknown; std::string strct, pcls; std::shared_ptr<PType> inner; };   // pcls = property class (IntProperty, ComponentProperty...)
struct PField { std::string name; PType t; int dim = 1; u64 flags = 0; };
struct Scope { bool ok = false; std::vector<PField> fields; std::string super; u32 structFlags = 0; };

static const u64 CPF_Native = 0x1000ull, CPF_Transient = 0x2000ull, CPF_Deprecated = 0x20000000ull;
static const u32 STRUCT_Immutable = 0x20, STRUCT_ImmutableWhenCooked = 0x80;

inline std::string lower(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }

class TypeDB {
public:
    void add(const Package* p) {
        pkgs.push_back(p);
        for (size_t k = 0; k < p->exports.size(); k++) {
            const Export& e = p->exports[k]; std::string c = p->classOf(e);
            if (c == "Class") classes.emplace(lower(p->objName((i32)k + 1)), std::make_pair(p, (i32)k + 1));
            else if (c == "ScriptStruct") structs.emplace(lower(p->objName((i32)k + 1)), std::make_pair(p, (i32)k + 1));
        }
    }
    bool hasClass(const std::string& n) const { return classes.count(lower(n)) != 0; }
    const Scope* scope(bool isStruct, const std::string& name) const {
        std::string key = (isStruct ? "S:" : "C:") + lower(name);
        auto it = cache.find(key); if (it != cache.end()) return &it->second;
        Scope& sc = cache[key];
        auto& tab = isStruct ? structs : classes; auto f = tab.find(lower(name)); if (f == tab.end()) return &sc;
        const Package& pk = *f->second.first; i32 idx = f->second.second;
        FieldInfo fi = parseField(pk, idx); if (!fi.ok) return &sc;
        sc.structFlags = fi.structFlags; if (fi.superField) sc.super = pk.objName(fi.superField);
        for (i32 ch : childFields(pk, idx)) { FieldInfo pf = parseField(pk, ch); if (!pf.isProperty) continue;
            PField fld; fld.name = pk.objName(ch); fld.t = typeOf(pk, ch, 0); fld.dim = pf.arrayDim; fld.flags = pf.propFlags; sc.fields.push_back(fld); }
        sc.ok = true; return &sc;
    }
    // looks up the property in the scope and its parents
    const PField* findProp(bool isStruct, const std::string& scopeName, const std::string& prop) const {
        std::string s = scopeName; for (int g = 0; !s.empty() && g < 64; g++) { const Scope* sc = scope(isStruct, s); if (!sc->ok) return nullptr;
            for (auto& f : sc->fields) if (Package::strcasecmp_(f.name, prop)) return &f; s = sc->super; }
        return nullptr;
    }
    // fields in binary serialization order (the struct itself, then the parent)
    bool binFields(const std::string& st, std::vector<const PField*>& out) const {
        std::string s = st; for (int g = 0; !s.empty() && g < 32; g++) { const Scope* sc = scope(true, s); if (!sc->ok) return false; for (auto& f : sc->fields) out.push_back(&f); s = sc->super; }
        return true;
    }
    bool immutable(const std::string& st) const { const Scope* sc = scope(true, st); return sc->ok && (sc->structFlags & (STRUCT_Immutable | STRUCT_ImmutableWhenCooked)); }
private:
    PType typeOf(const Package& pk, i32 prop, int depth) const {
        PType t; if (prop <= 0 || depth > 6) return t; FieldInfo f = parseField(pk, prop); const std::string& c = f.cls; t.pcls = c;
        if (c == "IntProperty") t.k = K_Int; else if (c == "FloatProperty") t.k = K_Float; else if (c == "BoolProperty") t.k = K_Bool;
        else if (c == "ByteProperty") t.k = f.ref1 ? K_Enum : K_Byte; else if (c == "NameProperty") t.k = K_Name; else if (c == "StrProperty") t.k = K_Str;
        else if (c == "ObjectProperty" || c == "ComponentProperty" || c == "ClassProperty" || c == "InterfaceProperty") t.k = K_Obj;
        else if (c == "DelegateProperty") t.k = K_Delegate; else if (c == "MapProperty") t.k = K_Map;
        else if (c == "StructProperty") { t.k = K_Struct; t.strct = pk.objName(f.ref1); }
        else if (c == "ArrayProperty") { t.k = K_Array; if (f.ref1 > 0) t.inner = std::make_shared<PType>(typeOf(pk, f.ref1, depth + 1)); }
        return t;
    }
    std::vector<const Package*> pkgs;
    std::multimap<std::string, std::pair<const Package*, i32>> classes, structs;
    mutable std::map<std::string, Scope> cache;
};

// positions (inside the export data) of object references and FNames
struct Refs { std::vector<size_t> objs, names; };

class Walker {
public:
    Walker(const Package& p, const TypeDB& d, const u8* data, size_t len, Refs& r) : pk(p), db(d), dt(data), n(len), out(r) {}
    std::string err;
    i32 rd(size_t p) const { if (p + 4 > n) throw Err("read past end"); i32 v; memcpy(&v, dt + p, 4); return v; }
    std::string nameAt(size_t p) const { FName f; f.idx = rd(p); f.num = rd(p + 4); return pk.nm(f); }
    void obj(size_t p) { rd(p); out.objs.push_back(p); }
    void name(size_t p) { rd(p + 4); out.names.push_back(p); }
    void fstr(size_t& p) { i32 l = rd(p); p += 4; if (l > 0) p += (size_t)l; else if (l < 0) p += (size_t)(-l) * 2; if (p > n) throw Err("string past end"); }
    void item(size_t& p, const PType& t, const std::string& ctx) {
        switch (t.k) {
        case K_Int: case K_Float: p += 4; break;
        case K_Bool: case K_Byte: p += 1; break;
        case K_Enum: case K_Name: name(p); p += 8; break;
        case K_Str: fstr(p); break;
        case K_Obj: obj(p); p += 4; break;
        case K_Delegate: obj(p); name(p + 4); p += 12; break;
        case K_Struct: structItem(p, t.strct); break;
        case K_Array: { if (!t.inner) throw Err("array without element type (" + ctx + ")"); i32 c = rd(p); p += 4; if (c < 0 || c > 10000000) throw Err("bad array count in " + ctx);
            for (i32 k = 0; k < c; k++) item(p, *t.inner, ctx); break; }
        default: throw Err("unsupported property type in " + ctx);
        }
        if (p > n) throw Err("past end in " + ctx);
    }
    void structItem(size_t& p, const std::string& st) {
        if (Package::strcasecmp_(st, "Guid")) { p += 16; return; }
        if (db.immutable(st)) { std::vector<const PField*> fl; if (!db.binFields(st, fl)) throw Err("unknown struct " + st);
            for (auto* f : fl) { if (f->flags & (CPF_Native | CPF_Transient | CPF_Deprecated)) continue; for (int k = 0; k < f->dim; k++) item(p, f->t, st + "." + f->name); }
            return; }
        if (!db.scope(true, st)->ok) throw Err("unknown struct " + st);
        tags(p, true, st);
    }
    // tagged property list; scope = class or struct (to find the type of array elements)
    void tags(size_t& p, bool isStruct, const std::string& scope) {
        for (int guard = 0; guard < 100000; guard++) {
            std::string nm = nameAt(p); name(p);
            if (nm == "None") { p += 8; return; }
            std::string ty = nameAt(p + 8); name(p + 8); i32 size = rd(p + 16); p += 24;
            if (ty == "StructProperty") { name(p); p += 8; }
            if (ty == "BoolProperty") { p += 4; continue; }
            if (size < 0 || p + (size_t)size > n) throw Err("bad tag size (" + nm + ")");
            size_t vp = p, end = p + (size_t)size;
            if (ty == "IntProperty" || ty == "FloatProperty" || ty == "StrProperty") {}
            else if (ty == "ObjectProperty" || ty == "ComponentProperty" || ty == "ClassProperty" || ty == "InterfaceProperty") { if (size >= 4) obj(vp); }
            else if (ty == "NameProperty") name(vp);
            else if (ty == "ByteProperty") { if (size == 8) name(vp); }
            else if (ty == "DelegateProperty") { obj(vp); name(vp + 4); }
            else if (ty == "StructProperty") { std::string st = nameAt(p - 8); size_t q = vp; structItem(q, st); if (q != end) throw Err("struct " + st + " (" + nm + ") size mismatch"); }
            else if (ty == "ArrayProperty") {
                const PField* f = db.findProp(isStruct, scope, nm); size_t q = vp;
                if (!f || f->t.k != K_Array) { if (size == 4 && rd(vp) == 0) q = end; else throw Err("unknown array " + scope + "." + nm); }
                else item(q, f->t, scope + "." + nm);
                if (q != end) throw Err("array " + scope + "." + nm + " size mismatch");
            }
            else if (ty == "MapProperty") { if (!(size == 4 && rd(vp) == 0)) throw Err("map property " + nm + " not supported"); }
            else throw Err("unknown property type " + ty);
            p = end;
        }
        throw Err("too many tags");
    }
private:
    const Package& pk; const TypeDB& db; const u8* dt; size_t n; Refs& out;
};

// ---- native data (after the tags) per class
namespace native {
inline void bulk(Walker& w, size_t& p) { u32 fl = (u32)w.rd(p); i32 sz = w.rd(p + 8), off = w.rd(p + 12); p += 16; if (!(fl & 1) && off != -1) p += (size_t)std::max(0, sz); (void)fl; }
// serialized FMaterialUniformExpression: type FName + data
inline void uexpr(Walker& w, size_t& p, int depth = 0) {
    if (depth > 64) throw Err("uniform expression too deep");
    std::string t = w.nameAt(p); w.name(p); p += 8;
    auto X = [&]() { uexpr(w, p, depth + 1); };
    if (t == "FMaterialUniformExpressionConstant") p += 17;                                      // FLinearColor + BYTE
    else if (t == "FMaterialUniformExpressionTexture") { w.obj(p); p += 4; }
    else if (t == "FMaterialUniformExpressionTime" || t == "FMaterialUniformExpressionRealTime") {}
    else if (t == "FMaterialUniformExpressionVectorParameter") { w.name(p); p += 8 + 16; }
    else if (t == "FMaterialUniformExpressionScalarParameter") { w.name(p); p += 8 + 4; }
    else if (t == "FMaterialUniformExpressionTextureParameter") { w.name(p); w.obj(p + 8); p += 12; }
    else if (t == "FMaterialUniformExpressionFlipBookTextureParameter") { w.obj(p); p += 4; }
    else if (t == "FMaterialUniformExpressionSine") { X(); p += 4; }
    else if (t == "FMaterialUniformExpressionSquareRoot" || t == "FMaterialUniformExpressionPeriodic" || t == "FMaterialUniformExpressionFloor" ||
             t == "FMaterialUniformExpressionCeil" || t == "FMaterialUniformExpressionFrac" || t == "FMaterialUniformExpressionAbs") X();
    else if (t == "FMaterialUniformExpressionFoldedMath") { X(); X(); p += 1; }
    else if (t == "FMaterialUniformExpressionAppendVector") { X(); X(); p += 4; }
    else if (t == "FMaterialUniformExpressionMin" || t == "FMaterialUniformExpressionMax") { X(); X(); }
    else if (t == "FMaterialUniformExpressionClamp") { X(); X(); X(); }
    else throw Err("unknown material expression " + t);
}
inline void staticMesh(Walker& w, size_t& p) {
    auto bulkArr = [&]() { i32 es = w.rd(p), c = w.rd(p + 4); if (es < 0 || c < 0) throw Err("bad bulk array"); p += 8 + (size_t)es * c; };
    p += 28; w.obj(p); p += 4;                                                                // Bounds, BodySetup
    bulkArr(); bulkArr();                                                                     // kDOP
    i32 iv = w.rd(p); p += 4; if (iv >= 17) { i32 c = w.rd(p); p += 4; for (i32 k = 0; k < c; k++) { w.name(p); p += 8; } }   // ContentTags
    i32 nl = w.rd(p); p += 4; if (nl < 0 || nl > 8) throw Err("bad LOD count");
    for (i32 l = 0; l < nl; l++) {
        bulk(w, p);                                                                           // RawTriangles
        i32 ne = w.rd(p); p += 4; if (ne < 0 || ne > 1024) throw Err("bad elements");
        for (i32 k = 0; k < ne; k++) { w.obj(p); p += 4 + 12 + 16 + 4; i32 nf = w.rd(p); p += 4 + (size_t)std::max(0, nf) * 8; }
        p += 12; i32 pes = w.rd(p), pc = w.rd(p + 4); p += 8 + (size_t)pes * pc;
        p += 16; i32 ves = w.rd(p), vc = w.rd(p + 4); p += 8 + (size_t)ves * vc;
        p += 8; bulkArr(); p += 4;
        i32 ies = w.rd(p), ic = w.rd(p + 4); p += 8 + (size_t)ies * ic;
        bulkArr(); bulkArr(); i32 nd = w.rd(p); p += 4 + (size_t)std::max(0, nd);
    }
    i32 li = w.rd(p); p += 4; (void)li;                                                       // LODInfo (elements without data)
    p += 12 + 4; w.fstr(p); p += 4 + 4;                                                       // ThumbnailAngle/Distance, HighResSourceMeshName, CRC, ForceShadowVolumes
}
inline void materialResource(Walker& w, size_t& p) {
    i32 ne = w.rd(p); p += 4; for (i32 k = 0; k < ne; k++) w.fstr(p);                       // CompileErrors
    i32 nm = w.rd(p); p += 4; for (i32 k = 0; k < nm; k++) { w.obj(p); p += 8; }               // TextureDependencyLengthMap
    p += 4 + 16 + 4;                                                                          // MaxTextureDependencyLength, Id, NumUserTexCoords
    for (int a = 0; a < 4; a++) { i32 c = w.rd(p); p += 4; if (c < 0 || c > 100000) throw Err("bad uniform expression count"); for (i32 k = 0; k < c; k++) uexpr(w, p); }
    p += 4 + 4 + 4 + 4;                                                                       // bUsesSceneColor, SceneDepth, DynamicParameter, UsingTransforms
    i32 tl = w.rd(p); p += 4 + (size_t)std::max(0, tl) * 16;                                   // TextureLookups
    p += 4;                                                                                   // DroppedFallbackComponents
}
}

// parses an export: header, tags and native data. Returns false (with err) if something is not recognized.
inline bool analyzeExport(const Package& pk, const TypeDB& db, i32 idx, Refs& out, std::string& err) {
    const Export& e = pk.exports[idx - 1]; const u8* d = pk.dataPtr(e); size_t n = pk.dataLen(e);
    if (n == 0) return true;
    std::string cls = pk.classOf(e);
    try {
        Walker w(pk, db, d, n, out);
        long ps = findPropStart(pk, idx); if (ps < 0) throw Err("cannot find the property list (" + cls + ")");
        // header before the properties
        size_t base = 0;
        if (e.flags & 0x0200000000000000ull) {                                                // FStateFrame
            w.obj(0); w.obj(4); i32 cnt = w.rd(18); if (cnt < 0 || cnt > 64) throw Err("bad state stack");
            for (i32 k = 0; k < cnt; k++) { w.obj(22 + (size_t)k * 12); w.obj(22 + (size_t)k * 12 + 4); }
            base = 22 + (size_t)cnt * 12 + (w.rd(0) ? 4 : 0);
        }
        size_t pre = (size_t)ps - base;
        if (pre == 16) { w.obj(base); w.name(base + 4); }                                        // TemplateOwnerClass + TemplateName + NetIndex
        else if (pre == 8) { w.obj(base); }                                                     // TemplateOwnerClass + NetIndex
        else if (pre != 4) throw Err("unexpected object header (" + std::to_string(pre) + " bytes)");
        size_t p = (size_t)ps; w.tags(p, false, cls);
        size_t left = n - p;
        if (left == 0) return true;
        if (cls == "Texture2D") { native::bulk(w, p); i32 m = w.rd(p); p += 4; for (i32 k = 0; k < m; k++) { native::bulk(w, p); p += 8; } p += 16; }
        else if (cls == "Material") { native::materialResource(w, p); native::materialResource(w, p); }
        else if (cls == "AnimSequence") { i32 nb = w.rd(p); p += 4 + (size_t)std::max(0, nb); }                  // CompressedByteStream (no references)
        else if (cls == "MaterialInstanceConstant" || cls == "MaterialInstanceTimeVarying") {                   // StaticPermutationResource + StaticParameters (SM3, SM2)
            for (int k = 0; k < 2; k++) { native::materialResource(w, p); p += 16;
                i32 ns = w.rd(p); p += 4; for (i32 q = 0; q < ns; q++) { w.name(p); p += 32; }
                i32 nm = w.rd(p); p += 4; for (i32 q = 0; q < nm; q++) { w.name(p); p += 44; } } }
        else if (cls == "StaticMesh") native::staticMesh(w, p);
        else if (cls == "SkeletalMesh") {
            RawSkel rs = readRawSkel(pk, idx); if (!rs.err.empty()) throw Err("SkeletalMesh: " + rs.err);
            p += 28 + 4; i32 nb = w.rd(p); p += 4 + (size_t)nb * 28;                                // Bounds, ConservativeBounds, PerBoneBounds
            i32 nm = w.rd(p); p += 4; for (i32 k = 0; k < nm; k++) { w.obj(p); p += 4; }              // Materials
            p += 24; i32 bn = w.rd(p); p += 4; for (i32 k = 0; k < bn; k++) { w.name(p); p += 52; }   // Origin/RotOrigin, RefSkeleton
            p += 4; if (p != rs.lodCountOff) throw Err("SkeletalMesh header mismatch");
            p = rs.lodEnd;                                                                         // LODModels (no references)
            i32 ni = w.rd(p); p += 4; for (i32 k = 0; k < ni; k++) { w.name(p); p += 12; }            // NameIndexMap
            i32 a1 = w.rd(p), a2 = w.rd(p + 4); if (a1 != 0 || a2 != 0) throw Err("SkeletalMesh: unknown trailing data"); p += 8;
        }
        else if (cls == "FaceFXAsset" || cls == "FaceFXAnimSet") { for (int k = 0; k < 2 && p < n; k++) { i32 c = w.rd(p); p += 4 + (size_t)std::max(0, c); } }
        else if (cls == "SoundNodeWave") { for (int k = 0; k < 4 && p < n; k++) native::bulk(w, p); }        // RawData, CompressedPCData (MP3), Xbox360, PS3: no references
        else if (cls == "RFMODSound" || cls == "ForceFeedbackWaveform" || cls == "TextureCube" || cls == "TextureMovie" || cls == "PhysicsAssetInstance") p = n;   // opaque data, no references
        else if (left <= 16 && [&] { for (size_t q = p; q < n; q++) if (d[q]) return false; return true; }()) p = n;   // empty arrays (0 counts)
        else throw Err("class " + cls + " has native data that the copier does not know yet (" + std::to_string(left) + " bytes)");
        if (p != n) throw Err(cls + ": native data size mismatch (" + std::to_string((long)n - (long)p) + " bytes left)");
        return true;
    } catch (std::exception& ex) { err = ex.what(); return false; }
}

// ------------------------------------------------------------------ copy
struct CopyReport {
    bool ok = false; std::string err; int copied = 0, reused = 0, replaced = 0, newImports = 0, newNames = 0;
    std::vector<std::string> notes, problems; std::vector<i32> roots;   // indices in the target
};

// copies 'roots' from S to D (with every dependency D does not have). replaceExisting: a root that already exists in D
// (same path) gets its data replaced by the S version.
// srcScriptPkg: name of the script package of S when S is an always-loaded package (e.g. "BmGame" for BmGame.u). Objects of S
// outside a forced export (classes, script notifies, CDOs...) become an import "BmGame.Path" instead of a copy.
inline CopyReport copyObjects(Package& D, const Package& S, const std::vector<i32>& roots, const TypeDB& db, bool replaceExisting, const std::map<i32, i32>& targetFor = {}, const std::string& srcScriptPkg = "") {
    CopyReport rep; size_t names0 = D.names.size(), imports0 = D.imports.size(), exports0 = D.exports.size();
    std::map<i32, Export> backup;                       // replaced exports (for undo)
    auto rollback = [&]() { D.names.resize(names0); D.imports.resize(imports0); D.exports.resize(exports0); for (auto& kv : backup) D.exports[kv.first - 1] = kv.second; };
    try {
        // --- dependency closure
        std::map<i32, i32> mapExp;                  // S export -> D export (existing or new)
        std::map<i32, Refs> refsOf; std::vector<i32> order; std::set<i32> isRoot(roots.begin(), roots.end());
        std::vector<i32> stack(roots.rbegin(), roots.rend()); std::set<i32> visiting;
        std::vector<i32> toCopy; std::map<i32, i32> replaceInto;
        // path the object will have in the target (a "replace with" root takes the place of the target, and the children go along)
        std::function<std::string(i32)> dPath = [&](i32 s) -> std::string {
            auto t = targetFor.find(s); if (t != targetFor.end()) return D.objPath(t->second);
            i32 o = S.exports[s - 1].outer; if (o > 0) { std::string po = dPath(o); return po + "." + S.objName(s); } return S.objPath(s); };
        std::function<bool(i32)> underRep = [&](i32 s) -> bool {
            for (int g = 0; s > 0 && g < 64; g++) { if (targetFor.count(s)) return true; if (replaceExisting && isRoot.count(s) && D.findPath(S.objPath(s)) > 0) return true; s = S.exports[s - 1].outer; } return false; };
        for (auto& kv : targetFor) if (S.classOf(S.exports[kv.first - 1]) != D.classOf(D.exports[kv.second - 1]))
            throw Err("cannot replace a " + D.classOf(D.exports[kv.second - 1]) + " with a " + S.classOf(S.exports[kv.first - 1]));
        std::function<void(i32)> visit = [&](i32 s) {
            if (s <= 0 || mapExp.count(s) || visiting.count(s)) return;
            const Export& e = S.exports[s - 1]; std::string cl = S.classOf(e);
            i32 inD = targetFor.count(s) ? targetFor.at(s) : D.findPath(dPath(s)); bool rep_ = underRep(s);
            if (inD > 0 && !rep_) { mapExp[s] = inD; rep.reused++; return; }
            if (inD < 0 && !rep_) { mapExp[s] = inD; rep.reused++; return; }               // D already imports this object: use the import
            if (inD < 0) inD = 0;
            if (!srcScriptPkg.empty() && !rep_) {
                bool forced = false; for (i32 x = s; x > 0; x = S.exports[x - 1].outer) if (S.exports[x - 1].exportFlags & 1u) { forced = true; break; }
                if (!forced) { std::function<i32(i32)> imp = [&](i32 x) -> i32 {
                        std::string p = srcScriptPkg + "." + S.objPath(x); i32 f = D.findPath(p); if (f) return f;
                        const Export& xe = S.exports[x - 1]; std::string cp, cn;
                        if (xe.cls < 0) { const Import& ci = S.imports[-xe.cls - 1]; cn = S.nm(ci.name); cp = ci.outer < 0 ? S.nm(S.imports[-ci.outer - 1].name) : "Core"; }
                        else if (xe.cls > 0) { cn = S.objName(xe.cls); cp = srcScriptPkg; } else { cn = "Class"; cp = "Core"; }
                        i32 outer = xe.outer > 0 ? imp(xe.outer) : D.ensureRef(srcScriptPkg, "Core", "Package");
                        Import im; im.classPkg.idx = D.addName(cp); im.className.idx = D.addName(cn); im.outer = outer; im.name.idx = D.addName(S.names[xe.name.idx].first); im.name.num = xe.name.num;
                        D.imports.push_back(im); rep.newImports++; return -(i32)D.imports.size(); };
                    mapExp[s] = imp(s); rep.reused++; return; }
            }
            if (cl == "Class" || cl == "Function" || cl == "State" || cl == "ScriptStruct" || cl == "Enum" || cl == "Const" || isPropType(cl))
                throw Err(S.objPath(s) + " is script code (" + cl + ") defined in the source package: not supported");
            visiting.insert(s);
            Refs r; std::string err; if (!analyzeExport(S, db, s, r, err)) throw Err(S.objPath(s) + ": " + err);
            refsOf[s] = r;
            if (inD > 0) replaceInto[s] = inD;
            mapExp[s] = 0; toCopy.push_back(s);
            visit(e.outer); visit(e.archetype); if (e.cls > 0) visit(e.cls); if (e.super_ > 0) visit(e.super_);
            const u8* d = S.dataPtr(e);
            for (size_t p : r.objs) { i32 v; memcpy(&v, d + p, 4); if (v > 0 && v <= (i32)S.exports.size()) visit(v); }
            visiting.erase(s);
        };
        for (i32 r : roots) visit(r);
        // --- new exports
        for (i32 s : toCopy) {
            if (replaceInto.count(s)) { mapExp[s] = replaceInto[s]; backup[replaceInto[s]] = D.exports[replaceInto[s] - 1]; continue; }
            Export ne = S.exports[s - 1]; ne.owned = true; ne.data.clear(); ne.netObjects.clear();
            ne.outer = 0; ne.archetype = 0; ne.cls = 0; ne.super_ = 0; ne.name.idx = D.addName("__bmcopy_pending"); ne.name.num = 0;   // S indices until the remap (findPath halfway through)
            D.exports.push_back(ne); mapExp[s] = (i32)D.exports.size(); rep.copied++;
        }
        // --- imports
        std::function<i32(i32)> mapImp = [&](i32 s) -> i32 {
            if (s == 0) return 0;
            if (s > 0) { auto it = mapExp.find(s); if (it != mapExp.end() && it->second != 0) return it->second; i32 f = D.findPath(S.objPath(s)); if (f) return f; throw Err("unresolved reference " + S.objPath(s)); }
            i32 f = D.findPath(S.objPath(s)); if (f) return f;
            const Import& si = S.imports[-s - 1]; Import im;
            im.outer = mapImp(si.outer);
            im.classPkg.idx = D.addName(S.names[si.classPkg.idx].first); im.classPkg.num = si.classPkg.num;
            im.className.idx = D.addName(S.names[si.className.idx].first); im.className.num = si.className.num;
            im.name.idx = D.addName(S.names[si.name.idx].first); im.name.num = si.name.num;
            D.imports.push_back(im); return -(i32)D.imports.size();
        };
        auto mapRef = [&](i32 v) -> i32 { if (v == 0) return 0; if (v > 0 && v > (i32)S.exports.size()) throw Err("bad reference"); return mapImp(v); };
        // --- remapped data
        for (i32 s : toCopy) {
            const Export& se = S.exports[s - 1]; i32 di = mapExp[s]; Export& de = D.exports[di - 1];
            std::vector<u8> d = S.dataCopy(se); const Refs& r = refsOf[s];
            for (size_t p : r.objs) { i32 v; memcpy(&v, &d[p], 4); i32 nv = mapRef(v); memcpy(&d[p], &nv, 4); }
            for (size_t p : r.names) { i32 v; memcpy(&v, &d[p], 4); if (v < 0 || v >= (i32)S.names.size()) throw Err("bad name index"); i32 nv = D.addName(S.names[v].first); memcpy(&d[p], &nv, 4); }
            i32 base = replaceInto.count(s) ? de.serialOffset : se.serialOffset;
            Package::fixInlineBulk(d, se.serialOffset, base);                                 // inline bulk relative to the target export
            de.cls = mapRef(se.cls); de.super_ = mapRef(se.super_); de.archetype = mapRef(se.archetype);
            if (!targetFor.count(s)) { de.outer = mapRef(se.outer); de.name.idx = D.addName(S.names[se.name.idx].first); de.name.num = se.name.num; }   // "replace with": the target keeps its name and place
            if (replaceInto.count(s)) rep.replaced++;
            de.serialOffset = base; de.data = std::move(d); de.owned = true;
        }
        for (i32 r : roots) rep.roots.push_back(mapExp[r]);
        // --- check: every reference points to the SAME path it pointed to in the source
        for (i32 s : toCopy) {
            i32 di = mapExp[s]; Refs r2; std::string err;
            if (!analyzeExport(D, db, di, r2, err)) { rep.problems.push_back(D.objPath(di) + ": " + err); continue; }
            const Refs& r = refsOf[s]; if (r.objs != r2.objs || r.names != r2.names) { rep.problems.push_back(D.objPath(di) + ": layout changed after copy"); continue; }
            const u8* a = S.dataPtr(S.exports[s - 1]); const u8* b = D.dataPtr(D.exports[di - 1]);
            for (size_t p : r.objs) { i32 x, y; memcpy(&x, a + p, 4); memcpy(&y, b + p, 4); std::string want = x > 0 ? dPath(x) : S.objPath(x); if (!Package::strcasecmp_(want, D.objPath(y))) { rep.problems.push_back(D.objPath(di) + ": reference " + want + " -> " + D.objPath(y)); break; } }
            for (size_t p : r.names) { i32 x, y; memcpy(&x, a + p, 4); memcpy(&y, b + p, 4); if (S.names[x].first != D.names[y].first) { rep.problems.push_back(D.objPath(di) + ": name mismatch"); break; } }
        }
        rep.newImports = (int)(D.imports.size() - imports0); rep.newNames = (int)(D.names.size() - names0);
        rep.ok = rep.problems.empty();
        if (!rep.ok) { rep.err = std::to_string(rep.problems.size()) + " problem(s) after copy: " + rep.problems[0]; rollback(); }
    } catch (std::exception& e) { rep.err = e.what(); rollback(); }
    if (!rep.ok) { rep.copied = rep.replaced = rep.newImports = rep.newNames = 0; rep.roots.clear(); }
    return rep;
}

}} // namespace bm::cp
