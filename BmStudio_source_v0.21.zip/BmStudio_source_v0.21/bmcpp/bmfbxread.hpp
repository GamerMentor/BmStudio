// bmfbxread.hpp - BINARY FBX reader (7.x; Blender/Maya/3ds Max/our exporter): meshes, skin (clusters),
// skeleton (LimbNodes), materials. Compressed arrays (zlib) via miniz.
#pragma once
#include "bmpkg.hpp"
#include <map>
#include <cmath>
#include <functional>

extern "C" {
typedef unsigned long mz_ulong;
int mz_uncompress(unsigned char* pDest, mz_ulong* pDest_len, const unsigned char* pSource, mz_ulong source_len);
}

namespace bm {
namespace fbxr {

struct Prop { char t = 0; int64_t i = 0; double d = 0; std::string s; std::vector<double> ad; std::vector<int64_t> ai; };
struct Node { std::string name; std::vector<Prop> props; std::vector<Node> kids;
    const Node* child(const std::string& n) const { for (auto& k : kids) if (k.name == n) return &k; return nullptr; }
    std::vector<const Node*> children(const std::string& n) const { std::vector<const Node*> v; for (auto& k : kids) if (k.name == n) v.push_back(&k); return v; }
};

class Parser {
public:
    const u8* d; size_t n; u32 version = 0; bool wide = false;
    Parser(const u8* data, size_t len) : d(data), n(len) {}
    void need(size_t p, size_t k) { if (p + k > n) throw Err("FBX truncated"); }
    template <class T> T rd(size_t& p) { need(p, sizeof(T)); T v; memcpy(&v, d + p, sizeof(T)); p += sizeof(T); return v; }
    std::vector<u8> arrayData(size_t& p, u32 count, u32 elem) {
        u32 enc = rd<u32>(p), clen = rd<u32>(p); need(p, clen); std::vector<u8> out((size_t)count * elem);
        if (enc == 0) { if (clen < out.size()) throw Err("bad FBX array"); memcpy(out.data(), d + p, out.size()); }
        else if (enc == 1) { mz_ulong ol = (mz_ulong)out.size(); if (mz_uncompress(out.data(), &ol, d + p, clen) != 0 || ol != out.size()) throw Err("FBX zlib error"); }
        else throw Err("unknown FBX array encoding");
        p += clen; return out;
    }
    Prop prop(size_t& p) {
        Prop pr; pr.t = (char)rd<u8>(p);
        switch (pr.t) {
            case 'Y': pr.i = rd<int16_t>(p); break; case 'C': pr.i = rd<u8>(p); break; case 'I': pr.i = rd<int32_t>(p); break; case 'L': pr.i = rd<int64_t>(p); break;
            case 'F': pr.d = rd<float>(p); break; case 'D': pr.d = rd<double>(p); break;
            case 'S': case 'R': { u32 l = rd<u32>(p); need(p, l); pr.s.assign((const char*)d + p, l); p += l; break; }
            case 'f': { u32 c = rd<u32>(p); auto b = arrayData(p, c, 4); pr.ad.resize(c); for (u32 k = 0; k < c; k++) { float f; memcpy(&f, &b[k * 4], 4); pr.ad[k] = f; } break; }
            case 'd': { u32 c = rd<u32>(p); auto b = arrayData(p, c, 8); pr.ad.resize(c); memcpy(pr.ad.data(), b.data(), b.size()); break; }
            case 'i': { u32 c = rd<u32>(p); auto b = arrayData(p, c, 4); pr.ai.resize(c); for (u32 k = 0; k < c; k++) { int32_t v; memcpy(&v, &b[k * 4], 4); pr.ai[k] = v; } break; }
            case 'l': { u32 c = rd<u32>(p); auto b = arrayData(p, c, 8); pr.ai.resize(c); memcpy(pr.ai.data(), b.data(), b.size()); break; }
            case 'b': { u32 c = rd<u32>(p); auto b = arrayData(p, c, 1); pr.ai.resize(c); for (u32 k = 0; k < c; k++) pr.ai[k] = b[k]; break; }
            default: throw Err(std::string("unknown FBX property type ") + pr.t);
        }
        return pr;
    }
    bool node(size_t& p, Node& out) {
        uint64_t end, np, plen; if (wide) { end = rd<uint64_t>(p); np = rd<uint64_t>(p); plen = rd<uint64_t>(p); } else { end = rd<u32>(p); np = rd<u32>(p); plen = rd<u32>(p); }
        u8 nl = rd<u8>(p); if (end == 0) return false;
        need(p, nl); out.name.assign((const char*)d + p, nl); p += nl;
        size_t ps = p; for (uint64_t k = 0; k < np; k++) out.props.push_back(prop(p)); if (p != ps + plen) p = ps + (size_t)plen;
        while (p < end) { Node c; size_t save = p; if (!node(p, c)) break; (void)save; out.kids.push_back(std::move(c)); }
        p = (size_t)end; return true;
    }
    std::vector<Node> parse() {
        if (n < 27 || memcmp(d, "Kaydara FBX Binary", 18) != 0) throw Err("not a binary FBX (ASCII FBX is not supported: export as binary)");
        memcpy(&version, d + 23, 4); wide = version >= 7500; size_t p = 27; std::vector<Node> top;
        while (p < n) { Node nd; if (!node(p, nd)) break; top.push_back(std::move(nd)); }
        return top;
    }
};

inline std::string baseName(const std::string& s) { size_t z = s.find('\0'); std::string r = z == std::string::npos ? s : s.substr(0, z); size_t c = r.find("::"); if (c != std::string::npos) r = r.substr(c + 2); return r; }

// ------------------------------------------------------------------ scene
struct M { double m[4][4]; };   // column (p' = M p)
inline M mident() { M r = {}; for (int i = 0; i < 4; i++) r.m[i][i] = 1; return r; }
inline M mmul(const M& a, const M& b) { M r; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) { r.m[i][j] = 0; for (int k = 0; k < 4; k++) r.m[i][j] += a.m[i][k] * b.m[k][j]; } return r; }
inline M fromArr(const std::vector<double>& a) { M r = mident(); if (a.size() >= 16) for (int c = 0; c < 4; c++) for (int rr = 0; rr < 4; rr++) r.m[rr][c] = a[c * 4 + rr]; return r; }
inline void apply(const M& m, const double v[3], double o[3]) { for (int i = 0; i < 3; i++) o[i] = m.m[i][0] * v[0] + m.m[i][1] * v[1] + m.m[i][2] * v[2] + m.m[i][3]; }
inline M euler(double x, double y, double z) {   // XYZ: R = Rz*Ry*Rx (degrees)
    const double k = 3.14159265358979 / 180; double cx = cos(x * k), sx = sin(x * k), cy = cos(y * k), sy = sin(y * k), cz = cos(z * k), sz = sin(z * k);
    M rx = mident(), ry = mident(), rz = mident(); rx.m[1][1] = cx; rx.m[1][2] = -sx; rx.m[2][1] = sx; rx.m[2][2] = cx; ry.m[0][0] = cy; ry.m[0][2] = sy; ry.m[2][0] = -sy; ry.m[2][2] = cy;
    rz.m[0][0] = cz; rz.m[0][1] = -sz; rz.m[1][0] = sz; rz.m[1][1] = cz; return mmul(rz, mmul(ry, rx));
}

struct Model { int64_t id = 0; std::string name, type; int64_t parent = 0; double t[3] = { 0, 0, 0 }, r[3] = { 0, 0, 0 }, s[3] = { 1, 1, 1 }, pre[3] = { 0, 0, 0 }, post[3] = { 0, 0, 0 }; };
struct Cluster { int64_t id = 0, bone = 0; std::vector<int64_t> idx; std::vector<double> w; M transform = mident(), link = mident(); bool hasLink = false; };
struct MeshGeo {
    int64_t id = 0, model = 0; std::string name;
    std::vector<double> verts; std::vector<int64_t> pvi;
    std::vector<double> normals; std::vector<int64_t> normalIdx; std::string normalMap, normalRef;
    std::vector<double> uvs; std::vector<int64_t> uvIdx; std::string uvMap, uvRef;
    std::vector<int64_t> mats; std::string matMap;
    std::vector<Cluster> clusters; std::vector<std::string> materialNames;
};
struct Scene { std::vector<MeshGeo> meshes; std::map<int64_t, Model> models; std::string err; double unitScale = 1; int upAxis = 1; };

inline void readP70(const Node* p70, Model& m) {
    if (!p70) return;
    for (auto* p : p70->children("P")) { if (p->props.size() < 5) continue; const std::string& nm = p->props[0].s;
        auto v3 = [&](double* o) { for (int k = 0; k < 3 && 4 + k < (int)p->props.size(); k++) o[k] = p->props[4 + k].d; };
        if (nm == "Lcl Translation") v3(m.t); else if (nm == "Lcl Rotation") v3(m.r); else if (nm == "Lcl Scaling") v3(m.s); else if (nm == "PreRotation") v3(m.pre); else if (nm == "PostRotation") v3(m.post); }
}
inline M modelLocal(const Model& m) {
    M t = mident(); for (int i = 0; i < 3; i++) t.m[i][3] = m.t[i]; M s = mident(); for (int i = 0; i < 3; i++) s.m[i][i] = m.s[i];
    M post = euler(m.post[0], m.post[1], m.post[2]); M postInv = mident(); for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) postInv.m[i][j] = post.m[j][i];
    return mmul(t, mmul(euler(m.pre[0], m.pre[1], m.pre[2]), mmul(euler(m.r[0], m.r[1], m.r[2]), mmul(postInv, s))));
}
inline M modelGlobal(const Scene& sc, int64_t id, int depth = 0) {
    auto it = sc.models.find(id); if (it == sc.models.end() || depth > 64) return mident();
    M l = modelLocal(it->second); return it->second.parent ? mmul(modelGlobal(sc, it->second.parent, depth + 1), l) : l;
}

inline Scene readScene(const std::vector<u8>& file) {
    Scene sc;
    try {
        Parser ps(file.data(), file.size()); std::vector<Node> top = ps.parse();
        const Node* objects = nullptr; const Node* conns = nullptr;
        for (auto& t : top) { if (t.name == "Objects") objects = &t; else if (t.name == "Connections") conns = &t;
            else if (t.name == "GlobalSettings") { if (auto* p70 = t.child("Properties70")) for (auto* p : p70->children("P")) { if (p->props.size() < 5) continue;
                if (p->props[0].s == "UnitScaleFactor") sc.unitScale = p->props[4].d; if (p->props[0].s == "UpAxis") sc.upAxis = (int)p->props[4].i; } } }
        if (!objects) throw Err("FBX has no Objects");
        std::map<int64_t, const Node*> byId;
        for (auto& o : objects->kids) if (!o.props.empty()) byId[o.props[0].i] = &o;
        // connections: child -> parents
        std::multimap<int64_t, int64_t> parents; std::multimap<int64_t, int64_t> kids;
        if (conns) for (auto& c : conns->kids) { if (c.props.size() < 3) continue; parents.insert({ c.props[1].i, c.props[2].i }); kids.insert({ c.props[2].i, c.props[1].i }); }
        auto isA = [&](int64_t id, const char* nodeName) { auto it = byId.find(id); return it != byId.end() && it->second->name == nodeName; };
        // models
        for (auto& kv : byId) if (kv.second->name == "Model") { Model m; m.id = kv.first; m.name = baseName(kv.second->props.size() > 1 ? kv.second->props[1].s : ""); m.type = kv.second->props.size() > 2 ? kv.second->props[2].s : "";
            readP70(kv.second->child("Properties70"), m); auto r = parents.equal_range(kv.first); for (auto it = r.first; it != r.second; ++it) if (isA(it->second, "Model")) m.parent = it->second; sc.models[m.id] = m; }
        // geometries
        for (auto& kv : byId) {
            const Node* g = kv.second; if (g->name != "Geometry" || g->props.size() < 3 || g->props[2].s != "Mesh") continue;
            MeshGeo mg; mg.id = kv.first;
            if (auto* v = g->child("Vertices")) if (!v->props.empty()) mg.verts = v->props[0].ad;
            if (auto* v = g->child("PolygonVertexIndex")) if (!v->props.empty()) mg.pvi = v->props[0].ai;
            if (auto* l = g->child("LayerElementNormal")) { if (auto* x = l->child("Normals")) mg.normals = x->props[0].ad; if (auto* x = l->child("NormalsIndex")) mg.normalIdx = x->props[0].ai;
                if (auto* x = l->child("MappingInformationType")) mg.normalMap = x->props[0].s; if (auto* x = l->child("ReferenceInformationType")) mg.normalRef = x->props[0].s; }
            if (auto* l = g->child("LayerElementUV")) { if (auto* x = l->child("UV")) mg.uvs = x->props[0].ad; if (auto* x = l->child("UVIndex")) mg.uvIdx = x->props[0].ai;
                if (auto* x = l->child("MappingInformationType")) mg.uvMap = x->props[0].s; if (auto* x = l->child("ReferenceInformationType")) mg.uvRef = x->props[0].s; }
            if (auto* l = g->child("LayerElementMaterial")) { if (auto* x = l->child("Materials")) mg.mats = x->props[0].ai; if (auto* x = l->child("MappingInformationType")) mg.matMap = x->props[0].s; }
            auto r = parents.equal_range(kv.first); for (auto it = r.first; it != r.second; ++it) if (isA(it->second, "Model")) mg.model = it->second;
            if (mg.model && sc.models.count(mg.model)) mg.name = sc.models[mg.model].name;
            // model materials, in connection order
            if (mg.model && conns) for (auto& c : conns->kids) if (c.props.size() >= 3 && c.props[2].i == mg.model && isA(c.props[1].i, "Material")) mg.materialNames.push_back(baseName(byId[c.props[1].i]->props[1].s));
            // skin -> clusters
            auto kr = kids.equal_range(kv.first);
            for (auto it = kr.first; it != kr.second; ++it) { auto sk = byId.find(it->second); if (sk == byId.end() || sk->second->name != "Deformer" || sk->second->props.size() < 3 || sk->second->props[2].s != "Skin") continue;
                auto cr = kids.equal_range(it->second);
                for (auto ct = cr.first; ct != cr.second; ++ct) { auto cn = byId.find(ct->second); if (cn == byId.end() || cn->second->name != "Deformer") continue; const Node* c = cn->second;
                    Cluster cl; cl.id = ct->second;
                    if (auto* x = c->child("Indexes")) cl.idx = x->props[0].ai; if (auto* x = c->child("Weights")) cl.w = x->props[0].ad;
                    if (auto* x = c->child("Transform")) cl.transform = fromArr(x->props[0].ad); if (auto* x = c->child("TransformLink")) { cl.link = fromArr(x->props[0].ad); cl.hasLink = true; }
                    auto br = kids.equal_range(ct->second); for (auto bt = br.first; bt != br.second; ++bt) if (isA(bt->second, "Model")) cl.bone = bt->second;
                    if (cl.bone) mg.clusters.push_back(cl); } }
            if (mg.verts.empty() || mg.pvi.empty()) continue;
            sc.meshes.push_back(std::move(mg));
        }
        if (sc.meshes.empty()) throw Err("no mesh found in the FBX");
    } catch (std::exception& e) { sc.err = e.what(); }
    return sc;
}

} // namespace fbxr
} // namespace bm
