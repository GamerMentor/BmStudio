// bmroomimp.hpp - "Import level": brings a whole room (main package + _Static/_Lights/_Fx/... sub-levels) from a
// map (e.g. a DLC challenge) into a game map, as part of the streaming group of an existing room.
// Generalization of admin_d1 (restored Admin room, tested in game on 2026-10-03).
//
//   - the packages are renamed: <Anchor>_<Suffix>[_Static|_Lights...]; inside them the room name becomes <Anchor>
//     (the game loads the parts of a room by name prefix: a room with a new name would never be requested)
//   - everything is translated by Delta: actors (Location), collection matrices (meshes/lights), BSP (points, planes,
//     vertex buffer and LeafHulls collision boxes); volumes are clipped to the room box (the ones from challenge maps
//     usually cover the whole map)
//   - marked actors leave the ULevel list; marked Kismet events get bEnabled=false
//   - target map: one LevelStreamingKismet per new package (copy of the anchor one) + WorldInfo.StreamingLevels
//   - GuidCache.upk: entries for the new packages
#pragma once
#include "bmbspedit.hpp"
#include "bmbetafix.hpp"
#include <cstdio>
#include <cstdarg>
#include <functional>
#include <map>
#include <set>
#include <memory>

namespace bm { namespace rimp {

struct Box { float mn[3], mx[3]; };
struct IO {
    std::function<bool(const std::string&, std::vector<u8>&)> read = [](const std::string& p, std::vector<u8>& out) {
        FILE* f = fopen(p.c_str(), "rb"); if (!f) return false; fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); out.resize((size_t)n);
        bool ok = n == 0 || fread(out.data(), 1, (size_t)n, f) == (size_t)n; fclose(f); return ok; };
    std::function<bool(const std::string&, const std::vector<u8>&)> write = [](const std::string& p, const std::vector<u8>& d) {
        FILE* f = fopen(p.c_str(), "wb"); if (!f) return false; bool ok = d.empty() || fwrite(d.data(), 1, d.size(), f) == d.size(); fclose(f); return ok; };
};
struct Log {
    std::vector<std::string> lines; std::function<void(const std::string&)> sink;
    void operator()(const char* f, ...) { char b[1024]; va_list a; va_start(a, f); vsnprintf(b, sizeof b, f, a); va_end(a); lines.push_back(b); if (sink) sink(b); }
};

// candidate for removal / disabling, listed for the user
struct Candidate {
    std::string pkg;        // source package name (e.g. CombatDLC1_C1)
    std::string path;       // object path (TheWorld.PersistentLevel....)
    std::string cls;
    int kind = 0;           // 0 actor (leaves the ULevel list), 1 Kismet event (bEnabled=false)
    bool def = false;       // checked by default
    std::string why;        // reason for the suggestion
    float loc[3] = { 0, 0, 0 }; bool hasLoc = false;
};

struct Spec {
    std::string srcDir;                     // folder of the source packages (with a trailing slash)
    std::string srcBase;                    // source room (e.g. CombatDLC1_C1)
    std::vector<std::string> srcPkgs;       // srcBase and the srcBase_* that go along
    std::string targetMap;                  // file of the target persistent map (e.g. ...\Maps\Admin\Admin.umap)
    std::string anchor;                     // room of the target that "pulls in" the new one (e.g. Admin_C8)
    std::string newBase;                    // name of the new files (e.g. Admin_C8_D1)
    float delta[3] = { 0, 0, 0 };
    int yaw90 = 0;                          // rotation in 90-degree steps (0..3, UE Yaw direction) around 'pivot' (source), before the Delta
    float pivot[3] = { 0, 0, 0 };
    bool clip = true; Box room{};           // room box in SOURCE coordinates (before the Delta)
    std::set<std::string> remove;           // "pkg|path" of actors to remove
    std::set<std::string> disable;          // "pkg|path" of events to disable
    std::string guidCache;                  // input GuidCache.upk ("" = leave alone)
    std::string outDir;                     // output folder (with a trailing slash)
};
struct OutFile { std::string file; std::string installAs; };   // generated file -> where it goes in the game (relative to CookedPC)

// ------------------------------------------------------------------ utilities
inline std::string fileBase(const std::string& p) { size_t s = p.find_last_of("\\/"); std::string f = s == std::string::npos ? p : p.substr(s + 1); size_t d = f.rfind('.'); return d == std::string::npos ? f : f.substr(0, d); }
inline std::string fileDir(const std::string& p) { size_t s = p.find_last_of("\\/"); return s == std::string::npos ? "" : p.substr(0, s + 1); }
inline std::string lower(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }
inline std::string outName(const Spec& S, const std::string& pkg) { return pkg == S.srcBase ? S.newBase : S.newBase + pkg.substr(S.srcBase.size()); }

inline void loadPkg(const IO& io, const std::string& path, Package& P) { std::vector<u8> b; if (!io.read(path, b)) throw Err("could not read " + path); P.loadBytes(std::move(b)); }
inline void savePkg(const IO& io, const std::string& path, const Package& P, Log& log) {
    auto bytes = P.saveToMemory(); if (!io.write(path, bytes)) throw Err("could not write " + path);
    Package Q; Q.loadBytes(std::vector<u8>(bytes)); log("    saved %s (%.1f MB), reloaded: %zu exports", fileBase(path).c_str(), bytes.size() / 1048576.0, Q.exports.size()); }

inline void writeBack(Package& P, i32 idx, const std::vector<Tag>& tags) {
    ObjProps op = objProps(P, idx); long st = findPropStart(P, idx); Export& e = P.exports[idx - 1]; const u8* d = P.dataPtr(e);
    std::vector<u8> nd(d, d + st); auto pb = writeProps(P, tags); nd.insert(nd.end(), pb.begin(), pb.end()); nd.insert(nd.end(), d + op.end, d + P.dataLen(e));
    e.data = nd; e.owned = true; }
inline Tag nameTag(Package& P, const std::string& n, const std::string& v) { Tag t; t.name = n; t.type = "NameProperty"; i32 a = P.addName(v), z = 0; t.raw.resize(8); memcpy(t.raw.data(), &a, 4); memcpy(t.raw.data() + 4, &z, 4); return t; }
inline Tag vecTag(const std::string& n, const float v[3]) { Tag t; t.name = n; t.type = "StructProperty"; t.strct = "Vector"; t.raw.resize(12); memcpy(t.raw.data(), v, 12); return t; }
inline Tag boolTag(const std::string& n, bool v) { Tag t; t.name = n; t.type = "BoolProperty"; t.isBool = true; t.boolVal = v; return t; }
inline void setT(std::vector<Tag>& tg, const Tag& nt, const char* before = "Location") {
    for (auto& t : tg) if (t.name == nt.name && t.index == nt.index) { t = nt; return; }
    for (size_t i = 0; i < tg.size(); i++) if (tg[i].name == before) { tg.insert(tg.begin() + i, nt); return; }
    tg.push_back(nt); }
inline void delT(std::vector<Tag>& tg, const std::string& n) { for (size_t i = 0; i < tg.size();) if (tg[i].name == n) tg.erase(tg.begin() + i); else i++; }
inline i32 need(Package& P, const std::string& p) { i32 i = P.findPath(p); if (i <= 0) throw Err("not found: " + p); return i; }
inline void ownData(Package& P, i32 idx) { Export& e = P.exports[idx - 1]; if (!e.owned) { e.data.assign(P.dataPtr(e), P.dataPtr(e) + P.dataLen(e)); e.owned = true; } }

// ULevel actor list (props, Owner, TArray)
struct ActorList { i32 level = 0; size_t at = 0; i32 count = 0; };
inline ActorList actorList(Package& P) { ActorList A; A.level = need(P, "TheWorld.PersistentLevel"); ObjProps op = objProps(P, A.level); A.at = op.end + 4; memcpy(&A.count, P.dataPtr(P.exports[A.level - 1]) + A.at, 4); return A; }
inline i32 actorAt(Package& P, const ActorList& A, i32 i) { i32 r; memcpy(&r, P.dataPtr(P.exports[A.level - 1]) + A.at + 4 + 4 * (size_t)i, 4); return r; }
inline void setActorAt(Package& P, const ActorList& A, i32 i, i32 v) { ownData(P, A.level); memcpy(P.exports[A.level - 1].data.data() + A.at + 4 + 4 * (size_t)i, &v, 4); }

// ------------------------------------------------------------------ transform: p' = Rz(q*90)(p - c) + c + d
// Rotation in multiples of 90 degrees: exact in float, and axis-aligned boxes stay aligned (BSP collision).
struct Xf { int q = 0; float c[3] = { 0, 0, 0 }, d[3] = { 0, 0, 0 };
    void rotv(float* v) const { float x = v[0], y = v[1]; switch (q & 3) { case 1: v[0] = -y; v[1] = x; break; case 2: v[0] = -x; v[1] = -y; break; case 3: v[0] = y; v[1] = -x; break; default: break; } }
    void pt(float* p) const { float t[3] = { p[0] - c[0], p[1] - c[1], p[2] - c[2] }; rotv(t); for (int k = 0; k < 3; k++) p[k] = t[k] + c[k] + d[k]; }
    // packed normal vector (FPackedNormal: byte b -> b/127.5 - 1; -v -> 255 - b)
    void packed(u8* n) const { u8 x = n[0], y = n[1]; switch (q & 3) { case 1: n[0] = (u8)(255 - y); n[1] = x; break; case 2: n[0] = (u8)(255 - x); n[1] = (u8)(255 - y); break; case 3: n[0] = y; n[1] = (u8)(255 - x); break; default: break; } }
    // plane n.p = w  ->  n' = R n, w' = n'.(p0') with p0 = n*w
    void plane(float* pl) const { float p0[3] = { pl[0] * pl[3], pl[1] * pl[3], pl[2] * pl[3] }; rotv(pl); pt(p0); pl[3] = pl[0] * p0[0] + pl[1] * p0[1] + pl[2] * p0[2]; }
    void box(float* mn, float* mx) const { float a[3] = { mn[0], mn[1], mn[2] }, b[3] = { mx[0], mx[1], mx[2] }; pt(a); pt(b); for (int k = 0; k < 3; k++) { mn[k] = std::min(a[k], b[k]); mx[k] = std::max(a[k], b[k]); } }
};

// ------------------------------------------------------------------ BSP
inline float modelPlaneError(const u8* b, const ModelLayout& L) {
    float worst = 0; for (i32 i = 0; i < L.nNodes; i++) { BspNodeV n = readNode(b, L, i); if (n.iVertexIndex < 0 || n.iVertexIndex + n.nv > L.vbn) continue; for (int k = 0; k < n.nv; k++) { const float* p = (const float*)(b + L.vbAt + (size_t)L.vbes * (n.iVertexIndex + k));
        worst = std::max(worst, fabsf(p[0] * n.plane[0] + p[1] * n.plane[1] + p[2] * n.plane[2] - n.plane[3])); } }
    return worst; }
inline void transformModel(Package& P, i32 m, const Xf& X, Log& log) {
    ModelLayout L = modelLayout(P, m); if (!L.ok) throw Err("BSP " + P.objPath(m) + ": " + L.err);
    float worst0 = modelPlaneError(P.dataPtr(P.exports[m - 1]), L);   // the beta already comes with some slack between plane and vertex
    ownData(P, m); u8* b = P.exports[m - 1].data.data();
    float bo[7]; memcpy(bo, b + L.boundsAt, 28); if (bo[3] != 0 || bo[4] != 0 || bo[5] != 0) { X.pt(bo); if (X.q & 1) std::swap(bo[3], bo[4]); memcpy(b + L.boundsAt, bo, 24); }
    for (i32 i = 0; i < L.nVec; i++) X.rotv((float*)(b + L.vecAt + 12 * (size_t)i));
    for (i32 i = 0; i < L.nPt; i++) X.pt((float*)(b + L.ptAt + 12 * (size_t)i));
    for (i32 i = 0; i < L.nNodes; i++) X.plane((float*)(b + L.nodesAt + 64 * (size_t)i));
    for (i32 i = 0; i < L.nSurfs; i++) X.plane((float*)(b + L.surfsAt + 56 * (size_t)i + 32));
    for (i32 i = 0; i < L.vbn; i++) { u8* v = b + L.vbAt + (size_t)L.vbes * i; X.pt((float*)v); if (L.vbes >= 20) { X.packed(v + 12); X.packed(v + 16); } }
    int hulls = 0; { i32* h = (i32*)(b + L.hullsAt); i32 i = 0;
        while (i < L.nHulls) { while (i < L.nHulls && h[i] != -1) i++; i++; if (i + 6 > L.nHulls) throw Err("LeafHulls: incomplete box");
            float* bx = (float*)(h + i); for (int k = 0; k < 3; k++) if (!(bx[k] <= bx[3 + k])) throw Err("LeafHulls: invalid box"); X.box(bx, bx + 3); i += 6; hulls++; } }
    float worst = modelPlaneError(b, L);
    if (worst > worst0 + 0.05f) throw Err("BSP: plane/vertex mismatch after moving (" + std::to_string(worst) + ")");
    log("    BSP %s: %d points, %d vectors, %d nodes, %d surfaces, %d vertices, %d collision boxes (plane error %.4f)", P.objName(m).c_str(), L.nPt, L.nVec, L.nNodes, L.nSurfs, L.vbn, hulls, worst);
}
inline void translateModel(Package& P, i32 m, const float d[3], Log& log) {
    ModelLayout L = modelLayout(P, m); if (!L.ok) throw Err("BSP " + P.objPath(m) + ": " + L.err);
    float worst0 = modelPlaneError(P.dataPtr(P.exports[m - 1]), L);   // the beta already comes with some slack between plane and vertex
    ownData(P, m); u8* b = P.exports[m - 1].data.data();
    float bo[7]; memcpy(bo, b + L.boundsAt, 28); if (bo[3] != 0 || bo[4] != 0 || bo[5] != 0) { for (int k = 0; k < 3; k++) bo[k] += d[k]; memcpy(b + L.boundsAt, bo, 12); }
    for (i32 i = 0; i < L.nPt; i++) { float* p = (float*)(b + L.ptAt + 12 * (size_t)i); for (int k = 0; k < 3; k++) p[k] += d[k]; }
    for (i32 i = 0; i < L.nNodes; i++) { float* pl = (float*)(b + L.nodesAt + 64 * (size_t)i); pl[3] += pl[0] * d[0] + pl[1] * d[1] + pl[2] * d[2]; }
    for (i32 i = 0; i < L.nSurfs; i++) { float* pl = (float*)(b + L.surfsAt + 56 * (size_t)i + 32); pl[3] += pl[0] * d[0] + pl[1] * d[1] + pl[2] * d[2]; }
    for (i32 i = 0; i < L.vbn; i++) { float* p = (float*)(b + L.vbAt + (size_t)L.vbes * i); for (int k = 0; k < 3; k++) p[k] += d[k]; }
    int hulls = 0; { i32* h = (i32*)(b + L.hullsAt); i32 i = 0;
        while (i < L.nHulls) { while (i < L.nHulls && h[i] != -1) i++; i++; if (i + 6 > L.nHulls) throw Err("LeafHulls: incomplete box");
            float* bx = (float*)(h + i); for (int k = 0; k < 3; k++) { if (!(bx[k] <= bx[3 + k])) throw Err("LeafHulls: invalid box"); bx[k] += d[k]; bx[3 + k] += d[k]; } i += 6; hulls++; } }
    float worst = modelPlaneError(b, L);
    if (worst > worst0 + 0.05f) throw Err("BSP: plane/vertex mismatch after moving (" + std::to_string(worst) + ")");
    log("    BSP %s: %d points, %d nodes, %d surfaces, %d vertices, %d collision boxes moved (plane error %.4f)", P.objName(m).c_str(), L.nPt, L.nNodes, L.nSurfs, L.vbn, hulls, worst);
}

// volume (brush): bounds in the world and in local space
inline bool brushBox(Package& P, const std::vector<Tag>& tags, Box& out, Box& local) {
    const Tag* b = findTag(tags, "Brush"); if (!b) return false; i32 m = tagObj(*b); if (m <= 0) return false;
    ModelLayout L = modelLayout(P, m); if (!L.ok || L.nPt == 0) return false; const u8* d = P.dataPtr(P.exports[m - 1]); M4 W = actorMatrix(tags);
    for (int k = 0; k < 3; k++) { out.mn[k] = local.mn[k] = 1e30f; out.mx[k] = local.mx[k] = -1e30f; }
    for (i32 i = 0; i < L.nPt; i++) { float q[3]; memcpy(q, d + L.ptAt + 12 * (size_t)i, 12); for (int k = 0; k < 3; k++) { local.mn[k] = std::min(local.mn[k], q[k]); local.mx[k] = std::max(local.mx[k], q[k]); }
        for (int j = 0; j < 3; j++) { float w = q[0] * W.m[0][j] + q[1] * W.m[1][j] + q[2] * W.m[2][j] + W.m[3][j]; out.mn[j] = std::min(out.mn[j], w); out.mx[j] = std::max(out.mx[j], w); } }
    return true; }

// ------------------------------------------------------------------ discovery
// packages that make up the room: base + base_* in the same folder (file names)
inline std::vector<std::string> roomPackages(const std::string& base, const std::vector<std::string>& filesInDir) {
    std::vector<std::string> out; std::string lb = lower(base);
    for (auto& f : filesInDir) { std::string n = fileBase(f), ln = lower(n); if (ln == lb) out.insert(out.begin(), n);
        else if (ln.size() > lb.size() + 1 && ln.compare(0, lb.size() + 1, lb + "_") == 0 && ln.find('_', lb.size() + 1) == std::string::npos) out.push_back(n); }
    return out;
}
// room box (source coordinates): BSP of every package; with no BSP, mesh positions
inline bool autoRoomBox(const std::vector<const Package*>& pkgs, Box& b, float pad = 32) {
    for (int k = 0; k < 3; k++) { b.mn[k] = 1e30f; b.mx[k] = -1e30f; } bool any = false;
    for (auto* P : pkgs) for (i32 m : levelModels(*P)) { ModelLayout L = modelLayout(*P, m); if (!L.ok) continue; const u8* d = P->dataPtr(P->exports[m - 1]);
        for (i32 i = 0; i < L.vbn; i++) { const float* p = (const float*)(d + L.vbAt + (size_t)L.vbes * i); for (int k = 0; k < 3; k++) { b.mn[k] = std::min(b.mn[k], p[k]); b.mx[k] = std::max(b.mx[k], p[k]); } any = true; } }
    if (!any) for (auto* P : pkgs) { Level LV = parseLevel(*P); for (auto& m : LV.meshes) { for (int k = 0; k < 3; k++) { b.mn[k] = std::min(b.mn[k], m.world.m[3][k]); b.mx[k] = std::max(b.mx[k], m.world.m[3][k]); } any = true; } }
    if (any) for (int k = 0; k < 3; k++) { b.mn[k] -= pad; b.mx[k] += pad; }
    return any;
}
// Kismet actions reached from an event (follows OutputLinks.LinkedOp inside the same sequence)
inline void kismetReach(const Package& P, i32 e, std::set<std::string>& acts, int depth = 0, std::set<i32>* seenp = nullptr) {
    std::set<i32> local; std::set<i32>& seen = seenp ? *seenp : local; if (depth > 8 || seen.count(e)) return; seen.insert(e);
    ObjProps op = objProps(P, e); if (!op.ok) return; const Tag* ol = findTag(op.tags, "OutputLinks"); if (!ol) return; i32 seq = P.exports[e - 1].outer;
    for (size_t k = 0; k + 4 <= ol->raw.size(); k++) { i32 v; memcpy(&v, ol->raw.data() + k, 4); if (v <= 0 || v > (i32)P.exports.size() || v == e || P.exports[v - 1].outer != seq) continue;
        std::string c = P.classOf(P.exports[v - 1]); if (c.rfind("SeqVar", 0) == 0) continue; acts.insert(c); kismetReach(P, v, acts, depth + 1, &seen); }
}
inline bool challengeAction(const std::string& c) {
    for (const char* k : { "Challenge", "Teleport", "Possess", "WaveController", "PawnSpawner", "CombatSpawner", "ForceCombatCamera", "SetDifficulty", "CinematicMode" }) if (c.find(k) != std::string::npos) return true;
    return false;
}
// actors and events that usually get in the way of a challenge room outside challenge mode
inline void listCandidates(const Package& Pc, const std::string& pkg, std::vector<Candidate>& out) {
    Package& P = const_cast<Package&>(Pc); i32 lvl = P.findPath("TheWorld.PersistentLevel"); if (lvl <= 0) return;
    ActorList A = actorList(P);
    for (i32 i = 0; i < A.count; i++) { i32 a = actorAt(P, A, i); if (a <= 0) continue; std::string cls = P.classOf(P.exports[a - 1]);
        if (cls == "WorldInfo" || cls == "StaticMeshCollectionActor" || cls == "StaticLightCollectionActor" || cls == "StaticMeshActor" || cls == "Note") continue;
        Candidate c; c.pkg = pkg; c.path = P.objPath(a); c.cls = cls; c.kind = 0;
        if (cls.rfind("RPawnPlayer", 0) == 0) { c.def = true; c.why = "challenge player (the game already has Batman)"; }
        else if (cls == "RLevelTransitionDoor") { c.def = true; c.why = "challenge transition door"; }
        else if (cls == "RDisruptableLaserGrid") { c.def = true; c.why = "challenge electric grid"; }
        else if (cls.find("PlayerStart") != std::string::npos) { c.why = "challenge spawn point"; }
        ObjProps op = objProps(P, a); if (op.ok) c.hasLoc = tagVec(op.tags, "Location", c.loc);
        out.push_back(c); }
    for (size_t k = 0; k < P.exports.size(); k++) { std::string cls = P.classOf(P.exports[k]);
        bool lv = cls == "SeqEvent_LevelLoaded", pd = cls == "RSeqEvent_PlayerDied"; if (!lv && !pd) continue;
        if (P.exports[k].flags & 0x600ull) continue;   // CDO/archetype
        Candidate c; c.pkg = pkg; c.path = P.objPath((i32)k + 1); c.cls = cls; c.kind = 1;
        std::vector<std::string> hits; std::set<std::string> acts; kismetReach(P, (i32)k + 1, acts);
        for (auto& a : acts) if (challengeAction(a)) hits.push_back(a);
        c.def = !hits.empty();
        std::string chain; int nshow = 0; for (auto& a : (hits.empty() ? std::vector<std::string>(acts.begin(), acts.end()) : hits)) { if (nshow++ == 4) { chain += ", ..."; break; } chain += (chain.empty() ? "" : ", ") + a; }
        c.why = c.def ? "triggers challenge mode: " + chain : (acts.empty() ? "does not trigger anything" : "ambient (kept): " + chain);
        out.push_back(c); }
}
// rooms (anchor) of a persistent map: streaming names that do not end in _Static/_Lights... (have members with that prefix)
inline std::vector<std::string> streamingNames(const Package& P) {
    std::vector<std::string> out; for (size_t k = 0; k < P.exports.size(); k++) { if (P.classOf(P.exports[k]) != "LevelStreamingKismet") continue;
        ObjProps op = objProps(P, (i32)k + 1); if (!op.ok) continue; std::string n = tagName(P, op.tags, "PackageName"); if (!n.empty() && n != "None") out.push_back(n); }
    return out;
}
inline std::vector<std::string> anchorRooms(const Package& P) {
    std::vector<std::string> names = streamingNames(P), out; std::set<std::string> seen;
    for (auto& n : names) { if (seen.count(lower(n))) continue; bool hasKids = false; for (auto& m : names) if (m.size() > n.size() + 1 && lower(m.substr(0, n.size() + 1)) == lower(n) + "_") hasKids = true;
        if (hasKids) { out.push_back(n); seen.insert(lower(n)); } }
    return out;
}
// next free name: <Anchor>_D1, _D2...
inline std::string freeNewBase(const Package& target, const std::string& anchor, const std::set<std::string>& existingFiles) {
    std::set<std::string> taken; for (auto& n : streamingNames(target)) taken.insert(lower(n)); for (auto& f : existingFiles) taken.insert(lower(f));
    for (int i = 1; i < 100; i++) { std::string c = anchor + "_D" + std::to_string(i); bool clash = false; for (auto& t : taken) if (t == lower(c) || t.rfind(lower(c) + "_", 0) == 0) clash = true; if (!clash) return c; }
    return anchor + "_D99";
}

// ------------------------------------------------------------------ execution
inline void portPackage(const IO& io, const Spec& S, const std::string& pkg, Log& log) {
    Package P; loadPkg(io, S.srcDir + pkg + ".umap", P); std::string on = outName(S, pkg); log("== %s -> %s", pkg.c_str(), on.c_str());
    // names: source room -> anchor; sub-levels -> new ones
    int rn = 0; for (auto& n : P.names) { for (auto& sp : S.srcPkgs) if (n.first == sp) { n.first = sp == S.srcBase ? S.anchor : outName(S, sp); rn++; break; } }
    log("    renamed names: %d", rn);
    std::set<i32> drop; for (auto& r : S.remove) { size_t b = r.find('|'); if (r.substr(0, b) != pkg) continue; i32 a = P.findPath(r.substr(b + 1)); if (a > 0) drop.insert(a); else log("    warning: not found: %s", r.c_str()); }
    Xf X; X.q = S.yaw90 & 3; for (int k = 0; k < 3; k++) { X.c[k] = S.pivot[k]; X.d[k] = S.delta[k]; }
    ActorList A = actorList(P); int moved = 0, mats = 0, clipped = 0, removed = 0;
    for (i32 i = 0; i < A.count; i++) {
        i32 a = actorAt(P, A, i); if (a <= 0) continue; std::string cls = P.classOf(P.exports[a - 1]);
        if (drop.count(a)) { setActorAt(P, A, i, 0); removed++; log("    removed: %s", P.objName(a).c_str()); continue; }
        if (cls == "WorldInfo") continue;
        ObjProps op = objProps(P, a); if (!op.ok) continue;
        if (cls == "StaticMeshCollectionActor" || cls == "StaticLightCollectionActor") {
            const Tag* t = findTag(op.tags, cls == "StaticMeshCollectionActor" ? "StaticMeshComponents" : "LightComponents"); if (!t) continue;
            i32 n; memcpy(&n, t->raw.data(), 4); if (op.end + (size_t)n * 64 > P.dataLen(P.exports[a - 1])) throw Err("collection with matrices of the wrong size: " + P.objName(a));
            ownData(P, a); u8* b = P.exports[a - 1].data.data(); for (i32 k = 0; k < n; k++) { float* m = (float*)(b + op.end + 64 * (size_t)k); X.rotv(m); X.rotv(m + 4); X.rotv(m + 8); X.pt(m + 12); mats++; }
            continue;
        }
        std::vector<Tag> tg = op.tags;
        Box wb, lb; if (S.clip && brushBox(P, tg, wb, lb)) {
            Box c; bool empty = false, changed = false;
            for (int k = 0; k < 3; k++) { c.mn[k] = std::max(wb.mn[k], S.room.mn[k]); c.mx[k] = std::min(wb.mx[k], S.room.mx[k]); if (c.mx[k] <= c.mn[k]) empty = true; if (c.mn[k] != wb.mn[k] || c.mx[k] != wb.mx[k]) changed = true; }
            if (empty) { setActorAt(P, A, i, 0); removed++; log("    removed (outside the room): %s", P.objName(a).c_str()); continue; }
            if (changed) {
                if (findTag(tg, "Rotation") || findTag(tg, "PrePivot")) log("    rotated volume kept whole (only moved): %s", P.objName(a).c_str());
                else { float ds = tagFloat(tg, "DrawScale", 1.f), s3[3], loc[3];
                    for (int k = 0; k < 3; k++) { float le = lb.mx[k] - lb.mn[k]; float s = le > 0 ? (c.mx[k] - c.mn[k]) / le : 1.f; s3[k] = s / ds; loc[k] = c.mn[k] - s * lb.mn[k]; }
                    setT(tg, vecTag("DrawScale3D", s3), "Tag"); setT(tg, vecTag("Location", loc), "Tag"); clipped++;
                    log("    volume clipped: %-34s x[%.0f..%.0f] y[%.0f..%.0f] z[%.0f..%.0f]", P.objName(a).c_str(), c.mn[0], c.mx[0], c.mn[1], c.mx[1], c.mn[2], c.mx[2]); }
            }
        }
        float loc[3] = { 0, 0, 0 }; tagVec(tg, "Location", loc); X.pt(loc);
        setT(tg, vecTag("Location", loc), "Tag");
        if (X.q) { i32 rot[3] = { 0, 0, 0 }; if (const Tag* rt = findTag(tg, "Rotation")) if (rt->raw.size() >= 12) memcpy(rot, rt->raw.data(), 12);
            rot[1] = (rot[1] + X.q * 16384) & 0xFFFF; if (rot[1] >= 32768) rot[1] -= 65536;
            Tag t; t.name = "Rotation"; t.type = "StructProperty"; t.strct = "Rotator"; t.raw.resize(12); memcpy(t.raw.data(), rot, 12); setT(tg, t, "Tag"); }
        writeBack(P, a, tg); moved++;
    }
    log("    actors moved: %d, collection matrices: %d, volumes clipped: %d, removed: %d", moved, mats, clipped, removed);
    for (i32 m : levelModels(P)) transformModel(P, m, X, log);
    for (auto& r : S.disable) { size_t b = r.find('|'); if (r.substr(0, b) != pkg) continue; i32 e = P.findPath(r.substr(b + 1)); if (e <= 0) { log("    warning: not found: %s", r.c_str()); continue; }
        auto t2 = objProps(P, e).tags; setT(t2, boolTag("bEnabled", false), "ObjInstanceVersion"); writeBack(P, e, t2); log("    Kismet disabled: %s", P.objName(e).c_str()); }
    if (betafix::isBetaRoom(P)) { auto R = betafix::sanitize(P, betafix::parentLevels(on, { fileBase(S.targetMap) })); log("    beta room: collision BSP %d, materials %d, room-only lights %d (fixes)", R.bsp, R.mics, R.lights); }
    savePkg(io, S.outDir + on + ".umap", P, log);
}

inline void editTarget(const IO& io, const Spec& S, Log& log) {
    Package P; loadPkg(io, S.targetMap, P); log("== %s", fileBase(S.targetMap).c_str());
    i32 src = 0, srcOff = 0;
    for (size_t k = 0; k < P.exports.size(); k++) if (P.classOf(P.exports[k]) == "LevelStreamingKismet") { auto op = objProps(P, (i32)k + 1);
        if (lower(tagName(P, op.tags, "PackageName")) != lower(S.anchor)) continue; if (!findTag(op.tags, "Offset")) { src = (i32)k + 1; break; } if (!srcOff) srcOff = (i32)k + 1; }
    if (!src) src = srcOff; if (!src) throw Err("LevelStreamingKismet of room " + S.anchor + " not found in " + fileBase(S.targetMap));
    std::set<std::string> have; for (auto& n : streamingNames(P)) have.insert(lower(n));
    i32 lsName = P.addName("LevelStreamingKismet"); int maxNum = 0; for (auto& e : P.exports) if (e.name.idx == lsName) maxNum = std::max(maxNum, e.name.num);
    std::vector<i32> news;
    for (auto& sp : S.srcPkgs) { std::string pkg = outName(S, sp);
        if (have.count(lower(pkg))) { log("    streaming for %s already exists (kept)", pkg.c_str()); continue; }
        Export ne = P.exports[src - 1]; ne.data.assign(P.dataPtr(P.exports[src - 1]), P.dataPtr(P.exports[src - 1]) + P.dataLen(P.exports[src - 1])); ne.owned = true; ne.netObjects.clear(); memset(ne.guid, 0, 16);
        ne.name.num = ++maxNum; P.exports.push_back(ne); i32 ni = (i32)P.exports.size();
        auto tg = objProps(P, ni).tags; setT(tg, nameTag(P, "PackageName", pkg), "DrawColor"); delT(tg, "PersonResponsible"); writeBack(P, ni, tg); news.push_back(ni);
        log("    new streaming: %s -> %s", P.objName(ni).c_str(), pkg.c_str()); }
    if (!news.empty()) {
        i32 wi = 0; for (size_t k = 0; k < P.exports.size(); k++) if (P.classOf(P.exports[k]) == "WorldInfo" && P.objPath(P.exports[k].outer) == "TheWorld.PersistentLevel") wi = (i32)k + 1;
        if (!wi) throw Err("WorldInfo not found in the target map");
        auto tg = objProps(P, wi).tags; bool ok = false;
        for (auto& t : tg) if (t.name == "StreamingLevels") { i32 n; memcpy(&n, t.raw.data(), 4); Writer w; w.i(n + (i32)news.size()); w.raw(std::vector<u8>(t.raw.begin() + 4, t.raw.end())); for (i32 x : news) w.i(x); t.raw = w.b; ok = true;
            log("    WorldInfo.StreamingLevels: %d -> %d", n, n + (int)news.size()); }
        if (!ok) throw Err("WorldInfo without StreamingLevels"); writeBack(P, wi, tg);
    }
    savePkg(io, S.outDir + fileBase(S.targetMap) + ".umap", P, log);
}

inline void editGuidCache(const IO& io, const Spec& S, Log& log) {
    Package P; loadPkg(io, S.guidCache, P); ownData(P, 1); auto& d = P.exports[0].data; i32 cnt; memcpy(&cnt, d.data() + 12, 4);
    if (16 + (size_t)cnt * 24 != d.size()) throw Err("GuidCache with an unexpected layout");
    std::set<std::string> have; for (i32 i = 0; i < cnt; i++) { FName f; memcpy(&f.idx, d.data() + 16 + 24 * (size_t)i, 4); memcpy(&f.num, d.data() + 20 + 24 * (size_t)i, 4); have.insert(lower(P.nm(f))); }
    int added = 0;
    for (auto& sp : S.srcPkgs) { std::string pkg = outName(S, sp); if (have.count(lower(pkg))) continue;
        i32 n = P.addName(pkg), z = 0; u8 ent[24] = { 0 }; memcpy(ent, &n, 4); memcpy(ent + 4, &z, 4); d.insert(d.end(), ent, ent + 24); cnt++; added++; }
    memcpy(d.data() + 12, &cnt, 4);
    log("== GuidCache.upk: +%d packages (%d in total)", added, cnt);
    savePkg(io, S.outDir + "GuidCache.upk", P, log);
}

// runs everything; returns the generated files (installAs: relative to the game's CookedPC folder, when it can be deduced)
inline std::vector<OutFile> run(const IO& io, const Spec& S, Log& log) {
    if (S.srcPkgs.empty() || S.anchor.empty() || S.newBase.empty() || S.targetMap.empty() || S.outDir.empty()) throw Err("incomplete parameters");
    if (lower(S.newBase).rfind(lower(S.anchor) + "_", 0) != 0) throw Err("the new name must start with " + S.anchor + "_ (that is how the game loads it together with the room)");
    log("Import room: %s -> %s (group of %s), offset (%.0f, %.0f, %.0f), rotation %d degrees around (%.0f, %.0f, %.0f)", S.srcBase.c_str(), S.newBase.c_str(), S.anchor.c_str(), S.delta[0], S.delta[1], S.delta[2], (S.yaw90 & 3) * 90, S.pivot[0], S.pivot[1], S.pivot[2]);
    if (S.clip) log("room box (source): x[%.0f..%.0f] y[%.0f..%.0f] z[%.0f..%.0f]", S.room.mn[0], S.room.mx[0], S.room.mn[1], S.room.mx[1], S.room.mn[2], S.room.mx[2]);
    std::vector<OutFile> out; std::string tdir = fileDir(S.targetMap), rel;
    { std::string l = lower(tdir); size_t c = l.find("cookedpc"); if (c != std::string::npos) { rel = tdir.substr(c + 9); } }
    for (auto& sp : S.srcPkgs) { portPackage(io, S, sp, log); out.push_back({ S.outDir + outName(S, sp) + ".umap", rel + outName(S, sp) + ".umap" }); }
    editTarget(io, S, log); out.push_back({ S.outDir + fileBase(S.targetMap) + ".umap", rel + fileBase(S.targetMap) + ".umap" });
    if (!S.guidCache.empty()) { editGuidCache(io, S, log); out.push_back({ S.outDir + "GuidCache.upk", "GuidCache.upk" }); }
    return out;
}

} }
