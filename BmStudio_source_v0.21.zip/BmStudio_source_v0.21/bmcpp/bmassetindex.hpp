// bmassetindex.hpp - asset index of every game package, reading ONLY the tables (names/imports/exports).
// Compressed package: only the chunks that cover the header are decompressed (the rest of the file is not even read).
#pragma once
#include "bmpkg.hpp"
#include <functional>
#include <unordered_map>
#include <set>

namespace bm { namespace aidx {

struct Entry { std::string path; std::string cls; i32 size = 0; int file = 0; };   // path = path as an import sees it (without the file, if it is a forced export)

inline bool isAssetClass(const std::string& c) {
    static const char* k[] = { "StaticMesh", "FracturedStaticMesh", "SkeletalMesh", "Texture2D", "TextureCube", "Material", "MaterialInstanceConstant", "MaterialInstanceTimeVarying",
        "ParticleSystem", "AnimSet", "SoundCue", "PhysicsAsset", "SpeedTree", "FaceFXAsset", "SwfMovie" };
    for (auto s : k) if (c == s) return true; return false;
}

// reads [off, off+n) of the file
using ReadFn = std::function<bool(uint64_t off, size_t n, std::vector<u8>& out)>;

// returns the package assets (empty + err on failure)
inline std::vector<Entry> scan(const ReadFn& rd, uint64_t fileSize, int fileId, std::string& err) {
    std::vector<Entry> out; std::vector<u8> head;
    try {
        if (!rd(0, (size_t)std::min<uint64_t>(fileSize, 65536), head)) throw Err("read");
        Reader r(head.data(), head.size());
        if (r.u() != 0x9E2A83C1u) throw Err("not a package"); u32 ver = r.u(); if ((ver & 0xFFFF) != 576) throw Err("version");
        i32 headerSize = r.i(); r.fstr(); r.u();
        i32 nameCount = r.i(), nameOff = r.i(), expCount = r.i(), expOff = r.i(), impCount = r.i(), impOff = r.i(); r.i(); r.p += 16;
        i32 gc = r.i(); r.p += (size_t)gc * 12; r.i(); r.i(); u32 cflags = r.u(); i32 nc = r.i();
        std::vector<u8> img;   // decompressed image of [0, headerSize)
        if (nc == 0) {   // the export table may have been relocated outside the header (edited package)
            uint64_t want = (uint64_t)std::max(headerSize, std::max(nameOff, std::max(impOff, expOff))) + (uint64_t)expCount * 96 + (uint64_t)impCount * 28 + (1u << 20);
            if (!rd(0, (size_t)std::min<uint64_t>(fileSize, want), img)) throw Err("read header"); }
        else {
            if (!(cflags & 2)) throw Err("compression");
            img.assign((size_t)headerSize, 0);
            struct Ch { i32 uo, us, co, cs; }; std::vector<Ch> ch(nc); for (auto& c : ch) { c.uo = r.i(); c.us = r.i(); c.co = r.i(); c.cs = r.i(); }
            for (auto& c : ch) { if (c.uo >= headerSize) continue;
                std::vector<u8> cb; if (!rd((uint64_t)c.co, (size_t)c.cs, cb)) throw Err("read chunk");
                Reader cr(cb.data(), cb.size()); if (cr.u() != 0x9E2A83C1u) throw Err("chunk tag"); i32 bs = cr.i(); cr.i(); i32 usz = cr.i(); if (bs <= 0) throw Err("chunk");
                i32 nb = (usz + bs - 1) / bs; std::vector<std::pair<i32, i32>> blk(nb); for (auto& b : blk) { b.first = cr.i(); b.second = cr.i(); }
                std::vector<u8> tmp((size_t)usz); size_t src = cr.p, dst = 0;
                for (auto& b : blk) { size_t got = 0; if (src + b.first > cb.size() || dst + b.second > tmp.size() || !lzo1xDecompress(cb.data() + src, (size_t)b.first, tmp.data() + dst, (size_t)b.second, &got)) throw Err("lzo"); src += b.first; dst += b.second; }
                size_t n = std::min((size_t)usz, (size_t)headerSize - (size_t)c.uo); memcpy(img.data() + c.uo, tmp.data(), n); }
        }
        Reader t(img.data(), img.size());
        std::vector<std::string> names(nameCount); t.p = (size_t)nameOff; for (auto& s : names) { s = t.fstr(); t.q(); }
        auto nm = [&](i32 idx, i32 num) { std::string s = (idx >= 0 && idx < nameCount) ? names[idx] : "?"; return num ? s + "_" + std::to_string(num - 1) : s; };
        struct Im { i32 clsN, clsNum, outer, nameN, nameNum; }; std::vector<Im> ims(impCount); t.p = (size_t)impOff;
        for (auto& im : ims) { t.i(); t.i(); im.clsN = t.i(); im.clsNum = t.i(); im.outer = t.i(); im.nameN = t.i(); im.nameNum = t.i(); }
        struct Ex { i32 cls, outer, nameN, nameNum, size; u32 ef; }; std::vector<Ex> exs(expCount); t.p = (size_t)expOff;
        for (auto& e : exs) { e.cls = t.i(); t.i(); e.outer = t.i(); e.nameN = t.i(); e.nameNum = t.i(); t.i(); t.q(); e.size = t.i(); t.i(); e.ef = t.u(); i32 nn = t.i(); t.p += (size_t)nn * 4 + 16; t.u(); }
        auto clsName = [&](i32 c) -> std::string { if (c < 0 && -c <= impCount) return nm(ims[-c - 1].nameN, ims[-c - 1].nameNum); if (c > 0 && c <= expCount) return nm(exs[c - 1].nameN, exs[c - 1].nameNum); return "Class"; };
        // actor templates (to place a light/emitter/mesh in a level that has none): one "@Class" entry per package
        { static const char* tc[] = { "InterpActor", "StaticMeshActor", "PointLightToggleable", "PointLightMovable", "SpotLightToggleable", "SpotLightMovable", "Emitter" }; std::set<std::string> seen;
          for (i32 k = 0; k < expCount; k++) { const Ex& e = exs[k]; if (e.outer <= 0 || e.outer > expCount) continue; const Ex& o = exs[e.outer - 1];
              if (nm(o.nameN, 0) != "PersistentLevel") continue; std::string c = clsName(e.cls); for (auto t : tc) if (c == t && !seen.count(c)) { seen.insert(c); Entry en; en.path = "TheWorld.PersistentLevel"; en.cls = "@" + c; en.file = fileId; out.push_back(en); } } }
        for (i32 k = 0; k < expCount; k++) { const Ex& e = exs[k]; std::string c = clsName(e.cls); if (!isAssetClass(c)) continue;
            // path: walks up the outers; stops at the topmost forced export (the asset's "package")
            std::vector<i32> chain; i32 x = k + 1; size_t top = 0; bool forced = false;
            for (int g = 0; x > 0 && x <= expCount && g < 64; g++) { chain.push_back(x); if (exs[x - 1].ef & 1u) { forced = true; top = chain.size(); } x = exs[x - 1].outer; }
            if (forced) chain.resize(top);
            std::string p; for (size_t q = chain.size(); q-- > 0;) { std::string s = nm(exs[chain[q] - 1].nameN, exs[chain[q] - 1].nameNum); p = p.empty() ? s : p + "." + s; }
            if (p.rfind("Default__", 0) == 0) continue;
            Entry en; en.path = p; en.cls = c; en.size = e.size; en.file = fileId; out.push_back(en); }
    } catch (std::exception& ex) { err = ex.what(); out.clear(); }
    return out;
}

} }
