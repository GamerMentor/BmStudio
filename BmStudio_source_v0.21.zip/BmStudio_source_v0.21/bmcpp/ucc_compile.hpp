// ucc_compile.hpp - UnrealScript compiler -> Batman: Arkham Asylum bytecode (UE3 v576/lic21, 32-bit PC).
// Compiles the body of a function (or the code of a state) in the context of the declarations that already exist in the package
// (parameters/locals/properties/functions), reproducing the emission rules of the UCC of that time.
#pragma once
#include "ucc_types.hpp"
#include "ucc_parse.hpp"
#include <unordered_set>
#include <functional>

namespace bm {
namespace ucc {

// conversion codes (ECastToken)
enum : u8 {
    CST_InterfaceToObject = 0x36, CST_InterfaceToString = 0x37, CST_InterfaceToBool = 0x38, CST_RotatorToVector = 0x39, CST_ByteToInt = 0x3A,
    CST_ByteToBool = 0x3B, CST_ByteToFloat = 0x3C, CST_IntToByte = 0x3D, CST_IntToBool = 0x3E, CST_IntToFloat = 0x3F, CST_BoolToByte = 0x40,
    CST_BoolToInt = 0x41, CST_BoolToFloat = 0x42, CST_FloatToByte = 0x43, CST_FloatToInt = 0x44, CST_FloatToBool = 0x45, CST_ObjectToInterface = 0x46,
    CST_ObjectToBool = 0x47, CST_NameToBool = 0x48, CST_StringToByte = 0x49, CST_StringToInt = 0x4A, CST_StringToBool = 0x4B, CST_StringToFloat = 0x4C,
    CST_StringToVector = 0x4D, CST_StringToRotator = 0x4E, CST_VectorToBool = 0x4F, CST_VectorToRotator = 0x50, CST_RotatorToBool = 0x51,
    CST_ByteToString = 0x52, CST_IntToString = 0x53, CST_BoolToString = 0x54, CST_FloatToString = 0x55, CST_ObjectToString = 0x56,
    CST_NameToString = 0x57, CST_VectorToString = 0x58, CST_RotatorToString = 0x59, CST_DelegateToString = 0x5A, CST_StringToName = 0x60
};
enum : u32 { FUNC_Final = 0x1, FUNC_Iterator = 0x4, FUNC_Latent = 0x8, FUNC_PreOperator = 0x10, FUNC_Native = 0x400, FUNC_Event = 0x800, FUNC_Operator = 0x1000, FUNC_Static = 0x2000, FUNC_Delegate = 0x100000 };
enum : uint64_t { CPF_OptionalParm = 0x10, CPF_Parm = 0x80, CPF_OutParm = 0x100, CPF_SkipParm = 0x200, CPF_ReturnParm = 0x400, CPF_CoerceParm = 0x800, CPF_Const = 0x2 };

// ------------------------------------------------------------------ scope indices (cache)
class Scopes {
public:
    TypeDB& db;
    explicit Scopes(TypeDB& d) : db(d) {}
    std::unordered_map<uint64_t, std::unordered_map<std::string, std::vector<Ref>>> maps;
    const std::unordered_map<std::string, std::vector<Ref>>& members(const Ref& s) {
        auto it = maps.find(s.key()); if (it != maps.end()) return it->second;
        auto& m = maps[s.key()]; for (Ref c : db.children(s)) m[lower(db.name(c))].push_back(c); return m;
    }
    // looks in the scope and its parents; filter by object class
    Ref find(Ref s, const std::string& n, const std::function<bool(const std::string&)>& ok, bool supers = true) {
        std::string ln = lower(n);
        for (int g = 0; s && g < 64; g++) {
            auto& m = members(s); auto it = m.find(ln);
            if (it != m.end()) for (Ref r : it->second) if (ok(db.cls(r))) return r;
            if (!supers) break; s = db.super_(s);
        }
        return Ref{};
    }
    Ref findProp(Ref s, const std::string& n) { return find(s, n, [](const std::string& c) { return isPropClass(c); }); }
    Ref findFunc(Ref s, const std::string& n) { return find(s, n, [](const std::string& c) { return c == "Function"; }); }
    Ref findState(Ref s, const std::string& n) { return find(s, n, [](const std::string& c) { return c == "State"; }); }
    Ref findConst(Ref s, const std::string& n) { return find(s, n, [](const std::string& c) { return c == "Const"; }); }
    Ref findType(Ref s, const std::string& n) { return find(s, n, [](const std::string& c) { return c == "ScriptStruct" || c == "Enum"; }); }
};

// ------------------------------------------------------------------ semantic information of an expression
enum class VK : u8 { None, Local, LocalOut, Instance, Default, Literal, Call, Context, StructMember, ArrayElem, DynElem, Other };
struct Sem {
    Type ty; bool lvalue = false; bool isLiteral = false; VK vk = VK::None;
    Ref prop;                // variable / member
    Ref fn;                  // called function / operator
    int nativeIdx = -1;      // native operator/function
    int enumVal = -1;        // enum value
    std::string constText;   // const -> literal
    bool isClassName = false; Ref classRef;   // identifier that is a class name
    bool isDelegateCall = false;
    bool isFuncName = false; // function name used as a delegate value
    int castCode = -1; bool dynCast = false, ifaceCast = false; Ref castClass; // explicit cast
    bool structCmp = false;  // == / != between structs without an operator
    int delCmp = -1;         // delegate comparison
    bool isStructDefault = false;
    bool isIterator = false;
    bool none = false;       // literal None
    bool forceFinal = false; // obj.super(Class).F()
    bool ctxLiteral = false; // obj.CONST / obj.EnumValue
};

class Compiler {
public:
    TypeDB& db; Scopes sc; int pi = 0;
    Ref func, state, cls;                 // function (or state) being compiled
    bool stateCode = false;               // compiling the code (labels) of a state
    std::unordered_map<std::string, Ref> locals;   // parameters and locals
    Ref retProp;
    std::vector<u8> code; std::string err;
    std::unordered_map<Expr*, Sem> sems;
    std::map<int, Ref> natives;           // iNative -> function
    std::map<std::string, std::vector<Ref>> operators;   // symbol -> operator functions
    OpTable optable;
    std::unordered_map<std::string, Ref> enumValues; std::unordered_map<std::string, int> enumIndex;   // value -> enum (global)
    std::unordered_map<uint64_t, i32> idxCache;

    explicit Compiler(TypeDB& d) : db(d), sc(d) { db.finalizeIntrinsics(); buildTables(); }

    // ---------------------------------------------------------- global tables
    void buildTables() {
        for (int p = 0; p < (int)db.pkgs.size(); p++) {
            Package& P = *db.pkgs[p];
            for (size_t k = 0; k < P.exports.size(); k++) {
                std::string c = P.classOf(P.exports[k]); Ref r{ p, (i32)k + 1 };
                if (c == "Function") {
                    const FieldInfo& f = db.field(r); if (!f.ok) continue;
                    if (f.iNative) natives[f.iNative] = r;
                    if (f.funcFlags & FUNC_Operator) {
                        std::string sym = P.nm(f.friendly); if (sym.empty() || sym == "None") continue;
                        std::string key = isalpha((unsigned char)sym[0]) ? lower(sym) : sym;
                        operators[key].push_back(r);
                        int np = 0; for (Ref ch : db.children(r)) { const FieldInfo& pf = db.field(ch); if (pf.isProperty && (pf.propFlags & CPF_Parm) && !(pf.propFlags & CPF_ReturnParm)) np++; }
                        OpInfo& oi = optable[key];
                        if (np == 2) oi.binPrec = f.operPrec;
                        else if (np == 1) { if (f.funcFlags & FUNC_PreOperator) oi.pre = true; else oi.post = true; }
                    }
                } else if (c == "Enum") {
                    const FieldInfo& f = db.field(r);
                    for (size_t i = 0; i < f.enumNames.size(); i++) { std::string v = lower(P.nm(f.enumNames[i])); if (!enumValues.count(v)) { enumValues[v] = r; enumIndex[v] = (int)i; } }
                }
            }
        }
    }

    // ---------------------------------------------------------- basic emission
    void b(u8 v) { code.push_back(v); }
    void w(uint16_t v) { code.push_back(v & 0xFF); code.push_back(v >> 8); }
    void i4(i32 v) { for (int k = 0; k < 4; k++) code.push_back((u8)((u32)v >> (8 * k))); }
    void f4(float v) { u32 u; memcpy(&u, &v, 4); i4((i32)u); }
    void patchW(size_t at, uint16_t v) { code[at] = v & 0xFF; code[at + 1] = v >> 8; }
    [[noreturn]] void fail(const std::string& m, int line) { throw CompileError(m, line); }
    Package& TP() { return *db.pkgs[pi]; }
    bool allowMutate = false;   // may create imports/names in the target package ("apply" mode)
    i32 objIndex(const Ref& r, int line) {
        if (!r) return 0;
        auto it = idxCache.find(r.key()); if (it != idxCache.end()) return it->second;
        i32 v = db.indexIn(pi, r);
        if (!v) { if (!allowMutate) fail("object not imported in this package: " + db.path(r), line); v = ensureImport(r, line); }
        idxCache[r.key()] = v; return v;
    }
    FName makeName(const std::string& s) {
        Package& P = TP(); FName f; size_t us = s.rfind('_');
        if (us != std::string::npos && us + 1 < s.size() && (s[us + 1] != '0' || us + 2 == s.size()) && s.find_first_not_of("0123456789", us + 1) == std::string::npos) {
            f.idx = P.addName(s.substr(0, us)); f.num = atoi(s.c_str() + us + 1) + 1; return f; }
        f.idx = P.addName(s); f.num = 0; return f;
    }
    // creates the import chain for an object of another package (e.g. Engine.Actor.SetLocation)
    i32 ensureImport(const Ref& r, int line) {
        Package& T = TP();
        // "forced export" object (e.g. Joker.Mesh.Combat_joker inside BmGame.u): the real path starts at the
        // forced package, without the file name -> import Joker.Mesh.Combat_joker (as the cooked maps do)
        if (r.idx > 0) { const Package& S = db.P(r); std::vector<i32> chain; i32 x = r.idx; bool forced = false;
            size_t top = 0; for (int g = 0; x > 0 && g < 64; g++) { chain.push_back(x); if (S.exports[x - 1].exportFlags & 1u) { forced = true; top = chain.size(); } x = S.exports[x - 1].outer; }
            if (forced) chain.resize(top);   // up to the topmost forced ancestor (the asset's "package")
            if (forced) { i32 outer = 0; std::string prefix;
                for (size_t k = chain.size(); k-- > 0;) { i32 e = chain[k]; std::string nm = S.objName(e); prefix = prefix.empty() ? nm : prefix + "." + nm;
                    i32 found = 0; for (size_t q = 0; q < T.imports.size(); q++) { i32 ii = -(i32)q - 1; if (Package::strcasecmp_(T.objPath(ii), prefix)) { found = ii; break; } }
                    if (found) { outer = found; continue; }
                    std::string clsName = S.classOf(S.exports[e - 1]), clsPkg = "Core";
                    if (clsName != "Package") { Ref cr = db.findClass(clsName); if (cr) { std::string cp = db.path(cr); clsPkg = cp.substr(0, cp.find('.')); } }
                    Import im; im.classPkg = makeName(clsPkg); im.className = makeName(clsName); im.outer = outer; im.name = makeName(nm);
                    T.imports.push_back(im); outer = -(i32)T.imports.size(); }
                (void)line; return outer; } }
        std::string full = db.path(r);
        std::vector<std::string> parts; { size_t a = 0; for (;;) { size_t d = full.find('.', a); parts.push_back(full.substr(a, d == std::string::npos ? std::string::npos : d - a)); if (d == std::string::npos) break; a = d + 1; } }
        i32 outer = 0; std::string prefix;
        for (size_t k = 0; k < parts.size(); k++) {
            prefix = k ? prefix + "." + parts[k] : parts[k];
            i32 found = 0; for (size_t q = 0; q < T.imports.size(); q++) { i32 ii = -(i32)q - 1; if (Package::strcasecmp_(T.objPath(ii), prefix)) { found = ii; break; } }
            if (found) { outer = found; continue; }
            std::string clsName = "Package", clsPkg = "Core";
            if (k > 0) { Ref obj = db.findPath(prefix); clsName = obj ? db.cls(obj) : "Class"; Ref cr = db.findClass(clsName);
                if (cr) { std::string cp = db.path(cr); clsPkg = cp.substr(0, cp.find('.')); } }
            Import im; im.classPkg = makeName(clsPkg); im.className = makeName(clsName); im.outer = outer; im.name = makeName(parts[k]);
            T.imports.push_back(im); outer = -(i32)T.imports.size();
        }
        (void)line; return outer;
    }
    void invalidate() { sc.maps.clear(); paramCache.clear(); idxCache.clear(); sems.clear(); }
    void ref(const Ref& r, int line) { i4(objIndex(r, line)); }
    FName nameOf(const std::string& s, int line) {
        Package& P = TP(); FName f;
        size_t us = s.rfind('_');
        if (us != std::string::npos && us + 1 < s.size() && (s[us + 1] != '0' || us + 2 == s.size()) && s.find_first_not_of("0123456789", us + 1) == std::string::npos) {
            i32 bi = P.findName(s.substr(0, us)); if (bi >= 0) { f.idx = bi; f.num = atoi(s.c_str() + us + 1) + 1; return f; }
        }
        i32 i = P.findName(s); if (i < 0) { if (allowMutate) return makeName(s); fail("name not in package name table: " + s, line); }
        f.idx = i; f.num = 0; return f;
    }
    void name(const std::string& s, int line) { FName f = nameOf(s, line); i4(f.idx); i4(f.num); }

    // ---------------------------------------------------------- utility types
    bool isStructNamed(const Type& t, const char* n) { return t.k == K::Struct && lower(db.name(t.strct)) == n; }
    bool isVector(const Type& t) { return isStructNamed(t, "vector"); }
    bool isRotator(const Type& t) { return isStructNamed(t, "rotator"); }
    bool sameType(const Type& a, const Type& b) {
        if (a.k != b.k) return false;
        switch (a.k) {
            case K::Object: case K::Interface: case K::Class: return a.cls == b.cls;
            case K::Struct: return a.strct == b.strct;
            case K::Array: return a.inner && b.inner && sameType(*a.inner, *b.inner);
            case K::Delegate: return true;
            default: return true;
        }
    }
    Ref objectClass() { static Ref r; if (!r) r = db.findClass("Object"); return r; }
    Ref classOfObjType(const Type& t) { return t.cls ? t.cls : objectClass(); }
    // size for the Context/Switch fields (0 for string and array)
    int resultSize(const Type& t) { if (t.k == K::String || t.k == K::Array || t.k == K::None) return 0; return db.typeSize(t); }
    bool needsDestruct(const Type& t) {
        if (t.k == K::String || t.k == K::Array) return true;
        if (t.k == K::Struct) { for (Ref c : db.children(t.strct)) { const FieldInfo& f = db.field(c); if (f.isProperty && needsDestruct(db.propType(c))) return true; } Ref s = db.super_(t.strct); if (s) { Type st; st.k = K::Struct; st.strct = s; return needsDestruct(st); } }
        return false;
    }
    std::string typeStr(const Type& t) {
        switch (t.k) {
            case K::Byte: return t.enm ? db.name(t.enm) : "byte"; case K::Int: return "int"; case K::Bool: return "bool"; case K::Float: return "float";
            case K::Name: return "name"; case K::String: return "string"; case K::Object: return db.name(classOfObjType(t)); case K::Interface: return db.name(t.cls);
            case K::Class: return "class<" + db.name(classOfObjType(t)) + ">"; case K::Struct: return db.name(t.strct);
            case K::Array: return "array<" + (t.inner ? typeStr(*t.inner) : std::string("?")) + ">"; case K::Delegate: return "delegate";
            default: return "none";
        }
    }

    // conversion: cast code and whether it is automatic
    int convCode(const Type& from, const Type& to, bool* autoConv) {
        *autoConv = false;
        auto F = from.k, T = to.k; bool fv = isVector(from), fr = isRotator(from), tv = isVector(to), tr = isRotator(to);
        if (T == K::Byte) { if (F == K::Int) { *autoConv = true; return CST_IntToByte; } if (F == K::Float) { *autoConv = true; return CST_FloatToByte; } if (F == K::Bool) return CST_BoolToByte; if (F == K::String) return CST_StringToByte; }
        if (T == K::Int) { if (F == K::Byte) { *autoConv = true; return CST_ByteToInt; } if (F == K::Float) { *autoConv = true; return CST_FloatToInt; } if (F == K::Bool) return CST_BoolToInt; if (F == K::String) return CST_StringToInt; }
        if (T == K::Float) { if (F == K::Byte) { *autoConv = true; return CST_ByteToFloat; } if (F == K::Int) { *autoConv = true; return CST_IntToFloat; } if (F == K::Bool) return CST_BoolToFloat; if (F == K::String) return CST_StringToFloat; }
        if (T == K::Bool) { if (F == K::Byte) return CST_ByteToBool; if (F == K::Int) return CST_IntToBool; if (F == K::Float) return CST_FloatToBool; if (F == K::Object || F == K::Class) return CST_ObjectToBool; if (F == K::Name) return CST_NameToBool; if (F == K::String) return CST_StringToBool; if (fv) return CST_VectorToBool; if (fr) return CST_RotatorToBool; if (F == K::Interface) return CST_InterfaceToBool; }
        if (T == K::String) { if (F == K::Byte) return CST_ByteToString; if (F == K::Int) return CST_IntToString; if (F == K::Bool) return CST_BoolToString; if (F == K::Float) return CST_FloatToString; if (F == K::Object || F == K::Class) return CST_ObjectToString; if (F == K::Name) return CST_NameToString; if (fv) return CST_VectorToString; if (fr) return CST_RotatorToString; if (F == K::Delegate) return CST_DelegateToString; if (F == K::Interface) return CST_InterfaceToString; }
        if (T == K::Name && F == K::String) return CST_StringToName;
        if (tv) { if (fr) return CST_RotatorToVector; if (F == K::String) return CST_StringToVector; }
        if (tr) { if (fv) return CST_VectorToRotator; if (F == K::String) return CST_StringToRotator; }
        if (T == K::Interface && (F == K::Object)) { *autoConv = true; return CST_ObjectToInterface; }
        if (T == K::Object && F == K::Interface) { *autoConv = true; return CST_InterfaceToObject; }
        return -1;
    }
    // cost of passing 'a' (type src) to a parameter (type dst, flags)
    static constexpr int INF = 1 << 28;
    int convCost(const Type& src, const Sem& s, const Type& dst, uint64_t pflags) {
        if (s.none) { if (dst.k == K::Object || dst.k == K::Class || dst.k == K::Interface || dst.k == K::Delegate) return 1; return INF; }
        if (sameType(src, dst)) return 0;
        if ((src.k == K::Object && dst.k == K::Object) || (src.k == K::Class && dst.k == K::Class) || (src.k == K::Interface && dst.k == K::Interface)) {
            if (db.isChildOf(classOfObjType(src), classOfObjType(dst))) return (pflags & CPF_OutParm) ? INF : 1;
            return INF;
        }
        if (src.k == K::Class && dst.k == K::Object) { Ref cc = db.findClass("Class"); if (db.isChildOf(cc, classOfObjType(dst)) || classOfObjType(dst) == objectClass()) return (pflags & CPF_OutParm) ? INF : 1; return INF; }
        if (pflags & CPF_OutParm) return INF;
        if (src.k == K::Byte && dst.k == K::Byte) return 0;
        bool au; int cc = convCode(src, dst, &au);
        if (cc < 0) return INF;
        if (au) {
            // order (empirical, checked by round-trip): byte->int < int->float < byte->float < float->int ...
            switch (cc) { case CST_ByteToInt: return 101; case CST_IntToFloat: return 102; case CST_ByteToFloat: return 103; case CST_IntToByte: return 104; case CST_FloatToInt: return 105; case CST_FloatToByte: return 106; default: return 110; }
        }
        if (pflags & CPF_CoerceParm) return 1000;
        return INF;
    }

    // ---------------------------------------------------------- functions: parameters
    struct Param { Ref prop; Type ty; uint64_t flags; };
    std::unordered_map<uint64_t, std::vector<Param>> paramCache;
    const std::vector<Param>& params(const Ref& fn) {
        auto it = paramCache.find(fn.key()); if (it != paramCache.end()) return it->second;
        std::vector<Param> v; for (Ref c : db.children(fn)) { const FieldInfo& f = db.field(c); if (!f.isProperty || !(f.propFlags & CPF_Parm) || (f.propFlags & CPF_ReturnParm)) continue; v.push_back({ c, db.propType(c), f.propFlags }); }
        return paramCache[fn.key()] = v;
    }
    Ref returnProp(const Ref& fn) { for (Ref c : db.children(fn)) { const FieldInfo& f = db.field(c); if (f.isProperty && (f.propFlags & CPF_ReturnParm)) return c; } return Ref{}; }
    Type returnType(const Ref& fn) { Ref r = returnProp(fn); return r ? db.propType(r) : Type(); }

    // ---------------------------------------------------------- name lookup in the current scope
    Ref ownerClass(Ref f) { for (int g = 0; f && g < 8; g++) { if (db.cls(f) == "Class") return f; f = db.outer(f); } return Ref{}; }
    // visible function: current state (and super-states), class and superclasses; states with the same name in superclasses
    Ref findFunction(Ref clsScope, Ref stScope, const std::string& n) {
        if (stScope) {
            Ref s = stScope;
            for (int g = 0; s && g < 32; g++) { Ref r = sc.find(s, n, [](const std::string& c) { return c == "Function"; }, false); if (r) return r; s = db.super_(s); }
        }
        return sc.findFunc(clsScope, n);
    }
    Ref findClassType(const std::string& n) { return db.findClass(n); }
    Ref findStructOrEnum(const std::string& n) {
        Ref r = sc.findType(cls, n); if (r) return r;
        auto it = db.typesByName.find(lower(n)); if (it != db.typesByName.end() && !it->second.empty()) return it->second.front();
        return Ref{};
    }

    // ---------------------------------------------------------- analysis (types)
    Sem& S(Expr* e) { return sems[e]; }
    Type tyK(K k) { Type t; t.k = k; return t; }
    Type tyObj(Ref c) { Type t; t.k = K::Object; t.cls = c; return t; }
    Type tyStruct(const char* n) { Type t; t.k = K::Struct; t.strct = db.findPath(std::string("Core.Object.") + n); return t; }
    bool primitiveCastType(const std::string& n, Type* t) {
        std::string l = lower(n);
        if (l == "byte") { *t = tyK(K::Byte); return true; } if (l == "int") { *t = tyK(K::Int); return true; } if (l == "bool") { *t = tyK(K::Bool); return true; }
        if (l == "float") { *t = tyK(K::Float); return true; } if (l == "string") { *t = tyK(K::String); return true; } if (l == "name") { *t = tyK(K::Name); return true; }
        if (l == "vector") { *t = tyStruct("Vector"); return true; } if (l == "rotator") { *t = tyStruct("Rotator"); return true; }
        return false;
    }

    Sem& analyze(Expr* e) {
        auto it = sems.find(e); if (it != sems.end()) return it->second;
        Sem s = analyze_(e); return sems[e] = s;
    }
    Sem varSem(Ref prop, VK vk, Ref ownerCls = Ref{}) {
        Sem s; s.prop = prop; s.vk = vk; s.ty = db.propType(prop); s.lvalue = true;
        // Object.Outer has the type of the 'within' class (e.g. CheatManager within PlayerController)
        if (s.ty.k == K::Object && lower(db.name(prop)) == "outer" && db.path(prop) == "Core.Object.Outer") {
            Ref c = ownerCls ? ownerCls : cls;
            for (int g = 0; c && g < 64; g++) { const FieldInfo& f = db.field(c); if (f.within) { Ref w = db.resolve(c.pkg, f.within); if (w) { s.ty.cls = w; break; } } c = db.super_(c); }
        }
        return s;
    }

    Sem analyze_(Expr* e) {
        Sem s;
        switch (e->k) {
            case EK::IntLit: s.ty = tyK(K::Int); s.isLiteral = true; return s;
            case EK::FloatLit: s.ty = tyK(K::Float); s.isLiteral = true; return s;
            case EK::StrLit: s.ty = tyK(K::String); s.isLiteral = true; return s;
            case EK::NameLit: s.ty = tyK(K::Name); s.isLiteral = true; return s;
            case EK::True: case EK::False: s.ty = tyK(K::Bool); s.isLiteral = true; return s;
            case EK::None: s.ty = tyObj(Ref{}); s.none = true; s.isLiteral = true; return s;
            case EK::Self: s.ty = tyObj(cls); return s;
            case EK::VectLit: s.ty = tyStruct("Vector"); s.isLiteral = true; return s;
            case EK::RotLit: s.ty = tyStruct("Rotator"); s.isLiteral = true; return s;
            case EK::ObjLit: {
                Ref c = lower(e->s) == "class" ? Ref{} : db.findClass(e->s); if (!c && lower(e->s) != "class") fail("unknown class '" + e->s + "'", e->line);
                Ref o = db.findPath(e->s2);
                if (!o) { // path without the package? try to find it by class
                    if (lower(e->s) == "class") { o = db.findClass(e->s2.substr(e->s2.rfind('.') + 1)); }
                }
                if (!o) fail("object not found: " + e->s + "'" + e->s2 + "'", e->line);
                s.prop = o; s.isLiteral = true;
                if (lower(e->s) == "class") { s.ty.k = K::Class; s.ty.cls = o; } else s.ty = tyObj(c);
                return s;
            }
            case EK::Ident: return analyzeIdent(e);
            case EK::Member: case EK::RssMember: return analyzeMember(e);
            case EK::DefaultMember: {
                if (e->a.empty()) { Ref p = sc.findProp(cls, e->s); if (!p) fail("unknown default variable '" + e->s + "'", e->line); return varSem(p, VK::Default); }
                Sem& t = analyze(e->a[0].get()); Ref c;
                if (t.isClassName) c = t.classRef; else if (t.ty.k == K::Class) c = classOfObjType(t.ty); else if (t.ty.k == K::Object) c = classOfObjType(t.ty);
                if (!c) fail("'default' needs a class", e->line);
                Ref p = sc.findProp(c, e->s); if (!p) fail("unknown default variable '" + e->s + "' in " + db.name(c), e->line);
                Sem r = varSem(p, VK::Default); return r;
            }
            case EK::Index: {
                Sem& a = analyze(e->a[0].get()); analyze(e->a[1].get());
                if (a.ty.k == K::Array) { s.ty = a.ty.inner ? *a.ty.inner : Type(); s.vk = VK::DynElem; s.lvalue = a.lvalue || true; return s; }
                if (a.prop && db.field(a.prop).arrayDim > 1) { s.ty = a.ty; s.vk = VK::ArrayElem; s.lvalue = a.lvalue; s.prop = a.prop; return s; }
                fail("indexing something that is not an array", e->line);
            }
            case EK::Call: return analyzeCall(e);
            case EK::SuperCall: {
                Ref owner = ownerClass(func); Ref start;
                Ref stStart;
                if (!e->s2.empty()) { start = db.findClass(e->s2); if (!start) { stStart = sc.findState(cls, e->s2); if (!stStart) fail("unknown class or state '" + e->s2 + "'", e->line); } }
                Ref fn;
                if (stStart) { for (Ref ss = stStart; ss && !fn; ss = db.super_(ss)) fn = sc.find(ss, e->s, [](const std::string& c) { return c == "Function"; }, false); if (!fn) fn = sc.findFunc(cls, e->s); }
                else if (!e->s2.empty()) fn = sc.findFunc(start, e->s);
                else {
                    // inside a state: super-state; otherwise superclass
                    Ref fo = db.outer(func); bool inState = state && !stateCode ? true : stateCode;
                    if (inState && state) { Ref ss = db.super_(state); for (int g = 0; ss && !fn && g < 32; g++) { fn = sc.find(ss, e->s, [](const std::string& c) { return c == "Function"; }, false); ss = db.super_(ss); } }
                    if (!fn) fn = sc.findFunc(db.super_(owner), e->s);
                    (void)fo;
                }
                if (!fn) fail("super function '" + e->s + "' not found", e->line);
                s.fn = fn; s.ty = returnType(fn); s.vk = VK::Call; analyzeArgs(e, fn, 0); return s;
            }
            case EK::GlobalCall: { Ref fn = sc.findFunc(cls, e->s); if (!fn) fail("function '" + e->s + "' not found", e->line); s.fn = fn; s.ty = returnType(fn); s.vk = VK::Call; analyzeArgs(e, fn, 0); return s; }
            case EK::StaticCall: {
                Ref c;
                if (e->a[0]) { Sem& t = analyze(e->a[0].get()); if (t.isClassName) c = t.classRef; else if (t.ty.k == K::Class) c = classOfObjType(t.ty); else fail("'static' needs a class", e->line); }
                else c = cls;
                Ref fn = sc.findFunc(c, e->s); if (!fn) fail("static function '" + e->s + "' not found in " + db.name(c), e->line);
                s.fn = fn; s.ty = returnType(fn); s.vk = VK::Call; analyzeArgs(e, fn, 1); return s;
            }
            case EK::NativeCall: {
                auto it = natives.find((int)e->iv); if (it == natives.end()) fail("unknown native " + std::to_string(e->iv), e->line);
                s.fn = it->second; s.nativeIdx = (int)e->iv; s.ty = returnType(s.fn); s.vk = VK::Call; analyzeArgs(e, s.fn, 0); return s;
            }
            case EK::Unary: case EK::Postfix: {
                Sem& a = analyze(e->a[0].get()); (void)a;
                Ref best = pickOperator(e->s, e, 1, e->k == EK::Unary); s.fn = best; s.ty = returnType(best); s.vk = VK::Call; return s;
            }
            case EK::Binary: {
                Sem& a = analyze(e->a[0].get()); Sem& bb = analyze(e->a[1].get());
                Ref best = pickOperator(e->s, e, 2, false, true);
                if (!best) {
                    if ((e->s == "==" || e->s == "!=") && a.ty.k == K::Struct && bb.ty.k == K::Struct) { s.structCmp = true; s.ty = tyK(K::Bool); return s; }
                    if ((e->s == "==" || e->s == "!=") && (a.ty.k == K::Delegate || bb.ty.k == K::Delegate)) { s.delCmp = 1; s.ty = tyK(K::Bool); return s; }
                    fail("no operator '" + e->s + "' for " + typeStr(a.ty) + ", " + typeStr(bb.ty), e->line);
                }
                s.fn = best; s.ty = returnType(best); s.vk = VK::Call; return s;
            }
            case EK::Cond: { analyze(e->a[0].get()); Sem& a = analyze(e->a[1].get()); analyze(e->a[2].get()); s.ty = a.ty; return s; }
            case EK::New: {
                for (size_t k = 0; k < e->a.size(); k++) if (e->a[k]) analyze(e->a[k].get());
                Sem& c = analyze(e->a[3].get()); s.ty = tyObj(c.ty.k == K::Class ? classOfObjType(c.ty) : objectClass()); return s;
            }
            case EK::MetaCast: { analyze(e->a[0].get()); Ref c = db.findClass(e->s); if (!c) fail("unknown class '" + e->s + "'", e->line); s.ty.k = K::Class; s.ty.cls = c; s.castClass = c; return s; }
            default: fail("unsupported expression", e->line);
        }
    }

    Sem analyzeIdent(Expr* e) {
        Sem s; std::string ln = lower(e->s);
        auto lit = locals.find(ln);
        if (lit != locals.end()) { const FieldInfo& f = db.field(lit->second); return varSem(lit->second, (f.propFlags & CPF_OutParm) ? VK::LocalOut : VK::Local); }
        Ref p = sc.findProp(cls, e->s);
        if (p) return varSem(p, VK::Instance);
        // enum
        Ref en; int ev = -1;
        { auto it = enumValues.find(ln); if (it != enumValues.end()) { en = it->second; ev = enumIndex[ln]; } }
        if (en) { s.ty.k = K::Byte; s.ty.enm = en; s.enumVal = ev; return s; }
        Ref c = sc.findConst(cls, e->s);
        if (!c) { // const global
            for (int pk = 0; pk < (int)db.pkgs.size() && !c; pk++) { auto it = db.byPath.end(); (void)it; }
        }
        if (c) { s.constText = db.field(c).constValue; s.isLiteral = true; s.ty = constType(s.constText); return s; }
        Ref cl = db.findClass(e->s);
        if (cl) { s.isClassName = true; s.classRef = cl; s.ty.k = K::Class; s.ty.cls = cl; return s; }
        // function name (delegate value)
        Ref fn = findFunction(cls, state, e->s);
        if (fn) { s.isFuncName = true; s.fn = fn; s.ty.k = K::Delegate; s.ty.func = fn; return s; }
        fail("unknown identifier '" + e->s + "'", e->line);
    }
    Type constType(const std::string& v) {
        if (v.empty()) return tyK(K::Int);
        if (v[0] == '"') return tyK(K::String); if (v[0] == '\'') return tyK(K::Name);
        if (lower(v) == "true" || lower(v) == "false") return tyK(K::Bool);
        if (v.find('.') != std::string::npos || v.find('e') != std::string::npos) { char* end; strtod(v.c_str(), &end); if (!*end) return tyK(K::Float); }
        char* end; strtol(v.c_str(), &end, 0); if (!*end) return tyK(K::Int);
        return tyK(K::String);
    }
    Sem analyzeMember(Expr* e) {
        Sem& a = analyze(e->a[0].get()); Sem s;
        if (a.ty.k == K::Array && lower(e->s) == "length") { s.ty = tyK(K::Int); s.vk = VK::Other; s.lvalue = true; return s; }
        if (a.ty.k == K::Struct) {
            Ref m = sc.findProp(a.ty.strct, e->s); if (!m) fail("struct " + db.name(a.ty.strct) + " has no member '" + e->s + "'", e->line);
            s = varSem(m, VK::StructMember); s.lvalue = a.lvalue; return s;
        }
        Ref c;
        if (a.isClassName) { c = a.classRef; fail("use '" + e->s + "' through default. or static.", e->line); }
        if (a.ty.k == K::Object || a.ty.k == K::Interface) c = classOfObjType(a.ty);
        else if (a.ty.k == K::Class) c = db.findClass("Class") ? db.findClass("Class") : objectClass();
        if (!c) fail("'" + e->s + "': left side is not an object (" + typeStr(a.ty) + ")", e->line);
        Ref p = sc.findProp(c, e->s);
        if (!p && a.ty.k == K::Class) p = sc.findProp(objectClass(), e->s);
        if (!p) {   // const or enum value accessed through the object -> Context(obj, literal)
            Ref cn = sc.findConst(c, e->s);
            if (cn) { s.constText = db.field(cn).constValue; s.ty = constType(s.constText); s.vk = VK::Context; s.ctxLiteral = true; return s; }
            std::string ln = lower(e->s);
            for (Ref x = c; x; x = db.super_(x)) for (Ref ch : db.childrenOf(x)) if (db.cls(ch) == "Enum") { const FieldInfo& f = db.field(ch); for (size_t i = 0; i < f.enumNames.size(); i++) if (lower(db.P(ch).nm(f.enumNames[i])) == ln) { s.ty.k = K::Byte; s.ty.enm = ch; s.enumVal = (int)i; s.vk = VK::Context; s.ctxLiteral = true; return s; } }
        }
        if (!p) {
            // function used as a delegate (obj.Func)
            Ref fn = sc.findFunc(c, e->s); if (fn) { s.isFuncName = true; s.fn = fn; s.ty.k = K::Delegate; s.ty.func = fn; s.vk = VK::Context; return s; }
            fail("class " + db.name(c) + " has no variable '" + e->s + "'", e->line);
        }
        s = varSem(p, VK::Context, c); return s;
    }
    // arguments: analyze each one
    void analyzeArgs(Expr* e, Ref fn, size_t first) { for (size_t k = first; k < e->a.size(); k++) if (e->a[k]) analyze(e->a[k].get()); (void)fn; }

    Sem analyzeCall(Expr* e) {
        Sem s; size_t first = e->hasTarget ? 1 : 0;
        std::string ln = lower(e->s);
        if (e->hasTarget) {
            Sem& t = analyze(e->a[0].get());
            if (t.ty.k == K::Array) {   // dynamic array methods
                for (size_t k = 1; k < e->a.size(); k++) if (e->a[k]) analyze(e->a[k].get());
                s.vk = VK::Other; s.prop = Ref{};
                if (ln == "find") s.ty = tyK(K::Int);
                return s;
            }
            Ref c;
            if (t.ty.k == K::Object || t.ty.k == K::Interface) c = classOfObjType(t.ty);
            else if (t.ty.k == K::Class) c = db.findClass("Class") ? db.findClass("Class") : objectClass();
            else if (t.isClassName) fail("use " + e->s + " through static.", e->line);
            else fail("calling '" + e->s + "' on a non-object (" + typeStr(t.ty) + ")", e->line);
            Ref fn;
            if (!e->s2.empty()) { Ref fc = db.findClass(e->s2); if (!fc) fail("unknown class '" + e->s2 + "'", e->line); fn = sc.findFunc(fc, e->s); if (!fn) fail("function '" + e->s + "' not found in " + e->s2, e->line); s.forceFinal = true; }
            else fn = sc.findFunc(c, e->s);
            if (!fn && t.ty.k == K::Class) fn = sc.findFunc(objectClass(), e->s);
            if (!fn) {   // delegate as an object property
                Ref dp = sc.findProp(c, e->s); if (dp && db.propType(dp).k == K::Delegate) { s.isDelegateCall = true; s.prop = dp; s.fn = db.propType(dp).func; s.ty = returnType(s.fn); s.vk = VK::Call; analyzeArgs(e, s.fn, 1); return s; }
                fail("class " + db.name(c) + " has no function '" + e->s + "'", e->line);
            }
            s.fn = fn; s.ty = returnType(fn); s.vk = VK::Call; s.isIterator = (db.field(fn).funcFlags & FUNC_Iterator) != 0; analyzeArgs(e, fn, 1); return s;
        }
        // primitive / class cast
        Type pt;
        if (e->a.size() == 1 && primitiveCastType(e->s, &pt)) { Sem& a = analyze(e->a[0].get()); (void)a; s.ty = pt; s.castCode = 0; return s; }
        Ref fn = findFunction(cls, state, e->s);
        if (!fn) {
            Ref lp; auto lit = locals.find(ln); if (lit != locals.end()) lp = lit->second; else lp = sc.findProp(cls, e->s);
            if (lp && db.propType(lp).k == K::Delegate) { s.isDelegateCall = true; s.prop = lp; s.fn = db.propType(lp).func; s.ty = returnType(s.fn); s.vk = VK::Call; analyzeArgs(e, s.fn, 0); return s; }
            Ref c = db.findClass(e->s);
            if (c && e->a.size() == 1) { Sem& src = analyze(e->a[0].get()); s.dynCast = true; s.castClass = c; bool iface = (db.field(c).classFlags & 0x4000) != 0;
                // InterfaceCast: static conversion (None or a class that already implements the interface); otherwise DynamicCast (runtime check)
                s.ifaceCast = iface && (src.none || (src.ty.k == K::Object && implementsIface(classOfObjType(src.ty), c)) || src.ty.k == K::Interface); s.ty = iface ? Type{} : tyObj(c); if (iface) { s.ty.k = K::Interface; s.ty.cls = c; } return s; }
            fail("unknown function '" + e->s + "'", e->line);
        }
        s.fn = fn; s.ty = returnType(fn); s.vk = VK::Call; s.isIterator = (db.field(fn).funcFlags & FUNC_Iterator) != 0; analyzeArgs(e, fn, 0); return s;
    }

    bool implementsIface(Ref c, Ref iface) {
        for (int g = 0; c && g < 64; g++) { for (i32 ii : db.field(c).interfaces) { Ref ir = db.resolve(c.pkg, ii); if (ir && db.isChildOf(ir, iface)) return true; } c = db.super_(c); }
        return false;
    }
    // operators: pick the cheapest one
    Ref pickOperator(const std::string& sym, Expr* e, int nops, bool pre, bool allowFail = false) {
        auto it = operators.find(sym); if (it == operators.end()) { if (allowFail) return Ref{}; fail("unknown operator '" + sym + "'", e->line); }
        Ref best; int bestCost = INF;
        for (Ref op : it->second) {
            const FieldInfo& f = db.field(op); const auto& ps = params(op);
            if ((int)ps.size() != nops) continue;
            if (nops == 1 && (((f.funcFlags & FUNC_PreOperator) != 0) != pre)) continue;
            // visible from the current class (Object operators are global)
            Ref owner = ownerClass(op); if (owner && !db.isChildOf(cls, owner)) continue;
            int cost = 0;
            for (int k = 0; k < nops && cost < INF; k++) {
                Sem& as = analyze(e->a[k].get());
                int c = convCost(as.ty, as, ps[k].ty, ps[k].flags);
                if (c >= INF) { cost = INF; break; }
                if ((ps[k].flags & CPF_OutParm) && !as.lvalue) { cost = INF; break; }
                cost += c;
            }
            if (cost < bestCost) { bestCost = cost; best = op; }
        }
        if (!best && !allowFail) fail("no matching operator '" + sym + "'", e->line);
        return best;
    }

    // ---------------------------------------------------------- expression emission
    void emitLiteralAs(Expr* e, Sem& s, const Type& want) {
        int line = e->line;
        // enum / const constants
        if (s.enumVal >= 0) { if (want.k == K::Int) { emitInt(s.enumVal); return; } b(EX_ByteConst); b((u8)s.enumVal); return; }
        if (!s.constText.empty()) { emitConstText(s.constText, want, line); return; }
        switch (e->k) {
            case EK::IntLit: {
                long long v = e->iv;
                if (want.k == K::Byte) { b(EX_ByteConst); b((u8)v); return; }
                if (want.k == K::Float) { b(EX_FloatConst); f4((float)v); return; }
                if (want.k == K::String && false) {}
                emitInt((i32)v); return;
            }
            case EK::FloatLit: {
                if (want.k == K::Int) { emitInt((i32)floatOf(e)); return; }
                if (want.k == K::Byte) { b(EX_ByteConst); b((u8)(int)floatOf(e)); return; }
                b(EX_FloatConst); f4(floatOf(e)); return;
            }
            case EK::StrLit: {
                if (want.k == K::Name) { b(EX_NameConst); name(e->s, line); return; }
                bool uni = false; for (unsigned char ch : e->s) if (ch >= 128) uni = true;
                if (uni) { b(EX_UnicodeStringConst); for (unsigned char ch : e->s) w(ch); w(0); return; }
                b(EX_StringConst); for (char ch : e->s) b((u8)ch); b(0); return;
            }
            case EK::NameLit: b(EX_NameConst); name(e->s, line); return;
            case EK::True: b(EX_True); return;
            case EK::False: b(EX_False); return;
            case EK::None: if (want.k == K::Delegate) b(EX_EmptyDelegate); else b(EX_NoObject); return;
            case EK::VectLit: b(EX_VectorConst); for (int k = 0; k < 3; k++) f4((float)e->fv[k]); return;
            case EK::RotLit: b(EX_RotationConst); for (int k = 0; k < 3; k++) i4(e->rv[k]); return;
            case EK::ObjLit: b(EX_ObjectConst); ref(s.prop, line); return;
            default: fail("bad literal", line);
        }
    }
    static float floatOf(const Expr* e) { if (!e->s.empty()) return strtof(e->s.c_str(), nullptr); return (float)e->fv[0]; }
    void emitInt(i32 v) { if (v == 0) b(EX_IntZero); else if (v == 1) b(EX_IntOne); else if (v >= 2 && v <= 255) { b(EX_IntConstByte); b((u8)v); } else { b(EX_IntConst); i4(v); } }
    void emitConstText(const std::string& v, const Type& want, int line) {
        Type t = constType(v);
        if (t.k == K::String) { std::string s = v; if (s.size() >= 2 && s[0] == '"') s = s.substr(1, s.size() - 2); b(EX_StringConst); for (char ch : s) b((u8)ch); b(0); return; }
        if (t.k == K::Name) { std::string s = v.substr(1, v.size() - 2); b(EX_NameConst); name(s, line); return; }
        if (t.k == K::Bool) { b(lower(v) == "true" ? EX_True : EX_False); return; }
        if (t.k == K::Float) { float f = (float)strtod(v.c_str(), nullptr); if (want.k == K::Int) emitInt((i32)f); else if (want.k == K::Byte) { b(EX_ByteConst); b((u8)(int)f); } else { b(EX_FloatConst); f4(f); } return; }
        long iv = strtol(v.c_str(), nullptr, 0);
        if (want.k == K::Byte) { b(EX_ByteConst); b((u8)iv); } else if (want.k == K::Float) { b(EX_FloatConst); f4((float)iv); } else emitInt((i32)iv);
    }

    // emits converting to 'want' (nullptr = no conversion)
    void emitAs(Expr* e, const Type* want, bool coerce = false, bool lv = false) {
        Sem& s = analyze(e);
        if (want && s.isLiteral && !s.none && e->k != EK::ObjLit && e->k != EK::VectLit && e->k != EK::RotLit) {
            bool literalOk = (want->k == K::Byte || want->k == K::Int || want->k == K::Float) && (s.ty.k == K::Int || s.ty.k == K::Float || s.ty.k == K::Byte);
            if (literalOk || s.enumVal >= 0 || !s.constText.empty() || sameType(s.ty, *want)) { emitLiteralAs(e, s, *want); return; }
            if (want->k == K::Name && e->k == EK::StrLit) { emitLiteralAs(e, s, *want); return; }
        }
        if (want && s.none) { emitLiteralAs(e, s, *want); return; }
        if (want && !sameType(s.ty, *want) && want->k != K::None && s.ty.k != K::None) {
            bool needCast = true;
            if ((s.ty.k == K::Object && want->k == K::Object) || (s.ty.k == K::Class && want->k == K::Class) || (s.ty.k == K::Interface && want->k == K::Interface) || (s.ty.k == K::Class && want->k == K::Object)) needCast = false;
            if (s.ty.k == K::Byte && want->k == K::Byte) needCast = false;
            if (s.ty.k == K::Delegate && want->k == K::Delegate) needCast = false;
            if (s.ty.k == K::Array && want->k == K::Array) needCast = false;
            if (needCast) {
                bool au; int cc = convCode(s.ty, *want, &au);
                if (cc >= 0 && (au || coerce)) { b(EX_PrimitiveCast); b((u8)cc); emitExpr(e, lv); return; }
                fail("type mismatch: " + typeStr(s.ty) + " -> " + typeStr(*want), e->line);
            }
        }
        if (want && s.isLiteral && !s.none) { emitLiteralAs(e, s, *want); return; }
        emitExpr(e, lv);
    }

    // variable (with BoolVariable when bool)
    void emitVarToken(const Sem& s, int line) {
        switch (s.vk) {
            case VK::Local: b(EX_LocalVariable); break; case VK::LocalOut: b(EX_LocalOutVariable); break;
            case VK::Instance: b(EX_InstanceVariable); break; case VK::Default: b(EX_DefaultVariable); break; default: fail("internal: var kind", line);
        }
        ref(s.prop, line);
    }
    bool isBoolVar(const Sem& s) { return s.ty.k == K::Bool && s.prop && (s.vk == VK::Local || s.vk == VK::LocalOut || s.vk == VK::Instance || s.vk == VK::Default || s.vk == VK::Context || s.vk == VK::StructMember); }

    void emitExpr(Expr* e, bool lv = false) {
        Sem& s = analyze(e); int line = e->line;
        if (s.isLiteral && !s.ctxLiteral) { emitLiteralAs(e, s, s.ty); return; }
        if (s.enumVal >= 0 && !s.ctxLiteral) { b(EX_ByteConst); b((u8)s.enumVal); return; }
        switch (e->k) {
            case EK::Self: b(EX_Self); return;
            case EK::Ident: {
                if (s.isFuncName) { b(EX_DelegateProperty); name(db.name(s.fn), line); return; }
                if (s.ty.k == K::Bool) b(EX_BoolVariable);
                emitVarToken(s, line); return;
            }
            case EK::DefaultMember: {
                if (e->a.empty()) { if (s.ty.k == K::Bool) b(EX_BoolVariable); emitVarToken(s, line); return; }
                // Class.default.X -> ClassContext(class, DefaultVariable) ; object.default.X -> Context(object, DefaultVariable)
                Sem& t = analyze(e->a[0].get());
                if (!t.isClassName && t.ty.k == K::Object) { emitContext(e->a[0].get(), false, [&] { if (s.ty.k == K::Bool) b(EX_BoolVariable); b(EX_DefaultVariable); ref(s.prop, line); }, resultSize(s.ty), line); return; }
                b(EX_ClassContext); if (t.isClassName) { b(EX_ObjectConst); ref(t.classRef, line); } else emitExpr(e->a[0].get());
                size_t at = code.size(); w(0); w((uint16_t)resultSize(s.ty)); size_t st = code.size();
                if (s.ty.k == K::Bool) b(EX_BoolVariable); b(EX_DefaultVariable); ref(s.prop, line);
                patchW(at, (uint16_t)(code.size() - st)); return;
            }
            case EK::Member: case EK::RssMember: {
                Sem& a = analyze(e->a[0].get());
                if (s.ctxLiteral) {
                    emitContext(e->a[0].get(), e->k == EK::RssMember, [&] { if (s.enumVal >= 0) { b(EX_ByteConst); b((u8)s.enumVal); } else emitConstText(s.constText, s.ty, line); }, resultSize(s.ty), line);
                    return;
                }
                if (a.ty.k == K::Array) { b(EX_DynArrayLength); emitExpr(e->a[0].get(), lv); return; }
                if (s.vk == VK::StructMember) {
                    bool copy = !isAddressable(e->a[0].get());
                    if (s.ty.k == K::Bool) b(EX_BoolVariable);
                    b(EX_StructMember); ref(s.prop, line); ref(a.ty.strct, line); b(copy ? 1 : 0); b(lv && !baseIsStructMember(e->a[0].get()) ? 1 : 0); emitExpr(e->a[0].get(), lv); return;
                }
                if (s.isFuncName) { emitContext(e->a[0].get(), e->k == EK::RssMember, [&] { b(EX_DelegateProperty); name(db.name(s.fn), line); }, 12, line); return; }
                { bool sv = ctxLv; ctxLv = lv; emitContext(e->a[0].get(), e->k == EK::RssMember, [&] { ctxLv = sv; if (s.ty.k == K::Bool) b(EX_BoolVariable); b(EX_InstanceVariable); ref(s.prop, line); }, varResultSize(s.prop, s.ty), line); ctxLv = sv; }
                return;
            }
            case EK::Index: {
                Sem& a = analyze(e->a[0].get());
                if (s.vk == VK::DynElem) { b(EX_DynArrayElement); emitAs(e->a[1].get(), &tyIntRef()); emitExpr(e->a[0].get(), lv); return; }
                b(EX_ArrayElement); emitAs(e->a[1].get(), &tyIntRef()); emitExpr(e->a[0].get(), lv); (void)a; return;
            }
            case EK::Call: emitCall(e, false); return;
            case EK::SuperCall: { b(EX_FinalFunction); ref(s.fn, line); emitArgs(e, s.fn, 0); return; }
            case EK::GlobalCall: { b(EX_GlobalFunction); name(e->s, line); emitArgs(e, s.fn, 0); return; }
            case EK::NativeCall: { emitNativeToken(s.nativeIdx); emitArgs(e, s.fn, 0); return; }
            case EK::StaticCall: {
                if (!e->a[0]) { emitFuncToken(s.fn, line); emitArgs(e, s.fn, 1); return; }
                Sem& t = analyze(e->a[0].get());
                b(EX_ClassContext); if (t.isClassName) { b(EX_ObjectConst); ref(t.classRef, line); } else emitExpr(e->a[0].get());
                size_t at = code.size(); w(0); w((uint16_t)resultSize(s.ty)); size_t st = code.size();
                emitFuncToken(s.fn, line); emitArgs(e, s.fn, 1);
                patchW(at, (uint16_t)(code.size() - st)); return;
            }
            case EK::Unary: case EK::Postfix: case EK::Binary: {
                if (s.delCmp >= 0) {
                    Sem& r = analyze(e->a[1].get()); bool eq = e->s == "==";
                    b(r.isFuncName ? (eq ? EX_EqualEqual_DelFunc : EX_NotEqual_DelFunc) : (eq ? EX_EqualEqual_DelDel : EX_NotEqual_DelDel));
                    Type dt; dt.k = K::Delegate; emitAs(e->a[0].get(), &dt); emitAs(e->a[1].get(), &dt); b(EX_EndFunctionParms); return;
                }
                if (s.structCmp) { b(e->s == "==" ? EX_StructCmpEq : EX_StructCmpNe); ref(analyze(e->a[0].get()).ty.strct, line); emitExpr(e->a[0].get()); emitExpr(e->a[1].get()); return; }
                const FieldInfo& f = db.field(s.fn);
                if (f.iNative) emitNativeToken(f.iNative); else { b(EX_FinalFunction); ref(s.fn, line); }
                const auto& ps = params(s.fn);
                for (size_t k = 0; k < ps.size(); k++) emitParam(e->a[k].get(), ps[k]);
                b(EX_EndFunctionParms); return;
            }
            case EK::Cond: {
                b(EX_Conditional); emitAs(e->a[0].get(), &tyBoolRef());
                size_t at = code.size(); w(0); size_t st = code.size(); emitAs(e->a[1].get(), &s.ty); patchW(at, (uint16_t)(code.size() - st));
                at = code.size(); w(0); st = code.size(); emitAs(e->a[2].get(), &s.ty); patchW(at, (uint16_t)(code.size() - st)); return;
            }
            case EK::New: {
                b(EX_New);
                for (int k = 0; k < 3; k++) { if (e->a[k]) { static Type tn; tn = k == 0 ? tyObj(objectClass()) : k == 1 ? tyK(K::String) : tyK(K::Int); emitAs(e->a[k].get(), k == 0 ? nullptr : &tn); } else b(EX_Nothing); }
                emitExpr(e->a[3].get());
                if (e->a.size() > 4 && e->a[4]) emitExpr(e->a[4].get()); else b(EX_Nothing);
                return;
            }
            case EK::MetaCast: { b(EX_MetaCast); ref(s.castClass, line); emitExpr(e->a[0].get()); return; }
            default: fail("cannot emit expression", line);
        }
    }
    const Type& tyIntRef() { static Type t; t.k = K::Int; return t; }
    const Type& tyBoolRef() { static Type t; t.k = K::Bool; return t; }
    bool isAddressable(Expr* e) {
        Sem& s = analyze(e);
        switch (e->k) {
            case EK::Ident: case EK::DefaultMember: return s.prop.pkg >= 0;
            case EK::Member: case EK::RssMember: return s.vk == VK::StructMember ? isAddressable(e->a[0].get()) : true;
            case EK::Index: return s.vk == VK::DynElem ? isAddressable(e->a[0].get()) : isAddressable(e->a[0].get());
            default: return false;
        }
    }
    int varResultSize(const Ref& prop, const Type& t) { if (t.k == K::String || t.k == K::Array) return 0; return db.propSize(prop); }
    // base of a StructMember (going down through array elements) is another StructMember?
    bool baseIsStructMember(Expr* x) {
        for (int g = 0; x && g < 32; g++) {
            Sem& s = analyze(x);
            if ((x->k == EK::Member || x->k == EK::RssMember) && s.vk == VK::StructMember) return true;
            if (x->k == EK::Index) { x = x->a[0].get(); continue; }
            return false;
        }
        return false;
    }
    bool isOuterExpr(Expr* x) {
        if (x->k != EK::Ident && x->k != EK::Member) return false;
        Sem& s = analyze(x); return s.prop && lower(db.name(s.prop)) == "outer" && db.path(s.prop) == "Core.Object.Outer";
    }
    template <class F> void emitContext(Expr* obj, bool rss, F right, int rsize, int line) {
        // UCC: a context on "Outer" ('within' class) writes a fixed skip = 5; "A.Outer.B" becomes Context(A, Context(Outer, B))
        if (isOuterExpr(obj)) {
            // (the original UCC writes skip 5 in most of these contexts - harmless bug, Outer is never None;
            //  here the correct skip is written)
            size_t iat = 0, ist = 0;
            auto inner = [&]() { b(rss ? EX_RSSContext : EX_Context); b(EX_InstanceVariable); ref(analyze(obj).prop, line); iat = code.size(); w(0); w((uint16_t)rsize); ist = code.size(); right(); patchW(iat, (uint16_t)(code.size() - ist)); };
            if (obj->k == EK::Ident) { inner(); lastContextSkipAt = iat; lastContextStart = ist; return; }
            b(EX_Context); emitExpr(obj->a[0].get()); size_t at = code.size(); w(0); w(0); size_t st = code.size();
            inner(); patchW(at, (uint16_t)(code.size() - st)); lastContextSkipAt = at; lastContextStart = st; return;
        }
        Sem& o = analyze(obj);
        b(rss ? EX_RSSContext : EX_Context);
        if (o.ty.k == K::Interface) { b(EX_InterfaceContext); emitExpr(obj, ctxLv); } else emitExpr(obj, ctxLv);
        size_t at = code.size(); w(0); w((uint16_t)rsize); size_t st = code.size();
        right(); patchW(at, (uint16_t)(code.size() - st)); (void)line;
        lastContextSkipAt = at; lastContextStart = st;
    }
    size_t lastContextSkipAt = 0, lastContextStart = 0; bool ctxLv = false;
    void emitNativeToken(int n) { if (n < 0x100) b((u8)n); else { b((u8)(EX_ExtendedNative + (n >> 8))); b((u8)(n & 0xFF)); } }
    void emitFuncToken(Ref fn, int line) {
        const FieldInfo& f = db.field(fn);
        if (f.iNative) { emitNativeToken(f.iNative); return; }
        if (f.funcFlags & FUNC_Final) { b(EX_FinalFunction); ref(fn, line); return; }
        b(EX_VirtualFunction); name(db.name(fn), line);
    }
    void emitParam(Expr* a, const Param& p) {
        if (!a) { b(EX_EmptyParmValue); return; }
        bool out = (p.flags & CPF_OutParm) != 0;
        if (p.flags & CPF_SkipParm) { b(EX_Skip); size_t at = code.size(); w(0); size_t st = code.size(); emitAs(a, &p.ty, (p.flags & CPF_CoerceParm) != 0, out); patchW(at, (uint16_t)(code.size() - st + 1)); return; }
        emitAs(a, &p.ty, (p.flags & CPF_CoerceParm) != 0, out);
    }
    void emitArgs(Expr* e, Ref fn, size_t first) {
        const auto& ps = params(fn); size_t na = e->a.size() - first;
        if (na > ps.size()) fail("too many arguments for " + db.name(fn), e->line);
        for (size_t k = 0; k < ps.size(); k++) {
            Expr* a = k < na ? e->a[first + k].get() : nullptr;
            if (!a && !(ps[k].flags & CPF_OptionalParm)) fail("missing argument '" + db.name(ps[k].prop) + "' for " + db.name(fn), e->line);
            emitParam(a, ps[k]);
        }
        b(EX_EndFunctionParms);
    }
    void emitCall(Expr* e, bool /*stmt*/) {
        Sem& s = analyze(e); int line = e->line;
        if (s.castCode == 0) {   // explicit primitive cast
            Sem& a = analyze(e->a[0].get());
            if (a.isLiteral && !a.none && a.constText.empty() && (e->a[0]->k == EK::IntLit || e->a[0]->k == EK::FloatLit) && (s.ty.k == K::Int || s.ty.k == K::Float || s.ty.k == K::Byte)) { emitLiteralAs(e->a[0].get(), a, s.ty); return; }
            if (sameType(a.ty, s.ty)) { emitExpr(e->a[0].get()); return; }
            bool au; int cc = convCode(a.ty, s.ty, &au); if (cc < 0) fail("cannot cast " + typeStr(a.ty) + " to " + typeStr(s.ty), line);
            b(EX_PrimitiveCast); b((u8)cc); emitExpr(e->a[0].get()); return;
        }
        if (s.dynCast) { b(s.ifaceCast ? EX_InterfaceCast : EX_DynamicCast); ref(s.castClass, line); emitExpr(e->a[0].get()); return; }
        if (e->hasTarget) {
            Sem& t = analyze(e->a[0].get());
            if (t.ty.k == K::Array) { emitArrayMethod(e, t); return; }
            int rs = s.fn ? resultSize(s.ty) : 0;
            emitContext(e->a[0].get(), e->iv == 1, [&] { emitCallBody(e, s, 1); }, rs, line);
            return;
        }
        emitCallBody(e, s, 0);
    }
    void emitCallBody(Expr* e, Sem& s, size_t first) {
        int line = e->line;
        if (s.isDelegateCall) { b(EX_DelegateFunction); b(s.prop && db.cls(db.outer(s.prop)) == "Function" ? 1 : 0); ref(s.prop, line); name(db.name(s.fn), line); emitArgs(e, s.fn, first); return; }
        if (s.forceFinal) { b(EX_FinalFunction); ref(s.fn, line); emitArgs(e, s.fn, first); return; }
        emitFuncToken(s.fn, line); emitArgs(e, s.fn, first);
    }
    void emitArrayMethod(Expr* e, Sem& t) {
        std::string m = lower(e->s); int line = e->line; Type inner = t.ty.inner ? *t.ty.inner : Type();
        auto arg = [&](size_t k) -> Expr* { if (k >= e->a.size() || !e->a[k]) fail("missing argument for " + e->s, line); return e->a[k].get(); };
        if (m == "add") { b(EX_DynArrayAdd); emitExpr(e->a[0].get(), false); emitAs(arg(1), &tyIntRef()); return; }
        if (m == "remove") { b(EX_DynArrayRemove); emitExpr(e->a[0].get(), false); emitAs(arg(1), &tyIntRef()); emitAs(arg(2), &tyIntRef()); return; }
        if (m == "insert") { b(EX_DynArrayInsert); emitExpr(e->a[0].get(), false); emitAs(arg(1), &tyIntRef()); emitAs(arg(2), &tyIntRef()); return; }
        if (m == "additem" || m == "removeitem") { b(m == "additem" ? EX_DynArrayAddItem : EX_DynArrayRemoveItem); emitExpr(e->a[0].get(), false); size_t at = code.size(); w(0); size_t st = code.size(); emitAs(arg(1), &inner); patchW(at, (uint16_t)(code.size() - st)); return; }
        if (m == "insertitem") { b(EX_DynArrayInsertItem); emitExpr(e->a[0].get(), false); size_t at = code.size(); w(0); size_t st = code.size(); emitAs(arg(1), &tyIntRef()); emitAs(arg(2), &inner); patchW(at, (uint16_t)(code.size() - st)); return; }
        if (m == "find") {
            if (e->a.size() >= 3) {   // Find(member, value)
                b(EX_DynArrayFindStruct); emitExpr(e->a[0].get()); size_t at = code.size(); w(0); size_t st = code.size();
                Expr* mn = arg(1); Ref mem;
                if (mn->k == EK::NameLit) mem = sc.findProp(inner.strct, mn->s);
                Type mt = mem ? db.propType(mem) : Type();
                emitAs(mn, nullptr); emitAs(arg(2), mem ? &mt : nullptr); patchW(at, (uint16_t)(code.size() - st)); return;
            }
            b(EX_DynArrayFind); emitExpr(e->a[0].get()); size_t at = code.size(); w(0); size_t st = code.size(); emitAs(arg(1), &inner); patchW(at, (uint16_t)(code.size() - st)); return;
        }
        fail("unknown array method '" + e->s + "'", line);
    }

    // ---------------------------------------------------------- statements
    struct Loop { std::vector<size_t> breaks, conts; bool isSwitch = false, isIter = false; size_t contTarget = 0; bool contKnown = false; };
    std::vector<Loop> loops;
    std::map<std::string, size_t> labels; std::vector<std::pair<size_t, std::string>> gotoFix;   // jumps to labels (extension)
    std::vector<std::pair<std::string, size_t>> stateLabels;

    uint16_t here() { if (code.size() > 0xFFFF) fail("function too big", 0); return (uint16_t)code.size(); }
    void jumpTo(size_t target) { b(EX_Jump); w((uint16_t)target); }
    size_t jumpFwd() { b(EX_Jump); size_t at = code.size(); w(0); return at; }
    void condJump(Expr* c, size_t* at) { b(EX_JumpIfNot); *at = code.size(); w(0); emitAs(c, &tyBoolRef()); }

    void stmt(Stmt* s) {
        int line = s->line;
        switch (s->k) {
            case SK::Empty: case SK::Local: return;
            case SK::Block: for (auto& x : s->body) stmt(x.get()); return;
            case SK::Expr: {
                Sem& se = analyze(s->e.get());
                if (se.vk == VK::Call && se.fn && !se.isDelegateCall && needsDestruct(se.ty)) { b(EX_EatReturnValue); ref(returnProp(se.fn), line); }
                emitExpr(s->e.get()); return;
            }
            case SK::Assign: {
                Sem& l = analyze(s->e.get()); analyze(s->e2.get());
                if (!l.lvalue) fail("left side of '=' is not assignable", line);
                if (l.ty.k == K::Bool) b(EX_LetBool); else if (l.ty.k == K::Delegate) b(EX_LetDelegate); else b(EX_Let);
                emitExpr(s->e.get(), true); emitAs(s->e2.get(), &l.ty); return;
            }
            case SK::Return: {
                for (auto& L : loops) if (L.isIter) b(EX_IteratorPop);
                b(EX_Return);
                if (s->e) { if (!retProp) fail("function returns nothing", line); Type rt = db.propType(retProp); emitAs(s->e.get(), &rt); }
                else if (retProp) { b(EX_ReturnNothing); ref(retProp, line); }
                else b(EX_Nothing);
                return;
            }
            case SK::Nothing: b(EX_Nothing); return;
            case SK::IterPop: b(s->label == "next" ? EX_IteratorNext : EX_IteratorPop); return;
            case SK::JumpIfNot: { b(EX_JumpIfNot); gotoFix.push_back({ code.size(), lower(s->label) }); w(0); emitAs(s->e.get(), &tyBoolRef()); return; }
            case SK::If: {
                size_t at; condJump(s->e.get(), &at); stmt(s->s1.get());
                if (s->s2) { size_t j = jumpFwd(); patchW(at, here()); stmt(s->s2.get()); patchW(j, here()); }
                else patchW(at, here());
                return;
            }
            case SK::While: {
                size_t top = here(); size_t at; condJump(s->e.get(), &at);
                loops.push_back(Loop()); loops.back().contTarget = top; loops.back().contKnown = true;
                stmt(s->s1.get()); jumpTo(top); size_t end = here(); patchW(at, (uint16_t)end);
                finishLoop(end); return;
            }
            case SK::DoUntil: {
                size_t top = here(); loops.push_back(Loop());
                stmt(s->s1.get()); size_t ct = here(); size_t at; condJump(s->e.get(), &at); patchW(at, (uint16_t)top);
                Loop& L = loops.back(); for (size_t c : L.conts) patchW(c, (uint16_t)ct);
                finishLoop(here()); return;
            }
            case SK::For: {
                if (s->s1) stmt(s->s1.get());
                size_t top = here(); size_t at = 0; bool hasCond = (bool)s->e; if (hasCond) condJump(s->e.get(), &at);
                loops.push_back(Loop());
                stmt(s->s2.get()); size_t inc = here(); for (size_t c : loops.back().conts) patchW(c, (uint16_t)inc); loops.back().conts.clear();
                if (s->s3) stmt(s->s3.get()); jumpTo(top); size_t end = here(); if (hasCond) patchW(at, (uint16_t)end);
                finishLoop(end); return;
            }
            case SK::ForEach: {
                Expr* it = s->e.get();
                // foreach Array(Item, Index) / foreach Obj.Array(Item, Index)
                EP arrExpr;
                if (it->k == EK::Call) {
                    bool isArr = false;
                    if (it->hasTarget) { Sem& ts = analyze(it->a[0].get()); if (ts.ty.k == K::Object) { Ref p = sc.findProp(classOfObjType(ts.ty), it->s); isArr = p && db.propType(p).k == K::Array; } }
                    else { auto lit = locals.find(lower(it->s)); Ref p = lit != locals.end() ? lit->second : sc.findProp(cls, it->s); isArr = p && db.propType(p).k == K::Array; }
                    if (isArr) {
                        arrExpr.reset(new Expr()); arrExpr->line = it->line; arrExpr->s = it->s;
                        if (it->hasTarget) { arrExpr->k = EK::Member; arrExpr->a.push_back(std::move(it->a[0])); it->a.erase(it->a.begin()); it->hasTarget = false; }
                        else arrExpr->k = EK::Ident;
                        it->a.insert(it->a.begin(), std::move(arrExpr)); it->hasTarget = true; it->s = "__foreach_array";
                    }
                }
                bool dynArr = it->k == EK::Call && it->hasTarget && analyze(it->a[0].get()).ty.k == K::Array;
                if (dynArr) {   // foreach Array(Item, Index)
                    b(EX_DynArrayIterator); emitExpr(it->a[0].get()); if (it->a.size() < 2 || !it->a[1]) fail("foreach array needs an item variable", line);
                    size_t actxAt = lastContextSkipAt, actxSt = lastContextStart; bool arrCtx = code.size() > 0 && it->a[0]->k == EK::Member && analyze(it->a[0].get()).vk == VK::Context;
                    emitExpr(it->a[1].get(), true); bool hasIdx = it->a.size() > 2 && it->a[2]; b(hasIdx ? 1 : 0); if (hasIdx) emitExpr(it->a[2].get(), true); else b(EX_EmptyParmValue);
                    size_t at = code.size(); w(0);
                    loops.push_back(Loop()); loops.back().isIter = true;
                    stmt(s->s1.get()); size_t nx = here(); b(EX_IteratorNext); for (size_t c : loops.back().conts) patchW(c, (uint16_t)nx); loops.back().conts.clear();
                    size_t pop = here(); b(EX_IteratorPop); patchW(at, (uint16_t)pop);
                    if (arrCtx) patchW(actxAt, (uint16_t)(pop - actxSt));
                    finishLoop(pop); return;
                }
                Sem& is = analyze(it); if (!is.isIterator) fail("foreach needs an iterator function", line);
                b(EX_Iterator);
                size_t ctxAt = (size_t)-1, ctxSt = 0;
                if (it->k == EK::Call && it->hasTarget) { emitCall(it, false); ctxAt = lastContextSkipAt; ctxSt = lastContextStart; }
                else emitExpr(it);
                size_t at = code.size(); w(0);
                loops.push_back(Loop()); loops.back().isIter = true;
                stmt(s->s1.get()); size_t nx = here(); b(EX_IteratorNext); for (size_t c : loops.back().conts) patchW(c, (uint16_t)nx); loops.back().conts.clear();
                size_t pop = here(); b(EX_IteratorPop); patchW(at, (uint16_t)pop);
                if (ctxAt != (size_t)-1) patchW(ctxAt, (uint16_t)(pop - ctxSt));
                finishLoop(pop); return;
            }
            case SK::Switch: {
                Sem& v = analyze(s->e.get());
                b(EX_Switch); w((uint16_t)resultSize(v.ty)); emitExpr(s->e.get());
                loops.push_back(Loop()); loops.back().isSwitch = true;
                size_t pendingCase = (size_t)-1;
                for (auto& x : s->body) {
                    if (x->k == SK::Case || x->k == SK::Default) {
                        if (pendingCase != (size_t)-1) patchW(pendingCase, here());
                        b(EX_Case);
                        if (x->k == SK::Default) { w(0xFFFF); pendingCase = (size_t)-1; }
                        else { pendingCase = code.size(); w(0); emitAs(x->e.get(), &v.ty); }
                        continue;
                    }
                    stmt(x.get());
                }
                if (pendingCase != (size_t)-1) patchW(pendingCase, here());
                finishLoop(here()); return;
            }
            case SK::Case: case SK::Default: fail("'case' outside switch", line);
            case SK::Break: {
                if (loops.empty()) fail("'break' outside loop", line);
                loops.back().breaks.push_back(jumpFwd()); return;   // in foreach: jumps to the IteratorPop
            }
            case SK::Continue: {
                int k = (int)loops.size() - 1; while (k >= 0 && loops[k].isSwitch) k--;
                if (k < 0) fail("'continue' outside loop", line);
                if (loops[k].contKnown) jumpTo(loops[k].contTarget); else loops[k].conts.push_back(jumpFwd());
                return;
            }
            case SK::Stop: b(EX_Stop); return;
            case SK::Label: {
                if (stateCode) { stateLabels.push_back({ s->label, code.size() }); }
                labels[lower(s->label)] = code.size(); return;
            }
            case SK::Goto: {
                // goto to a jump label (extension: J0x0000 / names) inside the function
                b(EX_Jump); gotoFix.push_back({ code.size(), lower(s->label) }); w(0); return;
            }
            case SK::GotoExpr: { b(EX_GotoLabel); Type nt = tyK(K::Name); emitAs(s->e.get(), &nt); return; }
            case SK::Assert: { b(EX_Assert); w((uint16_t)(s->e2 ? s->e2->iv : line)); b(0); emitAs(s->e.get(), &tyBoolRef()); return; }
            default: fail("unsupported statement", line);
        }
    }
    void finishLoop(size_t end) {
        Loop L = loops.back(); loops.pop_back();
        for (size_t at : L.breaks) patchW(at, (uint16_t)end);
        if (!L.conts.empty()) {
            // continue inside a switch: passed on to the outer loop
            if (!loops.empty()) for (size_t c : L.conts) loops.back().conts.push_back(c);
        }
    }

    // ---------------------------------------------------------- compiling a function / state
    // src = body (without the signature); defaults = expressions (text) of the default values of the optional parameters, in order
    std::vector<u8> compileBody(Ref fn, const std::string& src, const std::vector<std::string>* defaults = nullptr) {
        code.clear(); sems.clear(); loops.clear(); labels.clear(); gotoFix.clear(); stateLabels.clear(); idxCache.clear();
        func = fn; pi = fn.pkg; std::string c = db.cls(fn);
        stateCode = c == "State";
        Ref o = db.outer(fn);
        if (stateCode) { state = fn; cls = o; }
        else if (db.cls(o) == "State") { state = o; cls = db.outer(o); }
        else { state = Ref{}; cls = o; }
        locals.clear(); retProp = Ref{};
        if (!stateCode) for (Ref ch : db.children(fn)) { const FieldInfo& f = db.field(ch); if (!f.isProperty) continue; if (f.propFlags & CPF_ReturnParm) { retProp = ch; continue; } locals[lower(db.name(ch))] = ch; }
        // default values of the optionals
        if (defaults) {
            const auto& ps = params(fn); size_t di = 0;
            for (auto& p : ps) {
                if (!(p.flags & CPF_OptionalParm)) continue;
                if (di >= defaults->size()) break;
                const std::string& d = (*defaults)[di++]; if (d.empty()) { b(EX_Nothing); continue; }
                Parser dp(d, optable); EP de = dp.parseExpr();
                b(EX_DefaultParmValue); size_t at = code.size(); w(0); size_t st = code.size(); emitAs(de.get(), &p.ty); b(EX_EndParmValue); patchW(at, (uint16_t)(code.size() - st));
                sems.clear();
                ownedDefaults.push_back(std::move(de));
            }
        }
        Parser P(src, optable); std::vector<SP> prog = P.program();
        for (auto& s : prog) stmt(s.get());
        if (!stateCode) {
            b(EX_Return); if (retProp) { b(EX_ReturnNothing); ref(retProp, 0); } else b(EX_Nothing);
        }
        for (auto& g : gotoFix) { auto it = labels.find(g.second); if (it == labels.end()) fail("label not found: " + g.second, 0); patchW(g.first, (uint16_t)it->second); }
        labelTablePos = 0xFFFF;
        if (stateCode && !stateLabels.empty()) {
            labelTablePos = (uint16_t)code.size();
            b(EX_LabelTable);
            for (auto& l : stateLabels) { name(l.first, 0); i4((i32)l.second); }
            name("None", 0); i4(0xFFFF);
        }
        b(EX_EndOfScript);
        ownedDefaults.clear();
        return code;
    }
    std::vector<EP> ownedDefaults; uint16_t labelTablePos = 0xFFFF;
};

} // namespace ucc
} // namespace bm
