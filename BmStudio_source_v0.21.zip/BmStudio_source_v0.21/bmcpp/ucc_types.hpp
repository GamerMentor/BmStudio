// ucc_types.hpp - Batman: Arkham Asylum UnrealScript type model (UE3 v576/lic21) for the compiler.
// Loads several script packages (Core, Engine, CommonGame, GFxUI, IpDrv, BmGame...), resolves imports between them and
// exposes classes/states/functions/structs/enums/consts/properties with types and in-memory sizes (32-bit PC).
#pragma once
#include "bmscript.hpp"
#include <unordered_map>
#include <memory>

namespace bm {
namespace ucc {
using namespace bm::us;

inline std::string lower(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }

// reference to an object: loaded package + export index (>0). pkg = -1 -> null
struct Ref {
    int pkg = -1; i32 idx = 0;
    explicit operator bool() const { return pkg >= 0 && idx != 0; }   // idx < 0: intrinsic class (exists only as an import)
    bool operator==(const Ref& o) const { return pkg == o.pkg && idx == o.idx; }
    bool operator!=(const Ref& o) const { return !(*this == o); }
    uint64_t key() const { return ((uint64_t)(uint32_t)pkg << 32) | (uint32_t)idx; }
};

enum class K : u8 { None, Byte, Int, Bool, Float, Name, String, Object, Class, Struct, Array, Delegate, Interface, Map, Pointer };

struct Type {
    K k = K::None;
    Ref cls;          // Object/Interface: class; Class: meta class (class<cls>)
    Ref strct;        // Struct
    Ref enm;          // Byte: enum (optional)
    Ref func;         // Delegate: signature
    std::shared_ptr<Type> inner;   // Array
    bool isNone() const { return k == K::None; }
};

class TypeDB {
public:
    std::vector<Package*> pkgs; std::vector<std::unique_ptr<Package>> owned; std::vector<std::string> pkgNames;
    std::unordered_map<std::string, Ref> byPath;        // "core.object.vector" -> ref
    std::unordered_map<std::string, std::vector<Ref>> classesByName;   // short name -> classes
    std::unordered_map<std::string, std::vector<Ref>> typesByName;     // structs/enums by short name
    std::unordered_map<uint64_t, FieldInfo> fieldCache;

    // ---------------------------------------------------------- loading
    void add(const std::string& path) {
        auto p = std::make_unique<Package>(); p->load(path);
        std::string nm = path; size_t sl = nm.find_last_of("/\\"); if (sl != std::string::npos) nm = nm.substr(sl + 1); size_t dot = nm.rfind('.'); if (dot != std::string::npos) nm = nm.substr(0, dot);
        Package* raw = p.get(); owned.push_back(std::move(p)); addExternal(raw, nm);
    }
    // external package (e.g. the document open in the editor) - not copied or freed here
    int addExternal(Package* raw, const std::string& nm) {
        int pi = (int)pkgs.size(); pkgs.push_back(raw); pkgNames.push_back(nm);
        index(pi); return pi;
    }
    int find(const std::string& pkgName) const { for (size_t i = 0; i < pkgNames.size(); i++) if (strcasecmp_(pkgNames[i], pkgName)) return (int)i; return -1; }
    // (re)indexes a package (after creating new exports) and clears the caches
    void reindex(int pi) {
        for (auto it = byPath.begin(); it != byPath.end();) { if (it->second.pkg == pi && it->second.idx > 0) it = byPath.erase(it); else ++it; }
        for (auto* m : { &classesByName, &typesByName }) for (auto& kv : *m) kv.second.erase(std::remove_if(kv.second.begin(), kv.second.end(), [&](const Ref& r) { return r.pkg == pi && r.idx > 0; }), kv.second.end());
        index(pi); fieldCache.clear(); structLayout.clear();
    }
    void index(int pi) {
        const std::string& nm = pkgNames[pi];
        Package& P = *pkgs[pi];
        for (size_t k = 0; k < P.exports.size(); k++) {
            Ref r{ pi, (i32)k + 1 }; byPath[lower(nm + "." + P.objPath(r.idx))] = r;
            { i32 top = r.idx; while (P.exports[top - 1].outer > 0) top = P.exports[top - 1].outer;   // forced export (e.g. Thug_Anims.* inside a map): path without the file
              if (P.exports[top - 1].exportFlags & 1u) byPath.emplace(lower(P.objPath(r.idx)), r); }
            std::string c = P.classOf(P.exports[k]);
            if (c == "Class") classesByName[lower(P.objName(r.idx))].push_back(r);
            else if (c == "ScriptStruct" || c == "Enum") typesByName[lower(P.objName(r.idx))].push_back(r);
        }
    }
    Package& P(const Ref& r) const { return *pkgs[r.pkg]; }
    std::string name(const Ref& r) const { return r ? P(r).objName(r.idx) : "None"; }
    std::string path(const Ref& r) const { if (!r) return "None"; if (r.idx < 0) return P(r).objPath(r.idx); return pkgNames[r.pkg] + "." + P(r).objPath(r.idx); }
    std::string cls(const Ref& r) const { if (!r) return ""; if (r.idx < 0) return P(r).nm(P(r).imports[-r.idx - 1].className); return P(r).classOf(P(r).exports[r.idx - 1]); }
    // intrinsic classes (Class, BoolProperty, NetConnection...): no export in any package -> registers the import
    void finalizeIntrinsics() {
        for (int pi = 0; pi < (int)pkgs.size(); pi++) {
            Package& Pk = *pkgs[pi];
            for (size_t k = 0; k < Pk.imports.size(); k++) {
                std::string icls = Pk.nm(Pk.imports[k].className); if (icls == "Package") continue;
                i32 ii = -(i32)k - 1; std::string path = lower(Pk.objPath(ii));
                if (byPath.count(path)) continue;
                Ref r{ pi, ii }; byPath[path] = r; if (icls == "Class") classesByName[lower(Pk.objName(ii))].push_back(r);
            }
        }
    }
    // index inside a package (export >0 / import <0) -> global Ref
    Ref resolve(int pkg, i32 idx) const {
        if (idx > 0) return Ref{ pkg, idx };
        if (idx == 0) return Ref{};
        const Package& p = *pkgs[pkg]; std::string path = p.objPath(idx);
        auto it = byPath.find(lower(path)); if (it != byPath.end()) return it->second;
        return Ref{};
    }
    std::vector<Ref> childrenOf(const Ref& r) { return children(r); }
    // global Ref -> index in package 'pkg' (existing export or import); 0 if there is none
    i32 indexIn(int pkg, const Ref& r) const {
        if (!r) return 0; if (r.pkg == pkg) return r.idx;   // export (>0) or intrinsic import (<0) of the package itself
        const Package& p = *pkgs[pkg]; std::string full = path(r);
        // imports: the full path starts with the package
        for (size_t k = 0; k < p.imports.size(); k++) { i32 ii = -(i32)k - 1; if (strcasecmp_(p.objPath(ii), full)) return ii; }
        return 0;
    }
    static bool strcasecmp_(const std::string& a, const std::string& b) { return Package::strcasecmp_(a, b); }
    const FieldInfo& field(const Ref& r) {
        static const FieldInfo empty; if (!r || r.idx < 0) return empty;
        auto it = fieldCache.find(r.key()); if (it != fieldCache.end()) return it->second;
        return fieldCache.emplace(r.key(), parseField(P(r), r.idx)).first->second;
    }
    Ref super_(const Ref& r) { const FieldInfo& f = field(r); return resolve(r.pkg, f.superField); }
    Ref outer(const Ref& r) const { return resolve(r.pkg, P(r).outerOf(r.idx)); }
    std::vector<Ref> children(const Ref& r) {
        std::vector<Ref> out; if (!r) return out;
        if (r.idx < 0) { Package& Pk = P(r); for (size_t k = 0; k < Pk.imports.size(); k++) if (Pk.imports[k].outer == r.idx) out.push_back(Ref{ r.pkg, -(i32)k - 1 }); return out; }
        const FieldInfo& f = field(r); Ref c = resolve(r.pkg, f.children);
        for (int g = 0; c && g < 50000; g++) { out.push_back(c); const FieldInfo& cf = field(c); if (!cf.ok) break; c = resolve(c.pkg, cf.next); }
        return out;
    }
    bool isChildOf(Ref c, const Ref& base) { for (int g = 0; c && g < 64; g++) { if (c == base) return true; c = super_(c); } return false; }
    Ref findClass(const std::string& n) const { auto it = classesByName.find(lower(n)); return it == classesByName.end() || it->second.empty() ? Ref{} : it->second.front(); }
    Ref findPath(const std::string& p) const { auto it = byPath.find(lower(p)); return it == byPath.end() ? Ref{} : it->second; }

    // ---------------------------------------------------------- property types
    Type propType(const Ref& prop) {
        Type t;
        if (prop.idx < 0) {   // property of an intrinsic class (import only): type from the property class
            std::string c = cls(prop);
            if (c == "IntProperty") t.k = K::Int; else if (c == "FloatProperty") t.k = K::Float; else if (c == "BoolProperty") t.k = K::Bool;
            else if (c == "NameProperty") t.k = K::Name; else if (c == "StrProperty") t.k = K::String; else if (c == "ByteProperty") t.k = K::Byte;
            else if (c == "ObjectProperty" || c == "ComponentProperty") t.k = K::Object; else if (c == "ArrayProperty") { t.k = K::Array; t.inner = std::make_shared<Type>(); }
            return t;
        }
        const FieldInfo& f = field(prop); const std::string& c = f.cls;
        if (c == "IntProperty") t.k = K::Int; else if (c == "FloatProperty") t.k = K::Float; else if (c == "BoolProperty") t.k = K::Bool;
        else if (c == "NameProperty") t.k = K::Name; else if (c == "StrProperty") t.k = K::String;
        else if (c == "ByteProperty") { t.k = K::Byte; t.enm = resolve(prop.pkg, f.ref1); }
        else if (c == "ObjectProperty" || c == "ComponentProperty") { t.k = K::Object; t.cls = resolve(prop.pkg, f.ref1); }
        else if (c == "InterfaceProperty") { t.k = K::Interface; t.cls = resolve(prop.pkg, f.ref1); }
        else if (c == "ClassProperty") { t.k = K::Class; t.cls = resolve(prop.pkg, f.ref2); }
        else if (c == "StructProperty") { t.k = K::Struct; t.strct = resolve(prop.pkg, f.ref1); }
        else if (c == "ArrayProperty") { t.k = K::Array; Ref in = resolve(prop.pkg, f.ref1); t.inner = std::make_shared<Type>(in ? propType(in) : Type()); }
        else if (c == "DelegateProperty") { t.k = K::Delegate; t.func = resolve(prop.pkg, f.ref1); }
        else if (c == "MapProperty") t.k = K::Map;
        return t;
    }
    // ---------------------------------------------------------- in-memory sizes (UE3 Link, 32-bit PC)
    std::unordered_map<uint64_t, std::pair<int, int>> structLayout;   // size (PropertiesSize), alignment
    int typeSize(const Type& t) {
        switch (t.k) {
            case K::Byte: return 1; case K::Int: case K::Float: case K::Object: case K::Class: case K::Bool: case K::Pointer: return 4;
            case K::Name: return 8; case K::String: case K::Array: return 12; case K::Interface: return 8; case K::Delegate: return 12; case K::Map: return 60;
            case K::Struct: return structSizeAlign(t.strct).first; default: return 0;
        }
    }
    int typeAlign(const Type& t) {
        switch (t.k) { case K::Byte: return 1; case K::Struct: return structSizeAlign(t.strct).second; case K::None: return 1; default: return 4; }
    }
    int propSize(const Ref& prop) { const FieldInfo& f = field(prop); return typeSize(propType(prop)) * std::max(1, f.arrayDim); }
    std::pair<int, int> structSizeAlign(const Ref& s) {
        if (!s) return { 0, 1 };
        auto it = structLayout.find(s.key()); if (it != structLayout.end()) return it->second;
        structLayout[s.key()] = { 0, 4 };   // recursion guard
        int size = 0, align = 1; Ref sup = super_(s); if (sup) { auto sa = structSizeAlign(sup); size = sa.first; align = sa.second; }
        bool lastBool = false; int boolBit = 0;
        for (Ref c : children(s)) {
            const FieldInfo& f = field(c); if (!f.isProperty) continue;
            Type t = propType(c);
            if (t.k == K::Bool) {
                if (lastBool && boolBit < 32) { boolBit++; continue; }
                size = (size + 3) & ~3; size += 4; lastBool = true; boolBit = 1; align = std::max(align, 4); continue;
            }
            lastBool = false; int a = typeAlign(t), sz = typeSize(t) * std::max(1, f.arrayDim);
            size = (size + a - 1) / a * a; size += sz; align = std::max(align, a);
        }
        return structLayout[s.key()] = { size, align };
    }
    // ---------------------------------------------------------- member lookup (class/state/struct scope)
    // looks up a field by name inside a struct (Class/State/ScriptStruct/Function) and superclasses
    Ref findMember(Ref scope, const std::string& n, const char* wantCls = nullptr, bool supers = true) {
        std::string ln = lower(n);
        for (int g = 0; scope && g < 64; g++) {
            for (Ref c : children(scope)) {
                if (lower(name(c)) != ln) continue;
                if (wantCls) { std::string cc = cls(c); if (strcmp(wantCls, "Property") == 0 ? !isPropClass(cc) : cc != wantCls) continue; }
                return c;
            }
            if (!supers) break; scope = super_(scope);
        }
        return Ref{};
    }
};

} // namespace ucc
} // namespace bm
