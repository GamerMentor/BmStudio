// ucc_parse.hpp - lexer + AST + UnrealScript parser (function bodies / state code) for the BAA compiler.
// The operators are defined by the packages themselves ("operator" functions), so the parser receives the operator
// table (symbol -> precedence / prefix / postfix) from the type model.
#pragma once
#include <string>
#include <vector>
#include <memory>
#include <map>
#include <set>
#include <stdexcept>
#include <cstring>
#include <cstdlib>
#include <cmath>

namespace bm {
namespace ucc {

struct CompileError : std::runtime_error { int line; CompileError(const std::string& m, int l) : std::runtime_error(m), line(l) {} };

// ------------------------------------------------------------------ lexer
enum class TT : unsigned char { End, Ident, Int, Float, Str, Name, Sym };
struct Token { TT t = TT::End; std::string s; long long iv = 0; double fv = 0; int line = 1; bool spaceBefore = true; size_t pos = 0; };

inline std::vector<Token> lex(const std::string& src) {
    std::vector<Token> out; size_t i = 0, n = src.size(); int line = 1; bool sp = true;
    static const char* syms[] = { ">>>=", ">>>", "<<=", ">>=", "==", "!=", "<=", ">=", "&&", "||", "^^", "++", "--", "+=", "-=", "*=", "/=", "$=", "@=", "**", "~=", "<<", ">>", "::", nullptr };
    while (i < n) {
        char c = src[i];
        if (c == '\n') { line++; i++; sp = true; continue; }
        if (isspace((unsigned char)c)) { i++; sp = true; continue; }
        if (c == '/' && i + 1 < n && src[i + 1] == '/') { while (i < n && src[i] != '\n') i++; sp = true; continue; }
        if (c == '/' && i + 1 < n && src[i + 1] == '*') { i += 2; while (i + 1 < n && !(src[i] == '*' && src[i + 1] == '/')) { if (src[i] == '\n') line++; i++; } i += 2; sp = true; continue; }
        Token t; t.line = line; t.spaceBefore = sp; t.pos = i; sp = false;
        if (isalpha((unsigned char)c) || c == '_') {
            size_t j = i; while (j < n && (isalnum((unsigned char)src[j]) || src[j] == '_')) j++;
            t.t = TT::Ident; t.s = src.substr(i, j - i); i = j; out.push_back(t); continue;
        }
        if (isdigit((unsigned char)c) || (c == '.' && i + 1 < n && isdigit((unsigned char)src[i + 1]))) {
            size_t j = i;
            if (c == '0' && j + 1 < n && (src[j + 1] == 'x' || src[j + 1] == 'X')) { j += 2; while (j < n && isxdigit((unsigned char)src[j])) j++; t.t = TT::Int; t.iv = (long long)strtoull(src.substr(i + 2, j - i - 2).c_str(), nullptr, 16); t.s = src.substr(i, j - i); i = j; out.push_back(t); continue; }
            bool isF = false; while (j < n && isdigit((unsigned char)src[j])) j++;
            if (j < n && src[j] == '.' && !(j + 1 < n && src[j + 1] == '.')) { isF = true; j++; while (j < n && isdigit((unsigned char)src[j])) j++; }
            if (j < n && (src[j] == 'e' || src[j] == 'E') && j + 1 < n && (isdigit((unsigned char)src[j + 1]) || ((src[j + 1] == '-' || src[j + 1] == '+') && j + 2 < n && isdigit((unsigned char)src[j + 2])))) { isF = true; j += 2; while (j < n && isdigit((unsigned char)src[j])) j++; }
            t.s = src.substr(i, j - i);
            if (j < n && (src[j] == 'f' || src[j] == 'F')) { isF = true; j++; }
            if (isF) { t.t = TT::Float; t.fv = strtod(t.s.c_str(), nullptr); } else { t.t = TT::Int; t.iv = strtoll(t.s.c_str(), nullptr, 10); }
            i = j; out.push_back(t); continue;
        }
        if (c == '"') {
            std::string s; size_t j = i + 1;
            while (j < n && src[j] != '"') { if (src[j] == '\\' && j + 1 < n) { char e = src[j + 1]; s += e == 'n' ? '\n' : e == 't' ? '\t' : e; j += 2; continue; } if (src[j] == '\n') line++; s += src[j++]; }
            if (j >= n) throw CompileError("unterminated string", t.line);
            t.t = TT::Str; t.s = s; i = j + 1; out.push_back(t); continue;
        }
        if (c == '\'') {
            size_t j = i + 1; std::string s; while (j < n && src[j] != '\'' && src[j] != '\n') s += src[j++];
            if (j >= n || src[j] != '\'') throw CompileError("unterminated name", t.line);
            t.t = TT::Name; t.s = s; i = j + 1; out.push_back(t); continue;
        }
        t.t = TT::Sym; bool got = false;
        for (int k = 0; syms[k]; k++) { size_t L = strlen(syms[k]); if (src.compare(i, L, syms[k]) == 0) { t.s = syms[k]; i += L; got = true; break; } }
        if (!got) { t.s = std::string(1, c); i++; }
        out.push_back(t);
    }
    Token e; e.t = TT::End; e.line = line; out.push_back(e);
    return out;
}

// ------------------------------------------------------------------ AST
enum class EK : unsigned char {
    IntLit, FloatLit, StrLit, NameLit, ObjLit, VectLit, RotLit, True, False, None, Self,
    Ident,          // bare name (variable, enum, const, class...)
    Member,         // a.b
    RssMember,      // a~>b  (Rocksteady "RSS" context, opcode 0x50)
    DefaultMember,  // default.X  or  a.default.X
    StaticCall,     // a.static.F(args)
    Call,           // f(args)  (a = optional target: Member/Ident; s = name)
    SuperCall,      // super.F(args) / super(Class).F(args)
    GlobalCall,     // global.F(args)
    NativeCall,     // __NFUN_123__(args) / forced operator
    Index,          // a[i]
    Unary,          // op a  (prefix)
    Postfix,        // a op
    Binary,         // a op b
    Cond,           // c ? a : b
    New,            // new(args) cls
    MetaCast,       // class<X>(e)
    ArrayLength,    // a.Length (resolved in sema)
};
struct Expr;
using EP = std::unique_ptr<Expr>;
struct Expr {
    EK k; int line = 0;
    std::string s;            // identifier / operator / name / string / class
    std::string s2;           // ObjLit: path ; SuperCall: class ; Call: function name
    long long iv = 0; double fv[3] = { 0, 0, 0 }; float ff[3] = { 0, 0, 0 }; int rv[3] = { 0, 0, 0 };
    std::vector<EP> a;        // children / arguments (nullptr = empty argument)
    bool hasTarget = false;   // Call: a[0] is the target (a.F())
    bool parens = false;
    // filled in by sema
    void* sem = nullptr;
};
enum class SK : unsigned char { Expr, Assign, If, While, DoUntil, For, ForEach, Switch, Case, Default, Break, Continue, Return, Stop, Goto, GotoExpr, Label, Assert, Block, Local, Empty,
    Nothing, IterPop, JumpIfNot };   // fidelity extensions (decompiler)
struct Stmt;
using SP = std::unique_ptr<Stmt>;
struct Stmt {
    SK k; int line = 0;
    EP e, e2, e3;             // Expr/cond/lhs/rhs/...
    std::vector<SP> body;     // Block / body
    SP s1, s2, s3;            // If: then/else ; For: init/inc ; DoUntil: body
    std::string label;        // Label / Goto
    std::vector<std::pair<std::string, std::string>> locals;   // Local: type, name
};

// ------------------------------------------------------------------ operator table (from the type model)
struct OpInfo { int binPrec = -1; bool pre = false, post = false; };
using OpTable = std::map<std::string, OpInfo>;   // symbol (lowercase for identifiers) -> info

class Parser {
public:
    std::vector<Token> T; size_t p = 0; const OpTable& ops;
    Parser(const std::string& src, const OpTable& o) : T(lex(src)), ops(o) {}
    const Token& cur() const { return T[p]; }
    const Token& peek(int k = 1) const { return T[std::min(p + k, T.size() - 1)]; }
    bool isSym(const char* s, int k = 0) const { const Token& t = peek(k); return t.t == TT::Sym && t.s == s; }
    bool isKw(const char* s, int k = 0) const { const Token& t = peek(k); return t.t == TT::Ident && strcasecmp(t.s.c_str(), s) == 0; }
    [[noreturn]] void fail(const std::string& m) const { throw CompileError(m + " (near '" + (cur().t == TT::End ? std::string("end of file") : cur().s) + "')", cur().line); }
    void expect(const char* s) { if (!isSym(s)) fail(std::string("expected '") + s + "'"); p++; }
    bool accept(const char* s) { if (isSym(s)) { p++; return true; } return false; }
    bool acceptKw(const char* s) { if (isKw(s)) { p++; return true; } return false; }
    std::string ident() { if (cur().t != TT::Ident) fail("expected identifier"); return T[p++].s; }
    static std::string low(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }
    EP mk(EK k) { EP e(new Expr()); e->k = k; e->line = cur().line; return e; }

    const OpInfo* opFor(const Token& t) const {
        if (t.t != TT::Sym && t.t != TT::Ident) return nullptr;
        auto it = ops.find(t.t == TT::Ident ? low(t.s) : t.s); return it == ops.end() ? nullptr : &it->second;
    }

    // ---------------------------------------------------------- types (for class<X>(e), locals)
    std::string typeText() {
        std::string s = ident();
        if (low(s) == "class" || low(s) == "array" || low(s) == "delegate") {
            if (accept("<")) { s += "<" + typeText(); splitShift(); expect(">"); s += ">"; }
        } else while (accept(".")) s += "." + ident();
        return s;
    }
    void splitShift() { if (cur().t == TT::Sym && (cur().s == ">>" || cur().s == ">>>")) { Token t = cur(); t.s = t.s.substr(1); T[p].s = ">"; T.insert(T.begin() + p + 1, t); } }

    // ---------------------------------------------------------- expressions
    EP parseExpr(int maxPrec = 100) {
        EP left = parseUnary();
        for (;;) {
            if (isSym("?") && maxPrec >= 100) {   // conditional (lowest precedence)
                p++; EP c = mk(EK::Cond); c->a.push_back(std::move(left)); c->a.push_back(parseExpr(100)); expect(":"); c->a.push_back(parseExpr(100)); left = std::move(c); continue;
            }
            const Token& t = cur(); const OpInfo* oi = opFor(t);
            if (!oi || oi->binPrec < 0) break;
            if (t.t == TT::Sym && (t.s == "=")) break;
            int pr = oi->binPrec; if (pr >= maxPrec) break;
            p++; EP b = mk(EK::Binary); b->s = t.t == TT::Ident ? low(t.s) : t.s; b->line = t.line;
            b->a.push_back(std::move(left)); b->a.push_back(parseExpr(pr)); left = std::move(b);
        }
        return left;
    }
    EP parseUnary() {
        const Token& t = cur();
        if (t.t == TT::Sym && (t.s == "-" ) && (peek().t == TT::Int || peek().t == TT::Float) && !peek().spaceBefore) {
            // negative literal
            p++; EP e = parsePrimary(); if (e->k == EK::IntLit) { e->iv = -e->iv; return parsePostfix(std::move(e)); } if (e->k == EK::FloatLit) { e->fv[0] = -e->fv[0]; e->s = "-" + e->s; return parsePostfix(std::move(e)); }
            EP u = mk(EK::Unary); u->s = "-"; u->a.push_back(std::move(e)); return u;
        }
        const OpInfo* oi = opFor(t);
        if (oi && oi->pre && t.t == TT::Sym) { p++; EP u = mk(EK::Unary); u->s = t.s; u->a.push_back(parseUnary()); return u; }
        return parsePostfix(parsePrimary());
    }
    std::vector<EP> args() {   // '(' already consumed; up to ')'
        std::vector<EP> v;
        if (accept(")")) return v;
        for (;;) {
            if (isSym(",")) { v.push_back(nullptr); p++; continue; }
            if (isSym(")")) { v.push_back(nullptr); p++; return v; }
            v.push_back(parseExpr());
            if (accept(")")) return v;
            expect(",");
            if (isSym(")")) { v.push_back(nullptr); p++; return v; }
        }
    }
    EP parsePostfix(EP e) {
        for (;;) {
            if (isSym(".")) {
                p++;
                if (acceptKw("default")) { expect("."); EP d = mk(EK::DefaultMember); d->s = ident(); d->a.push_back(std::move(e)); e = std::move(d); continue; }
                if (isKw("super") && isSym("(", 1)) {   // obj.super(Class).F(args): non-virtual call on another object
                    p += 2; std::string c = ident(); expect(")"); expect("."); std::string fnm = ident(); expect("(");
                    EP cl = mk(EK::Call); cl->s = fnm; cl->s2 = c; cl->hasTarget = true; cl->a.push_back(std::move(e)); for (auto& x : args()) cl->a.push_back(std::move(x)); e = std::move(cl); continue;
                }
                if (acceptKw("static")) { expect("."); EP d = mk(EK::StaticCall); d->s = ident(); expect("("); d->a.push_back(std::move(e)); for (auto& x : args()) d->a.push_back(std::move(x)); e = std::move(d); continue; }
                std::string nm = ident();
                if (accept("(")) { EP c = mk(EK::Call); c->s = nm; c->hasTarget = true; c->a.push_back(std::move(e)); for (auto& x : args()) c->a.push_back(std::move(x)); e = std::move(c); continue; }
                EP m = mk(EK::Member); m->s = nm; m->a.push_back(std::move(e)); e = std::move(m); continue;
            }
            if (isSym("~") && isSym(">", 1)) {   // a~>b : RSS context
                p += 2; std::string nm = ident();
                if (accept("(")) { EP c = mk(EK::Call); c->s = nm; c->hasTarget = true; c->iv = 1; c->a.push_back(std::move(e)); for (auto& x : args()) c->a.push_back(std::move(x)); e = std::move(c); continue; }
                EP m = mk(EK::RssMember); m->s = nm; m->a.push_back(std::move(e)); e = std::move(m); continue;
            }
            if (isSym("[")) { p++; EP ix = mk(EK::Index); ix->a.push_back(std::move(e)); ix->a.push_back(parseExpr()); expect("]"); e = std::move(ix); continue; }
            const OpInfo* oi = opFor(cur());
            if (oi && oi->post && cur().t == TT::Sym && (cur().s == "++" || cur().s == "--")) { EP u = mk(EK::Postfix); u->s = cur().s; p++; u->a.push_back(std::move(e)); e = std::move(u); continue; }
            break;
        }
        return e;
    }
    EP parsePrimary() {
        const Token& t = cur();
        if (t.t == TT::Int) { p++; EP e = mk(EK::IntLit); e->iv = t.iv; return e; }
        if (t.t == TT::Float) { p++; EP e = mk(EK::FloatLit); e->fv[0] = t.fv; e->s = t.s; return e; }
        if (t.t == TT::Str) { p++; EP e = mk(EK::StrLit); e->s = t.s; return e; }
        if (t.t == TT::Name) { p++; EP e = mk(EK::NameLit); e->s = t.s; return e; }
        if (isSym("(")) { p++; EP e = parseExpr(); expect(")"); e->parens = true; return e; }
        if (t.t != TT::Ident) fail("expected expression");
        std::string id = t.s, lid = low(id);
        // Class'Path'
        if (peek().t == TT::Name && !peek().spaceBefore) { p += 2; EP e = mk(EK::ObjLit); e->s = id; e->s2 = peek(-1).s; return e; }
        if (lid == "true") { p++; return mk(EK::True); }
        if (lid == "false") { p++; return mk(EK::False); }
        if (lid == "none") { p++; return mk(EK::None); }
        if (lid == "self") { p++; return mk(EK::Self); }
        if (lid == "vect" && isSym("(", 1)) { p += 2; EP e = mk(EK::VectLit); for (int k = 0; k < 3; k++) { e->fv[k] = numLit(); if (k < 2) expect(","); } expect(")"); return e; }
        if (lid == "rot" && isSym("(", 1)) { p += 2; EP e = mk(EK::RotLit); for (int k = 0; k < 3; k++) { e->rv[k] = (int)numLit(); if (k < 2) expect(","); } expect(")"); return e; }
        if (lid == "default" && isSym(".", 1)) { p += 2; EP e = mk(EK::DefaultMember); e->s = ident(); return e; }
        if (lid == "static" && isSym(".", 1)) { p += 2; EP e = mk(EK::StaticCall); e->s = ident(); expect("("); e->a.push_back(nullptr); for (auto& x : args()) e->a.push_back(std::move(x)); return e; }
        if (lid == "super") {
            p++; EP e = mk(EK::SuperCall); if (accept("(")) { e->s2 = ident(); expect(")"); } expect("."); e->s = ident(); expect("(");
            for (auto& x : args()) e->a.push_back(std::move(x)); return e;
        }
        if (lid == "global" && isSym(".", 1)) { p += 2; EP e = mk(EK::GlobalCall); e->s = ident(); expect("("); for (auto& x : args()) e->a.push_back(std::move(x)); return e; }
        if (lid == "new") {
            p++; EP e = mk(EK::New);
            if (accept("(")) { auto v = args(); while (v.size() < 3) v.push_back(nullptr); for (auto& x : v) e->a.push_back(std::move(x)); }
            else for (int k = 0; k < 3; k++) e->a.push_back(nullptr);
            e->a.push_back(parsePostfixNoCall(parsePrimary()));   // the class
            if (accept("(")) { auto v = args(); if (!v.empty() && v[0]) e->a.push_back(std::move(v[0])); }   // optional template
            return e;
        }
        if (lid == "class" && isSym("<", 1)) {   // class<X>(e)
            p += 2; EP e = mk(EK::MetaCast); e->s = typeText(); splitShift(); expect(">"); expect("("); e->a.push_back(parseExpr()); expect(")"); return e;
        }
        if (lid.size() > 8 && lid.compare(0, 7, "__nfun_") == 0) {   // __NFUN_123__(...)
            p++; EP e = mk(EK::NativeCall); e->iv = atoi(id.c_str() + 7); expect("("); for (auto& x : args()) e->a.push_back(std::move(x)); return e;
        }
        p++;
        if (accept("(")) { EP c = mk(EK::Call); c->s = id; c->line = t.line; for (auto& x : args()) c->a.push_back(std::move(x)); return c; }
        EP e = mk(EK::Ident); e->s = id; e->line = t.line; return e;
    }
    EP parsePostfixNoCall(EP e) {   // for "new X.Y" (without a call)
        while (isSym(".") || isSym("[")) {
            if (accept(".")) { if (acceptKw("default")) { expect("."); EP d = mk(EK::DefaultMember); d->s = ident(); d->a.push_back(std::move(e)); e = std::move(d); continue; }
                EP m = mk(EK::Member); m->s = ident(); m->a.push_back(std::move(e)); e = std::move(m); continue; }
            p++; EP ix = mk(EK::Index); ix->a.push_back(std::move(e)); ix->a.push_back(parseExpr()); expect("]"); e = std::move(ix);
        }
        return e;
    }
    double numLit() { bool neg = accept("-"); const Token& t = cur(); if (t.t != TT::Int && t.t != TT::Float) fail("expected number"); p++;
        if (t.t == TT::Float) { float f = strtof(((neg ? "-" : "") + t.s).c_str(), nullptr); return (double)f; }
        double v = (double)t.iv; return neg ? -v : v; }

    // ---------------------------------------------------------- statements
    SP mkS(SK k) { SP s(new Stmt()); s->k = k; s->line = cur().line; return s; }
    SP block() { SP b = mkS(SK::Block); expect("{"); while (!isSym("}")) { if (cur().t == TT::End) fail("expected '}'"); b->body.push_back(statement()); } p++; return b; }
    SP bodyStmt() { if (isSym("{")) return block(); return statement(); }
    SP statement() {
        if (accept(";")) return mkS(SK::Empty);
        if (isSym("{")) return block();
        const Token& t = cur(); std::string l = t.t == TT::Ident ? low(t.s) : "";
        if (l == "__nothing") { p++; accept(";"); return mkS(SK::Nothing); }
        if (l == "__iteratorpop") { p++; accept(";"); return mkS(SK::IterPop); }
        if (l == "__iteratornext") { p++; accept(";"); SP s = mkS(SK::IterPop); s->label = "next"; return s; }
        if (l == "__jumpifnot") { p++; SP s = mkS(SK::JumpIfNot); expect("("); s->e = parseExpr(); expect(","); s->label = ident(); expect(")"); accept(";"); return s; }
        if (l == "local") { p++; SP s = mkS(SK::Local); std::string ty = typeText(); do { std::string nm = ident(); if (accept("[")) { nm += "[" + cur().s + "]"; p++; expect("]"); } s->locals.push_back({ ty, nm }); } while (accept(",")); expect(";"); return s; }
        if (l == "if") { p++; SP s = mkS(SK::If); expect("("); s->e = parseExpr(); expect(")"); s->s1 = bodyStmt(); if (acceptKw("else")) s->s2 = bodyStmt(); return s; }
        if (l == "while") { p++; SP s = mkS(SK::While); expect("("); s->e = parseExpr(); expect(")"); s->s1 = bodyStmt(); return s; }
        if (l == "do") { p++; SP s = mkS(SK::DoUntil); s->s1 = bodyStmt(); if (!acceptKw("until")) fail("expected 'until'"); expect("("); s->e = parseExpr(); expect(")"); accept(";"); return s; }
        if (l == "for") {
            p++; SP s = mkS(SK::For); expect("(");
            if (!isSym(";")) s->s1 = simpleStatement(); expect(";");
            if (!isSym(";")) s->e = parseExpr(); expect(";");
            if (!isSym(")")) s->s3 = simpleStatement(); expect(")");
            s->s2 = bodyStmt(); return s;
        }
        if (l == "foreach") { p++; SP s = mkS(SK::ForEach); s->e = parseUnary(); s->s1 = bodyStmt(); return s; }
        if (l == "switch") { p++; SP s = mkS(SK::Switch); expect("("); s->e = parseExpr(); expect(")"); expect("{");
            while (!isSym("}")) { if (cur().t == TT::End) fail("expected '}'"); s->body.push_back(statement()); } p++; return s; }
        if (l == "case") { p++; SP s = mkS(SK::Case); s->e = parseExpr(); expect(":"); return s; }
        if (l == "default" && isSym(":", 1)) { p += 2; return mkS(SK::Default); }
        if (l == "break") { p++; accept(";"); return mkS(SK::Break); }
        if (l == "continue") { p++; accept(";"); return mkS(SK::Continue); }
        if (l == "return") { p++; SP s = mkS(SK::Return); if (!isSym(";")) s->e = parseExpr(); accept(";"); return s; }
        if (l == "stop") { p++; accept(";"); return mkS(SK::Stop); }
        if (l == "goto") { p++; SP s;
            if (cur().t == TT::Ident && (isSym(";", 1))) { s = mkS(SK::Goto); s->label = ident(); }
            else { s = mkS(SK::GotoExpr); s->e = parseExpr(); }
            accept(";"); return s; }
        if (l == "assert") { p++; SP s = mkS(SK::Assert); expect("("); s->e = parseExpr(); if (accept(",")) { s->e2 = parseExpr(); } expect(")"); accept(";"); return s; }
        if (t.t == TT::Ident && isSym(":", 1) && !isSym(":", 2)) { p += 2; SP s = mkS(SK::Label); s->label = t.s; return s; }
        SP s = simpleStatement(); accept(";"); return s;
    }
    SP simpleStatement() {   // expression or assignment
        SP s = mkS(SK::Expr); EP e = parseExpr();
        if (accept("=")) { s->k = SK::Assign; s->e = std::move(e); s->e2 = parseExpr(); return s; }
        s->e = std::move(e); return s;
    }
    std::vector<SP> program() { std::vector<SP> v; while (cur().t != TT::End) v.push_back(statement()); return v; }
};

} // namespace ucc
} // namespace bm
