// bmasset.hpp - reading cooked assets of Batman: Arkham Asylum (UE3 v576 / lic 21):
//   Texture2D (inline mips or in the .tfc, with LZO/ZLIB), SkeletalMesh (LODs, GPU-skin vertices, bones, weights).
// Layout follows the UE3 v576 engine source with the BATMAN changes (etkramer/UnrealEngine3-bm).
#pragma once
#include "bmpkg.hpp"
#include "bmlzo.hpp"
#include <cmath>
#include <map>
#include <set>

extern "C" {
typedef unsigned long mz_ulong;
int mz_uncompress(unsigned char* pDest, mz_ulong* pDest_len, const unsigned char* pSource, mz_ulong source_len);
}

namespace bm {

// ------------------------------------------------------------------ bulk data
enum { BULK_SEPARATE = 1, BULK_ZLIB = 2, BULK_LZO = 0x10, BULK_LZX = 0x80 };
struct Bulk { u32 flags = 0; i32 count = 0, sizeOnDisk = 0, offset = -1; long inlinePos = -1; };   // inlinePos = position inside the export
inline Bulk readBulk(Reader& r) {
    Bulk b; b.flags = r.u(); b.count = r.i(); b.sizeOnDisk = r.i(); b.offset = r.i();
    if (!(b.flags & BULK_SEPARATE) && b.offset != -1) { b.inlinePos = (long)r.p; r.need((size_t)std::max(0, b.sizeOnDisk)); r.p += (size_t)std::max(0, b.sizeOnDisk); }
    return b;
}
// FArchive::SerializeCompressed: tag, summary, block table, compressed blocks
inline bool decompressChunked(const u8* src, size_t srcLen, u32 flags, std::vector<u8>& out, size_t expected) {
    Reader r(src, srcLen);
    try {
        u32 tag = r.u(); i32 chunkSize = r.i(); if (tag != TAG) return false; if ((u32)chunkSize == TAG) chunkSize = 131072;
        i32 sumComp = r.i(), sumUncomp = r.i(); (void)sumComp;
        if (sumUncomp < 0 || (expected && (size_t)sumUncomp != expected)) { if (!expected) return false; }
        i32 chunks = chunkSize > 0 ? (sumUncomp + chunkSize - 1) / chunkSize : 0;
        std::vector<std::pair<i32, i32>> tab; for (i32 k = 0; k < chunks; k++) { i32 c = r.i(), u = r.i(); tab.push_back({ c, u }); }
        out.resize((size_t)sumUncomp); size_t o = 0;
        for (auto& ch : tab) {
            r.need((size_t)ch.first); if (o + (size_t)ch.second > out.size()) return false;
            if (flags & BULK_LZO) { size_t got = 0; if (!lzo1xDecompress(src + r.p, (size_t)ch.first, out.data() + o, (size_t)ch.second, &got) || got != (size_t)ch.second) return false; }
            else if (flags & BULK_ZLIB) { mz_ulong got = (mz_ulong)ch.second; if (mz_uncompress(out.data() + o, &got, src + r.p, (mz_ulong)ch.first) != 0 || got != (mz_ulong)ch.second) return false; }
            else return false;
            r.p += (size_t)ch.first; o += (size_t)ch.second;
        }
        return true;
    } catch (...) { return false; }
}

// ------------------------------------------------------------------ property utilities
inline const Tag* findTag(const std::vector<Tag>& tags, const std::string& name) { for (auto& t : tags) if (t.name == name) return &t; return nullptr; }
inline i32 tagInt(const std::vector<Tag>& tags, const std::string& name, i32 def = 0) { const Tag* t = findTag(tags, name); if (!t || t->raw.size() < 4) return def; i32 v; memcpy(&v, t->raw.data(), 4); return v; }
inline std::string tagName(const Package& pk, const std::vector<Tag>& tags, const std::string& name) {
    const Tag* t = findTag(tags, name); if (!t) return ""; if (t->raw.size() == 8) { FName f; memcpy(&f.idx, t->raw.data(), 4); memcpy(&f.num, t->raw.data() + 4, 4); return pk.nm(f); }
    if (t->raw.size() == 1) return std::to_string(t->raw[0]); return "";
}
// props + end position
struct ObjProps { std::vector<Tag> tags; size_t end = 0; bool ok = false; };
inline ObjProps objProps(const Package& pk, i32 idx) {
    ObjProps o; long st = findPropStart(pk, idx); if (st < 0) return o;
    const Export& e = pk.exports[idx - 1];
    try { o.tags = readProps(pk, pk.dataPtr(e), pk.dataLen(e), (size_t)st, &o.end); o.ok = true; } catch (...) {}
    return o;
}

// ------------------------------------------------------------------ Texture2D
struct Mip { i32 w = 0, h = 0; Bulk bulk; };
struct TextureInfo {
    i32 sizeX = 0, sizeY = 0; std::string format, tfc; std::vector<Mip> mips; std::string err;
    u32 blockBytes() const { if (format == "PF_DXT1") return 8; if (format == "PF_DXT3" || format == "PF_DXT5") return 16; return 0; }
    u32 bpp() const { if (format == "PF_A8R8G8B8") return 4; if (format == "PF_G8") return 1; if (format == "PF_V8U8") return 2; if (format == "PF_A32B32G32R32F") return 16; if (format == "PF_FloatRGB") return 12; return 0; }
    size_t mipBytes(i32 w, i32 h) const { if (blockBytes()) return (size_t)std::max(1, (w + 3) / 4) * std::max(1, (h + 3) / 4) * blockBytes(); return (size_t)w * h * bpp(); }
};
inline TextureInfo parseTexture(const Package& pk, i32 idx) {
    TextureInfo ti; ObjProps op = objProps(pk, idx); if (!op.ok) { ti.err = "no properties"; return ti; }
    ti.sizeX = tagInt(op.tags, "SizeX"); ti.sizeY = tagInt(op.tags, "SizeY"); ti.format = tagName(pk, op.tags, "Format"); ti.tfc = tagName(pk, op.tags, "TextureFileCacheName");
    if (ti.format.empty()) ti.format = "PF_A8R8G8B8";        // class default value
    const Export& e = pk.exports[idx - 1];
    try {
        Reader r(pk.dataPtr(e), pk.dataLen(e), op.end);
        readBulk(r);                                            // SourceArt (UTexture)
        i32 n = r.i(); if (n < 0 || n > 20) throw Err("bad mip count");
        for (i32 k = 0; k < n; k++) { Mip m; m.bulk = readBulk(r); m.w = r.i(); m.h = r.i(); ti.mips.push_back(m); }
    } catch (std::exception& ex) { ti.err = ex.what(); }
    return ti;
}
// CookedPC folder from the package path
inline std::string cookedDirOf(std::string path) {
    for (auto& c : path) if (c == '\\') c = '/';
    std::string low = path; for (auto& c : low) c = (char)tolower((unsigned char)c);
    size_t p = low.rfind("/cookedpc/"); if (p != std::string::npos) return path.substr(0, p + 10);
    size_t s = path.rfind('/'); return s == std::string::npos ? std::string("./") : path.substr(0, s + 1);
}
// reads the bytes of a mip (inline or in the .tfc). readFile(path, offset, size, out) is provided by the caller.
template <class ReadFileFn>
inline bool loadMip(const Package& pk, i32 idx, const TextureInfo& ti, const Mip& m, const std::string& cookedDir, ReadFileFn readFile, std::vector<u8>& out) {
    const Export& e = pk.exports[idx - 1]; std::vector<u8> raw;
    if (m.bulk.flags & BULK_SEPARATE) {
        if (ti.tfc.empty() || m.bulk.offset < 0 || m.bulk.sizeOnDisk <= 0) return false;
        if (!readFile(cookedDir + ti.tfc + ".tfc", (uint64_t)(uint32_t)m.bulk.offset, (size_t)m.bulk.sizeOnDisk, raw)) return false;
    } else if (m.bulk.inlinePos >= 0) {
        const u8* d = pk.dataPtr(e) + m.bulk.inlinePos; raw.assign(d, d + m.bulk.sizeOnDisk);
    } else return false;
    size_t expect = ti.mipBytes(m.w, m.h);
    if (m.bulk.flags & (BULK_LZO | BULK_ZLIB)) return decompressChunked(raw.data(), raw.size(), m.bulk.flags, out, expect) && out.size() >= expect;
    out.swap(raw); return out.size() >= expect;
}

// ------------------------------------------------------------------ DXT decoding -> RGBA8
inline void rgb565(uint16_t c, u8* o) { o[0] = (u8)(((c >> 11) & 31) * 255 / 31); o[1] = (u8)(((c >> 5) & 63) * 255 / 63); o[2] = (u8)((c & 31) * 255 / 31); }
inline void decodeColorBlock(const u8* b, u8 out[16][4], bool dxt1) {
    uint16_t c0 = b[0] | (b[1] << 8), c1 = b[2] | (b[3] << 8); u8 p[4][4]; rgb565(c0, p[0]); rgb565(c1, p[1]); p[0][3] = p[1][3] = 255;
    if (c0 > c1 || !dxt1) { for (int i = 0; i < 3; i++) { p[2][i] = (u8)((2 * p[0][i] + p[1][i]) / 3); p[3][i] = (u8)((p[0][i] + 2 * p[1][i]) / 3); } p[2][3] = p[3][3] = 255; }
    else { for (int i = 0; i < 3; i++) { p[2][i] = (u8)((p[0][i] + p[1][i]) / 2); p[3][i] = 0; } p[2][3] = 255; p[3][3] = 0; }
    u32 bits = b[4] | (b[5] << 8) | (b[6] << 16) | ((u32)b[7] << 24);
    for (int k = 0; k < 16; k++) { int s = (bits >> (2 * k)) & 3; memcpy(out[k], p[s], 4); }
}
inline bool decodeToRGBA(const TextureInfo& ti, i32 w, i32 h, const u8* src, size_t srcLen, std::vector<u8>& rgba) {
    rgba.assign((size_t)w * h * 4, 255);
    if (ti.format == "PF_DXT1" || ti.format == "PF_DXT3" || ti.format == "PF_DXT5") {
        int bw = std::max(1, (w + 3) / 4), bh = std::max(1, (h + 3) / 4); size_t bs = ti.blockBytes(); if (srcLen < (size_t)bw * bh * bs) return false;
        for (int by = 0; by < bh; by++) for (int bx = 0; bx < bw; bx++) {
            const u8* b = src + ((size_t)by * bw + bx) * bs; u8 px[16][4];
            if (ti.format == "PF_DXT1") decodeColorBlock(b, px, true);
            else {
                decodeColorBlock(b + 8, px, false);
                if (ti.format == "PF_DXT3") { for (int k = 0; k < 16; k++) { int a = (b[k / 2] >> ((k & 1) * 4)) & 15; px[k][3] = (u8)(a * 17); } }
                else { u8 a0 = b[0], a1 = b[1]; u8 a[8]; a[0] = a0; a[1] = a1;
                    if (a0 > a1) for (int i = 1; i < 7; i++) a[i + 1] = (u8)(((7 - i) * a0 + i * a1) / 7);
                    else { for (int i = 1; i < 5; i++) a[i + 1] = (u8)(((5 - i) * a0 + i * a1) / 5); a[6] = 0; a[7] = 255; }
                    uint64_t bits = 0; for (int i = 0; i < 6; i++) bits |= (uint64_t)b[2 + i] << (8 * i);
                    for (int k = 0; k < 16; k++) px[k][3] = a[(bits >> (3 * k)) & 7]; }
            }
            for (int k = 0; k < 16; k++) { int x = bx * 4 + (k & 3), y = by * 4 + (k >> 2); if (x < w && y < h) memcpy(&rgba[((size_t)y * w + x) * 4], px[k], 4); }
        }
        return true;
    }
    if (ti.format == "PF_A8R8G8B8") { if (srcLen < (size_t)w * h * 4) return false; for (size_t k = 0; k < (size_t)w * h; k++) { rgba[k * 4] = src[k * 4 + 2]; rgba[k * 4 + 1] = src[k * 4 + 1]; rgba[k * 4 + 2] = src[k * 4]; rgba[k * 4 + 3] = src[k * 4 + 3]; } return true; }
    if (ti.format == "PF_G8") { if (srcLen < (size_t)w * h) return false; for (size_t k = 0; k < (size_t)w * h; k++) { rgba[k * 4] = rgba[k * 4 + 1] = rgba[k * 4 + 2] = src[k]; } return true; }
    if (ti.format == "PF_V8U8") { if (srcLen < (size_t)w * h * 2) return false; for (size_t k = 0; k < (size_t)w * h; k++) { rgba[k * 4] = (u8)(src[k * 2] + 128); rgba[k * 4 + 1] = (u8)(src[k * 2 + 1] + 128); rgba[k * 4 + 2] = 255; } return true; }
    return false;
}
// DDS with the chosen mip (DXT1/3/5 and A8R8G8B8)
inline std::vector<u8> makeDDS(const TextureInfo& ti, i32 w, i32 h, const std::vector<u8>& data) {
    Writer wr; wr.u(0x20534444); wr.u(124); u32 flags = 0x1 | 0x2 | 0x4 | 0x1000 | (ti.blockBytes() ? 0x80000 : 0x8);
    wr.u(flags); wr.u((u32)h); wr.u((u32)w); wr.u(ti.blockBytes() ? (u32)ti.mipBytes(w, h) : (u32)w * 4); wr.u(0); wr.u(1); for (int k = 0; k < 11; k++) wr.u(0);
    wr.u(32);
    if (ti.blockBytes()) { wr.u(0x4); wr.u(ti.format == "PF_DXT1" ? 0x31545844 : ti.format == "PF_DXT3" ? 0x33545844 : 0x35545844); wr.u(0); wr.u(0); wr.u(0); wr.u(0); wr.u(0); }
    else { wr.u(0x41); wr.u(0); wr.u(32); wr.u(0x00FF0000); wr.u(0x0000FF00); wr.u(0x000000FF); wr.u(0xFF000000); }
    wr.u(0x1000); wr.u(0); wr.u(0); wr.u(0); wr.u(0);
    size_t n = ti.mipBytes(w, h); wr.raw(data.data(), std::min(n, data.size()));
    return wr.b;
}

// ------------------------------------------------------------------ SkeletalMesh
struct Bone { std::string name; u32 flags = 0; float q[4] = { 0, 0, 0, 1 }; float pos[3] = { 0, 0, 0 }; i32 numChildren = 0, parent = 0; };
struct SkelVertex { float pos[3]; float normal[3]; float tangent[3]; float uv[2]; u8 bones[4]; u8 weights[4]; };
struct SkelSection { int material = 0; int chunk = 0; u32 baseIndex = 0; u32 numTris = 0; };
struct SkelChunk { u32 baseVertex = 0; std::vector<uint16_t> boneMap; i32 numRigid = 0, numSoft = 0, maxInfluences = 0; };
struct SkelLOD { std::vector<SkelSection> sections; std::vector<uint32_t> indices; std::vector<SkelChunk> chunks; std::vector<SkelVertex> verts; u32 numVertices = 0; bool fullUV = false; };
struct SkeletalMesh {
    std::vector<std::string> materials; std::vector<i32> materialRefs; std::vector<Bone> bones; std::vector<SkelLOD> lods; float origin[3] = { 0, 0, 0 }; i32 rotOrigin[3] = { 0, 0, 0 }; std::string err;
};
inline float unpackN(u8 b) { return (float)b / 127.5f - 1.0f; }
inline float halfToFloat(uint16_t h) {
    u32 s = (h >> 15) & 1, e = (h >> 10) & 31, m = h & 1023; u32 f;
    if (e == 0) { if (m == 0) f = s << 31; else { e = 1; while (!(m & 1024)) { m <<= 1; e--; } m &= 1023; f = (s << 31) | ((e + 112) << 23) | (m << 13); } }
    else if (e == 31) f = (s << 31) | 0x7F800000 | (m << 13); else f = (s << 31) | ((e + 112) << 23) | (m << 13);
    float r; memcpy(&r, &f, 4); return r;
}
inline SkeletalMesh parseSkeletalMesh(const Package& pk, i32 idx) {
    SkeletalMesh sm; ObjProps op = objProps(pk, idx); if (!op.ok) { sm.err = "no properties"; return sm; }
    const Export& e = pk.exports[idx - 1];
    try {
        Reader r(pk.dataPtr(e), pk.dataLen(e), op.end);
        r.p += 28;                                              // Bounds
        r.f();                                                  // ConservativeBounds (BM)
        i32 nb = r.i(); if (nb < 0 || nb > 4096) throw Err("bad PerBoneBounds"); r.p += (size_t)nb * 28;
        i32 nm = r.i(); if (nm < 0 || nm > 256) throw Err("bad materials");
        for (i32 k = 0; k < nm; k++) { i32 m = r.i(); sm.materialRefs.push_back(m); sm.materials.push_back(m ? pk.objPath(m) : "None"); }
        for (int k = 0; k < 3; k++) sm.origin[k] = r.f(); for (int k = 0; k < 3; k++) sm.rotOrigin[k] = r.i();
        i32 bn = r.i(); if (bn < 0 || bn > 1024) throw Err("bad skeleton");
        for (i32 k = 0; k < bn; k++) { Bone b; FName f; f.idx = r.i(); f.num = r.i(); b.name = pk.nm(f); b.flags = r.u();
            for (int j = 0; j < 4; j++) b.q[j] = r.f(); for (int j = 0; j < 3; j++) b.pos[j] = r.f(); b.numChildren = r.i(); b.parent = r.i(); r.u(); sm.bones.push_back(b); }
        r.i();                                                  // SkeletalDepth
        i32 nl = r.i(); if (nl < 0 || nl > 8) throw Err("bad LOD count");
        for (i32 l = 0; l < nl; l++) {
            SkelLOD lod;
            i32 ns = r.i(); if (ns < 0 || ns > 1024) throw Err("bad sections");
            for (i32 k = 0; k < ns; k++) { SkelSection s; uint16_t a, b; r.need(2); memcpy(&a, r.d + r.p, 2); r.p += 2; r.need(2); memcpy(&b, r.d + r.p, 2); r.p += 2; s.material = a; s.chunk = b; s.baseIndex = r.u(); uint16_t nt; r.need(2); memcpy(&nt, r.d + r.p, 2); r.p += 2; s.numTris = nt; lod.sections.push_back(s); }
            i32 isz = r.i(), ic = r.i(); if (isz != 2 && isz != 4) throw Err("bad index size"); r.need((size_t)ic * isz);
            lod.indices.resize(ic); for (i32 k = 0; k < ic; k++) { if (isz == 2) { uint16_t v; memcpy(&v, r.d + r.p + k * 2, 2); lod.indices[k] = v; } else memcpy(&lod.indices[k], r.d + r.p + k * 4, 4); } r.p += (size_t)ic * isz;
            i32 n = r.i(); r.need((size_t)n * 2); r.p += (size_t)n * 2;              // ShadowIndices
            n = r.i(); r.need((size_t)n * 2); r.p += (size_t)n * 2;                  // ActiveBoneIndices
            n = r.i(); r.need((size_t)n); r.p += (size_t)n;                          // ShadowTriangleDoubleSided
            i32 nc = r.i(); if (nc < 0 || nc > 1024) throw Err("bad chunks");
            for (i32 k = 0; k < nc; k++) { SkelChunk c; c.baseVertex = r.u();
                i32 rv = r.i(); r.need((size_t)rv * 33); r.p += (size_t)rv * 33;        // RigidVertices (cooked: empty)
                i32 sv = r.i(); r.need((size_t)sv * 40); r.p += (size_t)sv * 40;        // SoftVertices (cooked: empty)
                i32 bm = r.i(); for (i32 j = 0; j < bm; j++) { uint16_t v; r.need(2); memcpy(&v, r.d + r.p, 2); r.p += 2; c.boneMap.push_back(v); }
                c.numRigid = r.i(); c.numSoft = r.i(); c.maxInfluences = r.i(); lod.chunks.push_back(c); }
            r.u();                                                                   // Size
            lod.numVertices = r.u();
            n = r.i(); r.need((size_t)n * 8); r.p += (size_t)n * 8;                  // Edges (BM: 16 bits)
            n = r.i(); r.need((size_t)n); r.p += (size_t)n;                          // RequiredBones
            readBulk(r);                                                             // RawPointIndices
            lod.fullUV = r.i() != 0;                                                 // bUseFullPrecisionUVs
            i32 stride = r.i(), vc = r.i(); if (vc < 0 || vc > 2000000) throw Err("bad vertex count");
            if (stride != (lod.fullUV ? 36 : 32)) throw Err("unexpected vertex stride " + std::to_string(stride));
            r.need((size_t)vc * stride);
            for (i32 k = 0; k < vc; k++) { const u8* v = r.d + r.p + (size_t)k * stride; SkelVertex sv;
                memcpy(sv.pos, v, 12);
                for (int j = 0; j < 3; j++) { sv.tangent[j] = unpackN(v[12 + j]); sv.normal[j] = unpackN(v[16 + j]); }
                memcpy(sv.bones, v + 20, 4); memcpy(sv.weights, v + 24, 4);
                if (lod.fullUV) memcpy(sv.uv, v + 28, 8); else { uint16_t hu, hv; memcpy(&hu, v + 28, 2); memcpy(&hv, v + 30, 2); sv.uv[0] = halfToFloat(hu); sv.uv[1] = halfToFloat(hv); }
                lod.verts.push_back(sv); }
            r.p += (size_t)vc * stride;
            n = r.i(); if (n < 0 || n > 64) throw Err("bad influences");                // VertexInfluences
            for (i32 k = 0; k < n; k++) { i32 m = r.i(); r.need((size_t)m * 8); r.p += (size_t)m * 8; }
            sm.lods.push_back(std::move(lod));
        }
    } catch (std::exception& ex) { sm.err = ex.what(); }
    return sm;
}
// global bone index of a vertex: bones[] are local to the BoneMap of the chunk that contains the vertex
inline int chunkOfVertex(const SkelLOD& lod, u32 v) { for (size_t c = 0; c < lod.chunks.size(); c++) { const auto& ch = lod.chunks[c]; if (v >= ch.baseVertex && v < ch.baseVertex + (u32)(ch.numRigid + ch.numSoft)) return (int)c; } return -1; }


// ------------------------------------------------------------------ StaticMesh
struct StaticVertex { float pos[3]; float normal[3]; float uv[2]; };
struct StaticElement { i32 material = 0; std::string materialPath; u32 firstIndex = 0, numTris = 0, minV = 0, maxV = 0; };
struct StaticLOD { std::vector<StaticElement> elements; std::vector<StaticVertex> verts; std::vector<uint32_t> indices; int numUV = 0; };
struct StaticMesh { std::vector<StaticLOD> lods; std::string err; };
inline void skipBulkArray(Reader& r) { i32 es = r.i(), n = r.i(); if (es < 0 || n < 0) throw Err("bad bulk array"); r.need((size_t)es * n); r.p += (size_t)es * n; }
inline StaticMesh parseStaticMesh(const Package& pk, i32 idx) {
    StaticMesh sm; ObjProps op = objProps(pk, idx); if (!op.ok) { sm.err = "no properties"; return sm; }
    const Export& e = pk.exports[idx - 1];
    try {
        Reader r(pk.dataPtr(e), pk.dataLen(e), op.end);
        r.p += 28; r.i();                                       // Bounds, BodySetup
        skipBulkArray(r); skipBulkArray(r);                     // kDOP Nodes, Triangles
        i32 iv = r.i();                                         // InternalVersion
        if (iv >= 17) { i32 n = r.i(); r.need((size_t)n * 8); r.p += (size_t)n * 8; }   // ContentTags
        i32 nl = r.i(); if (nl < 0 || nl > 8) throw Err("bad LOD count");
        for (i32 l = 0; l < nl; l++) {
            StaticLOD lod; readBulk(r);                         // RawTriangles
            i32 ne = r.i(); if (ne < 0 || ne > 1024) throw Err("bad elements");
            for (i32 k = 0; k < ne; k++) { StaticElement el; el.material = r.i(); el.materialPath = el.material ? pk.objPath(el.material) : "None";
                r.i(); r.i(); r.i();                            // EnableCollision, OldEnableCollision, bEnableShadowCasting
                el.firstIndex = r.u(); el.numTris = r.u(); el.minV = r.u(); el.maxV = r.u(); r.i();   // MaterialIndex
                i32 nf = r.i(); r.need((size_t)nf * 8); r.p += (size_t)nf * 8; lod.elements.push_back(el); }
            // positions
            i32 pstride = r.i(), pnum = r.i(); r.i();           // + bNeedsCPUAccess (BM)
            i32 pes = r.i(), pc = r.i(); if (pes != 12 || pc != pnum) throw Err("bad position buffer"); r.need((size_t)pc * 12);
            lod.verts.resize(pc); for (i32 k = 0; k < pc; k++) memcpy(lod.verts[k].pos, r.d + r.p + (size_t)k * 12, 12); r.p += (size_t)pc * 12; (void)pstride;
            // tangents + UVs
            i32 ntc = r.i(), stride = r.i(), vnum = r.i(); bool full = r.i() != 0; i32 ves = r.i(), vc = r.i();
            if (vc != pc || ves != stride || ntc < 1 || ntc > 8) throw Err("bad vertex buffer");
            int uvBytes = ntc * (full ? 8 : 4); int tangents = (stride - uvBytes) / 4; if (tangents < 2 || tangents > 3) throw Err("bad vertex stride");
            r.need((size_t)vc * stride); lod.numUV = ntc;
            for (i32 k = 0; k < vc; k++) { const u8* v = r.d + r.p + (size_t)k * stride; const u8* nz = v + (tangents - 1) * 4;
                for (int j = 0; j < 3; j++) lod.verts[k].normal[j] = unpackN(nz[j]);
                const u8* uv = v + tangents * 4; if (full) memcpy(lod.verts[k].uv, uv, 8); else { uint16_t a, b; memcpy(&a, uv, 2); memcpy(&b, uv + 2, 2); lod.verts[k].uv[0] = halfToFloat(a); lod.verts[k].uv[1] = halfToFloat(b); } }
            r.p += (size_t)vc * stride; (void)vnum;
            r.i(); r.i(); skipBulkArray(r);                     // ShadowExtrusionVertexBuffer
            r.i();                                              // NumVertices
            i32 ies = r.i(), ic = r.i(); if (ies != 2 && ies != 4) throw Err("bad index buffer"); r.need((size_t)ic * ies);
            lod.indices.resize(ic); for (i32 k = 0; k < ic; k++) { if (ies == 2) { uint16_t x; memcpy(&x, r.d + r.p + k * 2, 2); lod.indices[k] = x; } else memcpy(&lod.indices[k], r.d + r.p + k * 4, 4); }
            r.p += (size_t)ic * ies;
            skipBulkArray(r);                                   // WireframeIndexBuffer
            skipBulkArray(r);                                   // Edges
            i32 n = r.i(); r.need((size_t)n); r.p += (size_t)n; // ShadowTriangleDoubleSided
            sm.lods.push_back(std::move(lod));
        }
    } catch (std::exception& ex) { sm.err = ex.what(); }
    return sm;
}


// ------------------------------------------------------------------ "diffuse" texture of a material (for the preview)
// MaterialInstanceConstant: TextureParameterValues overrides; follows Parent up to the Material and walks the
// expression graph from DiffuseColor to the first TextureSample (honoring parameter overrides).
inline i32 findDiffuseTexture(const Package& pk, i32 mat) {
    auto low = [](std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; };
    auto isDiffName = [&](const std::string& s) { std::string l = low(s); return l.find("diffuse") != std::string::npos || (l.size() > 2 && l.compare(l.size() - 2, 2, "_d") == 0) || l.find("_d_") != std::string::npos; };
    auto valid = [&](i32 o) { return o > 0 && o <= (i32)pk.exports.size(); };
    std::map<std::string, i32> overrides; std::vector<i32> refTex; i32 cur = mat;
    for (int depth = 0; depth < 8 && valid(cur); depth++) {
        ObjProps op = objProps(pk, cur); if (!op.ok) return 0;
        std::string cls = pk.classOf(pk.exports[cur - 1]);
        if (const Tag* tp = findTag(op.tags, "TextureParameterValues")) {
            try { Reader r(tp->raw.data(), tp->raw.size()); i32 n = r.i();
                for (i32 k = 0; k < n && k < 64; k++) { size_t end = 0; auto sub = readProps(pk, tp->raw.data(), tp->raw.size(), r.p, &end); r.p = end;
                    std::string pn = tagName(pk, sub, "ParameterName"); const Tag* pv = findTag(sub, "ParameterValue"); i32 tx = pv ? tagObj(*pv) : 0;
                    if (tx && !overrides.count(pn)) overrides[pn] = tx; } } catch (...) {}
        }
        if (const Tag* rt = findTag(op.tags, "ReferencedTextures")) { try { Reader r(rt->raw.data(), rt->raw.size()); i32 n = r.i(); for (i32 k = 0; k < n && k < 256; k++) { i32 t = r.i(); if (t) refTex.push_back(t); } } catch (...) {} }
        if (cls == "Material") {
            // BFS on the expression graph starting at DiffuseColor
            std::vector<i32> q; std::set<i32> seen;
            if (const Tag* dc = findTag(op.tags, "DiffuseColor")) { try { size_t e = 0; auto sub = readProps(pk, dc->raw.data(), dc->raw.size(), 0, &e); if (const Tag* ex = findTag(sub, "Expression")) q.push_back(tagObj(*ex)); } catch (...) {} }
            for (size_t qi = 0; qi < q.size() && qi < 400; qi++) {
                i32 o = q[qi]; if (!valid(o) || !seen.insert(o).second) continue;
                ObjProps ep = objProps(pk, o); if (!ep.ok) continue;
                if (const Tag* tx = findTag(ep.tags, "Texture")) {
                    std::string pn = tagName(pk, ep.tags, "ParameterName");
                    if (!pn.empty() && pn != "None" && overrides.count(pn)) return overrides[pn];
                    i32 t = tagObj(*tx); if (t) return t;
                }
                for (auto& t : ep.tags) if (t.type == "StructProperty") { try { size_t e = 0; auto sub = readProps(pk, t.raw.data(), t.raw.size(), 0, &e); if (const Tag* ex = findTag(sub, "Expression")) q.push_back(tagObj(*ex)); } catch (...) {} }
            }
            break;
        }
        const Tag* par = findTag(op.tags, "Parent"); if (!par) break; cur = tagObj(*par);
    }
    for (auto& kv : overrides) if (isDiffName(kv.first) || isDiffName(pk.objName(kv.second))) return kv.second;
    for (i32 t : refTex) if (isDiffName(pk.objName(t))) return t;
    if (!overrides.empty()) return overrides.begin()->second;
    return refTex.empty() ? 0 : refTex[0];
}


// blend mode of a material (follows Parent up to the Material): 0 opaque, 1 masked, 2 translucent, 3 additive, 4 modulate
inline int materialBlendMode(const Package& pk, i32 mat) {
    for (int d = 0; d < 8 && mat > 0 && mat <= (i32)pk.exports.size(); d++) {
        ObjProps op = objProps(pk, mat); if (!op.ok) return 0; std::string cls = pk.classOf(pk.exports[mat - 1]);
        if (cls == "Material") { std::string b = tagName(pk, op.tags, "BlendMode"); bool masked = findTag(op.tags, "bIsMasked") && findTag(op.tags, "bIsMasked")->boolVal;
            if (b == "BLEND_Masked" || masked) return 1; if (b == "BLEND_Translucent") return 2; if (b == "BLEND_Additive") return 3; if (b == "BLEND_Modulate") return 4; return 0; }
        const Tag* p = findTag(op.tags, "Parent"); if (!p) return 0; mat = tagObj(*p);
    }
    return 0;
}

} // namespace bm
