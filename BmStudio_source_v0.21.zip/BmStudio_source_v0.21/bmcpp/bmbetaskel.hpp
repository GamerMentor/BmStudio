// bmbetaskel.hpp - characters of the 2007 BETA (Xbox 360, v512 BE) -> PC game (v576): SkeletalMesh, AnimSet/AnimSequence
// and character materials.
//
// SkeletalMesh v512 (checked on the beta Male_Doctor/Guard): Bounds | Materials | Origin | RotOrigin | RefSkeleton
// (bone = 48 bytes: name, flags, quat, pos, NumChildren, Parent) | SkeletalDepth | LODs { sections (u16 mat, u16 chunk,
// u32 base, u16 tris) | indices | ShadowIndices | ActiveBoneIndices | ShadowTriangleDoubleSided | chunks | Size |
// NumVertices | Edges | RequiredBones | RawPointIndices | bFullUV, stride, vertices (32 bytes: pos, tangent, normal,
// bones, weights, half uv) } | NameIndexMap.
// On PC (v576) these are added: ConservativeBounds + PerBoneBounds after Bounds, 4 more bytes per bone (color), Influences
// (empty) at the end of each LOD, and 2 empty counts at the end.
// AnimSequence: same CompressedTrackOffsets scheme as PC; the CompressedByteStream only changes endianness (floats,
// Fixed48 u16s), the offsets do not change.
#pragma once
#include "bmbetaconv.hpp"
#include "bmskelimp.hpp"
#include "bmcopy.hpp"
#include "bmlevel.hpp"
#include <memory>
#include <random>

namespace bm { namespace betaskel {

using beta::BE;
struct Bone { std::string name; u32 flags = 0; float q[4] = { 0, 0, 0, 1 }, p[3] = { 0, 0, 0 }; i32 nc = 0, parent = 0; };
struct Skel { float bounds[7] = { 0 }; std::vector<i32> mats; float origin[3] = { 0, 0, 0 }; i32 rot[3] = { 0, 0, 0 }; std::vector<Bone> bones; i32 depth = 0; std::vector<RawLOD> lods; std::string err; };

inline uint16_t be16(const u8* d) { return (uint16_t)(d[0] << 8 | d[1]); }

inline Skel readSkel(const Package& B, i32 x) {
    Skel S;
    try {
        ObjProps op = objProps(B, x); if (!op.ok) throw Err("properties");
        const u8* d = B.dataPtr(B.exports[x - 1]); size_t n = B.dataLen(B.exports[x - 1]); BE r(d, n, op.end);
        auto f = [&]() { r.need(4); float v = betaconv::rbef(d + r.p); r.p += 4; return v; };
        auto u16 = [&]() { r.need(2); uint16_t v = be16(d + r.p); r.p += 2; return v; };
        for (int k = 0; k < 7; k++) S.bounds[k] = f();
        i32 nm = r.i(); if (nm < 0 || nm > 256) throw Err("materials"); for (i32 k = 0; k < nm; k++) S.mats.push_back(r.i());
        for (int k = 0; k < 3; k++) S.origin[k] = f(); for (int k = 0; k < 3; k++) S.rot[k] = r.i();
        i32 nb = r.i(); if (nb < 1 || nb > 1024) throw Err("skeleton");
        for (i32 k = 0; k < nb; k++) { Bone b; FName fn; fn.idx = r.i(); fn.num = r.i(); b.name = B.nm(fn); b.flags = r.u(); for (int j = 0; j < 4; j++) b.q[j] = f(); for (int j = 0; j < 3; j++) b.p[j] = f(); b.nc = r.i(); b.parent = r.i(); S.bones.push_back(b); }
        S.depth = r.i();
        i32 nl = r.i(); if (nl < 1 || nl > 8) throw Err("LODs");
        for (i32 l = 0; l < nl; l++) {
            RawLOD L;
            i32 ns = r.i(); if (ns < 0 || ns > 1024) throw Err("sections");
            for (i32 k = 0; k < ns; k++) { RawSection s; s.material = u16(); s.chunk = u16(); s.baseIndex = r.u(); s.numTris = u16(); L.sections.push_back(s); }
            L.indexSize = r.i(); i32 ic = r.i(); if (L.indexSize != 2 && L.indexSize != 4) throw Err("indices");
            L.indices.resize(ic); for (i32 k = 0; k < ic; k++) L.indices[k] = L.indexSize == 2 ? u16() : r.u();
            auto u16arr = [&](std::vector<uint16_t>& v) { i32 c = r.i(); if (c < 0) throw Err("array"); v.resize(c); for (i32 k = 0; k < c; k++) v[k] = u16(); };
            u16arr(L.shadowIndices); u16arr(L.activeBones);
            { i32 c = r.i(); r.need((size_t)c); L.shadowDoubleSided.assign(d + r.p, d + r.p + c); r.p += (size_t)c; }
            i32 nc = r.i(); if (nc < 0 || nc > 1024) throw Err("chunks");
            for (i32 k = 0; k < nc; k++) { RawChunk c; c.baseVertex = r.u(); i32 rv = r.i(); if (rv) throw Err("raw rigid vertices (not cooked)"); i32 sv = r.i(); if (sv) throw Err("raw soft vertices (not cooked)");
                u16arr(c.boneMap); c.numRigid = r.i(); c.numSoft = r.i(); c.maxInfluences = r.i(); L.chunks.push_back(c); }
            L.size = r.u(); L.numVertices = r.u();
            { i32 ne = r.i(); if (ne < 0) throw Err("edges"); r.need((size_t)ne * 16); r.p += (size_t)ne * 16; L.edgeCount = 0; }
            { i32 c = r.i(); r.need((size_t)c); L.requiredBones.assign(d + r.p, d + r.p + c); r.p += (size_t)c; }
            { auto bk = beta::readBulkBE(r); if (bk.size > 0) throw Err("RawPointIndices with data"); L.rpFlags = 0; L.rpCount = 0; L.rpOffset = 0; }
            L.fullUV = r.i(); L.stride = r.i(); L.vertCount = r.i(); if (L.stride != (L.fullUV ? 36 : 32)) throw Err("vertex stride " + std::to_string(L.stride));
            r.need((size_t)L.stride * L.vertCount); L.vertsRaw.assign(d + r.p, d + r.p + (size_t)L.stride * L.vertCount); r.p += (size_t)L.stride * L.vertCount;
            for (i32 v = 0; v < L.vertCount; v++) { u8* p = &L.vertsRaw[(size_t)v * L.stride];
                for (int w = 0; w < 7; w++) { std::swap(p[w * 4], p[w * 4 + 3]); std::swap(p[w * 4 + 1], p[w * 4 + 2]); }   // pos(3), tangent, normal, bones, weights
                u8* uv = p + 28; if (L.fullUV) { for (int k = 0; k < 2; k++) { std::swap(uv[k * 4], uv[k * 4 + 3]); std::swap(uv[k * 4 + 1], uv[k * 4 + 2]); } } else { std::swap(uv[0], uv[1]); std::swap(uv[2], uv[3]); } }
            { i32 z = 0; L.influencesRaw.assign((u8*)&z, (u8*)&z + 4); }
            S.lods.push_back(std::move(L));
        }
        // weight sanity (main influence first, sum 255)
        { const auto& L = S.lods[0]; int bad = 0; for (i32 v = 0; v < L.vertCount; v++) { const u8* w = &L.vertsRaw[(size_t)v * L.stride + 24]; if (w[0] + w[1] + w[2] + w[3] < 250 || w[0] < w[3]) bad++; }
          if (bad > L.vertCount / 10) throw Err("unexpected vertex weights (" + std::to_string(bad) + " of " + std::to_string(L.vertCount) + ")"); }
    } catch (std::exception& e) { S.err = e.what(); }
    return S;
}

// new PC SkeletalMesh in T. mats = materials (in the target) in mesh order
inline i32 createSkel(Package& T, i32 outer, const std::string& name, Skel& S, const std::vector<i32>& mats) {
    if (T.findPath((outer ? T.objPath(outer) + "." : "") + name) != 0) throw Err("already exists " + name);
    i32 x = betaconv::newAsset(T, "Engine.SkeletalMesh", outer, name); i32 base = T.exports[x - 1].serialOffset;
    // properties: LODInfo (1 per LOD: shadow on for every section), SkelMeshGUID
    std::vector<Tag> tags;
    { Writer w; w.i((i32)S.lods.size());
      for (size_t l = 0; l < S.lods.size(); l++) { std::vector<Tag> st;
          { Tag t; t.name = "DisplayFactor"; t.type = "FloatProperty"; float v = l == 0 ? 0.f : 1.f / (float)(l + 1); t.raw.resize(4); memcpy(t.raw.data(), &v, 4); st.push_back(t); }
          { Tag t; t.name = "LODHysteresis"; t.type = "FloatProperty"; float v = 0.02f; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); st.push_back(t); }
          { Tag t; t.name = "LODMaterialMap"; t.type = "ArrayProperty"; t.raw.assign(4, 0); st.push_back(t); }
          { Tag t; t.name = "bEnableShadowCasting"; t.type = "ArrayProperty"; i32 ns = (i32)S.lods[l].sections.size(); t.raw.resize(4); memcpy(t.raw.data(), &ns, 4); for (i32 k = 0; k < ns; k++) t.raw.push_back(1); st.push_back(t); }
          w.raw(writeProps(T, st)); }
      Tag t; t.name = "LODInfo"; t.type = "ArrayProperty"; t.raw = w.b; tags.push_back(t); }
    { static std::mt19937 rng{ std::random_device{}() }; u32 g[4]; for (auto& v : g) v = rng(); setStructTag(tags, "SkelMeshGUID", "Guid", g, 16); }
    Writer w; w.raw(std::vector<u8>(4, 0)); w.raw(writeProps(T, tags));
    for (int k = 0; k < 7; k++) w.f(S.bounds[k]);
    w.f(S.bounds[6] * 1.25f); w.i(0);                                                 // ConservativeBounds, PerBoneBounds (empty)
    w.i((i32)mats.size()); for (i32 m : mats) w.i(m);
    for (int k = 0; k < 3; k++) w.f(S.origin[k]); for (int k = 0; k < 3; k++) w.i(S.rot[k]);
    w.i((i32)S.bones.size());
    for (auto& b : S.bones) { w.i(T.addName(b.name)); w.i(0); w.u(b.flags); for (int j = 0; j < 4; j++) w.f(b.q[j]); for (int j = 0; j < 3; j++) w.f(b.p[j]); w.i(b.nc); w.i(b.parent); w.u(0xFFFFFFFFu); }
    w.i(S.depth);
    size_t lodStart = w.b.size(); Writer lw; writeRawLODs(lw, S.lods, base, lodStart); w.raw(lw.b);
    w.i((i32)S.bones.size()); for (size_t k = 0; k < S.bones.size(); k++) { w.i(T.addName(S.bones[k].name)); w.i(0); w.i((i32)k); }
    w.i(0); w.i(0);
    T.exports[x - 1].data = std::move(w.b);
    return x;
}

// ------------------------------------------------------------------ animations
struct SeqInfo { std::string err; };
// CompressedByteStream BE -> LE (same layout). offs = CompressedTrackOffsets (4 per track)
inline bool swapStream(std::vector<u8>& st, const std::vector<i32>& offs, const std::string& rotFmt, const std::string& transFmt, const std::string& keyFmt, int numFrames, std::string& err) {
    std::vector<char> done(st.size(), 0);
    auto sw = [&](size_t off, int sz) -> bool { if (off + sz > st.size()) return false; if (done[off]) return true; done[off] = 1; if (sz == 4) { std::swap(st[off], st[off + 3]); std::swap(st[off + 1], st[off + 2]); } else if (sz == 2) std::swap(st[off], st[off + 1]); return true; };
    int rsz = animdetail::rotSize(rotFmt); if (rsz < 0) { err = "rotation format " + rotFmt; return false; }
    if (transFmt != "ACF_None" && transFmt != "ACF_Float96NoW" && !transFmt.empty()) { err = "translation format " + transFmt; return false; }
    bool variable = keyFmt == "AKF_VariableKeyLerp"; bool wide = numFrames > 0xFF;
    auto frames = [&](size_t off, int n) -> bool { if (!variable || n < 2) return true; off = (off + 3) & ~(size_t)3; if (wide) for (int k = 0; k < n; k++) if (!sw(off + k * 2, 2)) return false; return true; };
    for (size_t t = 0; t + 3 < offs.size(); t += 4) {
        i32 tOff = offs[t], tN = offs[t + 1], rOff = offs[t + 2], rN = offs[t + 3];
        if (tN > 0 && tOff >= 0) { for (int k = 0; k < tN * 3; k++) if (!sw(tOff + k * 4, 4)) { err = "translation outside the stream"; return false; } if (!frames(tOff + (size_t)tN * 12, tN)) return false; }
        if (rN == 1 && rOff >= 0) { for (int k = 0; k < 3; k++) if (!sw(rOff + k * 4, 4)) { err = "rotation outside the stream"; return false; } }
        else if (rN > 1 && rOff >= 0) {
            for (int k = 0; k < 6; k++) if (!sw(rOff + k * 4, 4)) { err = "rotation outside the stream"; return false; }
            size_t b = rOff + 24;
            for (int k = 0; k < rN; k++) { size_t p = b + (size_t)k * rsz;
                if (rsz == 6) { for (int j = 0; j < 3; j++) if (!sw(p + j * 2, 2)) { err = "rotation outside the stream"; return false; } }
                else for (int j = 0; j < rsz / 4; j++) if (!sw(p + j * 4, 4)) { err = "rotation outside the stream"; return false; } }
            if (!frames(b + (size_t)rN * rsz, rN)) return false;
        }
    }
    return true;
}

struct AnimConv { i32 set = 0; int seqs = 0, failed = 0; std::vector<std::string> log; };
// beta AnimSet -> PC (in the given outer). previewMesh = name of the mesh for the preview
inline AnimConv convAnimSet(Package& B, Package& T, i32 bset, i32 outer, const std::string& previewMesh) {
    AnimConv R; ObjProps op = objProps(B, bset); if (!op.ok) { R.log.push_back("unreadable AnimSet"); return R; }
    std::vector<std::string> bones; std::vector<i32> seqs;
    if (const Tag* t = findTag(op.tags, "TrackBoneNames")) { Reader r(t->raw.data(), t->raw.size()); i32 n = r.i(); for (i32 k = 0; k < n; k++) { FName f; f.idx = r.i(); f.num = r.i(); bones.push_back(B.nm(f)); } }
    if (const Tag* t = findTag(op.tags, "Sequences")) { Reader r(t->raw.data(), t->raw.size()); i32 n = r.i(); for (i32 k = 0; k < n; k++) seqs.push_back(r.i()); }
    std::string setName = B.objName(bset); if (T.findPath((outer ? T.objPath(outer) + "." : "") + setName)) setName += "_Beta";
    i32 xs = betaconv::newAsset(T, "Engine.AnimSet", outer, setName); R.set = xs;
    std::vector<i32> newSeqs;
    for (i32 s : seqs) {
        if (s <= 0) continue;
        try {
            ObjProps sp = objProps(B, s); if (!sp.ok) throw Err("properties");
            auto nameOf = [&](const char* n) { return tagName(B, sp.tags, n); };
            std::string rotFmt = nameOf("RotationCompressionFormat"); if (rotFmt.empty()) rotFmt = "ACF_None";
            std::string transFmt = nameOf("TranslationCompressionFormat"); if (transFmt.empty()) transFmt = "ACF_None";
            std::string keyFmt = nameOf("KeyEncodingFormat"); if (keyFmt.empty()) keyFmt = "AKF_ConstantKeyLerp";
            i32 nf = tagInt(sp.tags, "NumFrames", 0);
            std::vector<i32> offs; if (const Tag* t = findTag(sp.tags, "CompressedTrackOffsets")) { Reader r(t->raw.data(), t->raw.size()); i32 n = r.i(); for (i32 k = 0; k < n; k++) offs.push_back(r.i()); }
            if (offs.size() != bones.size() * 4) throw Err("tracks " + std::to_string(offs.size() / 4) + " != bones " + std::to_string(bones.size()));
            const u8* d = B.dataPtr(B.exports[s - 1]); size_t n = B.dataLen(B.exports[s - 1]); BE r(d, n, sp.end);
            i32 cnt = r.i(); r.need((size_t)std::max(0, cnt)); std::vector<u8> st(d + r.p, d + r.p + cnt);
            std::string err; if (!swapStream(st, offs, rotFmt, transFmt, keyFmt, nf, err)) throw Err(err);
            // properties in the target
            std::vector<Tag> tags;
            auto nameT = [&](const char* nm, const std::string& v) { Tag t; t.name = nm; t.type = "NameProperty"; i32 a = T.addName(v), z = 0; t.raw.resize(8); memcpy(t.raw.data(), &a, 4); memcpy(t.raw.data() + 4, &z, 4); tags.push_back(t); };
            auto enumT = [&](const char* nm, const std::string& v) { Tag t; t.name = nm; t.type = "ByteProperty"; i32 a = T.addName(v), z = 0; t.raw.resize(8); memcpy(t.raw.data(), &a, 4); memcpy(t.raw.data() + 4, &z, 4); tags.push_back(t); };
            auto fT = [&](const char* nm, float v) { Tag t; t.name = nm; t.type = "FloatProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); tags.push_back(t); };
            auto iT = [&](const char* nm, i32 v) { Tag t; t.name = nm; t.type = "IntProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); tags.push_back(t); };
            std::string sn = nameOf("SequenceName"); if (sn.empty() || sn == "None") sn = B.objName(s);
            nameT("SequenceName", sn);
            float len = 0; if (const Tag* t = findTag(sp.tags, "SequenceLength")) memcpy(&len, t->raw.data(), 4); fT("SequenceLength", len);
            iT("NumFrames", nf);
            if (const Tag* t = findTag(sp.tags, "RateScale")) { float v; memcpy(&v, t->raw.data(), 4); fT("RateScale", v); }
            if (const Tag* t = findTag(sp.tags, "bNoLoopingInterpolation")) tags.push_back(*t);
            if (const Tag* t = findTag(sp.tags, "bIsAdditive")) tags.push_back(*t);
            enumT("RotationCompressionFormat", rotFmt); if (transFmt != "ACF_None") enumT("TranslationCompressionFormat", transFmt); enumT("KeyEncodingFormat", keyFmt);
            { Tag t; t.name = "CompressedTrackOffsets"; t.type = "ArrayProperty"; Writer ow; ow.i((i32)offs.size()); for (i32 o : offs) ow.i(o); t.raw = ow.b; tags.push_back(t); }
            i32 xq = betaconv::newAsset(T, "Engine.AnimSequence", xs, B.objName(s));
            Writer w; w.raw(std::vector<u8>(4, 0)); w.raw(writeProps(T, tags)); w.i((i32)st.size()); w.raw(st);
            T.exports[xq - 1].data = std::move(w.b); newSeqs.push_back(xq); R.seqs++;
        } catch (std::exception& e) { R.failed++; R.log.push_back("  " + B.objPath(s) + ": " + e.what()); }
    }
    std::vector<Tag> tags;
    { Tag t; t.name = "TrackBoneNames"; t.type = "ArrayProperty"; Writer w; w.i((i32)bones.size()); for (auto& b : bones) { w.i(T.addName(b)); w.i(0); } t.raw = w.b; tags.push_back(t); }
    { Tag t; t.name = "Sequences"; t.type = "ArrayProperty"; Writer w; w.i((i32)newSeqs.size()); for (i32 q : newSeqs) w.i(q); t.raw = w.b; tags.push_back(t); }
    if (!previewMesh.empty()) { Tag t; t.name = "PreviewSkelMeshName"; t.type = "NameProperty"; i32 a = T.addName(previewMesh), z = 0; t.raw.resize(8); memcpy(t.raw.data(), &a, 4); memcpy(t.raw.data() + 4, &z, 4); tags.push_back(t); }
    Writer w; w.raw(std::vector<u8>(4, 0)); w.raw(writeProps(T, tags)); T.exports[xs - 1].data = std::move(w.b);
    return R;
}

// ------------------------------------------------------------------ character material
// master in the target: a Material with bUsedWithSkeletalMesh and texture parameters (FIT_Plaque_Gardens_Adobe_MAT)
inline i32 findSkelMaster(const Package& T) {
    for (size_t k = 0; k < T.exports.size(); k++) { if (T.classOf(T.exports[k]) != "Material") continue; if (T.objName((i32)k + 1) == "FIT_Plaque_Gardens_Adobe_MAT") return (i32)k + 1; }
    return 0;
}
struct ParamInfo { std::string name; u8 guid[16]; bool hasGuid = false; std::string cls; i32 tex = 0; };
inline std::vector<ParamInfo> materialParams(const Package& T, i32 mat) {
    std::vector<ParamInfo> out;
    for (size_t k = 0; k < T.exports.size(); k++) { if (T.exports[k].outer != mat) continue; std::string c = T.classOf(T.exports[k]); if (c.find("Parameter") == std::string::npos) continue;
        ObjProps op = objProps(T, (i32)k + 1); if (!op.ok) continue; ParamInfo p; p.cls = c; p.name = tagName(T, op.tags, "ParameterName");
        if (const Tag* g = findTag(op.tags, "ExpressionGUID")) if (g->raw.size() == 16) { memcpy(p.guid, g->raw.data(), 16); p.hasGuid = true; }
        if (const Tag* t = findTag(op.tags, "Texture")) p.tex = tagObj(*t); out.push_back(p); }
    return out;
}
// new MIC (from scratch) of the master 'parent'. tex: parameter name -> texture; scal: name -> value
inline i32 createParamMIC(Package& T, i32 outer, const std::string& name, i32 parent, const std::map<std::string, i32>& tex, const std::map<std::string, float>& scal) {
    auto params = materialParams(T, parent);
    auto entry = [&](const ParamInfo& p, bool isTex, i32 tv, float sv) {
        std::vector<Tag> st; { Tag t; t.name = "ParameterName"; t.type = "NameProperty"; i32 a = T.addName(p.name), z = 0; t.raw.resize(8); memcpy(t.raw.data(), &a, 4); memcpy(t.raw.data() + 4, &z, 4); st.push_back(t); }
        if (isTex) st.push_back(objTag("ParameterValue", tv)); else { Tag t; t.name = "ParameterValue"; t.type = "FloatProperty"; t.raw.resize(4); memcpy(t.raw.data(), &sv, 4); st.push_back(t); }
        if (p.hasGuid) setStructTag(st, "ExpressionGUID", "Guid", p.guid, 16);
        return writeProps(T, st); };
    Writer tw, sw; int nt = 0, ns = 0; std::vector<i32> refTex;
    for (auto& p : params) {
        if (p.cls.find("TextureSampleParameter") != std::string::npos) { auto it = tex.find(p.name); i32 v = it != tex.end() ? it->second : p.tex; if (it != tex.end()) { tw.raw(entry(p, true, v, 0)); nt++; } if (v) refTex.push_back(v); }
        else if (p.cls == "MaterialExpressionScalarParameter") { auto it = scal.find(p.name); if (it != scal.end()) { sw.raw(entry(p, false, 0, it->second)); ns++; } }
    }
    std::vector<Tag> tags;
    if (ns) { Tag t; t.name = "ScalarParameterValues"; t.type = "ArrayProperty"; Writer w; w.i(ns); w.raw(sw.b); t.raw = w.b; tags.push_back(t); }
    if (nt) { Tag t; t.name = "TextureParameterValues"; t.type = "ArrayProperty"; Writer w; w.i(nt); w.raw(tw.b); t.raw = w.b; tags.push_back(t); }
    tags.push_back(objTag("Parent", parent));
    { ObjProps pp = objProps(T, parent); if (const Tag* rt = findTag(pp.tags, "ReferencedTextures")) { Reader r(rt->raw.data(), rt->raw.size()); i32 n = r.i(); for (i32 k = 0; k < n; k++) { i32 v = r.i(); if (v && std::find(refTex.begin(), refTex.end(), v) == refTex.end()) refTex.push_back(v); } } }
    { Tag t; t.name = "ReferencedTextures"; t.type = "ArrayProperty"; Writer w; w.i((i32)refTex.size()); for (i32 v : refTex) w.i(v); t.raw = w.b; tags.push_back(t); }
    i32 x = betaconv::newAsset(T, "Engine.MaterialInstanceConstant", outer, name);
    Writer w; w.raw(std::vector<u8>(4, 0)); w.raw(writeProps(T, tags)); T.exports[x - 1].data = std::move(w.b);
    return x;
}
inline i32 convSkelMaterial(betaconv::Ctx& C, i32 master, i32 bx) {
    if (bx <= 0) return 0;
    auto key = -1000000 - bx; auto it = C.done.find(key); if (it != C.done.end()) return it->second;
    float sp = 20.f;
    i32 bd = betaconv::betaInputTexture(C.B, bx, "DiffuseColor"), bs = betaconv::betaInputTexture(C.B, bx, "SpecularColor"), bn = betaconv::betaInputTexture(C.B, bx, "Normal");
    betaconv::betaInputTexture(C.B, bx, "SpecularPower", &sp); if (!bd) bd = betaconv::betaInputTexture(C.B, bx, "EmissiveColor");
    i32 d = betaconv::convTexture(C, bd), s = betaconv::convTexture(C, bs), n = betaconv::convTexture(C, bn);
    if (!C.white) C.white = betaconv::solidTexture(C, "White", 255, 255, 255, false);
    if (!C.flatNormal) C.flatNormal = betaconv::solidTexture(C, "FlatNormal", 128, 128, 255, true);
    i32 black = betaconv::solidTexture(C, "Black", 0, 0, 0, false), dark = betaconv::solidTexture(C, "Dark", 40, 40, 40, false);
    std::map<std::string, i32> tex = { { "DIFFUSE Texture", d ? d : C.white }, { "NORMAL TEXTURE", n ? n : C.flatNormal }, { "SPEC TEXTURE", s ? s : dark }, { "REFLECTION MAP", black } };
    std::map<std::string, float> scal = { { "REFLECTION STRENGTH", 0.f }, { "SPEC STRENGTH", 1.f } };
    std::string nm = C.B.objName(bx) + "_Char"; i32 outer = betaconv::destOuter(C, bx); if (C.T.findPath(C.T.objPath(outer) + "." + nm)) nm += "2";
    i32 x = createParamMIC(C.T, outer, nm, master, tex, scal); C.materials++;
    C.done[key] = x; return x;
}

} }
