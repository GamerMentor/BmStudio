// bmskelimp.hpp - Phase 5: importing FBX into an existing COOKED SkeletalMesh (replaces the geometry of every LOD,
// keeping skeleton, materials, properties and the rest of the export). Layout as in parseSkeletalMesh (BM v576).
#pragma once
#include "bmanim.hpp"
#include "bmfbxread.hpp"
#include <unordered_map>
#include <set>
#include <array>
#include <cmath>

namespace bm {

// ------------------------------------------------------------------ "raw" LOD: every field, to rewrite byte by byte
struct RawChunk { u32 baseVertex = 0; std::vector<u8> rigidRaw, softRaw; i32 rigidCount = 0, softCount = 0; std::vector<uint16_t> boneMap; i32 numRigid = 0, numSoft = 0, maxInfluences = 0; };
struct RawSection { uint16_t material = 0, chunk = 0; u32 baseIndex = 0; uint16_t numTris = 0; };
struct RawLOD {
    std::vector<RawSection> sections; i32 indexSize = 2; std::vector<u32> indices;
    std::vector<uint16_t> shadowIndices, activeBones; std::vector<u8> shadowDoubleSided;
    std::vector<RawChunk> chunks; u32 size = 0, numVertices = 0; i32 edgeCount = 0; std::vector<u8> edgesRaw; std::vector<u8> requiredBones;
    u32 rpFlags = 0; i32 rpCount = 0; std::vector<u8> rpData; i32 rpOffset = -1;     // RawPointIndices (bulk)
    i32 fullUV = 0, stride = 32, vertCount = 0; std::vector<u8> vertsRaw; std::vector<u8> influencesRaw;
};
struct RawSkel { size_t boundsOff = 0, lodCountOff = 0, lodEnd = 0; std::vector<RawLOD> lods; std::string err; };

inline RawSkel readRawSkel(const Package& pk, i32 idx) {
    RawSkel rs; ObjProps op = objProps(pk, idx); if (!op.ok) { rs.err = "no properties"; return rs; }
    const Export& e = pk.exports[idx - 1];
    try {
        Reader r(pk.dataPtr(e), pk.dataLen(e), op.end);
        rs.boundsOff = r.p; r.p += 28; r.f();
        i32 nb = r.i(); r.p += (size_t)nb * 28; i32 nm = r.i(); r.p += (size_t)nm * 4; r.p += 24;
        i32 bn = r.i(); r.p += (size_t)bn * 52; r.i();
        rs.lodCountOff = r.p; i32 nl = r.i(); if (nl < 0 || nl > 8) throw Err("bad LOD count");
        auto u16arr = [&](std::vector<uint16_t>& v) { i32 n = r.i(); r.need((size_t)n * 2); v.resize(n); if (n) memcpy(v.data(), r.d + r.p, (size_t)n * 2); r.p += (size_t)n * 2; };
        for (i32 l = 0; l < nl; l++) {
            RawLOD L;
            i32 ns = r.i(); for (i32 k = 0; k < ns; k++) { RawSection s; r.need(10); memcpy(&s.material, r.d + r.p, 2); memcpy(&s.chunk, r.d + r.p + 2, 2); memcpy(&s.baseIndex, r.d + r.p + 4, 4); memcpy(&s.numTris, r.d + r.p + 8, 2); r.p += 10; L.sections.push_back(s); }
            L.indexSize = r.i(); i32 ic = r.i(); r.need((size_t)ic * L.indexSize); L.indices.resize(ic);
            for (i32 k = 0; k < ic; k++) { if (L.indexSize == 2) { uint16_t v; memcpy(&v, r.d + r.p + k * 2, 2); L.indices[k] = v; } else memcpy(&L.indices[k], r.d + r.p + k * 4, 4); } r.p += (size_t)ic * L.indexSize;
            u16arr(L.shadowIndices); u16arr(L.activeBones);
            { i32 n = r.i(); L.shadowDoubleSided = r.raw((size_t)n); }
            i32 nc = r.i(); for (i32 k = 0; k < nc; k++) { RawChunk c; c.baseVertex = r.u(); c.rigidCount = r.i(); c.rigidRaw = r.raw((size_t)c.rigidCount * 33); c.softCount = r.i(); c.softRaw = r.raw((size_t)c.softCount * 40);
                u16arr(c.boneMap); c.numRigid = r.i(); c.numSoft = r.i(); c.maxInfluences = r.i(); L.chunks.push_back(c); }
            L.size = r.u(); L.numVertices = r.u();
            L.edgeCount = r.i(); L.edgesRaw = r.raw((size_t)L.edgeCount * 8);
            { i32 n = r.i(); L.requiredBones = r.raw((size_t)n); }
            L.rpFlags = r.u(); L.rpCount = r.i(); i32 sz = r.i(); L.rpOffset = r.i(); if (!(L.rpFlags & BULK_SEPARATE) && L.rpOffset != -1) L.rpData = r.raw((size_t)std::max(0, sz)); else if (sz) throw Err("separate RawPointIndices not supported");
            L.fullUV = r.i(); L.stride = r.i(); L.vertCount = r.i(); L.vertsRaw = r.raw((size_t)L.vertCount * L.stride);
            { size_t st = r.p; i32 n = r.i(); for (i32 k = 0; k < n; k++) { i32 m = r.i(); r.need((size_t)m * 8); r.p += (size_t)m * 8; } L.influencesRaw.assign(r.d + st, r.d + r.p); }
            rs.lods.push_back(std::move(L));
        }
        rs.lodEnd = r.p;
    } catch (std::exception& ex) { rs.err = ex.what(); }
    return rs;
}
// writes the LODs; bulkBase = ORIGINAL SerialOffset of the export + position where the LOD block starts in the export
// (the inline bulk offset becomes "original+pos+16", which Package::save fixes to the final position)
inline void writeRawLODs(Writer& w, const std::vector<RawLOD>& lods, i32 exportSerialOffset, size_t blockStartInExport) {
    size_t base = w.b.size();
    auto u16 = [&](uint16_t v) { w.b.push_back((u8)v); w.b.push_back((u8)(v >> 8)); };
    auto u16arr = [&](const std::vector<uint16_t>& v) { w.i((i32)v.size()); for (auto x : v) u16(x); };
    w.i((i32)lods.size());
    for (auto& L : lods) {
        w.i((i32)L.sections.size()); for (auto& s : L.sections) { u16(s.material); u16(s.chunk); w.u(s.baseIndex); u16(s.numTris); }
        w.i(L.indexSize); w.i((i32)L.indices.size()); for (u32 x : L.indices) { if (L.indexSize == 2) u16((uint16_t)x); else w.u(x); }
        u16arr(L.shadowIndices); u16arr(L.activeBones);
        w.i((i32)L.shadowDoubleSided.size()); w.raw(L.shadowDoubleSided);
        w.i((i32)L.chunks.size()); for (auto& c : L.chunks) { w.u(c.baseVertex); w.i(c.rigidCount); w.raw(c.rigidRaw); w.i(c.softCount); w.raw(c.softRaw); u16arr(c.boneMap); w.i(c.numRigid); w.i(c.numSoft); w.i(c.maxInfluences); }
        w.u(L.size); w.u(L.numVertices);
        w.i(L.edgeCount); w.raw(L.edgesRaw);
        w.i((i32)L.requiredBones.size()); w.raw(L.requiredBones);
        size_t hdr = w.b.size() - base + blockStartInExport;   // position of the bulk header inside the export
        w.u(L.rpFlags); w.i(L.rpCount); w.i((i32)L.rpData.size()); w.i(L.rpOffset == -1 && L.rpData.empty() ? -1 : exportSerialOffset + (i32)hdr + 16); w.raw(L.rpData);
        w.i(L.fullUV); w.i(L.stride); w.i(L.vertCount); w.raw(L.vertsRaw);
        w.raw(L.influencesRaw);
    }
}

// ------------------------------------------------------------------ vertex utilities
inline uint16_t floatToHalf(float f) {
    u32 x; memcpy(&x, &f, 4); u32 sign = (x >> 16) & 0x8000; i32 exp = (i32)((x >> 23) & 0xFF) - 127 + 15; u32 man = x & 0x7FFFFF;
    if (exp <= 0) { if (exp < -10) return (uint16_t)sign; man |= 0x800000; u32 t = 14 - exp; u32 h = man >> t; if ((man >> (t - 1)) & 1) h++; return (uint16_t)(sign | h); }
    if (exp >= 31) return (uint16_t)(sign | 0x7C00);
    u32 h = sign | ((u32)exp << 10) | (man >> 13); if (man & 0x1000) h++; return (uint16_t)h;
}
inline u8 packN(float v) { int i = (int)lroundf((v + 1.0f) * 127.5f); return (u8)std::max(0, std::min(255, i)); }


// ------------------------------------------------------------------ FBX import -> cooked LOD
struct ImportOptions {
    std::map<std::string, int> materialMap;   // material name in the FBX -> mesh material index (-1 = automatic)
    int maxBones = 75;                        // MAX_GPUSKIN_BONES
    bool identityFit = false;                 // geometry already in mesh space (e.g. 1-bone PSK): no bone-based fitting
};
struct ImportReport {
    bool ok = false; std::string err; std::vector<std::string> warnings;
    int fbxMeshes = 0, fbxVerts = 0, triangles = 0, vertices = 0, sections = 0, chunks = 0, unweighted = 0, fitPairs = 0; double fitScale = 1, fitError = 0, fitMaxError = 0; bool mirrored = false;
    std::vector<std::string> fbxMaterials; std::vector<int> materialSlot; std::vector<std::string> unmatchedBones;
    std::vector<u8> newData;   // new export data
};

namespace imp {
using fbxr::M;
struct Wedge { float pos[3], nrm[3], uv[2]; uint16_t bones[4]; u8 w[4]; int mat; };
inline double det3(const M& a) { return a.m[0][0] * (a.m[1][1] * a.m[2][2] - a.m[1][2] * a.m[2][1]) - a.m[0][1] * (a.m[1][0] * a.m[2][2] - a.m[1][2] * a.m[2][0]) + a.m[0][2] * (a.m[1][0] * a.m[2][1] - a.m[1][1] * a.m[2][0]); }
inline bool inv3(const double a[3][3], double o[3][3]) {
    double d = a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1]) - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0]) + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]); if (fabs(d) < 1e-30) return false;
    o[0][0] = (a[1][1] * a[2][2] - a[1][2] * a[2][1]) / d; o[0][1] = (a[0][2] * a[2][1] - a[0][1] * a[2][2]) / d; o[0][2] = (a[0][1] * a[1][2] - a[0][2] * a[1][1]) / d;
    o[1][0] = (a[1][2] * a[2][0] - a[1][0] * a[2][2]) / d; o[1][1] = (a[0][0] * a[2][2] - a[0][2] * a[2][0]) / d; o[1][2] = (a[0][2] * a[1][0] - a[0][0] * a[1][2]) / d;
    o[2][0] = (a[1][0] * a[2][1] - a[1][1] * a[2][0]) / d; o[2][1] = (a[0][1] * a[2][0] - a[0][0] * a[2][1]) / d; o[2][2] = (a[0][0] * a[1][1] - a[0][1] * a[1][0]) / d; return true;
}
// best similarity (rotation/reflection + uniform scale + translation) taking src -> dst
inline bool fitSimilarity(const std::vector<std::array<double, 3>>& src, const std::vector<std::array<double, 3>>& dst, M& out, double& scale) {
    size_t n = src.size(); if (n < 4) return false;
    double cs[3] = { 0, 0, 0 }, cd[3] = { 0, 0, 0 }; for (size_t i = 0; i < n; i++) for (int k = 0; k < 3; k++) { cs[k] += src[i][k] / n; cd[k] += dst[i][k] / n; }
    double SS[3][3] = {}, DS[3][3] = {};   // A = DS * SS^-1  (least squares for the linear part)
    for (size_t i = 0; i < n; i++) { double a[3], b[3]; for (int k = 0; k < 3; k++) { a[k] = src[i][k] - cs[k]; b[k] = dst[i][k] - cd[k]; }
        for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) { SS[r][c] += a[r] * a[c]; DS[r][c] += b[r] * a[c]; } }
    double SI[3][3]; if (!inv3(SS, SI)) return false; double A[3][3] = {};
    for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) for (int k = 0; k < 3; k++) A[r][c] += DS[r][k] * SI[k][c];
    // polar decomposition: orthogonal Q (may have det -1)
    double Q[3][3]; memcpy(Q, A, sizeof Q);
    for (int it = 0; it < 60; it++) { double I[3][3]; if (!inv3(Q, I)) return false; double N[3][3]; for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) N[r][c] = 0.5 * (Q[r][c] + I[c][r]); memcpy(Q, N, sizeof Q); }
    double tr = 0; for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) tr += Q[r][c] * A[r][c]; scale = tr / 3.0;
    out = fbxr::mident(); for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) out.m[r][c] = Q[r][c] * scale;
    for (int r = 0; r < 3; r++) { double v = cd[r]; for (int c = 0; c < 3; c++) v -= out.m[r][c] * cs[c]; out.m[r][3] = v; }
    return true;
}
inline void normalize(float v[3]) { float l = sqrtf(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); if (l > 1e-12f) for (int k = 0; k < 3; k++) v[k] /= l; }
struct PosKey { int32_t x, y, z; bool operator==(const PosKey& o) const { return x == o.x && y == o.y && z == o.z; } };
struct PosHash { size_t operator()(const PosKey& k) const { return (size_t)k.x * 73856093u ^ (size_t)k.y * 19349663u ^ (size_t)k.z * 83492791u; } };
inline PosKey pkey(const float p[3]) { PosKey k; memcpy(&k.x, &p[0], 4); memcpy(&k.y, &p[1], 4); memcpy(&k.z, &p[2], 4); return k; }
}


// ---- LODInfo (property) has to follow the new sections: the engine does check(Info.bEnableShadowCasting.Num() == LODModel.Sections.Num())
// (UnSkeletalMesh.cpp, FSkeletalMeshSceneProxy) -> assert/crash on load if the FBX has a different number of materials/sections.
namespace imp {
inline void writeTagsConst(const Package& pk, const std::vector<Tag>& tags, Writer& w) {
    auto nm = [&](const std::string& s) { i32 k = pk.findName(s); if (k < 0) throw Err("name not in package: " + s); return k; };
    for (auto& t : tags) {
        w.i(nm(t.name)); w.i(0); w.i(nm(t.type)); w.i(0); w.i(t.isBool ? 0 : (i32)t.raw.size()); w.i(t.index);
        if (t.type == "StructProperty") { w.i(nm(t.strct)); w.i(0); }
        if (t.isBool) { w.i(t.boolVal ? 1 : 0); continue; }
        w.raw(t.raw);
    }
    w.i(nm("None")); w.i(0);
}
// returns the rewritten property block (LODInfo with bEnableShadowCasting = nsec[l] TRUE entries and an empty LODMaterialMap)
inline std::vector<u8> rebuildPropsForSections(const Package& pk, const std::vector<Tag>& tags, const std::vector<size_t>& nsec, std::string& note) {
    std::vector<Tag> out = tags; bool found = false;
    for (auto& t : out) {
        if (t.name != "LODInfo" || t.type != "ArrayProperty") continue; found = true;
        Reader r(t.raw.data(), t.raw.size()); i32 n = r.i(); size_t pos = 4; Writer w; w.i(n);
        for (i32 i = 0; i < n; i++) {
            size_t end = 0; std::vector<Tag> el = readProps(pk, t.raw.data(), t.raw.size(), pos, &end); pos = end;
            size_t want = i < (i32)nsec.size() ? nsec[i] : nsec.back();
            for (auto& x : el) {
                if (x.name == "bEnableShadowCasting" && x.type == "ArrayProperty") { x.raw.clear(); Writer a; a.i((i32)want); for (size_t k = 0; k < want; k++) a.b.push_back(1); x.raw = a.b; }
                if (x.name == "LODMaterialMap" && x.type == "ArrayProperty") { Writer a; a.i(0); x.raw = a.b; }   // sections already use the mesh material index
            }
            bool hasShadow = false; for (auto& x : el) if (x.name == "bEnableShadowCasting") hasShadow = true;
            if (!hasShadow) { Tag x; x.name = "bEnableShadowCasting"; x.type = "ArrayProperty"; Writer a; a.i((i32)want); for (size_t k = 0; k < want; k++) a.b.push_back(1); x.raw = a.b; el.push_back(x); }
            writeTagsConst(pk, el, w);
        }
        t.raw = w.b; note = "LODInfo: " + std::to_string(n) + " LOD(s), shadow flags resized to " + std::to_string(nsec.empty() ? 0 : nsec[0]) + " section(s)";
    }
    if (!found) note = "LODInfo absent (the game rebuilds it on load)";
    Writer w; writeTagsConst(pk, out, w); return w.b;
}
}
inline ImportReport importFBXToSkeletalMesh(const Package& pk, i32 meshIdx, const fbxr::Scene& sc, const ImportOptions& opt) {
    using namespace imp; ImportReport rep;
    try {
        if (!sc.err.empty()) throw Err(sc.err);
        SkeletalMesh sm = parseSkeletalMesh(pk, meshIdx); if (!sm.err.empty()) throw Err("target mesh: " + sm.err);
        RawSkel rs = readRawSkel(pk, meshIdx); if (!rs.err.empty() || rs.lods.empty()) throw Err("target mesh: " + rs.err);
        const Export& ex = pk.exports[meshIdx - 1]; const RawLOD& orig = rs.lods[0];
        std::vector<M4> ueWorld; std::vector<int> none; poseBones(sm, nullptr, none, 0, ueWorld);
        size_t nb = sm.bones.size();
        // --- bones: FBX model -> mesh bone
        auto findBone = [&](const std::string& n) -> int { for (size_t b = 0; b < nb; b++) if (_bmieq(sm.bones[b].name, n)) return (int)b; return -1; };
        std::map<int64_t, int> boneOf;
        std::set<std::string> unmatched;
        for (auto& kv : sc.models) { int b = findBone(kv.second.name); if (b >= 0) boneOf[kv.first] = b; }
        auto resolve = [&](int64_t id) -> int { for (int g = 0; id && g < 128; g++) { auto it = boneOf.find(id); if (it != boneOf.end()) return it->second; auto m = sc.models.find(id); if (m == sc.models.end()) break; id = m->second.parent; } return -1; };
        // --- pairs for the fit (bone position in the FBX bind pose x position in the game skeleton)
        std::vector<std::array<double, 3>> src, dst; std::set<int> used;
        for (auto& mg : sc.meshes) for (auto& cl : mg.clusters) { auto it = boneOf.find(cl.bone); if (it == boneOf.end() || used.count(it->second)) continue;
            M g = cl.hasLink ? cl.link : fbxr::modelGlobal(sc, cl.bone); used.insert(it->second);
            src.push_back({ g.m[0][3], g.m[1][3], g.m[2][3] }); dst.push_back({ ueWorld[it->second].m[3][0], ueWorld[it->second].m[3][1], ueWorld[it->second].m[3][2] }); }
        if (src.size() < 4) for (auto& kv : boneOf) { if (used.count(kv.second)) continue; M g = fbxr::modelGlobal(sc, kv.first); used.insert(kv.second);
            src.push_back({ g.m[0][3], g.m[1][3], g.m[2][3] }); dst.push_back({ ueWorld[kv.second].m[3][0], ueWorld[kv.second].m[3][1], ueWorld[kv.second].m[3][2] }); }
        M S = fbxr::mident(); double scale = 1;
        if (!opt.identityFit && !fitSimilarity(src, dst, S, scale)) throw Err("could not match the FBX skeleton to the game skeleton (need at least 4 bones with the same names)");
        rep.fitPairs = (int)src.size(); rep.fitScale = scale;
        { double sum = 0, mx = 0; size_t k = 0; for (size_t i = 0; i < src.size(); i++) { double o[3]; double v[3] = { src[i][0], src[i][1], src[i][2] }; fbxr::apply(S, v, o); double e = sqrt((o[0] - dst[i][0]) * (o[0] - dst[i][0]) + (o[1] - dst[i][1]) * (o[1] - dst[i][1]) + (o[2] - dst[i][2]) * (o[2] - dst[i][2])); sum += e; mx = std::max(mx, e); k++; }
          rep.fitError = k ? sum / k : 0; rep.fitMaxError = mx; }
        // --- wedges
        std::vector<Wedge> wedges; std::vector<std::string> matNames;
        auto matIndex = [&](const std::string& n) { for (size_t k = 0; k < matNames.size(); k++) if (matNames[k] == n) return (int)k; matNames.push_back(n); return (int)matNames.size() - 1; };
        for (auto& mg : sc.meshes) {
            rep.fbxMeshes++; size_t ncp = mg.verts.size() / 3; rep.fbxVerts += (int)ncp;
            // influences per control point
            std::vector<std::vector<std::pair<int, double>>> infl(ncp);
            M meshG = fbxr::modelGlobal(sc, mg.model);
            bool haveTransform = false;
            for (auto& cl : mg.clusters) { int b = resolve(cl.bone); if (b < 0) { auto m = sc.models.find(cl.bone); unmatched.insert(m != sc.models.end() ? m->second.name : "?"); b = 0; }
                if (!haveTransform) { meshG = cl.hasLink ? fbxr::mmul(cl.link, cl.transform) : cl.transform; haveTransform = true; }   // in the file: Transform = inv(Link) * mesh
                for (size_t k = 0; k < cl.idx.size() && k < cl.w.size(); k++) { int64_t v = cl.idx[k]; if (v < 0 || (size_t)v >= ncp || cl.w[k] <= 0) continue; auto& L = infl[v]; bool merged = false;
                    for (auto& p : L) if (p.first == b) { p.second += cl.w[k]; merged = true; } if (!merged) L.push_back({ b, cl.w[k] }); } }
            M T = fbxr::mmul(S, meshG); bool flip = det3(T) < 0; rep.mirrored = flip;
            // normal matrix = inverse transpose of the linear part of T
            double L3[3][3], I3[3][3]; for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) L3[r][c] = T.m[r][c]; inv3(L3, I3);
            // mesh materials
            std::vector<int> localMat; for (auto& n : mg.materialNames) localMat.push_back(matIndex(n)); if (localMat.empty()) localMat.push_back(matIndex(mg.name.empty() ? "material" : mg.name));
            // transformed points
            std::vector<std::array<float, 3>> P(ncp); for (size_t i = 0; i < ncp; i++) { double v[3] = { mg.verts[i * 3], mg.verts[i * 3 + 1], mg.verts[i * 3 + 2] }, o[3]; fbxr::apply(T, v, o); P[i] = { (float)o[0], (float)o[1], (float)o[2] }; }
            // quantized weights
            std::vector<std::array<uint16_t, 4>> VB(ncp); std::vector<std::array<u8, 4>> VW(ncp);
            for (size_t i = 0; i < ncp; i++) { auto L = infl[i]; std::sort(L.begin(), L.end(), [](auto& a, auto& b) { return a.second > b.second; }); if (L.size() > 4) L.resize(4);
                double tot = 0; for (auto& p : L) tot += p.second; VB[i] = { 0, 0, 0, 0 }; VW[i] = { 255, 0, 0, 0 };
                if (L.empty() || tot <= 0) { rep.unweighted++; int b = mg.clusters.empty() ? resolve(mg.model) : -1; VB[i][0] = (uint16_t)std::max(0, b); continue; }
                int sum = 0; for (size_t k = 0; k < L.size(); k++) { VB[i][k] = (uint16_t)L[k].first; int w = (int)(L[k].second / tot * 255.0); VW[i][k] = (u8)w; sum += w; } VW[i][0] = (u8)(VW[i][0] + (255 - sum)); }
            // polygons
            size_t corner = 0, poly = 0; std::vector<size_t> cornersOfPoly;
            auto attr = [&](const std::vector<double>& data, const std::vector<int64_t>& idx, const std::string& map, const std::string& ref, size_t cornerIdx, size_t cp, int comps, double* out) -> bool {
                if (data.empty()) return false; size_t i = (map == "ByPolygonVertex") ? cornerIdx : (map == "ByPolygon" ? poly : cp);
                if (ref == "IndexToDirect" && !idx.empty()) { if (i >= idx.size()) return false; i = (size_t)idx[i]; }
                if ((i + 1) * comps > data.size()) return false; for (int k = 0; k < comps; k++) out[k] = data[i * comps + k]; return true; };
            for (size_t c = 0; c < mg.pvi.size(); c++) {
                cornersOfPoly.push_back(c);
                if (mg.pvi[c] >= 0) continue;
                // closes the polygon: fan triangulation
                int mat = 0; if (!mg.mats.empty()) { size_t mi = mg.matMap == "AllSame" ? 0 : poly; if (mi < mg.mats.size() && mg.mats[mi] >= 0 && (size_t)mg.mats[mi] < localMat.size()) mat = localMat[mg.mats[mi]]; else mat = localMat[0]; } else mat = localMat[0];
                std::vector<Wedge> pw;
                for (size_t cc : cornersOfPoly) { int64_t v = mg.pvi[cc]; if (v < 0) v = ~v; if ((size_t)v >= ncp) continue; Wedge w;
                    memcpy(w.pos, P[v].data(), 12);
                    double n[3] = { 0, 0, 1 }; bool hn = attr(mg.normals, mg.normalIdx, mg.normalMap, mg.normalRef, cc, (size_t)v, 3, n);
                    if (hn) { for (int r = 0; r < 3; r++) w.nrm[r] = (float)(I3[0][r] * n[0] + I3[1][r] * n[1] + I3[2][r] * n[2]); normalize(w.nrm); } else { w.nrm[0] = w.nrm[1] = 0; w.nrm[2] = 0; }
                    double uv[2] = { 0, 0 }; attr(mg.uvs, mg.uvIdx, mg.uvMap, mg.uvRef, cc, (size_t)v, 2, uv); w.uv[0] = (float)uv[0]; w.uv[1] = (float)(1.0 - uv[1]);
                    for (int k = 0; k < 4; k++) { w.bones[k] = VB[v][k]; w.w[k] = VW[v][k]; } w.mat = mat; pw.push_back(w); }
                for (size_t k = 1; k + 1 < pw.size(); k++) { if (flip) { wedges.push_back(pw[0]); wedges.push_back(pw[k + 1]); wedges.push_back(pw[k]); } else { wedges.push_back(pw[0]); wedges.push_back(pw[k]); wedges.push_back(pw[k + 1]); } }
                cornersOfPoly.clear(); poly++;
            }
        }
        for (auto& n : unmatched) rep.unmatchedBones.push_back(n);
        size_t ntri = wedges.size() / 3; if (!ntri) throw Err("the FBX has no triangles");
        // missing normals: face normal
        for (size_t t = 0; t < ntri; t++) { Wedge* w = &wedges[t * 3]; float e1[3], e2[3], n[3]; for (int k = 0; k < 3; k++) { e1[k] = w[1].pos[k] - w[0].pos[k]; e2[k] = w[2].pos[k] - w[0].pos[k]; }
            n[0] = e1[1] * e2[2] - e1[2] * e2[1]; n[1] = e1[2] * e2[0] - e1[0] * e2[2]; n[2] = e1[0] * e2[1] - e1[1] * e2[0]; normalize(n);
            for (int j = 0; j < 3; j++) if (w[j].nrm[0] == 0 && w[j].nrm[1] == 0 && w[j].nrm[2] == 0) memcpy(w[j].nrm, n, 12); }
        // --- materials: FBX -> mesh slots
        int nm = (int)sm.materials.size(); rep.fbxMaterials = matNames;
        for (size_t k = 0; k < matNames.size(); k++) {
            int slot = -1; auto it = opt.materialMap.find(matNames[k]); if (it != opt.materialMap.end() && it->second >= 0 && it->second < nm) slot = it->second;
            if (slot < 0) for (int m = 0; m < nm; m++) { std::string s = sm.materials[m]; size_t d = s.rfind('.'); if (d != std::string::npos) s = s.substr(d + 1); if (_bmieq(s, matNames[k])) { slot = m; break; } }
            if (slot < 0) slot = (int)std::min<size_t>(k, (size_t)std::max(0, nm - 1));
            rep.materialSlot.push_back(slot);
        }
        // --- per-face tangents (like USkeletalMesh::CreateSkinningStreams)
        std::vector<std::array<float, 3>> ftx(ntri), fty(ntri), fn(ntri);
        for (size_t t = 0; t < ntri; t++) { Wedge* w = &wedges[t * 3]; float e1[3], e2[3]; for (int k = 0; k < 3; k++) { e1[k] = w[1].pos[k] - w[0].pos[k]; e2[k] = w[2].pos[k] - w[0].pos[k]; }
            float du1 = w[1].uv[0] - w[0].uv[0], dv1 = w[1].uv[1] - w[0].uv[1], du2 = w[2].uv[0] - w[0].uv[0], dv2 = w[2].uv[1] - w[0].uv[1]; float r = du1 * dv2 - du2 * dv1; float inv = fabsf(r) > 1e-12f ? 1.f / r : 0.f;
            float tx[3], ty[3], n[3] = { e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0] }; normalize(n);
            for (int k = 0; k < 3; k++) { tx[k] = (e1[k] * dv2 - e2[k] * dv1) * inv; ty[k] = (e2[k] * du1 - e1[k] * du2) * inv; }
            float d = tx[0] * n[0] + tx[1] * n[1] + tx[2] * n[2]; for (int k = 0; k < 3; k++) tx[k] -= n[k] * d; d = ty[0] * n[0] + ty[1] * n[1] + ty[2] * n[2]; for (int k = 0; k < 3; k++) ty[k] -= n[k] * d;
            normalize(tx); normalize(ty); ftx[t] = { tx[0], tx[1], tx[2] }; fty[t] = { ty[0], ty[1], ty[2] }; fn[t] = { n[0], n[1], n[2] }; }
        // tangents smoothed across triangles that share position+UV (and the same basis handedness), like the engine editor
        struct TK { float p[3], uv[2]; int s; bool operator==(const TK& o) const { return memcmp(this, &o, sizeof(TK)) == 0; } };
        struct TH { size_t operator()(const TK& k) const { const u8* p = (const u8*)&k; size_t h = 1469598103934665603ull; for (size_t i = 0; i < sizeof(TK); i++) { h ^= p[i]; h *= 1099511628211ull; } return h; } };
        std::unordered_map<TK, std::array<float, 6>, TH> tacc; std::vector<TK> wkey(wedges.size());
        for (size_t t = 0; t < ntri; t++) { float* X = ftx[t].data(); float* Y = fty[t].data(); float* N = fn[t].data();
            float det = X[0] * (Y[1] * N[2] - Y[2] * N[1]) - X[1] * (Y[0] * N[2] - Y[2] * N[0]) + X[2] * (Y[0] * N[1] - Y[1] * N[0]);
            for (int j = 0; j < 3; j++) { TK k; memset(&k, 0, sizeof k); memcpy(k.p, wedges[t * 3 + j].pos, 12); memcpy(k.uv, wedges[t * 3 + j].uv, 8); k.s = det < 0 ? -1 : 1; wkey[t * 3 + j] = k;
                auto& a = tacc[k]; for (int q = 0; q < 3; q++) { a[q] += X[q]; a[3 + q] += Y[q]; } } }
        // --- sections/chunks (bone budget per chunk)
        struct VKey { float pos[3], nrm[3], uv[2]; uint16_t b[4]; u8 w[4]; bool operator==(const VKey& o) const { return memcmp(this, &o, sizeof(VKey)) == 0; } };
        struct VHash { size_t operator()(const VKey& k) const { const u8* p = (const u8*)&k; size_t h = 1469598103934665603ull; for (size_t i = 0; i < sizeof(VKey); i++) { h ^= p[i]; h *= 1099511628211ull; } return h; } };
        struct BVert { VKey k; float tx[3], ty[3]; };
        struct BChunk { std::vector<uint16_t> boneMap; std::vector<BVert> verts; std::unordered_map<VKey, int, VHash> index; };
        struct BSection { int mat; int chunk; std::vector<int> tris; std::vector<u32> local; };
        std::vector<BSection> secs; std::vector<BChunk> chunks;
        for (size_t t = 0; t < ntri; t++) {
            Wedge* w = &wedges[t * 3]; int mat = rep.materialSlot[w[0].mat];
            std::set<uint16_t> tb; for (int j = 0; j < 3; j++) for (int k = 0; k < 4; k++) if (w[j].w[k]) tb.insert(w[j].bones[k]); tb.insert(w[0].bones[0]);
            int si = -1;
            for (size_t s = 0; s < secs.size(); s++) { if (secs[s].mat != mat) continue; BChunk& c = chunks[secs[s].chunk]; int add = 0; for (auto b : tb) if (std::find(c.boneMap.begin(), c.boneMap.end(), b) == c.boneMap.end()) add++;
                if ((int)c.boneMap.size() + add <= opt.maxBones) { si = (int)s; break; } }
            if (si < 0) { BSection s; s.mat = mat; s.chunk = (int)chunks.size(); chunks.emplace_back(); secs.push_back(s); si = (int)secs.size() - 1; }
            BSection& S2 = secs[si]; BChunk& C = chunks[S2.chunk];
            u32 tri[3];
            for (int j = 0; j < 3; j++) { VKey k; memcpy(k.pos, w[j].pos, 12); memcpy(k.nrm, w[j].nrm, 12); memcpy(k.uv, w[j].uv, 8); memset(k.b, 0, 8); memset(k.w, 0, 4);
                for (int q = 0; q < 4; q++) { if (!w[j].w[q] && q) continue; uint16_t gb = w[j].bones[q]; auto it = std::find(C.boneMap.begin(), C.boneMap.end(), gb); if (it == C.boneMap.end()) { C.boneMap.push_back(gb); it = C.boneMap.end() - 1; } k.b[q] = (uint16_t)(it - C.boneMap.begin()); k.w[q] = w[j].w[q]; }
                auto f = C.index.find(k); int vi; if (f == C.index.end()) { vi = (int)C.verts.size(); BVert bv; bv.k = k; memset(bv.tx, 0, 12); memset(bv.ty, 0, 12); C.verts.push_back(bv); C.index[k] = vi; } else vi = f->second;
                if (f == C.index.end()) { auto& a = tacc[wkey[t * 3 + j]]; for (int q = 0; q < 3; q++) { C.verts[vi].tx[q] = a[q]; C.verts[vi].ty[q] = a[3 + q]; } }
                tri[j] = (u32)vi; }
            if (tri[0] != tri[1] && tri[0] != tri[2] && tri[1] != tri[2]) { S2.local.push_back(tri[0]); S2.local.push_back(tri[1]); S2.local.push_back(tri[2]); }
        }
        // --- builds the cooked LOD
        RawLOD L; L.indexSize = 2; L.size = orig.size; L.requiredBones = orig.requiredBones; L.rpFlags = orig.rpFlags; L.rpOffset = orig.rpOffset; L.rpCount = 0;
        L.fullUV = orig.fullUV; L.stride = orig.fullUV ? 36 : 32; L.influencesRaw = orig.influencesRaw;
        std::vector<std::vector<u32>> remap(chunks.size()); std::vector<std::array<float, 3>> vpos; u32 nv = 0; std::set<uint16_t> active; std::vector<uint16_t> activeOrder;
        for (size_t c = 0; c < chunks.size(); c++) {
            BChunk& C = chunks[c]; RawChunk rc; rc.baseVertex = nv; rc.boneMap = C.boneMap; remap[c].resize(C.verts.size()); int maxInf = 1;
            for (int pass = 0; pass < 2; pass++) for (size_t v = 0; v < C.verts.size(); v++) {
                BVert& bv = C.verts[v]; bool rigid = bv.k.w[1] == 0; if ((pass == 0) != rigid) continue;
                remap[c][v] = nv++; if (pass == 0) rc.numRigid++; else rc.numSoft++;
                int ninf = 0; for (int q = 0; q < 4; q++) if (bv.k.w[q]) ninf = q + 1; maxInf = std::max(maxInf, ninf);
                for (int q = 0; q < 4; q++) if (bv.k.w[q] || q == 0) { uint16_t gb = C.boneMap[bv.k.b[q]]; if (active.insert(gb).second) activeOrder.push_back(gb); }
                // tangents (Gram-Schmidt with the normal)
                float Z[3] = { bv.k.nrm[0], bv.k.nrm[1], bv.k.nrm[2] }, X[3] = { bv.tx[0], bv.tx[1], bv.tx[2] }, Y[3] = { bv.ty[0], bv.ty[1], bv.ty[2] }; normalize(X); normalize(Y);
                float d = X[0] * Z[0] + X[1] * Z[1] + X[2] * Z[2]; for (int q = 0; q < 3; q++) X[q] -= Z[q] * d; normalize(X);
                if (X[0] == 0 && X[1] == 0 && X[2] == 0) { float a[3] = { fabsf(Z[0]) < 0.9f ? 1.f : 0.f, fabsf(Z[0]) < 0.9f ? 0.f : 1.f, 0 }; X[0] = a[1] * Z[2] - a[2] * Z[1]; X[1] = a[2] * Z[0] - a[0] * Z[2]; X[2] = a[0] * Z[1] - a[1] * Z[0]; normalize(X); }
                float det = X[0] * (Y[1] * Z[2] - Y[2] * Z[1]) - X[1] * (Y[0] * Z[2] - Y[2] * Z[0]) + X[2] * (Y[0] * Z[1] - Y[1] * Z[0]);
                u8 vb[36] = { 0 }; memcpy(vb, bv.k.pos, 12);
                vb[12] = packN(X[0]); vb[13] = packN(X[1]); vb[14] = packN(X[2]); vb[15] = 127;
                vb[16] = packN(Z[0]); vb[17] = packN(Z[1]); vb[18] = packN(Z[2]); vb[19] = det < 0 ? 0 : 255;
                for (int q = 0; q < 4; q++) { vb[20 + q] = (u8)bv.k.b[q]; vb[24 + q] = bv.k.w[q]; }
                if (L.fullUV) memcpy(vb + 28, bv.k.uv, 8); else { uint16_t h0 = floatToHalf(bv.k.uv[0]), h1 = floatToHalf(bv.k.uv[1]); memcpy(vb + 28, &h0, 2); memcpy(vb + 30, &h1, 2); }
                L.vertsRaw.insert(L.vertsRaw.end(), vb, vb + L.stride); vpos.push_back({ bv.k.pos[0], bv.k.pos[1], bv.k.pos[2] });
            }
            rc.maxInfluences = maxInf; L.chunks.push_back(rc);
        }
        if (nv > 65535) throw Err("too many vertices after import (" + std::to_string(nv) + " > 65535). Reduce the mesh or split UV seams less.");
        for (size_t s = 0; s < secs.size(); s++) { RawSection rsx; rsx.material = (uint16_t)secs[s].mat; rsx.chunk = (uint16_t)secs[s].chunk; rsx.baseIndex = (u32)L.indices.size();
            if (secs[s].local.size() / 3 > 65535) throw Err("section with more than 65535 triangles");
            rsx.numTris = (uint16_t)(secs[s].local.size() / 3); for (u32 i : secs[s].local) L.indices.push_back(remap[secs[s].chunk][i]); L.sections.push_back(rsx); }
        L.numVertices = nv; L.vertCount = (i32)nv; L.activeBones = activeOrder;
        for (u32 i : L.indices) L.shadowIndices.push_back((uint16_t)i);
        // requiredBones: the original if it already covers the used bones; otherwise active + ancestors
        { std::set<int> req(orig.requiredBones.begin(), orig.requiredBones.end()); bool ok = true; for (auto b : active) if (!req.count(b)) ok = false;
          if (!ok) { std::set<int> r2; for (auto b : active) { int x = b; for (int g = 0; g < 256 && x >= 0; g++) { r2.insert(x); if (x == 0) break; x = sm.bones[x].parent; } } L.requiredBones.clear(); for (int x : r2) L.requiredBones.push_back((u8)x); } }
        // edges (shadow volumes) by position + double-sided triangles
        { size_t nt = L.shadowIndices.size() / 3; if (nt > 32767) rep.warnings.push_back("more than 32767 triangles: shadow-volume edges limited");
          struct EK { PosKey a, b; bool operator==(const EK& o) const { return a == o.a && b == o.b; } }; struct EH { size_t operator()(const EK& k) const { PosHash h; return h(k.a) * 31 + h(k.b); } };
          std::unordered_map<EK, std::vector<size_t>, EH> open; std::vector<std::array<int16_t, 4>> edges;
          for (size_t t = 0; t < nt && t < 32767; t++) for (int e = 0; e < 3; e++) {
              uint16_t v1 = L.shadowIndices[t * 3 + e], v2 = L.shadowIndices[t * 3 + (e + 1) % 3]; float p1[3], p2[3]; memcpy(p1, vpos[v1].data(), 12); memcpy(p2, vpos[v2].data(), 12);
              EK rev{ pkey(p2), pkey(p1) }; auto it = open.find(rev);
              if (it != open.end() && !it->second.empty()) { size_t ei = it->second.back(); it->second.pop_back(); edges[ei][3] = (int16_t)t; continue; }
              edges.push_back({ (int16_t)v1, (int16_t)v2, (int16_t)t, (int16_t)-1 }); open[EK{ pkey(p1), pkey(p2) }].push_back(edges.size() - 1); }
          L.edgeCount = (i32)edges.size(); for (auto& e : edges) { u8 b[8]; memcpy(b, e.data(), 8); L.edgesRaw.insert(L.edgesRaw.end(), b, b + 8); }
          std::set<int> sep; for (;;) { size_t before = sep.size(); for (auto& e : edges) { if (e[3] == -1 || sep.count(e[3])) sep.insert(e[2]); else if (sep.count(e[2])) sep.insert(e[3]); } if (sep.size() == before) break; }
          L.shadowDoubleSided.assign(nt, 0); for (int t : sep) if (t >= 0 && (size_t)t < nt) L.shadowDoubleSided[t] = 1; }
        rep.triangles = (int)(L.indices.size() / 3); rep.vertices = (int)nv; rep.sections = (int)L.sections.size(); rep.chunks = (int)L.chunks.size();
        if (rep.unweighted) rep.warnings.push_back(std::to_string(rep.unweighted) + " FBX points without skin weights (bound to the root/mesh bone)");
        if (!rep.unmatchedBones.empty()) rep.warnings.push_back(std::to_string(rep.unmatchedBones.size()) + " FBX bones not found in the game skeleton (weights moved to the nearest matching parent or to the root)");
        if (rep.fitMaxError > 2.0) rep.warnings.push_back("the FBX bind pose differs from the game skeleton (max bone error " + std::to_string((int)rep.fitMaxError) + " units): deformation may look wrong");
        for (auto& e2 : pk.exports) { std::string c2 = pk.classOf(e2); if (c2 == "MorphTargetSet" || c2 == "MorphTarget") { rep.warnings.push_back("the package has morph targets: if any belongs to this mesh it will no longer match the new vertices"); break; } }
        if (rs.lods.size() > 1) rep.warnings.push_back("the original mesh has " + std::to_string(rs.lods.size()) + " LODs: all of them receive the imported mesh");
        // --- bounds
        float mn[3] = { 1e30f, 1e30f, 1e30f }, mx[3] = { -1e30f, -1e30f, -1e30f }; for (auto& p : vpos) for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], p[k]); mx[k] = std::max(mx[k], p[k]); }
        float origin[3], ext[3], rad = 0; for (int k = 0; k < 3; k++) { origin[k] = (mn[k] + mx[k]) * 0.5f; ext[k] = (mx[k] - mn[k]) * 0.5f; }
        for (auto& p : vpos) { float d = sqrtf((p[0] - origin[0]) * (p[0] - origin[0]) + (p[1] - origin[1]) * (p[1] - origin[1]) + (p[2] - origin[2]) * (p[2] - origin[2])); rad = std::max(rad, d); }
        float geomRad = rad;
        { // union with the original bounds (the cooker leaves them loose; never shrinking avoids culling pops)
          const u8* od = pk.dataPtr(ex) + rs.boundsOff; float ob[7]; memcpy(ob, od, 28);
          for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], ob[k] - ob[3 + k]); mx[k] = std::max(mx[k], ob[k] + ob[3 + k]); origin[k] = (mn[k] + mx[k]) * 0.5f; ext[k] = (mx[k] - mn[k]) * 0.5f; }
          rad = std::max(rad, ob[6]); float boxRad = sqrtf(ext[0] * ext[0] + ext[1] * ext[1] + ext[2] * ext[2]); rad = std::min(std::max(rad, 0.f), std::max(boxRad, ob[6])); }
        // --- new export
        const u8* d = pk.dataPtr(ex); size_t dl = pk.dataLen(ex);
        // PerBoneBounds (BM): bone-space box of the vertices with weight > 10/255 on that bone; union with the original (never shrinks)
        std::vector<u8> head(d, d + rs.lodCountOff);
        { size_t p = rs.boundsOff + 28; float cons; memcpy(&cons, &head[p], 4); i32 nbb; memcpy(&nbb, &head[p + 4], 4);
          // old radius (same computation) to scale ConservativeBounds
          float orad = 0; { float omn[3] = { 1e30f, 1e30f, 1e30f }, omx[3] = { -1e30f, -1e30f, -1e30f }; for (auto& v : sm.lods[0].verts) for (int k = 0; k < 3; k++) { omn[k] = std::min(omn[k], v.pos[k]); omx[k] = std::max(omx[k], v.pos[k]); }
              float oc[3]; for (int k = 0; k < 3; k++) oc[k] = (omn[k] + omx[k]) * 0.5f; for (auto& v : sm.lods[0].verts) { float dd = sqrtf((v.pos[0] - oc[0]) * (v.pos[0] - oc[0]) + (v.pos[1] - oc[1]) * (v.pos[1] - oc[1]) + (v.pos[2] - oc[2]) * (v.pos[2] - oc[2])); orad = std::max(orad, dd); } }
          if (orad > 0 && geomRad > orad * 1.001f) { cons *= geomRad / orad; memcpy(&head[p], &cons, 4); }
          std::vector<M4> inv(nb); for (size_t b = 0; b < nb; b++) inv[b] = m4RigidInverse(ueWorld[b]);
          for (i32 k = 0; k < nbb && nbb < 4096; k++) { size_t q = p + 8 + (size_t)k * 28; i32 b; memcpy(&b, &head[q], 4); if (b < 0 || (size_t)b >= nb) continue; float box[6]; memcpy(box, &head[q + 4], 24);
              for (auto& C : L.chunks) (void)C;
              for (size_t vi = 0; vi < vpos.size(); vi++) { const u8* vb = &L.vertsRaw[vi * L.stride]; int c = 0; for (size_t cc = 0; cc < L.chunks.size(); cc++) if (vi >= L.chunks[cc].baseVertex) c = (int)cc;
                  bool any = false; for (int j = 0; j < 4; j++) if (vb[24 + j] > 10 && vb[20 + j] < L.chunks[c].boneMap.size() && L.chunks[c].boneMap[vb[20 + j]] == b) any = true; if (!any) continue;
                  const M4& m = inv[b]; for (int kk = 0; kk < 3; kk++) { float pp = vpos[vi][0] * m.m[0][kk] + vpos[vi][1] * m.m[1][kk] + vpos[vi][2] * m.m[2][kk] + m.m[3][kk]; box[kk] = std::min(box[kk], pp); box[3 + kk] = std::max(box[3 + kk], pp); } }
              memcpy(&head[q + 4], box, 24); } }
        std::vector<RawLOD> lods(rs.lods.size(), L);
        // properties: LODInfo follows the new section count of each LOD (otherwise the game asserts when loading the mesh)
        size_t boundsOff = rs.boundsOff, lodCountOff = rs.lodCountOff;
        { ObjProps op = objProps(pk, meshIdx); long ps = findPropStart(pk, meshIdx); if (!op.ok || ps < 0) throw Err("cannot read mesh properties");
          std::vector<size_t> nsec; for (auto& LL : lods) nsec.push_back(LL.sections.size()); std::string note;
          std::vector<u8> np = rebuildPropsForSections(pk, op.tags, nsec, note);
          std::vector<u8> nh(head.begin(), head.begin() + ps); nh.insert(nh.end(), np.begin(), np.end()); nh.insert(nh.end(), head.begin() + op.end, head.end());
          long delta = (long)np.size() - (long)(op.end - (size_t)ps); boundsOff = (size_t)((long)boundsOff + delta); lodCountOff = (size_t)((long)lodCountOff + delta);
          head.swap(nh); (void)note; }
        d = head.data();
        Writer w; w.raw(d, boundsOff); for (int k = 0; k < 3; k++) { u32 x; memcpy(&x, &origin[k], 4); w.u(x); } for (int k = 0; k < 3; k++) { u32 x; memcpy(&x, &ext[k], 4); w.u(x); } { u32 x; memcpy(&x, &rad, 4); w.u(x); }
        w.raw(d + boundsOff + 28, lodCountOff - boundsOff - 28);
        writeRawLODs(w, lods, ex.serialOffset, w.b.size());
        w.raw(pk.dataPtr(ex) + rs.lodEnd, dl - rs.lodEnd);
        rep.newData = std::move(w.b); rep.ok = true;
    } catch (std::exception& e) { rep.err = e.what(); }
    return rep;
}

} // namespace bm
