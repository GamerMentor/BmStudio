// bspmodel.hpp - write access to the cooked BAA UModel (BSP): part offsets, point solidity, translation, NotCsg.
#pragma once
#include "bmlevel.hpp"
namespace bm {
struct ModelLayout { bool ok = false; std::string err; size_t boundsAt = 0, vecAt = 0, ptAt = 0, nodesAt = 0, surfsAt = 0, vertsAt = 0, rootOutsideAt = 0, vbAt = 0, hullsAt = 0;
    i32 nHulls = 0;
    i32 nVec = 0, nPt = 0, nNodes = 0, nSurfs = 0, vbes = 0, vbn = 0; };
inline ModelLayout modelLayout(const Package& pk, i32 idx) {
    ModelLayout L; const Export& e = pk.exports[idx - 1];
    try { long ps = findPropStart(pk, idx); if (ps < 0) throw Err("no props"); size_t st = 0; readProps(pk, pk.dataPtr(e), pk.dataLen(e), (size_t)ps, &st);
        Reader r(pk.dataPtr(e), pk.dataLen(e), st); L.boundsAt = r.p; r.p += 28;
        auto bulk = [&](i32& es, i32& n) { es = r.i(); n = r.i(); size_t a = r.p; r.need((size_t)es * n); r.p += (size_t)es * n; return a; };
        i32 es; L.vecAt = bulk(es, L.nVec); if (L.nVec && es != 12) throw Err("vectors");
        L.ptAt = bulk(es, L.nPt); if (L.nPt && es != 12) throw Err("points");
        L.nodesAt = bulk(es, L.nNodes); if (L.nNodes && es != 64) throw Err("nodes");
        r.i(); L.nSurfs = r.i(); L.surfsAt = r.p; r.p += (size_t)L.nSurfs * 56;
        i32 n; L.vertsAt = bulk(es, n); r.i(); i32 nz = r.i(); r.p += (size_t)nz * 24; r.i();
        L.hullsAt = bulk(es, L.nHulls); if (L.nHulls && es != 4) throw Err("leafhulls"); bulk(es, n); L.rootOutsideAt = r.p; r.i(); r.i(); bulk(es, n); bulk(es, n); r.i();
        L.vbes = r.i(); L.vbn = r.i(); L.vbAt = r.p; r.need((size_t)L.vbes * L.vbn); L.ok = true;
    } catch (std::exception& ex) { L.err = ex.what(); }
    return L;
}
struct BspNodeV { float plane[4]; i32 iSurf, iVertexIndex, iBack, iFront, iPlane; u8 nv, flags; };
inline BspNodeV readNode(const u8* d, const ModelLayout& L, i32 n) { const u8* p = d + L.nodesAt + (size_t)n * 64; BspNodeV v; memcpy(v.plane, p, 16); memcpy(&v.iSurf, p + 20, 4); memcpy(&v.iVertexIndex, p + 24, 4);
    memcpy(&v.iBack, p + 36, 4); memcpy(&v.iFront, p + 40, 4); memcpy(&v.iPlane, p + 44, 4); v.nv = p[54]; v.flags = p[55]; return v; }
static const u8 NF_NotCsg = 0x01;
// solidity of a point (UModel::PointCheck with zero radius): walks the tree updating "Outside"
inline bool bspSolid(const u8* d, const ModelLayout& L, const float p[3]) {
    if (L.nNodes == 0) return false; i32 ro; memcpy(&ro, d + L.rootOutsideAt, 4); bool outside = ro != 0; i32 i = 0; int guard = 0;
    while (i != -1 && guard++ < 100000) { BspNodeV n = readNode(d, L, i); float dist = p[0] * n.plane[0] + p[1] * n.plane[1] + p[2] * n.plane[2] - n.plane[3]; bool csg = !(n.flags & NF_NotCsg);
        if (dist >= 0) { outside = outside || csg; i = n.iFront; } else { outside = outside && !csg; i = n.iBack; } }
    return !outside;
}
}
