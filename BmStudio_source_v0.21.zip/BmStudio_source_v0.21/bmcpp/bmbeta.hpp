// bmbeta.hpp - packages of the 2007 BETA of Batman: Arkham Asylum (Xbox 360, .xxx): big-endian, version 512/0,
// compressed with LZO (flag 2; the beta ones use LZO even on Xbox) or LZX (flag 4, XMemCompress). Builds the decompressed image ("logical" offsets, as in the PC LZO path)
// and fills a bm::Package with names/imports/exports already converted in memory (little-endian).
// The object DATA stays big-endian and in the v512 layout - read only (Package::bigEndian = true).
//
// Layout reference: UE Viewer (Unreal/UnrealPackage/UnPackage3.cpp, MIT) + the real file (BmGame.xxx).
#pragma once
#include "bmpkg.hpp"
#include "bmlzo.hpp"

extern "C" int bm_lzx_decompress(const unsigned char* src, int srcSize, unsigned char* dst, int dstSize);

namespace bm { namespace beta {

struct BE {
    const u8* d; size_t n, p = 0;
    BE(const u8* data, size_t len, size_t pos = 0) : d(data), n(len), p(pos) {}
    void need(size_t k) const { if (p + k > n) throw Err("beta package: read past end"); }
    u32 u() { need(4); u32 v = (u32)d[p] << 24 | (u32)d[p + 1] << 16 | (u32)d[p + 2] << 8 | d[p + 3]; p += 4; return v; }
    i32 i() { return (i32)u(); }
    u64 q() { u64 hi = u(); return hi << 32 | u(); }
    std::string fstr() { i32 l = i(); if (l == 0) return ""; if (l > 0) { need((size_t)l); std::string s((const char*)d + p, (size_t)l - 1); p += (size_t)l; return s; }
        size_t c = (size_t)(-l); need(c * 2); std::string s; for (size_t k = 0; k + 1 < c; k++) { uint16_t ch = (uint16_t)(d[p + k * 2] << 8 | d[p + k * 2 + 1]); s += ch < 128 ? (char)ch : '?'; } p += c * 2; return s; }
};

struct Info { u32 version = 0, licensee = 0, flags = 0, compression = 0; i32 engineVer = 0, cookerVer = 0, chunks = 0; std::string err; };

// is it a big-endian console package? (tag stored reversed)
inline bool isBigEndianPackage(const u8* d, size_t n) { return n >= 8 && d[0] == 0x9E && d[1] == 0x2A && d[2] == 0x83 && d[3] == 0xC1; }

// loads 'file' (bytes of the .xxx) into P. Returns false + err on failure.
inline bool load(std::vector<u8>&& file, Package& P, Info& info) {
    try {
        if (!isBigEndianPackage(file.data(), file.size())) throw Err("not a big-endian (console) package");
        BE r(file.data(), file.size(), 4);
        u32 ver = r.u(); info.version = ver & 0xFFFF; info.licensee = ver >> 16;
        if (info.version < 400 || info.version > 600) throw Err("unsupported version " + std::to_string(info.version));
        i32 headerSize = r.i(); r.fstr(); info.flags = r.u();
        i32 nameCount = r.i(), nameOff = r.i(), expCount = r.i(), expOff = r.i(), impCount = r.i(), impOff = r.i();
        if (info.version >= 415) r.i();                           // DependsOffset
        r.need(16); r.p += 16;                                     // Guid
        i32 gc = r.i(); if (gc < 0 || gc > 1000) throw Err("bad generation count"); r.p += (size_t)gc * (info.version >= 322 ? 12 : 8);
        info.engineVer = r.i(); info.cookerVer = r.i(); info.compression = r.u();
        i32 nc = r.i(); info.chunks = nc; if (nc < 0 || nc > 100000) throw Err("bad chunk count");
        struct Ch { i32 uo, us, co, cs; }; std::vector<Ch> ch(nc); for (auto& c : ch) { c.uo = r.i(); c.us = r.i(); c.co = r.i(); c.cs = r.i(); }
        (void)headerSize;
        // --- decompressed image (logical offsets). No chunks = the file itself.
        std::vector<u8> img;
        if (nc == 0) img = file;
        else {
            size_t total = 0; for (auto& c : ch) total = std::max(total, (size_t)c.uo + (size_t)c.us);
            img.assign(total, 0);
            size_t firstUo = (size_t)-1; for (auto& c : ch) firstUo = std::min(firstUo, (size_t)c.uo);
            if (firstUo <= file.size()) memcpy(img.data(), file.data(), std::min(firstUo, img.size()));
            for (auto& c : ch) {
                if (c.co < 0 || (size_t)c.co + 16 > file.size()) throw Err("chunk outside the file");
                BE cr(file.data(), file.size(), (size_t)c.co);
                if (cr.u() != 0x9E2A83C1u) throw Err("bad chunk tag");
                i32 bs = cr.i(); cr.i(); i32 usz = cr.i(); if (bs <= 0 || usz != c.us) throw Err("bad chunk header");
                i32 nb = (usz + bs - 1) / bs; std::vector<std::pair<i32, i32>> blk(nb); for (auto& b : blk) { b.first = cr.i(); b.second = cr.i(); }
                size_t src = cr.p, dst = (size_t)c.uo;
                for (auto& b : blk) {
                    if (b.first < 0 || b.second < 0 || src + (size_t)b.first > file.size() || dst + (size_t)b.second > img.size()) throw Err("block outside bounds");
                    if (info.compression & 2) { size_t got = 0; if (!lzo1xDecompress(file.data() + src, (size_t)b.first, img.data() + dst, (size_t)b.second, &got) || got != (size_t)b.second) {
                            if (b.first == b.second) memcpy(img.data() + dst, file.data() + src, (size_t)b.second); else throw Err("LZO data corrupted (recovered file damaged?)"); } }
                    else if (info.compression & 4) { int rc = bm_lzx_decompress(file.data() + src, b.first, img.data() + dst, b.second); if (rc != 0) throw Err("LZX data corrupted (code " + std::to_string(rc) + ")"); }
                    else throw Err("unknown compression " + std::to_string(info.compression));
                    src += (size_t)b.first; dst += (size_t)b.second; }
            }
        }
        // --- tables
        P = Package(); P.file = std::move(img); P.fp = P.file.data(); P.fn = P.file.size();
        P.fileVersion = info.version; P.licensee = info.licensee; P.packageFlags = info.flags; P.engineVer = info.engineVer; P.cookerVer = info.cookerVer; P.bigEndian = true;
        BE t(P.fp, P.fn, (size_t)nameOff);
        for (i32 k = 0; k < nameCount; k++) { std::string s = t.fstr(); u64 fl = info.version >= 195 ? t.q() : t.u(); P.names.push_back({ s, fl }); }
        t.p = (size_t)impOff;
        for (i32 k = 0; k < impCount; k++) { Import im; im.classPkg.idx = t.i(); im.classPkg.num = t.i(); im.className.idx = t.i(); im.className.num = t.i(); im.outer = t.i(); im.name.idx = t.i(); im.name.num = t.i(); P.imports.push_back(im); }
        t.p = (size_t)expOff;
        for (i32 k = 0; k < expCount; k++) {
            Export e; e.cls = t.i(); e.super_ = t.i(); e.outer = t.i(); e.name.idx = t.i(); e.name.num = t.i();
            if (info.version >= 220) e.archetype = t.i();
            e.flags = info.version >= 195 ? t.q() : t.u();
            e.serialSize = t.i(); if (e.serialSize || info.version >= 249) e.serialOffset = t.i();
            if (info.version < 543) { i32 cm = t.i(); if (cm < 0 || cm > 100000) throw Err("bad component map"); t.p += (size_t)cm * 12; }
            if (info.version >= 247) e.exportFlags = t.u();
            if (info.version >= 322) { i32 nn = t.i(); if (nn < 0 || nn > 100000) throw Err("bad net object count"); for (i32 q = 0; q < nn; q++) e.netObjects.push_back(t.i()); t.need(16); memcpy(e.guid, t.d + t.p, 16); t.p += 16; }
            if (info.version >= 475) e.packageFlags = t.u();
            if (e.serialSize < 0 || (e.serialSize > 0 && (size_t)e.serialOffset + (size_t)e.serialSize > P.fn)) throw Err("export " + std::to_string(k + 1) + " data outside the package");
            P.exports.push_back(std::move(e)); }
        // sanity: valid name indices
        for (auto& e : P.exports) if (e.name.idx < 0 || e.name.idx >= (i32)P.names.size()) throw Err("bad export name index");
        return true;
    } catch (std::exception& e) { info.err = e.what(); return false; }
}

inline bool loadFile(const std::string& path, Package& P, Info& info) {
    FILE* f = fopen(path.c_str(), "rb"); if (!f) { info.err = "cannot open " + path; return false; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); std::vector<u8> v((size_t)std::max(0L, n)); bool ok = n <= 0 || fread(v.data(), 1, v.size(), f) == v.size(); fclose(f);
    if (!ok) { info.err = "read failed"; return false; }
    return load(std::move(v), P, info);
}

// ------------------------------------------------------------------ properties (big-endian) -> little-endian Tags
inline u32 rbe(const u8* d) { return (u32)d[0] << 24 | (u32)d[1] << 16 | (u32)d[2] << 8 | d[3]; }
inline void swap4(std::vector<u8>& b, size_t from = 0) { for (size_t k = from; k + 4 <= b.size(); k += 4) { std::swap(b[k], b[k + 3]); std::swap(b[k + 1], b[k + 2]); } }
inline std::string nameAt(const Package& P, const u8* d) { FName f; f.idx = (i32)rbe(d); f.num = (i32)rbe(d + 4); if (f.idx < 0 || f.idx >= (i32)P.names.size()) return "?"; return P.nm(f); }
inline bool validName(const Package& P, const u8* d) { i32 i = (i32)rbe(d), n = (i32)rbe(d + 4); return i >= 0 && i < (i32)P.names.size() && n >= 0 && n < 100000; }

inline std::vector<Tag> readPropsBE(const Package& P, const u8* d, size_t n, size_t pos, size_t* endPos, int depth = 0);
// tags -> little-endian bytes (list terminated by None); the names already exist in the package (they came from it)
inline std::vector<u8> writeTagsLE(const Package& P, const std::vector<Tag>& sub) {
    std::vector<u8> o; auto w = [&](i32 x) { u8 t[4]; memcpy(t, &x, 4); o.insert(o.end(), t, t + 4); };
    auto nameIdx = [&](const std::string& s) { for (size_t q = 0; q < P.names.size(); q++) if (P.names[q].first == s) return (i32)q; return 0; };
    for (auto& t : sub) { w(nameIdx(t.name)); w(0); w(nameIdx(t.type)); w(0); w(t.isBool ? 0 : (i32)t.raw.size()); w(t.index); if (t.type == "StructProperty") { w(nameIdx(t.strct)); w(0); } if (t.isBool) w(t.boolVal); else o.insert(o.end(), t.raw.begin(), t.raw.end()); }
    w(nameIdx("None")); w(0); return o;
}
// value of a tag, converted to little-endian (anything unrecognized stays raw)
inline std::vector<u8> convertValue(const Package& P, const std::string& type, const std::string& strct, const u8* v, size_t size, int depth) {
    std::vector<u8> b(v, v + size);
    if (type == "IntProperty" || type == "FloatProperty" || type == "ObjectProperty" || type == "ComponentProperty" || type == "ClassProperty" || type == "InterfaceProperty" || type == "NameProperty" || type == "DelegateProperty") { swap4(b); return b; }
    if (type == "ByteProperty") { if (size == 8) swap4(b); return b; }
    if (type == "StrProperty") { if (size < 4) return b; i32 l = (i32)rbe(v); std::vector<u8> o(4); memcpy(o.data(), &l, 4);
        if (l >= 0) o.insert(o.end(), v + 4, v + size); else { for (size_t k = 4; k + 1 < size; k += 2) { o.push_back(v[k + 1]); o.push_back(v[k]); } } return o; }
    if (type == "StructProperty") {
        if (depth < 6 && size >= 8 && validName(P, v)) { try { size_t e = 0; auto sub = readPropsBE(P, v, size, 0, &e, depth + 1); if (e == size) return writeTagsLE(P, sub); } catch (...) {} }
        if (strct == "Color") { swap4(b); return b; }
        if (size % 4 == 0) swap4(b);   // Vector, Rotator, Guid, LinearColor, Matrix... (4-byte fields)
        return b;
    }
    if (type == "ArrayProperty") { if (size < 4) return b; i32 cnt = (i32)rbe(v); std::vector<u8> o(4); memcpy(o.data(), &cnt, 4);
        if (cnt > 0 && size == 4 + (size_t)cnt * 4) { o.insert(o.end(), v + 4, v + size); swap4(o, 4); return o; }   // ints/floats/objects
        if (cnt > 0 && depth < 6 && size >= 12 && validName(P, v + 4)) {                                                // structs with tags
            try { size_t p = 4; std::vector<u8> acc = o; for (i32 k = 0; k < cnt; k++) { size_t e = 0; auto sub = readPropsBE(P, v, size, p, &e, depth + 1); auto le = writeTagsLE(P, sub); acc.insert(acc.end(), le.begin(), le.end()); p = e; }
                if (p == size) return acc; } catch (...) {} }
        o.insert(o.end(), v + 4, v + size);
        if (cnt > 0 && (size - 4) % (size_t)cnt == 0 && ((size - 4) / (size_t)cnt) % 4 == 0) swap4(o, 4);           // native structs of 4-byte fields (Vector, Plane...)
        return o; }                                                                                                     // bytes: raw
    return b;
}
inline std::vector<Tag> readPropsBE(const Package& P, const u8* d, size_t n, size_t pos, size_t* endPos, int depth) {
    std::vector<Tag> out; size_t p = pos;
    for (int guard = 0; guard < 20000; guard++) {
        if (p + 8 > n || !validName(P, d + p)) throw Err("bad property name");
        std::string nm = nameAt(P, d + p); if (nm == "None") { p += 8; if (endPos) *endPos = p; return out; }
        if (p + 24 > n || !validName(P, d + p + 8)) throw Err("bad property type");
        Tag t; t.name = nm; t.type = nameAt(P, d + p + 8); i32 size = (i32)rbe(d + p + 16); t.index = (i32)rbe(d + p + 20); p += 24;
        if (!isPropType(t.type)) throw Err("unknown property type " + t.type);
        if (t.type == "StructProperty") { if (p + 8 > n) throw Err("struct name"); t.strct = nameAt(P, d + p); p += 8; }
        if (t.type == "BoolProperty") { if (p + 4 > n) throw Err("bool"); t.isBool = true; t.boolVal = rbe(d + p) != 0; p += 4; out.push_back(t); continue; }
        if (size < 0 || p + (size_t)size > n) throw Err("bad property size (" + nm + ")");
        t.raw = convertValue(P, t.type, t.strct, d + p, (size_t)size, depth); p += (size_t)size; out.push_back(t);
    }
    throw Err("too many properties");
}
// start of the property list in the data (big-endian): first offset (multiple of 4, up to 128) at which the whole list parses
inline long findPropStartBE(const Package& P, i32 idx) {
    const Export& e = P.exports[idx - 1]; const u8* d = P.dataPtr(e); size_t n = P.dataLen(e);
    std::string cls = P.classOf(e);
    if (e.cls == 0 || cls == "Function" || cls == "State" || cls == "ScriptStruct" || cls == "Const" || cls == "Enum" || cls == "Class" || isPropType(cls)) return -1;
    for (size_t off = 0; off + 8 <= n && off <= 128; off += 2) {
        if (!validName(P, d + off)) continue;
        std::string nm = nameAt(P, d + off); if (nm != "None" && (off + 24 > n || !validName(P, d + off + 8) || !isPropType(nameAt(P, d + off + 8)))) continue;
        try { size_t end = 0; readPropsBE(P, d, n, off, &end); return (long)off; } catch (...) {}
    }
    return -1;
}


// ------------------------------------------------------------------ beta Texture2D -> mips in the PC layout
struct BetaMip { i32 w = 0, h = 0; std::vector<u8> data; };   // data already in PC format (untiled, PC endianness)
struct BetaTexture { i32 sizeX = 0, sizeY = 0; std::string format, tfc; std::vector<BetaMip> mips; std::string err; };

inline u32 alignU(u32 v, u32 a) { return (v + a - 1) / a * a; }
inline unsigned xboxTiledOffset(int x, int y, int width, int logBpb) {
    int alignedWidth = (int)alignU((u32)width, 32);
    int macro = ((x >> 5) + (y >> 5) * (alignedWidth >> 5)) << (logBpb + 7);
    int micro = ((x & 7) + ((y & 0xE) << 2)) << logBpb;
    int offset = macro + ((micro & ~0xF) << 1) + (micro & 0xF) + ((y & 1) << 4);
    return (unsigned)((((offset & ~0x1FF) << 3) + ((y & 16) << 7) + ((offset & 0x1C0) << 2) + (((((y & 8) >> 2) + (x >> 3)) & 3) << 6) + (offset & 0x3F)) >> logBpb);
}
// undoes the Xbox 360 "tiling" and swaps bytes (16-bit words; 32 bits for A8R8G8B8) - like UE Viewer
inline bool untileXbox(const std::string& fmt, int w, int h, const std::vector<u8>& src, std::vector<u8>& out) {
    int bx = 1, by = 1, bpb = 0, ax = 0, ay = 0;
    if (fmt == "PF_DXT1") { bx = by = 4; bpb = 8; ax = ay = 128; } else if (fmt == "PF_DXT3" || fmt == "PF_DXT5") { bx = by = 4; bpb = 16; ax = ay = 128; }
    else if (fmt == "PF_A8R8G8B8") { bpb = 4; ax = ay = 32; } else if (fmt == "PF_G8") { bpb = 1; ax = ay = 64; } else if (fmt == "PF_V8U8") { bpb = 2; ax = 64; ay = 32; } else return false;
    int tw = (int)alignU((u32)w, (u32)ax) / bx, th = (int)alignU((u32)h, (u32)ay) / by, ow = std::max(1, w / bx), oh = std::max(1, h / by);
    if ((size_t)tw * th * bpb > src.size()) return false;
    int logBpp = 0; while ((1 << logBpp) < bpb) logBpp++;
    int sxo = 0, syo = 0; if (tw >= ow * 2 && w == 16) sxo = ow; if (th >= oh * 2 && h == 16) syo = oh;
    out.assign((size_t)ow * oh * bpb, 0);
    for (int dy = 0; dy < oh; dy++) for (int dx = 0; dx < ow; dx++) {
        unsigned a = xboxTiledOffset(dx + sxo, dy + syo, tw, logBpp); if ((size_t)a >= (size_t)tw * th) return false;
        int sy = (int)(a / (unsigned)tw), sx = (int)(a % (unsigned)tw);
        memcpy(&out[((size_t)dy * ow + dx) * bpb], &src[((size_t)sy * tw + sx) * bpb], (size_t)bpb); }
    if (fmt == "PF_A8R8G8B8") { for (size_t k = 0; k + 4 <= out.size(); k += 4) { std::swap(out[k], out[k + 3]); std::swap(out[k + 1], out[k + 2]); } }
    else if (bpb > 1) for (size_t k = 0; k + 2 <= out.size(); k += 2) std::swap(out[k], out[k + 1]);
    return true;
}
// bulk data (big-endian): flags, elementCount, sizeOnDisk, offsetInFile [+ inline data]. Compressed = chunk like the package one.
struct BetaBulk { u32 flags = 0; i32 count = 0, size = 0, offset = 0; size_t inlinePos = 0; };
inline BetaBulk readBulkBE(BE& r) { BetaBulk b; b.flags = r.u(); b.count = r.i(); b.size = r.i(); b.offset = r.i(); b.inlinePos = r.p; if (!(b.flags & 1) && b.size > 0) { r.need((size_t)b.size); r.p += (size_t)b.size; } return b; }
inline bool decompressBulkBE(const u8* d, size_t n, u32 flags, std::vector<u8>& out) {
    if (!(flags & (0x02 | 0x10 | 0x80))) { out.assign(d, d + n); return true; }
    BE r(d, n); if (r.u() != 0x9E2A83C1u) return false; i32 bs = r.i(); r.i(); i32 usz = r.i(); if (bs <= 0 || usz < 0) return false;
    i32 nb = (usz + bs - 1) / bs; std::vector<std::pair<i32, i32>> blk(nb); for (auto& b : blk) { b.first = r.i(); b.second = r.i(); }
    out.assign((size_t)usz, 0); size_t src = r.p, dst = 0;
    for (auto& b : blk) { if (src + (size_t)b.first > n || dst + (size_t)b.second > out.size()) return false;
        if (flags & 0x10) { size_t got = 0; if (!lzo1xDecompress(d + src, (size_t)b.first, out.data() + dst, (size_t)b.second, &got) || got != (size_t)b.second) return false; }
        else if (flags & 0x80) { if (bm_lzx_decompress(d + src, b.first, out.data() + dst, b.second) != 0) return false; }
        else return false;
        src += (size_t)b.first; dst += (size_t)b.second; }
    return true;
}
// readTfc(tfc name, offset, size, out)
template <class ReadTfc>
inline BetaTexture readTexture(const Package& P, i32 idx, ReadTfc readTfc, int maxMips = 32) {
    BetaTexture T; const Export& e = P.exports[idx - 1]; const u8* d = P.dataPtr(e); size_t n = P.dataLen(e);
    try {
        long ps = findPropStartBE(P, idx); if (ps < 0) throw Err("no properties");
        size_t end = 0; auto tags = readPropsBE(P, d, n, (size_t)ps, &end);
        auto nameVal = [&](const Tag& t) { FName f; memcpy(&f.idx, t.raw.data(), 4); memcpy(&f.num, t.raw.data() + 4, 4); return P.nm(f); };
        T.format = "PF_A8R8G8B8";
        for (auto& t : tags) { if (t.name == "SizeX" && t.raw.size() == 4) memcpy(&T.sizeX, t.raw.data(), 4); else if (t.name == "SizeY" && t.raw.size() == 4) memcpy(&T.sizeY, t.raw.data(), 4);
            else if (t.name == "Format" && t.raw.size() == 8) T.format = nameVal(t); else if (t.name == "TextureFileCacheName" && t.raw.size() == 8) T.tfc = nameVal(t); }
        BE r(d, n, end); readBulkBE(r);                                    // SourceArt
        i32 nm = r.i(); if (nm < 0 || nm > 16) throw Err("bad mip count");
        for (i32 k = 0; k < nm && (int)T.mips.size() < maxMips; k++) {
            BetaBulk b = readBulkBE(r); BetaMip m; m.w = r.i(); m.h = r.i();
            std::vector<u8> raw, plain;
            if (b.flags & 1) { if (T.tfc.empty() || b.size <= 0 || !readTfc(T.tfc, (uint64_t)(u32)b.offset, (size_t)b.size, raw)) continue; }
            else { if (b.size <= 0) continue; raw.assign(d + b.inlinePos, d + b.inlinePos + b.size); }
            if (!decompressBulkBE(raw.data(), raw.size(), b.flags, plain)) continue;
            if (!untileXbox(T.format, m.w, m.h, plain, m.data)) continue;
            T.mips.push_back(std::move(m)); }
        if (T.mips.empty()) throw Err("no readable mip (texture data missing from the recovered files?)");
    } catch (std::exception& ex) { T.err = ex.what(); }
    return T;
}

} }
