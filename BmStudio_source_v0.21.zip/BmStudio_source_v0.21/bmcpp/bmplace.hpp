// bmplace.hpp - placing a NEW static mesh in a cooked level (without removing anything that already exists).
// Clones an InterpActor/StaticMeshActor of the level itself (actor + subobjects: mesh component, light environment...)
// and swaps the mesh. Uses an actor (not the mesh collection) because the collection depends on precomputed lighting per
// component; the InterpActor has a DynamicLightEnvironment and is lit without a lightmap.
#pragma once
#include "bmcopy.hpp"
#include "bmlevel.hpp"
#include <random>

namespace bm { namespace place {

inline void own(Package& P, i32 idx) { Export& e = P.exports[idx - 1]; if (!e.owned) { e.data.assign(P.dataPtr(e), P.dataPtr(e) + P.dataLen(e)); e.owned = true; } }

// actor used as template: InterpActor (preferred) or StaticMeshActor, in the PersistentLevel, with a StaticMeshComponent
struct Template { i32 actor = 0, comp = 0; std::string cls; };
inline Template findTemplate(const Package& P) {
    Template best;
    for (size_t k = 0; k < P.exports.size(); k++) { std::string c = P.classOf(P.exports[k]); if (c != "InterpActor" && c != "StaticMeshActor") continue;
        if (P.objPath(P.exports[k].outer) != "TheWorld.PersistentLevel" || (P.exports[k].flags & 0x600ull)) continue;
        i32 a = (i32)k + 1, comp = 0;
        for (size_t q = 0; q < P.exports.size(); q++) if (P.exports[q].outer == a && P.classOf(P.exports[q]) == "StaticMeshComponent") { comp = (i32)q + 1; break; }
        if (!comp) continue;
        if (!best.actor || (c == "InterpActor" && best.cls != "InterpActor")) { best.actor = a; best.comp = comp; best.cls = c; } }
    return best;
}

// ULevel actor list: Owner(4) + TArray, right after the properties
inline bool addActorToLevel(Package& P, i32 actor) {
    i32 lvl = P.findPath("TheWorld.PersistentLevel"); if (lvl <= 0) return false; ObjProps op = objProps(P, lvl); if (!op.ok) return false;
    own(P, lvl); auto& d = P.exports[lvl - 1].data; size_t at = op.end + 4; i32 cnt; memcpy(&cnt, d.data() + at, 4);
    // always at the end (like an actor spawned at game time): the empty slots at the start (e.g. [1] = editor brush, removed
    // when cooking) are not reused.
    cnt++; memcpy(d.data() + at, &cnt, 4); u8 b[4]; memcpy(b, &actor, 4); d.insert(d.begin() + at + 4 + 4 * (size_t)(cnt - 1), b, b + 4); return true;
}

// freshly cloned actor/component: new mesh, new position, nothing inherited from the template
inline void configurePlaced(Package& P, i32 na, i32 nc, i32 mesh, const float loc[3]) {
        // component: new mesh, no materials/collision/shadow inherited from the template
        { ObjProps op = objProps(P, nc); std::vector<Tag> tags = op.tags;
            for (size_t i = 0; i < tags.size();) { const std::string& n = tags[i].name; if (n == "Materials" || n == "CollideActors" || n == "BlockActors" || n == "BlockRigidBody" || n == "bCastDynamicShadow" || n == "CastShadow" || n == "HiddenGame" || n == "Scale3D" || n == "Translation" || n == "Rotation" || n == "Scale" || n == "IrrelevantLights" || n == "MaxDrawDistance" || n == "CachedMaxDrawDistance" || n == "bOverrideLightMapResolution" || n == "OverriddenLightMapResolution") tags.erase(tags.begin() + i); else i++; }
            bool has = false; for (auto& t : tags) if (t.name == "StaticMesh") { memcpy(t.raw.data(), &mesh, 4); has = true; }
            if (!has) { Tag t; t.name = "StaticMesh"; t.type = "ObjectProperty"; t.raw.resize(4); memcpy(t.raw.data(), &mesh, 4); tags.insert(tags.begin(), t); }
            if (!replaceProps(P, nc, tags)) throw Err("component properties");
            // native data (LODData: lightmap/vertex colors of the template) -> empty
            own(P, nc); ObjProps op2 = objProps(P, nc); auto& d = P.exports[nc - 1].data; d.resize(op2.end); u8 z[4] = { 0, 0, 0, 0 }; d.insert(d.end(), z, z + 4); }
        // actor: new position, no rotation/scale from the template
        { ObjProps op = objProps(P, na); std::vector<Tag> tags = op.tags;
            for (size_t i = 0; i < tags.size();) { const std::string& n = tags[i].name; if (n == "Rotation" || n == "DrawScale" || n == "DrawScale3D" || n == "PrePivot" || n == "Tag" || n == "Base" || n == "bHidden" || n == "Attached") tags.erase(tags.begin() + i); else i++; }
            setStructTag(tags, "Location", "Vector", loc, 12);
            if (!replaceProps(P, na, tags)) throw Err("actor properties"); }
}

struct Result { bool ok = false; std::string err; i32 actor = 0, comp = 0; };

// ------------------------------------------------------------------ generic actors: mesh, light, emitter
enum class Kind { Mesh, PointLight, SpotLight, Emitter };
struct LightParams { float radius = 512, brightness = 1; u8 r = 255, g = 255, b = 255; bool shadows = false; float inner = 20, outer = 40; };
struct PlaceSpec { Kind kind = Kind::Mesh; i32 asset = 0; float loc[3] = { 0, 0, 0 }; LightParams lp; };

inline int kindPref(Kind k, const std::string& c) {
    switch (k) {
    case Kind::Mesh: return c == "InterpActor" ? 2 : c == "StaticMeshActor" ? 1 : 0;
    case Kind::PointLight: return c == "PointLightToggleable" ? 3 : c == "PointLightMovable" ? 2 : 0;
    case Kind::SpotLight: return c == "SpotLightToggleable" ? 3 : c == "SpotLightMovable" ? 2 : 0;
    case Kind::Emitter: return c == "Emitter" ? 1 : 0; }
    return 0; }
inline bool kindComp(Kind k, const std::string& c) {
    switch (k) {
    case Kind::Mesh: return c == "StaticMeshComponent";
    case Kind::PointLight: return c == "PointLightComponent";
    case Kind::SpotLight: return c == "SpotLightComponent";
    case Kind::Emitter: return c == "ParticleSystemComponent"; }
    return false; }
// subobjects of the actor (depth first: parent before child)
inline std::vector<i32> actorSet(const Package& P, i32 actor) {
    std::vector<i32> set; for (size_t k = 0; k < P.exports.size(); k++) { i32 o = (i32)k + 1; for (int g = 0; o > 0 && g < 16; g++) { if (o == actor) { set.push_back((i32)k + 1); break; } o = P.exports[o - 1].outer; } }
    auto depth = [&](i32 x) { int d = 0; while (x != actor && x > 0) { x = P.exports[x - 1].outer; d++; } return d; };
    std::stable_sort(set.begin(), set.end(), [&](i32 a, i32 b) { return depth(a) < depth(b); }); return set; }
// template of a kind: actor in the PersistentLevel with the right component. Light/emitter: only actor + component, Engine archetypes
// (an archetype from another package - e.g. LIGHTS_Int.AlarmLight - would become an import of a package the map may not load)
inline Template findTemplateK(const Package& P, Kind k) {
    if (k == Kind::Mesh) return findTemplate(P);
    Template best; int bp = 0; bool light = k == Kind::PointLight || k == Kind::SpotLight; Kind other = k == Kind::PointLight ? Kind::SpotLight : Kind::PointLight;
    for (size_t q = 0; q < P.exports.size(); q++) { std::string c = P.classOf(P.exports[q]); int pr = kindPref(k, c) * 2; if (!pr && light) pr = kindPref(other, c); if (!pr || pr <= bp) continue;
        if (P.exports[q].outer <= 0 || P.objPath(P.exports[q].outer) != "TheWorld.PersistentLevel" || (P.exports[q].flags & 0x600ull)) continue;
        i32 a = (i32)q + 1; auto set = actorSet(P, a); if (set.size() != 2) continue; i32 comp = set[1]; std::string cc = P.classOf(P.exports[comp - 1]); if (!kindComp(k, cc) && !(light && kindComp(other, cc))) continue;
        auto engineArch = [&](i32 x) { i32 ar = P.exports[x - 1].archetype; if (!ar) return true; std::string ap = P.objPath(ar); return ap.rfind("Engine.", 0) == 0; };
        if (!engineArch(a) || !engineArch(comp)) continue;
        best.actor = a; best.comp = comp; best.cls = c; bp = pr; }
    return best;
}
inline void eraseTags(std::vector<Tag>& tags, std::initializer_list<const char*> names) {
    for (size_t i = 0; i < tags.size();) { bool kill = false; for (auto n : names) if (tags[i].name == n) { kill = true; break; } if (kill) tags.erase(tags.begin() + i); else i++; } }
inline void truncNative(Package& P, i32 x) { own(P, x); ObjProps op = objProps(P, x); auto& d = P.exports[x - 1].data; d.resize(op.end); u8 z[4] = { 0, 0, 0, 0 }; d.insert(d.end(), z, z + 4); }

// clones the template inside the level itself (actor + subobjects); returns the new actor and the component
inline std::pair<i32, i32> cloneInLevel(Package& P, const cp::TypeDB& db, const Template& T, bool truncComp) {
    std::vector<i32> set = actorSet(P, T.actor);
    std::map<i32, i32> remap; std::vector<std::pair<i32, cp::Refs>> refs;
    int maxNum = 0; for (auto& e : P.exports) if (e.name.idx == P.exports[T.actor - 1].name.idx) maxNum = std::max(maxNum, e.name.num);
    for (i32 s : set) {
        Export ne = P.exports[s - 1]; ne.data.assign(P.dataPtr(P.exports[s - 1]), P.dataPtr(P.exports[s - 1]) + P.dataLen(P.exports[s - 1])); ne.owned = true; ne.netObjects.clear(); memset(ne.guid, 0, 16);
        // mesh component: the template's native data (LODData with lightmap/per-vertex colors of that mesh) is useless for the new one -> empty
        if (s == T.comp && truncComp) { ObjProps op = objProps(P, s); if (!op.ok) throw Err("template component properties"); ne.data.resize(op.end); u8 z[4] = { 0, 0, 0, 0 }; ne.data.insert(ne.data.end(), z, z + 4); }
        if (s == T.actor) ne.name.num = maxNum + 1; P.exports.push_back(ne); i32 ni = (i32)P.exports.size(); remap[s] = ni;
        cp::Refs r; std::string err; if (!cp::analyzeExport(P, db, ni, r, err)) { P.exports.resize(P.exports.size() - remap.size()); throw Err(P.objPath(s) + ": " + err); } refs.push_back({ s, r }); }
    for (auto& [s, r] : refs) { Export& ne = P.exports[remap[s] - 1]; if (remap.count(ne.outer)) ne.outer = remap[ne.outer];
        if (remap.count(ne.archetype)) ne.archetype = remap[ne.archetype];
        for (size_t p : r.objs) { i32 v; memcpy(&v, ne.data.data() + p, 4); if (remap.count(v)) { i32 nv = remap[v]; memcpy(ne.data.data() + p, &nv, 4); } } }
    return { remap[T.actor], remap[T.comp] };
}

// brings the template from another map ('donor', loaded just for this - and modified here): cleans up the donor actor (no links to
// other actors/assets of that map), gives it a free name number in the target and copies it with its subobjects
inline std::pair<i32, i32> importFromDonor(Package& P, const cp::TypeDB& db, Package& donor, const Template& T, Kind k) {
    { ObjProps op = objProps(donor, T.comp); if (!op.ok) throw Err("donor component properties"); std::vector<Tag> tags = op.tags;
        if (k == Kind::Mesh) eraseTags(tags, { "StaticMesh", "Materials", "ReplacementPrimitive", "ShadowParent" });
        else if (k == Kind::Emitter) eraseTags(tags, { "Template", "InstanceParameters", "ReplacementPrimitive", "ShadowParent" });
        else eraseTags(tags, { "Function", "OtherLevelsToAffect", "InclusionVolumes", "ExclusionVolumes", "InclusionConvexVolumes", "ExclusionConvexVolumes", "PreviewLightRadius", "PreviewInnerCone", "PreviewOuterCone", "PreviewLightSourceRadius" });
        if (!replaceProps(donor, T.comp, tags)) throw Err("donor component properties");
        if (k == Kind::Mesh) truncNative(donor, T.comp); }
    { ObjProps op = objProps(donor, T.actor); if (!op.ok) throw Err("donor actor properties"); std::vector<Tag> tags = op.tags;
        eraseTags(tags, { "ReplicatedMesh", "Base", "Owner", "Attached", "Tag", "Group", "BaseBoneName", "BaseSkelComponent", "Rotation", "DrawScale", "DrawScale3D", "PrePivot", "bHidden" });
        if (!replaceProps(donor, T.actor, tags)) throw Err("donor actor properties"); }
    { const std::string& an = donor.names[donor.exports[T.actor - 1].name.idx].first; int maxNum = 0;
        for (auto& e : P.exports) if (e.name.idx >= 0 && e.name.idx < (i32)P.names.size() && P.names[e.name.idx].first == an) maxNum = std::max(maxNum, e.name.num);
        donor.exports[T.actor - 1].name.num = maxNum + 1000; }
    cp::CopyReport cr = cp::copyObjects(P, donor, { T.actor }, db, false);
    if (!cr.ok) throw Err("copy from donor: " + cr.err);
    i32 na = cr.roots[0], nc = 0;
    for (size_t q = 0; q < P.exports.size(); q++) if (P.exports[q].outer == na && (kindComp(k, P.classOf(P.exports[q])) || ((k == Kind::PointLight || k == Kind::SpotLight) && P.classOf(P.exports[q]).find("LightComponent") != std::string::npos))) { nc = (i32)q + 1; break; }
    if (!nc) throw Err("copied template has no component");
    return { na, nc };
}

inline Tag boolT(const std::string& n, bool v) { Tag t; t.name = n; t.type = "BoolProperty"; t.isBool = true; t.boolVal = v; return t; }
inline Tag floatT(const std::string& n, float v) { Tag t; t.name = n; t.type = "FloatProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); return t; }
inline Tag objT(const std::string& n, i32 v) { Tag t; t.name = n; t.type = "ObjectProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); return t; }
inline void setTag(std::vector<Tag>& tags, const Tag& nt) { for (auto& t : tags) if (t.name == nt.name && t.index == 0) { t = nt; return; } tags.insert(tags.begin(), nt); }

// point light <-> spotlight: same serialization (SpotLightComponent derives from PointLightComponent); swaps the actor class
// (and the FStateFrame, which points to the class), the component class and archetype
inline void swapLightClass(Package& P, i32 na, i32 nc, Kind k) {
    std::string ac = P.classOf(P.exports[na - 1]); bool isSpot = ac.rfind("SpotLight", 0) == 0; bool wantSpot = k == Kind::SpotLight; if (isSpot == wantSpot) return;
    std::string suffix = ac.size() > 9 && ac.find("Movable") != std::string::npos ? "Movable" : "Toggleable"; std::string base = wantSpot ? "SpotLight" : "PointLight";
    i32 oldCls = P.exports[na - 1].cls, newCls = P.ensureRef("Engine." + base + suffix, "Core", "Class");
    own(P, na); auto& d = P.exports[na - 1].data; if (P.exports[na - 1].flags & 0x0200000000000000ull) for (size_t o : { (size_t)0, (size_t)4 }) { i32 v; memcpy(&v, d.data() + o, 4); if (v == oldCls) memcpy(d.data() + o, &newCls, 4); }
    P.exports[na - 1].cls = newCls;
    { i32 nn = P.addName(base + suffix); int mx = 0; for (auto& e : P.exports) if (e.name.idx == nn) mx = std::max(mx, e.name.num); P.exports[na - 1].name.idx = nn; P.exports[na - 1].name.num = mx + 1;
      P.exports[nc - 1].name.idx = P.addName(base + "Component"); }
    P.exports[nc - 1].cls = P.ensureRef("Engine." + base + "Component", "Core", "Class");
    P.ensureRef("Engine.Default__" + base + suffix, "Engine", base + suffix);   // outer of the archetype (with the right class, not "Package")
    P.exports[nc - 1].archetype = P.ensureRef("Engine.Default__" + base + suffix + "." + base + "Component0", "Engine", base + "Component");
    if (!wantSpot) { ObjProps op = objProps(P, nc); std::vector<Tag> tags = op.tags; eraseTags(tags, { "InnerConeAngle", "OuterConeAngle", "PreviewInnerCone", "PreviewOuterCone" }); if (!replaceProps(P, nc, tags)) throw Err("light component properties"); }
}
inline void configureLight(Package& P, i32 na, i32 nc, const PlaceSpec& S) {
    bool spot = S.kind == Kind::SpotLight; const LightParams& L = S.lp; swapLightClass(P, na, nc, S.kind);
    { ObjProps op = objProps(P, nc); std::vector<Tag> tags = op.tags;
        // LightingChannels: the template channels were those of its room; without the property the Engine ones apply (BSP + static + dynamic)
        eraseTags(tags, { "Function", "OtherLevelsToAffect", "bOnlyAffectSameAndSpecifiedLevels", "InclusionVolumes", "ExclusionVolumes", "InclusionConvexVolumes", "ExclusionConvexVolumes", "LightingChannels" });
        setTag(tags, floatT("Radius", L.radius)); setTag(tags, floatT("Brightness", L.brightness));
        { u8 c[4] = { L.b, L.g, L.r, 255 }; setStructTag(tags, "LightColor", "Color", c, 4); }
        setTag(tags, boolT("CastShadows", L.shadows)); setTag(tags, boolT("CastDynamicShadows", L.shadows)); setTag(tags, boolT("bEnabled", true));
        if (spot) { setTag(tags, floatT("InnerConeAngle", L.inner)); setTag(tags, floatT("OuterConeAngle", L.outer)); }
        // new GUIDs: the light is not in any lightmap/shadowmap -> the engine treats it as a dynamic light
        static std::mt19937 rng{ std::random_device{}() }; for (const char* g : { "LightGuid", "LightmapGuid" }) { u32 v[4]; for (auto& x : v) x = rng(); setStructTag(tags, g, "Guid", v, 16); }
        float m[16] = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, S.loc[0], S.loc[1], S.loc[2], 1 };
        if (spot) { float pm[16] = { 0, 0, -1, 0, 0, 1, 0, 0, 1, 0, 0, 0, S.loc[0], S.loc[1], S.loc[2], 1 }; memcpy(m, pm, sizeof m); }   // pointing down
        setStructTag(tags, "CachedParentToWorld", "Matrix", m, 64);
        if (!replaceProps(P, nc, tags)) throw Err("light component properties"); }
    { ObjProps op = objProps(P, na); std::vector<Tag> tags = op.tags;
        eraseTags(tags, { "Rotation", "DrawScale", "DrawScale3D", "PrePivot", "Tag", "Base", "bHidden", "Attached" });
        setStructTag(tags, "Location", "Vector", S.loc, 12);
        if (spot) { i32 r[3] = { -16384, 0, 0 }; setStructTag(tags, "Rotation", "Rotator", r, 12); }
        if (!replaceProps(P, na, tags)) throw Err("light actor properties"); }
}
inline void configureEmitter(Package& P, i32 na, i32 nc, const PlaceSpec& S) {
    { ObjProps op = objProps(P, nc); std::vector<Tag> tags = op.tags;
        eraseTags(tags, { "InstanceParameters", "bAutoActivate", "bJustAttached", "Translation", "Rotation", "Scale", "Scale3D", "HiddenGame", "OldPosition", "PartSysVelocity" });
        setTag(tags, objT("Template", S.asset)); setTag(tags, boolT("bAutoActivate", true));
        if (!replaceProps(P, nc, tags)) throw Err("emitter component properties"); }
    { ObjProps op = objProps(P, na); std::vector<Tag> tags = op.tags;
        eraseTags(tags, { "Rotation", "DrawScale", "DrawScale3D", "PrePivot", "Tag", "Base", "bHidden", "Attached", "bCurrentlyActive" });
        setStructTag(tags, "Location", "Vector", S.loc, 12);
        if (!replaceProps(P, na, tags)) throw Err("emitter actor properties"); }
}

// places a new actor: template from the level itself, or from 'donor' if the level has none (donor may be null)
inline Result placeActor(Package& P, const cp::TypeDB& db, const PlaceSpec& S, Package* donor) {
    Result R;
    try {
        Template T = findTemplateK(P, S.kind); std::pair<i32, i32> ac;
        if (T.actor) ac = cloneInLevel(P, db, T, S.kind == Kind::Mesh);
        else { if (!donor) throw Err("this level has no actor of this kind to use as a template");
            Template D = findTemplateK(*donor, S.kind); if (!D.actor) throw Err("the donor level has no template either");
            ac = importFromDonor(P, db, *donor, D, S.kind); }
        if (S.kind == Kind::Mesh) configurePlaced(P, ac.first, ac.second, S.asset, S.loc);
        else if (S.kind == Kind::Emitter) configureEmitter(P, ac.first, ac.second, S);
        else configureLight(P, ac.first, ac.second, S);
        if (!addActorToLevel(P, ac.first)) throw Err("cannot add the actor to the level");
        R.ok = true; R.actor = ac.first; R.comp = ac.second;
    } catch (std::exception& e) { R.err = e.what(); R.ok = false; }
    return R;
}
inline Result placeStaticMesh(Package& P, const cp::TypeDB& db, i32 mesh, const float loc[3]) { PlaceSpec S; S.asset = mesh; memcpy(S.loc, loc, 12); return placeActor(P, db, S, nullptr); }
inline Result placeStaticMeshFrom(Package& P, const cp::TypeDB& db, i32 mesh, const float loc[3], Package& donor) { PlaceSpec S; S.asset = mesh; memcpy(S.loc, loc, 12); return placeActor(P, db, S, &donor); }

} }
