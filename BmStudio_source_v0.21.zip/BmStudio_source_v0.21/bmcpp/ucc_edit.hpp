// ucc_edit.hpp - editing functions/states as source code: generates the editable text (faithful decompiler), compiles and writes
// the new bytecode into the package (any size), creating local variables, imports and names when needed.
// "Check" mode runs everything in a transaction and undoes it at the end (the package stays untouched).
#pragma once
#include "ucc_decomp.hpp"

namespace bm {
namespace ucc {

struct EditResult { bool ok = false; std::string err; int line = 0; size_t oldSize = 0, newSize = 0; int newLocals = 0, newImports = 0, newNames = 0; std::string warn; };

class ScriptEditor {
public:
    TypeDB& db; Compiler& C; Decomp& D;
    ScriptEditor(TypeDB& d, Compiler& c, Decomp& dc) : db(d), C(c), D(dc) {}

    static bool editable(TypeDB& db, const Ref& fn, std::string* why = nullptr) {
        std::string c = db.cls(fn);
        if (c != "Function" && c != "State") { if (why) *why = "not a function/state"; return false; }
        const FieldInfo& f = db.field(fn);
        if (c == "Function" && (f.funcFlags & FUNC_Native)) { if (why) *why = "native function (code is in the .exe)"; return false; }
        return true;
    }

    // ---------------------------------------------------------- editable text
    std::string source(const Ref& fn) {
        DecompResult r = D.run(fn); std::string out;
        std::string c = db.cls(fn);
        if (c == "Function") {
            out += "// " + funcSignature(db.P(fn), fn.idx) + "\n";
            // default values of the optional parameters
            size_t di = 0;
            for (auto& p : C.params(fn)) {
                if (!(p.flags & CPF_OptionalParm)) continue;
                std::string d = di < r.defaults.size() ? r.defaults[di] : std::string(); di++;
                out += "//@default " + db.name(p.prop) + (d.empty() ? std::string() : " = " + d) + "\n";
            }
            // locals
            std::string loc;
            for (Ref ch : db.children(fn)) { const FieldInfo& f = db.field(ch); if (!f.isProperty || (f.propFlags & CPF_Parm)) continue;
                loc += "    local " + typeDecl(db.propType(ch)) + " " + db.name(ch) + (f.arrayDim > 1 ? "[" + std::to_string(f.arrayDim) + "]" : std::string()) + ";\n"; }
            if (!loc.empty()) out += loc + "\n";
        } else out += "// state " + db.name(fn) + " (state code / labels)\n";
        if (!r.err.empty()) out += "// ERROR while decompiling: " + r.err + "\n";
        out += r.body;
        return out;
    }
    std::string typeDecl(const Type& t) { return C.typeStr(t); }

    // ---------------------------------------------------------- transaction
    struct Snap { size_t names, imports, exports; std::vector<std::pair<i32, std::vector<u8>>> data; std::vector<std::pair<i32, bool>> owned; };
    Snap snap(Package& P) { Snap s; s.names = P.names.size(); s.imports = P.imports.size(); s.exports = P.exports.size(); return s; }
    void touch(Snap& s, Package& P, i32 idx) {   // saves the state of an export before changing it
        for (auto& d : s.data) if (d.first == idx) return;
        Export& e = P.exports[idx - 1]; s.data.push_back({ idx, std::vector<u8>(P.dataPtr(e), P.dataPtr(e) + P.dataLen(e)) }); s.owned.push_back({ idx, e.owned });
    }
    void rollback(Snap& s, Package& P) {
        for (size_t k = 0; k < s.data.size(); k++) { Export& e = P.exports[s.data[k].first - 1]; if (s.owned[k].second) { e.data = s.data[k].second; e.owned = true; } else { e.data.clear(); e.owned = false; } }
        P.exports.resize(s.exports); P.imports.resize(s.imports); P.names.resize(s.names);
    }
    void setOwned(Package& P, i32 idx) { Export& e = P.exports[idx - 1]; if (!e.owned) { e.data.assign(P.dataPtr(e), P.dataPtr(e) + P.dataLen(e)); e.owned = true; } }

    // ---------------------------------------------------------- local variable creation
    // supported types: int float bool byte name string, enums (byte), classes (object), class<X>, structs
    i32 coreClassImport(Package& P, const std::string& cls) {
        Ref r = db.findPath("Core." + cls); if (!r) r = db.findClass(cls);
        if (r) return C.objIndex(r, 0);
        for (size_t q = 0; q < P.imports.size(); q++) { i32 ii = -(i32)q - 1; if (Package::strcasecmp_(P.objPath(ii), "Core." + cls)) return ii; }
        throw CompileError("class Core." + cls + " not found", 0);
    }
    // creates a property export (outer = function, class or array). Returns the index; does NOT link it.
    // types: int float bool byte name string, enums, structs, classes (object/interface), class<X>, array<T>
    Type lastPropType;
    i32 makeProp(const Ref& owner, const std::string& typeText, const std::string& name, int arrayDim, uint64_t flags, int line) {
        Package& P = db.P(owner); std::string tl = lower(typeText);
        std::string propCls; i32 ref1 = 0, ref2 = 0; Type ty; std::string innerType;
        if (tl == "int") { propCls = "IntProperty"; ty.k = K::Int; } else if (tl == "float") { propCls = "FloatProperty"; ty.k = K::Float; } else if (tl == "bool") { propCls = "BoolProperty"; ty.k = K::Bool; }
        else if (tl == "byte") { propCls = "ByteProperty"; ty.k = K::Byte; } else if (tl == "name") { propCls = "NameProperty"; ty.k = K::Name; } else if (tl == "string") { propCls = "StrProperty"; ty.k = K::String; }
        else if (tl.compare(0, 6, "class<") == 0) { propCls = "ClassProperty"; std::string in = typeText.substr(6, typeText.size() - 7); Ref c = db.findClass(in); if (!c) throw CompileError("unknown class '" + in + "'", line);
            Ref cc = db.findPath("Core.Class"); if (!cc) cc = db.findClass("Class"); ref1 = C.objIndex(cc, line); ref2 = C.objIndex(c, line); ty.k = K::Class; ty.cls = c; }
        else if (tl.compare(0, 6, "array<") == 0) { propCls = "ArrayProperty"; innerType = typeText.substr(6, typeText.size() - 7); ty.k = K::Array; }
        else if (tl.compare(0, 9, "delegate<") == 0) throw CompileError("delegate variables are not supported yet", line);
        else {
            Ref c = db.findClass(typeText);
            if (c) { bool iface = (db.field(c).classFlags & 0x4000) != 0; propCls = iface ? "InterfaceProperty" : "ObjectProperty"; ref1 = C.objIndex(c, line); ty.k = iface ? K::Interface : K::Object; ty.cls = c; }
            else { Ref t = C.findStructOrEnum(typeText); if (!t) throw CompileError("unknown type '" + typeText + "'", line);
                if (db.cls(t) == "Enum") { propCls = "ByteProperty"; ref1 = C.objIndex(t, line); ty.k = K::Byte; ty.enm = t; } else { propCls = "StructProperty"; ref1 = C.objIndex(t, line); ty.k = K::Struct; ty.strct = t; } }
        }
        if (ty.k == K::Array || ty.k == K::String || (ty.k == K::Struct && C.needsDestruct(ty))) flags |= 0x400000ull;   // CPF_NeedCtorLink
        i32 noneIdx = P.findName("None"); if (noneIdx < 0) noneIdx = P.addName("None");
        Export e; e.cls = coreClassImport(P, propCls); e.super_ = 0; e.outer = owner.idx; e.name = C.makeName(name); e.archetype = 0; e.flags = 0x0007000400000000ull; if (owner.idx > 0) e.exportFlags = P.exports[owner.idx - 1].exportFlags;
        e.owned = true; e.serialSize = 0; e.serialOffset = 0;
        P.exports.push_back(e); i32 ni = (i32)P.exports.size();
        if (ty.k == K::Array) {   // inner property (same name, outer = the array)
            if (lower(innerType).compare(0, 6, "array<") == 0) throw CompileError("arrays of arrays are not supported", line);
            ref1 = makeProp(Ref{ owner.pkg, ni }, innerType, name, 1, 0, line);
        }
        Writer w; w.i(0); w.i(noneIdx); w.i(0); w.i(0); w.i(0); w.i(arrayDim); w.q(flags); w.i(noneIdx); w.i(0); w.i(0);
        if (propCls == "ByteProperty" || propCls == "ObjectProperty" || propCls == "StructProperty" || propCls == "InterfaceProperty" || propCls == "ClassProperty" || propCls == "ArrayProperty") w.i(ref1);
        if (propCls == "ClassProperty") w.i(ref2);
        P.exports[ni - 1].data = w.b; lastPropType = ty;
        return ni;
    }
    // links 'ni' at the end of the children list of 'owner' (function/class/state)
    void appendChild(Snap& s, const Ref& owner, i32 ni) {
        Package& P = db.P(owner); FieldInfo of = parseField(P, owner.idx); i32 last = 0, c = of.children;
        for (int g = 0; c > 0 && g < 100000; g++) { last = c; FieldInfo cf = parseField(P, c); if (!cf.ok) break; c = cf.next; }
        if (last) { touch(s, P, last); setOwned(P, last); FieldInfo lf = parseField(P, last); memcpy(P.exports[last - 1].data.data() + lf.nextOff, &ni, 4); }
        else { touch(s, P, owner.idx); setOwned(P, owner.idx); memcpy(P.exports[owner.idx - 1].data.data() + of.childrenOff, &ni, 4); }
    }
    i32 addLocal(Snap& s, const Ref& fn, const std::string& typeText, const std::string& name, int line) {
        std::string nm = name; int arrayDim = 1; size_t br = nm.find('['); if (br != std::string::npos) { arrayDim = atoi(nm.c_str() + br + 1); nm = nm.substr(0, br); if (arrayDim < 1) arrayDim = 1; }
        i32 ni = makeProp(fn, typeText, nm, arrayDim, 0, line);
        appendChild(s, fn, ni);
        return ni;
    }
    // sets HasDefaults (0x800000) if the function has a local struct (initialized with the struct defaults)
    void fixFuncFlags(Snap& s, const Ref& fn) {
        Package& P = db.P(fn); FieldInfo f = parseField(P, fn.idx); if (!f.ok || !f.isFunction) return;
        u32 fl = f.funcFlags; bool sl = false, opt = false, out = false;
        for (Ref ch : db.children(fn)) { const FieldInfo& cf = db.field(ch); if (!cf.isProperty) continue; Type t = db.propType(ch);
            if (!(cf.propFlags & CPF_Parm) && t.k == K::Struct) sl = true; if (cf.propFlags & CPF_OptionalParm) opt = true; if ((cf.propFlags & CPF_OutParm) && !(cf.propFlags & CPF_ReturnParm)) out = true; }
        if (sl) fl |= 0x800000; if (opt) fl |= 0x4000; if (out) fl |= 0x400000;
        if (fl != f.funcFlags) { touch(s, P, fn.idx); setOwned(P, fn.idx); memcpy(P.exports[fn.idx - 1].data.data() + f.funcFlagsOff, &fl, 4); db.fieldCache.clear(); }
    }
    // ---------------------------------------------------------- compile (+ apply)
    EditResult compile(const Ref& fn, const std::string& text, bool apply) {
        EditResult R; Package& P = db.P(fn);
        std::string why; if (!editable(db, fn, &why)) { R.err = why; return R; }
        Snap s = snap(P);
        try {
            const FieldInfo f0 = db.field(fn); R.oldSize = (size_t)f0.scriptSize;
            // //@default
            std::vector<std::string> defaults; std::map<std::string, std::string> defByName; bool anyDefault = false;
            { size_t a = 0; while (a < text.size()) { size_t e = text.find('\n', a); std::string ln = text.substr(a, e == std::string::npos ? std::string::npos : e - a); a = e == std::string::npos ? text.size() : e + 1;
                size_t k = ln.find_first_not_of(" \t"); if (k == std::string::npos || ln.compare(k, 10, "//@default") != 0) continue; anyDefault = true;
                std::string rest = ln.substr(k + 10); size_t eq = rest.find('='); std::string pn = rest.substr(0, eq); pn.erase(0, pn.find_first_not_of(" \t")); pn.erase(pn.find_last_not_of(" \t\r") + 1);
                std::string val = eq == std::string::npos ? std::string() : rest.substr(eq + 1); val.erase(0, val.find_first_not_of(" \t")); val.erase(val.find_last_not_of(" \t\r;") + 1);
                defByName[lower(pn)] = val; } }
            if (db.cls(fn) == "Function") for (auto& p : C.params(fn)) if (p.flags & CPF_OptionalParm) defaults.push_back(defByName.count(lower(db.name(p.prop))) ? defByName[lower(db.name(p.prop))] : std::string());
            // new locals
            C.func = fn; C.pi = fn.pkg; C.allowMutate = true; C.idxCache.clear();
            { Parser ps(text, C.optable); auto prog = ps.program(); std::set<std::string> have; for (Ref ch : db.children(fn)) have.insert(lower(db.name(ch)));
              std::function<void(const std::vector<SP>&)> walk = [&](const std::vector<SP>& v) { for (auto& st : v) { if (!st) continue;
                    if (st->k == SK::Local) for (auto& l : st->locals) { std::string base = l.second.substr(0, l.second.find('[')); if (have.count(lower(base))) continue;
                        if (db.cls(fn) != "Function") throw CompileError("state code cannot declare locals", st->line);
                        addLocal(s, fn, l.first, l.second, st->line); have.insert(lower(base)); R.newLocals++; }
                    if (st->k == SK::Block || st->k == SK::Switch) walk(st->body); } };
              walk(prog); }
            if (R.newLocals) { db.reindex(fn.pkg); C.invalidate(); }
            // compile
            size_t imp0 = P.imports.size(), nm0 = P.names.size();
            std::vector<u8> code = C.compileBody(fn, text, anyDefault || !defaults.empty() ? &defaults : nullptr);
            R.newImports = (int)(P.imports.size() - imp0); R.newNames = (int)(P.names.size() - nm0); R.newSize = code.size();
            { Script chk = tokenize(P, code.data(), (u32)code.size()); if (!chk.err.empty()) throw CompileError("internal: generated bytecode does not tokenize: " + chk.err, 0); }
            if (code.size() > 0xFFFF) throw CompileError("function too big (64 KB limit)", 0);
            // writes: [..ScriptSize][bytecode][rest]
            touch(s, P, fn.idx); setOwned(P, fn.idx);
            const FieldInfo f = parseField(P, fn.idx);   // current offsets (they may have changed because of locals)
            Export& ex = P.exports[fn.idx - 1];
            std::vector<u8> nd(ex.data.begin(), ex.data.begin() + (f.scriptOff - 4));
            i32 ns = (i32)code.size(); const u8* nsb = (const u8*)&ns; nd.insert(nd.end(), nsb, nsb + 4);
            nd.insert(nd.end(), code.begin(), code.end());
            nd.insert(nd.end(), ex.data.begin() + f.scriptOff + f.scriptSize, ex.data.end());
            ex.data.swap(nd);
            if (db.cls(fn) == "State") { FieldInfo f2 = parseField(P, fn.idx); if (f2.ok && f2.labelTableOffsetOff) { uint16_t lt = C.labelTablePos; memcpy(ex.data.data() + f2.labelTableOffsetOff, &lt, 2); } }
            // check: the export is still readable and the code matches
            FieldInfo f3 = parseField(P, fn.idx); if (!f3.ok || f3.scriptSize != ns || memcmp(ex.data.data() + f3.scriptOff, code.data(), code.size())) throw CompileError("internal: export rewrite check failed", 0);
            db.fieldCache.clear(); C.invalidate();
            if (R.newLocals) fixFuncFlags(s, fn);
            R.ok = true;
        } catch (CompileError& e) { R.err = e.what(); R.line = e.line; }
        catch (std::exception& e) { R.err = e.what(); }
        C.allowMutate = false;
        if (!apply || !R.ok) { rollback(s, P); db.reindex(fn.pkg); C.invalidate(); }
        return R;
    }
};

} // namespace ucc
} // namespace bm
