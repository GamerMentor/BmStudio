// bmteximp.hpp - importing an image (PNG/TGA/BMP/JPG/DDS) into a cooked Batman: Arkham Asylum Texture2D.
// Texture2D layout (UE3 v576/lic21, checked against the engine source + the game packages):
//   [UObject prefix] [properties] [SourceArt: bulk] [Mips: count + (bulk + SizeX + SizeY)*] [16 bytes (GUID)]
// Cooked mips: the largest ones go in a .tfc (flags 0x11 = separate + LZO) and the tail inline (flags 0).
// Import: every mip goes INLINE and uncompressed, TextureFileCacheName is removed (the texture stops using the .tfc),
// NeverStream=True (stays resident, no streaming). The BAA engine itself (etkramer's editor) does the same on open.
#pragma once
#include "bmasset.hpp"
#define STB_DXT_IMPLEMENTATION
#include "stb_dxt.h"
#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_HDR
#define STBI_NO_PIC
#define STBI_NO_PNM
#define STBI_NO_PSD
#define STBI_NO_GIF
#include "stb_image.h"

namespace bm {

struct TexImportReport {
    bool ok = false; std::string err; std::vector<std::string> notes;
    int w = 0, h = 0, mips = 0; std::string format, source; std::vector<u8> newData;
};

namespace teximp {
struct Img { int w = 0, h = 0; std::vector<u8> rgba; };
// DDS: returns the UE format ("PF_DXT1"/"PF_DXT5"/"PF_DXT3"/"PF_A8R8G8B8"), dimensions and the raw mips
inline bool parseDDS(const std::vector<u8>& f, std::string& fmt, int& w, int& h, std::vector<std::vector<u8>>& mips) {
    if (f.size() < 128 || memcmp(f.data(), "DDS ", 4) != 0) return false;
    auto u = [&](size_t o) { u32 v; memcpy(&v, &f[o], 4); return v; };
    h = (int)u(12); w = (int)u(16); u32 mipCount = std::max<u32>(1, u(28)); u32 pfFlags = u(80), four = u(84), bits = u(88);
    if (pfFlags & 0x4) { if (four == 0x31545844) fmt = "PF_DXT1"; else if (four == 0x33545844) fmt = "PF_DXT3"; else if (four == 0x35545844) fmt = "PF_DXT5"; else return false; }
    else if ((pfFlags & 0x40) && bits == 32 && u(92) == 0x00FF0000 && u(96) == 0x0000FF00 && u(100) == 0x000000FF) fmt = "PF_A8R8G8B8";
    else return false;
    TextureInfo ti; ti.format = fmt; size_t off = 128; int mw = w, mh = h;
    for (u32 m = 0; m < mipCount && mw >= 1 && mh >= 1; m++) {
        size_t n = ti.mipBytes(mw, mh); if (off + n > f.size()) break;
        mips.emplace_back(f.begin() + off, f.begin() + off + n); off += n;
        if (mw == 1 && mh == 1) break; mw = std::max(1, mw / 2); mh = std::max(1, mh / 2);
    }
    return !mips.empty();
}
inline Img half(const Img& s) {
    Img d; d.w = std::max(1, s.w / 2); d.h = std::max(1, s.h / 2); d.rgba.resize((size_t)d.w * d.h * 4);
    for (int y = 0; y < d.h; y++) for (int x = 0; x < d.w; x++) for (int c = 0; c < 4; c++) {
        int sum = 0, n = 0; for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) { int sx = std::min(s.w - 1, x * 2 + dx), sy = std::min(s.h - 1, y * 2 + dy); sum += s.rgba[((size_t)sy * s.w + sx) * 4 + c]; n++; }
        d.rgba[((size_t)y * d.w + x) * 4 + c] = (u8)((sum + n / 2) / n); }
    return d;
}
// encodes an RGBA mip in the game format
inline std::vector<u8> encode(const Img& im, const std::string& fmt) {
    std::vector<u8> out;
    if (fmt == "PF_DXT1" || fmt == "PF_DXT5") {
        bool a = fmt == "PF_DXT5"; int bw = std::max(1, (im.w + 3) / 4), bh = std::max(1, (im.h + 3) / 4); out.resize((size_t)bw * bh * (a ? 16 : 8));
        for (int by = 0; by < bh; by++) for (int bx = 0; bx < bw; bx++) { u8 blk[64];
            for (int k = 0; k < 16; k++) { int x = std::min(im.w - 1, bx * 4 + (k & 3)), y = std::min(im.h - 1, by * 4 + (k >> 2)); memcpy(blk + k * 4, &im.rgba[((size_t)y * im.w + x) * 4], 4); }
            stb_compress_dxt_block(&out[((size_t)by * bw + bx) * (a ? 16 : 8)], blk, a ? 1 : 0, STB_DXT_HIGHQUAL); }
    } else if (fmt == "PF_A8R8G8B8") { out.resize((size_t)im.w * im.h * 4); for (size_t k = 0; k < (size_t)im.w * im.h; k++) { out[k * 4] = im.rgba[k * 4 + 2]; out[k * 4 + 1] = im.rgba[k * 4 + 1]; out[k * 4 + 2] = im.rgba[k * 4]; out[k * 4 + 3] = im.rgba[k * 4 + 3]; } }
    else if (fmt == "PF_G8") { out.resize((size_t)im.w * im.h); for (size_t k = 0; k < (size_t)im.w * im.h; k++) out[k] = (u8)((im.rgba[k * 4] * 77 + im.rgba[k * 4 + 1] * 150 + im.rgba[k * 4 + 2] * 29) >> 8); }
    return out;
}
inline bool isPow2(int v) { return v > 0 && (v & (v - 1)) == 0; }
}

// empty fmtOverride = keep the texture format (DXT3 becomes DXT5: there is no DXT3 encoder)
inline TexImportReport importTexture2D(Package& pk, i32 idx, const std::vector<u8>& file, const std::string& fmtOverride = "") {
    using namespace teximp; TexImportReport rep;
    try {
        if (idx <= 0 || pk.classOf(pk.exports[idx - 1]) != "Texture2D") throw Err("target is not a Texture2D");
        ObjProps op = objProps(pk, idx); long ps = findPropStart(pk, idx); if (!op.ok || ps < 0) throw Err("cannot read texture properties");
        TextureInfo ti = parseTexture(pk, idx); if (!ti.err.empty()) throw Err("target texture: " + ti.err);
        std::string fmt = fmtOverride.empty() ? ti.format : fmtOverride; if (fmt == "PF_DXT3") fmt = "PF_DXT5";
        if (fmt != "PF_DXT1" && fmt != "PF_DXT5" && fmt != "PF_A8R8G8B8" && fmt != "PF_G8") throw Err("texture format " + fmt + " is not supported for import");
        // --- source
        std::vector<std::vector<u8>> mipsData; int W = 0, H = 0; std::string ddsFmt;
        Img top; bool fromDDS = false;
        if (parseDDS(file, ddsFmt, W, H, mipsData)) {
            fromDDS = true; rep.source = "DDS " + ddsFmt + " " + std::to_string(mipsData.size()) + " mip(s)";
            if (ddsFmt == fmt && mipsData.size() > 1) { /* uses the DDS mips as they are */ }
            else { TextureInfo t2; t2.format = ddsFmt; if (!decodeToRGBA(t2, W, H, mipsData[0].data(), mipsData[0].size(), top.rgba)) throw Err("cannot decode the DDS (" + ddsFmt + ")"); top.w = W; top.h = H; mipsData.clear(); }
        } else {
            int n = 0; u8* px = stbi_load_from_memory(file.data(), (int)file.size(), &W, &H, &n, 4);
            if (!px) throw Err(std::string("cannot read the image: ") + stbi_failure_reason());
            top.w = W; top.h = H; top.rgba.assign(px, px + (size_t)W * H * 4); stbi_image_free(px); rep.source = "image " + std::to_string(W) + "x" + std::to_string(H);
        }
        if (!isPow2(W) || !isPow2(H)) throw Err("image size " + std::to_string(W) + "x" + std::to_string(H) + " is not a power of two (e.g. 512, 1024, 2048)");
        if (W > 4096 || H > 4096) throw Err("image larger than 4096");
        // --- mip chain (down to 1x1; in DXT formats the stored dimensions stop at 4, like the game cooker does)
        bool dxt = fmt == "PF_DXT1" || fmt == "PF_DXT5";
        struct OutMip { int w, h; std::vector<u8> data; }; std::vector<OutMip> mips;
        if (!mipsData.empty()) {
            int mw = W, mh = H; for (auto& d : mipsData) { mips.push_back({ dxt ? std::max(4, mw) : mw, dxt ? std::max(4, mh) : mh, d }); if (mw == 1 && mh == 1) break; mw = std::max(1, mw / 2); mh = std::max(1, mh / 2); }
        } else {
            Img cur = top;
            for (;;) { mips.push_back({ dxt ? std::max(4, cur.w) : cur.w, dxt ? std::max(4, cur.h) : cur.h, encode(cur, fmt) }); if (cur.w == 1 && cur.h == 1) break; cur = half(cur); }
        }
        // --- properties
        std::vector<Tag> tags; bool hasNever = false;
        for (auto t : op.tags) {
            if (t.name == "TextureFileCacheName") continue;                                    // stops using the .tfc
            if (t.name == "SizeX" && t.raw.size() == 4) memcpy(t.raw.data(), &W, 4);
            if (t.name == "SizeY" && t.raw.size() == 4) memcpy(t.raw.data(), &H, 4);
            if (t.name == "MipTailBaseIdx" && t.raw.size() == 4) { i32 v = (i32)mips.size() - 1; memcpy(t.raw.data(), &v, 4); }
            if (t.name == "Format" && t.raw.size() == 8) { i32 n = pk.addName(fmt), z = 0; memcpy(t.raw.data(), &n, 4); memcpy(t.raw.data() + 4, &z, 4); }
            if (t.name == "NeverStream") { t.isBool = true; t.boolVal = 1; hasNever = true; }
            tags.push_back(t);
        }
        auto has = [&](const char* n) { for (auto& t : tags) if (t.name == n) return true; return false; };
        auto intTag = [&](const char* n, i32 v) { Tag t; t.name = n; t.type = "IntProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); tags.push_back(t); };
        if (!has("SizeX")) intTag("SizeX", W); if (!has("SizeY")) intTag("SizeY", H);
        if (!has("MipTailBaseIdx")) intTag("MipTailBaseIdx", (i32)mips.size() - 1);
        if (!has("Format")) { Tag t; t.name = "Format"; t.type = "ByteProperty"; t.raw.resize(8); i32 n = pk.addName(fmt), z = 0; memcpy(t.raw.data(), &n, 4); memcpy(t.raw.data() + 4, &z, 4); tags.push_back(t); }
        if (!hasNever) { Tag t; t.name = "NeverStream"; t.type = "BoolProperty"; t.isBool = true; t.boolVal = 1; tags.push_back(t); }
        std::vector<u8> props = writeProps(pk, tags);
        // --- native data
        const Export& ex = pk.exports[idx - 1]; const u8* d = pk.dataPtr(ex); size_t dl = pk.dataLen(ex);
        Reader r(d, dl, op.end); readBulk(r); size_t srcArtEnd = r.p;                            // SourceArt untouched
        i32 n0 = r.i(); for (i32 k = 0; k < n0; k++) { readBulk(r); r.i(); r.i(); }
        std::vector<u8> tail(d + r.p, d + dl);                                                    // final 16 bytes (GUID)
        Writer w; w.raw(d, (size_t)ps); w.raw(props);
        { size_t sa = w.b.size(); w.raw(d + op.end, srcArtEnd - op.end);
          // SourceArt (inline): the header moved together with the properties -> absolute offset recomputed (otherwise the game stops at
          // "BulkDataOffsetInFile == Ar.Tell()"; the save fix only recognizes offsets that match the old position)
          if (srcArtEnd - op.end >= 16) { u32 fl; memcpy(&fl, &w.b[sa], 4); i32 off; memcpy(&off, &w.b[sa + 12], 4);
              if (!(fl & BULK_SEPARATE) && off != -1) { i32 nv = ex.serialOffset + (i32)sa + 16; memcpy(&w.b[sa + 12], &nv, 4); } } }
        w.i((i32)mips.size());
        for (auto& m : mips) { w.u(0); w.i((i32)m.data.size()); w.i((i32)m.data.size()); w.i(ex.serialOffset + (i32)w.b.size() + 4); w.raw(m.data); w.i(m.w); w.i(m.h); }
        w.raw(tail);
        rep.newData = std::move(w.b); rep.w = W; rep.h = H; rep.mips = (int)mips.size(); rep.format = fmt; rep.ok = true;
        if (!ti.tfc.empty()) rep.notes.push_back("the texture no longer uses " + ti.tfc + ".tfc: all mips are now stored inside the package (" + std::to_string(rep.newData.size() / 1024) + " KB)");
        if (fromDDS && ddsFmt != fmt) rep.notes.push_back("DDS was " + ddsFmt + ", re-encoded to " + fmt);
        if (fmt != ti.format) rep.notes.push_back("format changed from " + ti.format + " to " + fmt);
    } catch (std::exception& e) { rep.err = e.what(); }
    return rep;
}

} // namespace bm
