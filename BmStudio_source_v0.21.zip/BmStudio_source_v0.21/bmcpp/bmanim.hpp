// bmanim.hpp - cooked AnimSet / AnimSequence of Batman: Arkham Asylum (UE3 v576 / lic 21)
// Format: CompressedTrackOffsets (4 ints per bone: offsetTrans, numTrans, offsetRot, numRot) + CompressedByteStream.
// Keys: AKF_ConstantKeyLerp / AKF_VariableKeyLerp (u8/u16 frame table aligned to 4); rotation ACF_Fixed48Max
// (BATMAN-only, "smallest 3") or the standard formats; see AnimationEncodingFormat*.h in the engine source.
#pragma once
#include "bmasset.hpp"
#include <array>

namespace bm {
inline bool _bmieq(const std::string& a, const std::string& b) { if (a.size() != b.size()) return false; for (size_t i = 0; i < a.size(); i++) if (tolower((unsigned char)a[i]) != tolower((unsigned char)b[i])) return false; return true; }

struct AnimTrack {
    std::vector<std::array<float, 3>> pos; std::vector<int> posFrames;     // empty frames = uniform keys
    std::vector<std::array<float, 4>> rot; std::vector<int> rotFrames;
};
struct AnimSeq {
    i32 idx = 0; std::string name; int numFrames = 0; float length = 0, rateScale = 1; bool additive = false;
    std::string keyFmt, rotFmt, transFmt; std::vector<AnimTrack> tracks; std::string err;
    float fps() const { return rawFps() * rateScale; }
    float rawFps() const { return length > 0 ? (numFrames > 1 ? (numFrames - 1) : 1) / length : 30.f; }   // without RateScale (PSA)
};
struct AnimSetData { std::vector<std::string> bones; std::vector<i32> seqRefs; std::string previewMesh; std::string err; };

inline AnimSetData parseAnimSet(const Package& pk, i32 idx) {
    AnimSetData a; ObjProps op = objProps(pk, idx); if (!op.ok) { a.err = "cannot read AnimSet properties"; return a; }
    try {
        if (const Tag* t = findTag(op.tags, "TrackBoneNames")) { Reader r(t->raw.data(), t->raw.size()); i32 n = r.i(); for (i32 k = 0; k < n; k++) { FName f; f.idx = r.i(); f.num = r.i(); a.bones.push_back(pk.nm(f)); } }
        if (const Tag* t = findTag(op.tags, "Sequences")) { Reader r(t->raw.data(), t->raw.size()); i32 n = r.i(); for (i32 k = 0; k < n; k++) a.seqRefs.push_back(r.i()); }
        a.previewMesh = tagName(pk, op.tags, "PreviewSkelMeshName");
    } catch (std::exception& e) { a.err = e.what(); }
    return a;
}

namespace animdetail {
inline std::array<float, 4> fixed48Max(const u8* p) {
    uint16_t d[3]; memcpy(d, p, 6);
    unsigned tmp = ((unsigned)d[1] << 16) | d[0]; int S = tmp & 3, L = (tmp >> 2) & 0x7FFF;
    tmp = ((unsigned)d[2] << 16) | d[1]; int M = (tmp >> 1) & 0x7FFF, H = (tmp >> 16) & 0x7FFF;
    const float shift = 0.70710678118f, scale = 1.41421356237f;
    float l = (L - 0.5f) / 32767 * scale - shift, m = (M - 0.5f) / 32767 * scale - shift, h = (H - 0.5f) / 32767 * scale - shift;
    float a = sqrtf(std::max(0.f, 1.0f - (l * l + m * m + h * h)));
    switch (S) { case 0: return { a, l, m, h }; case 1: return { l, a, m, h }; case 2: return { l, m, a, h }; default: return { l, m, h, a }; }
}
inline float wFrom(float x, float y, float z) { float w2 = 1.f - (x * x + y * y + z * z); return w2 > 0 ? sqrtf(w2) : 0.f; }
inline std::array<float, 4> fixed48NoW(const u8* p) { uint16_t d[3]; memcpy(d, p, 6); float x = (d[0] - 32767) / 32767.f, y = (d[1] - 32767) / 32767.f, z = (d[2] - 32767) / 32767.f; return { x, y, z, wFrom(x, y, z) }; }
inline std::array<float, 4> fixed32NoW(const u8* p) { u32 v; memcpy(&v, p, 4);
    float x = ((int)(v >> 21) - 1023) / 1023.f, y = ((int)((v >> 10) & 0x7FF) - 1023) / 1023.f, z = ((int)(v & 0x3FF) - 511) / 511.f; return { x, y, z, wFrom(x, y, z) }; }
inline std::array<float, 4> interval32NoW(const u8* p, const float* mins, const float* ranges) { u32 v; memcpy(&v, p, 4);
    float x = (((int)(v >> 21) - 1023) / 1023.f) * ranges[0] + mins[0], y = (((int)((v >> 10) & 0x7FF) - 1023) / 1023.f) * ranges[1] + mins[1], z = (((int)(v & 0x3FF) - 511) / 511.f) * ranges[2] + mins[2];
    return { x, y, z, wFrom(x, y, z) }; }
inline float f32(const u8* p) { float f; memcpy(&f, p, 4); return f; }
inline int rotSize(const std::string& f) {
    if (f == "ACF_None") return 16; if (f == "ACF_Float96NoW") return 12; if (f == "ACF_Fixed48NoW" || f == "ACF_Fixed48Max") return 6;
    if (f == "ACF_IntervalFixed32NoW" || f == "ACF_Fixed32NoW" || f == "ACF_Float32NoW") return 4; return -1;
}
}

// numTracks = TrackBoneNames.Num() of the owning AnimSet
inline AnimSeq parseAnimSequence(const Package& pk, i32 idx, int numTracks) {
    using namespace animdetail;
    AnimSeq s; s.idx = idx;
    try {
        ObjProps op = objProps(pk, idx); if (!op.ok) throw Err("cannot read properties");
        s.name = tagName(pk, op.tags, "SequenceName"); if (s.name.empty() || s.name == "None") s.name = pk.objName(idx);
        s.numFrames = tagInt(op.tags, "NumFrames", 0);
        if (const Tag* t = findTag(op.tags, "SequenceLength")) s.length = f32(t->raw.data());
        if (const Tag* t = findTag(op.tags, "RateScale")) s.rateScale = f32(t->raw.data());
        if (const Tag* t = findTag(op.tags, "bIsAdditive")) s.additive = t->boolVal != 0;
        s.keyFmt = tagName(pk, op.tags, "KeyEncodingFormat"); if (s.keyFmt.empty()) s.keyFmt = "AKF_ConstantKeyLerp";
        s.rotFmt = tagName(pk, op.tags, "RotationCompressionFormat"); if (s.rotFmt.empty()) s.rotFmt = "ACF_None";
        s.transFmt = tagName(pk, op.tags, "TranslationCompressionFormat"); if (s.transFmt.empty()) s.transFmt = "ACF_None";
        std::vector<i32> offs;
        if (const Tag* t = findTag(op.tags, "CompressedTrackOffsets")) { Reader r(t->raw.data(), t->raw.size()); i32 n = r.i(); for (i32 k = 0; k < n; k++) offs.push_back(r.i()); }
        if ((int)offs.size() != numTracks * 4) throw Err("CompressedTrackOffsets size " + std::to_string(offs.size()) + " != 4*" + std::to_string(numTracks));
        if (s.keyFmt != "AKF_ConstantKeyLerp" && s.keyFmt != "AKF_VariableKeyLerp") throw Err("unsupported key format " + s.keyFmt);
        if (s.transFmt != "ACF_None" && s.transFmt != "ACF_Float96NoW") throw Err("unsupported translation format " + s.transFmt);
        int rsz = rotSize(s.rotFmt); if (rsz < 0) throw Err("unsupported rotation format " + s.rotFmt);
        const u8* d = pk.dataPtr(pk.exports[idx - 1]); size_t dl = pk.dataLen(pk.exports[idx - 1]);
        Reader rr(d, dl, op.end); i32 nb = rr.i(); if (nb < 0 || rr.p + (size_t)nb > dl) throw Err("bad CompressedByteStream size");
        const u8* st = d + rr.p; size_t sl = (size_t)nb;
        bool variable = s.keyFmt == "AKF_VariableKeyLerp"; bool wide = s.numFrames > 0xFF;
        auto need = [&](size_t off, size_t n) { if (off + n > sl) throw Err("track data out of range"); };
        auto align4 = [](size_t v) { return (v + 3) & ~(size_t)3; };
        auto readFrames = [&](size_t off, int n, std::vector<int>& out) { if (!variable || n < 2) return; off = align4(off); need(off, (size_t)n * (wide ? 2 : 1));
            for (int k = 0; k < n; k++) out.push_back(wide ? (int)(st[off + k * 2] | (st[off + k * 2 + 1] << 8)) : (int)st[off + k]); };
        s.tracks.resize(numTracks);
        for (int t = 0; t < numTracks; t++) {
            AnimTrack& tr = s.tracks[t]; i32 tOff = offs[t * 4], tN = offs[t * 4 + 1], rOff = offs[t * 4 + 2], rN = offs[t * 4 + 3];
            if (tN > 0 && tOff >= 0) { need(tOff, (size_t)tN * 12); for (int k = 0; k < tN; k++) { const u8* p = st + tOff + k * 12; tr.pos.push_back({ f32(p), f32(p + 4), f32(p + 8) }); } readFrames(tOff + (size_t)tN * 12, tN, tr.posFrames); }
            if (rN == 1 && rOff >= 0) { need(rOff, 12); const u8* p = st + rOff; float x = f32(p), y = f32(p + 4), z = f32(p + 8); tr.rot.push_back({ x, y, z, wFrom(x, y, z) }); }
            else if (rN > 1 && rOff >= 0) {
                need(rOff, 24 + (size_t)rN * rsz); const u8* base = st + rOff; float mins[3] = { f32(base), f32(base + 4), f32(base + 8) }, ranges[3] = { f32(base + 12), f32(base + 16), f32(base + 20) };
                for (int k = 0; k < rN; k++) { const u8* p = base + 24 + (size_t)k * rsz; std::array<float, 4> q;
                    if (s.rotFmt == "ACF_Fixed48Max") q = fixed48Max(p); else if (s.rotFmt == "ACF_Fixed48NoW") q = fixed48NoW(p);
                    else if (s.rotFmt == "ACF_Float96NoW") q = { f32(p), f32(p + 4), f32(p + 8), wFrom(f32(p), f32(p + 4), f32(p + 8)) };
                    else if (s.rotFmt == "ACF_None") q = { f32(p), f32(p + 4), f32(p + 8), f32(p + 12) };
                    else if (s.rotFmt == "ACF_Fixed32NoW") q = fixed32NoW(p); else if (s.rotFmt == "ACF_IntervalFixed32NoW") q = interval32NoW(p, mins, ranges);
                    else throw Err("unsupported rotation format " + s.rotFmt);
                    tr.rot.push_back(q); }
                readFrames(rOff + 24 + (size_t)rN * rsz, rN, tr.rotFrames);
            }
            if (tr.pos.empty()) tr.pos.push_back({ 0, 0, 0 }); if (tr.rot.empty()) tr.rot.push_back({ 0, 0, 0, 1 });
        }
    } catch (std::exception& e) { s.err = e.what(); }
    return s;
}

// sample (no looping) at frame 'f' (0..numFrames-1), like the engine's TimeToIndex
namespace animdetail {
inline void keyIndex(int numKeys, const std::vector<int>& frames, int numFrames, float f, int& i0, int& i1, float& a) {
    i0 = i1 = 0; a = 0; if (numKeys < 2 || f <= 0) return;
    int last = numKeys - 1; int totalFrames = std::max(1, numFrames - 1);
    if (f >= totalFrames) { i0 = i1 = last; return; }
    if (!frames.empty()) {
        int lo = 0; for (int k = 0; k < numKeys; k++) { if (frames[k] <= f) lo = k; else break; }
        i0 = lo; i1 = std::min(lo + 1, last); int delta = std::max(frames[i1] - frames[i0], 1); a = (f - frames[i0]) / (float)delta; if (i0 == i1) a = 0;
    } else {
        float kp = f / totalFrames * last; i0 = std::min((int)kp, last); i1 = std::min(i0 + 1, last); a = kp - i0; if (i0 == i1) a = 0;
    }
}
}
inline void sampleTrack(const AnimTrack& tr, int numFrames, float f, float pos[3], float q[4]) {
    using namespace animdetail; int a0, a1; float al;
    keyIndex((int)tr.pos.size(), tr.posFrames, numFrames, f, a0, a1, al);
    for (int k = 0; k < 3; k++) pos[k] = tr.pos[a0][k] + (tr.pos[a1][k] - tr.pos[a0][k]) * al;
    keyIndex((int)tr.rot.size(), tr.rotFrames, numFrames, f, a0, a1, al);
    const auto& r0 = tr.rot[a0]; const auto& r1 = tr.rot[a1]; float dot = r0[0] * r1[0] + r0[1] * r1[1] + r0[2] * r1[2] + r0[3] * r1[3]; float bias = dot >= 0 ? 1.f : -1.f;
    float n = 0; for (int k = 0; k < 4; k++) { q[k] = r0[k] * (1 - al) + r1[k] * al * bias; n += q[k] * q[k]; }
    n = n > 0 ? 1.f / sqrtf(n) : 1.f; for (int k = 0; k < 4; k++) q[k] *= n;
}


// ------------------------------------------------------------------ CPU pose/skinning (row-vector convention: v' = v * M, same as the engine)
struct M4 { float m[4][4]; };
inline M4 m4Identity() { M4 r = {}; for (int i = 0; i < 4; i++) r.m[i][i] = 1; return r; }
inline M4 m4Mul(const M4& a, const M4& b) { M4 r; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) { r.m[i][j] = 0; for (int k = 0; k < 4; k++) r.m[i][j] += a.m[i][k] * b.m[k][j]; } return r; }
inline M4 m4QuatPos(const float q[4], const float p[3]) {   // FQuatRotationTranslationMatrix
    float x = q[0], y = q[1], z = q[2], w = q[3]; M4 r = m4Identity();
    r.m[0][0] = 1 - 2 * (y * y + z * z); r.m[0][1] = 2 * (x * y + w * z); r.m[0][2] = 2 * (x * z - w * y);
    r.m[1][0] = 2 * (x * y - w * z); r.m[1][1] = 1 - 2 * (x * x + z * z); r.m[1][2] = 2 * (y * z + w * x);
    r.m[2][0] = 2 * (x * z + w * y); r.m[2][1] = 2 * (y * z - w * x); r.m[2][2] = 1 - 2 * (x * x + y * y);
    r.m[3][0] = p[0]; r.m[3][1] = p[1]; r.m[3][2] = p[2]; return r;
}
inline M4 m4RigidInverse(const M4& a) { M4 r = m4Identity();
    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) r.m[i][j] = a.m[j][i];
    for (int j = 0; j < 3; j++) r.m[3][j] = -(a.m[3][0] * r.m[0][j] + a.m[3][1] * r.m[1][j] + a.m[3][2] * r.m[2][j]); return r; }
// world matrices of every bone; seq == nullptr -> reference pose. trackOf[b] = track of bone b or -1
inline void poseBones(const SkeletalMesh& sm, const AnimSeq* seq, const std::vector<int>& trackOf, float frame, std::vector<M4>& world, bool rotOnly = false) {
    world.resize(sm.bones.size());
    for (size_t b = 0; b < sm.bones.size(); b++) {
        const Bone& bn = sm.bones[b]; float q[4] = { bn.q[0], bn.q[1], bn.q[2], bn.q[3] }, p[3] = { bn.pos[0], bn.pos[1], bn.pos[2] };
        if (seq && b < trackOf.size() && trackOf[b] >= 0 && trackOf[b] < (int)seq->tracks.size()) {
            sampleTrack(seq->tracks[trackOf[b]], seq->numFrames, frame, p, q);
            // Asylum convention (measured on 400+ AnimSets): the track rotation of NON-root bones is conjugated relative to
            // the mesh RefSkeleton (the root is not). Without this the pose comes out twisted (~45 degrees per bone on average, 180 on fingers/feet).
            if (b > 0) { q[0] = -q[0]; q[1] = -q[1]; q[2] = -q[2]; }
            if (b > 0 && rotOnly) { p[0] = bn.pos[0]; p[1] = bn.pos[1]; p[2] = bn.pos[2]; }   // rotation only: bone lengths from the mesh itself (mesh of another character)
        }
        M4 local = m4QuatPos(q, p);
        world[b] = (b == 0 || bn.parent < 0 || bn.parent >= (int)b) ? local : m4Mul(local, world[bn.parent]);
    }
}
// global bone indices per vertex (the vertex ones are local to the chunk)
inline std::vector<std::array<uint16_t, 4>> globalVertexBones(const SkelLOD& lod) {
    std::vector<std::array<uint16_t, 4>> out(lod.verts.size());
    for (size_t v = 0; v < lod.verts.size(); v++) { int c = chunkOfVertex(lod, (u32)v);
        for (int j = 0; j < 4; j++) { int b = lod.verts[v].bones[j]; if (c >= 0 && b < (int)lod.chunks[c].boneMap.size()) b = lod.chunks[c].boneMap[b]; out[v][j] = (uint16_t)b; } }
    return out;
}
inline void skinVertices(const SkelLOD& lod, const std::vector<std::array<uint16_t, 4>>& gb, const std::vector<M4>& skin, std::vector<float>& pos, std::vector<float>& nrm) {
    size_t n = lod.verts.size(); pos.assign(n * 3, 0); nrm.assign(n * 3, 0);
    for (size_t v = 0; v < n; v++) { const SkelVertex& sv = lod.verts[v]; float tw = 0;
        for (int j = 0; j < 4; j++) { if (!sv.weights[j]) continue; int b = gb[v][j]; if (b >= (int)skin.size()) continue; float w = sv.weights[j] / 255.f; tw += w; const M4& m = skin[b];
            for (int k = 0; k < 3; k++) { pos[v * 3 + k] += w * (sv.pos[0] * m.m[0][k] + sv.pos[1] * m.m[1][k] + sv.pos[2] * m.m[2][k] + m.m[3][k]);
                nrm[v * 3 + k] += w * (sv.normal[0] * m.m[0][k] + sv.normal[1] * m.m[1][k] + sv.normal[2] * m.m[2][k]); } }
        if (tw <= 0) for (int k = 0; k < 3; k++) { pos[v * 3 + k] = sv.pos[k]; nrm[v * 3 + k] = sv.normal[k]; } }
}
// track of each mesh bone by name; returns how many bones were matched
inline int mapTracks(const SkeletalMesh& sm, const AnimSetData& set, std::vector<int>& trackOf) {
    trackOf.assign(sm.bones.size(), -1); int hits = 0;
    for (size_t b = 0; b < sm.bones.size(); b++) for (size_t t = 0; t < set.bones.size(); t++) if (_bmieq(sm.bones[b].name, set.bones[t])) { trackOf[b] = (int)t; hits++; break; }
    return hits;
}

} // namespace bm
