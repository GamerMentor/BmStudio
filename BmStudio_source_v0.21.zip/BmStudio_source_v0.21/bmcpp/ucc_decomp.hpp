// ucc_decomp.hpp - FAITHFUL decompiler: BAA bytecode -> UnrealScript that our compiler (ucc_compile.hpp)
// turns back into the SAME bytecode. if/else/while/do/switch/foreach structure from the UCC patterns;
// whatever does not fit becomes "goto"/labels (an extension the compiler accepts) so no information is ever lost.
#pragma once
#include "ucc_compile.hpp"
#include <cinttypes>

namespace bm {
namespace ucc {

struct DecompResult { std::string body; std::vector<std::string> defaults; std::string err; int fallbacks = 0; };

class Decomp {
public:
    TypeDB& db; Compiler& C; Ref fn, cls, state; bool stateCode = false; int pi = 0;
    const Package* P = nullptr; Script S; u32 scriptEnd = 0;
    std::map<u32, std::string> stateLabels;   // position -> name (state code)
    std::set<u32> jumpLabels;                 // positions that need a label (fallback goto)
    int fallbacks = 0; bool implicitCasts = false; long opTotal = 0, opFallback = 0;

    Decomp(TypeDB& d, Compiler& c) : db(d), C(c) {}

    // ---------------------------------------------------------- token types
    Ref R(i32 idx) { return db.resolve(pi, idx); }
    Type tyK(K k) { Type t; t.k = k; return t; }
    Type castTarget(u8 c) {
        switch (c) {
            case CST_ByteToInt: case CST_BoolToInt: case CST_FloatToInt: case CST_StringToInt: return tyK(K::Int);
            case CST_IntToByte: case CST_BoolToByte: case CST_FloatToByte: case CST_StringToByte: return tyK(K::Byte);
            case CST_ByteToFloat: case CST_IntToFloat: case CST_BoolToFloat: case CST_StringToFloat: return tyK(K::Float);
            case CST_ByteToBool: case CST_IntToBool: case CST_FloatToBool: case CST_ObjectToBool: case CST_NameToBool: case CST_StringToBool: case CST_VectorToBool: case CST_RotatorToBool: case CST_InterfaceToBool: return tyK(K::Bool);
            case CST_ByteToString: case CST_IntToString: case CST_BoolToString: case CST_FloatToString: case CST_ObjectToString: case CST_NameToString: case CST_VectorToString: case CST_RotatorToString: case CST_DelegateToString: case CST_InterfaceToString: return tyK(K::String);
            case CST_StringToName: return tyK(K::Name);
            case CST_RotatorToVector: case CST_StringToVector: return C.tyStruct("Vector");
            case CST_VectorToRotator: case CST_StringToRotator: return C.tyStruct("Rotator");
            case CST_InterfaceToObject: return C.tyObj(C.objectClass());
            default: return Type();
        }
    }
    const char* castName(u8 c) {
        Type t = castTarget(c);
        switch (t.k) { case K::Int: return "int"; case K::Byte: return "byte"; case K::Float: return "float"; case K::Bool: return "bool"; case K::String: return "string"; case K::Name: return "name"; case K::Struct: return C.isVector(t) ? "vector" : "rotator"; default: return nullptr; }
    }
    Ref nativeFn(int n) { auto it = C.natives.find(n); return it == C.natives.end() ? Ref{} : it->second; }
    // function called by a call token; 'scopeCls' = context class (or the current one)
    Ref calledFn(const Tok& t, Ref scopeCls, Ref scopeState) {
        if (t.native >= 0) return nativeFn(t.native);
        if (t.op == EX_FinalFunction) return R(t.ref);
        if (t.op == EX_VirtualFunction || t.op == EX_GlobalFunction) return C.findFunction(scopeCls, scopeState, P->nm(t.name));
        if (t.op == EX_DelegateFunction) { Ref p = R(t.ref); return p ? db.propType(p).func : Ref{}; }
        return Ref{};
    }
    Type typeOf(int id, Ref scopeCls = Ref{}, Ref scopeState = Ref{}, bool hasScope = false) {
        const Tok& t = S.toks[id];
        if (!hasScope) { scopeCls = cls; scopeState = state; }
        if (t.native >= 0) { Ref f = nativeFn(t.native); return f ? C.returnType(f) : Type(); }
        switch (t.op) {
            case EX_LocalVariable: case EX_InstanceVariable: case EX_DefaultVariable: case EX_LocalOutVariable: case EX_NativeParm: { Ref p = R(t.ref); if (!p) return Type(); Sem vs = C.varSem(p, VK::Instance, hasScope ? scopeCls : cls); return vs.ty; }
            case EX_BoolVariable: return tyK(K::Bool);
            case EX_Context: case EX_RSSContext: case EX_ClassContext: {
                Type l = typeOf(t.kids[0]); Ref c = l.k == K::Object || l.k == K::Interface || l.k == K::Class ? C.classOfObjType(l) : C.objectClass();
                if (t.op != EX_ClassContext && l.k == K::Class) c = db.findClass("Class");
                return typeOf(t.kids[1], c, Ref{}, true);
            }
            case EX_InterfaceContext: return typeOf(t.kids[0]);
            case EX_StructMember: { Ref p = R(t.ref); return p ? db.propType(p) : Type(); }
            case EX_ArrayElement: return typeOf(t.kids[1]);
            case EX_DynArrayElement: { Type a = typeOf(t.kids[1]); return a.inner ? *a.inner : Type(); }
            case EX_DynArrayLength: case EX_DynArrayFind: case EX_DynArrayFindStruct: return tyK(K::Int);
            case EX_VirtualFunction: case EX_FinalFunction: case EX_GlobalFunction: case EX_DelegateFunction: { Ref f = calledFn(t, scopeCls, scopeState); return f ? C.returnType(f) : Type(); }
            case EX_PrimitiveCast: return castTarget(t.b);
            case EX_DynamicCast: return C.tyObj(R(t.ref));
            case EX_InterfaceCast: { Type x; x.k = K::Interface; x.cls = R(t.ref); return x; }
            case EX_MetaCast: { Type x; x.k = K::Class; x.cls = R(t.ref); return x; }
            case EX_IntConst: case EX_IntZero: case EX_IntOne: case EX_IntConstByte: return tyK(K::Int);
            case EX_ByteConst: return tyK(K::Byte);
            case EX_FloatConst: return tyK(K::Float);
            case EX_StringConst: case EX_UnicodeStringConst: return tyK(K::String);
            case EX_NameConst: return tyK(K::Name);
            case EX_True: case EX_False: case EX_StructCmpEq: case EX_StructCmpNe: case EX_EqualEqual_DelDel: case EX_NotEqual_DelDel: case EX_EqualEqual_DelFunc: case EX_NotEqual_DelFunc: return tyK(K::Bool);
            case EX_VectorConst: return C.tyStruct("Vector");
            case EX_RotationConst: return C.tyStruct("Rotator");
            case EX_ObjectConst: { Ref o = R(t.ref); if (!o) return C.tyObj(Ref{}); if (db.cls(o) == "Class") { Type x; x.k = K::Class; x.cls = o; return x; } return C.tyObj(db.findClass(db.cls(o))); }
            case EX_NoObject: return C.tyObj(Ref{});
            case EX_Self: return C.tyObj(cls);
            case EX_New: { Type c = typeOf(t.kids[3]); return C.tyObj(c.k == K::Class ? C.classOfObjType(c) : C.objectClass()); }
            case EX_Conditional: return typeOf(t.kids[1]);
            case EX_Skip: return typeOf(t.kids[0]);
            case EX_EmptyDelegate: case EX_DelegateProperty: case EX_InstanceDelegate: return tyK(K::Delegate);
            default: return Type();
        }
    }
    bool isNoneTok(int id) { return S.toks[id].op == EX_NoObject; }
    bool isLvalueTok(int id) {
        const Tok& t = S.toks[id];
        switch (t.op) { case EX_LocalVariable: case EX_InstanceVariable: case EX_DefaultVariable: case EX_LocalOutVariable: case EX_BoolVariable: case EX_Context: case EX_RSSContext: case EX_StructMember: case EX_ArrayElement: case EX_DynArrayElement: case EX_DynArrayLength: case EX_ClassContext: return true; default: return false; }
    }

    // ---------------------------------------------------------- literals
    static std::string fstr(float f) {
        if (std::isinf(f) || std::isnan(f)) { char b[64]; snprintf(b, sizeof b, "%.9g", f); return b; }
        float af = std::fabs(f);
        if (af == 0.0f || (af >= 1e-4f && af < 1e9f)) {   // fixed notation with the fewest digits that round-trip to the same float
            for (int prec = 1; prec <= 12; prec++) { char b[64]; snprintf(b, sizeof b, "%.*f", prec, f); if (strtof(b, nullptr) == f && std::signbit(strtof(b, nullptr)) == std::signbit(f)) return b; }
        }
        for (int prec = 1; prec <= 9; prec++) {
            char b[64]; snprintf(b, sizeof b, "%.*g", prec, f); float back = strtof(b, nullptr);
            if (back == f && std::signbit(back) == std::signbit(f)) {
                std::string s = b; if (s.find('.') == std::string::npos && s.find('e') == std::string::npos) s += ".0";
                else if (s.find('e') != std::string::npos && s.find('.') == std::string::npos) { size_t e = s.find('e'); s = s.substr(0, e) + ".0" + s.substr(e); }
                return s;
            }
        }
        char b[64]; snprintf(b, sizeof b, "%.9g", f); return b;
    }
    static std::string strLit(const std::string& s) { std::string o = "\""; for (char c : s) { if (c == '"' || c == '\\') o += '\\'; if (c == '\n') { o += "\\n"; continue; } o += c; } return o + "\""; }
    std::string objPath(const Ref& r) { std::string p = db.path(r); return p; }

    // ---------------------------------------------------------- readability (does not change the bytecode)
    static std::string strip(const std::string& s) {   // removes a pair of parentheses that wraps everything
        if (s.size() < 2 || s[0] != '(' || s.back() != ')') return s;
        int d = 0; bool inStr = false, inName = false;
        for (size_t i = 0; i < s.size(); i++) { char c = s[i];
            if (inStr) { if (c == '\\') { i++; continue; } if (c == '"') inStr = false; continue; }
            if (inName) { if (c == '\'') inName = false; continue; }
            if (c == '"') { inStr = true; continue; } if (c == '\'') { inName = true; continue; }
            if (c == '(') d++; else if (c == ')') { d--; if (d == 0 && i + 1 < s.size()) return s; } }
        return s.substr(1, s.size() - 2);
    }
    // ByteConst with a known enum type -> value name (only if the name resolves back to the same index)
    std::string enumOr(int id, const Type& want) {
        const Tok& t = S.toks[id];
        if (t.op == EX_ByteConst && want.k == K::Byte && want.enm) {
            const FieldInfo& f = db.field(want.enm);
            if (t.b < f.enumNames.size()) { std::string n = db.P(want.enm).nm(f.enumNames[t.b]); auto it = C.enumIndex.find(lower(n)); auto ie = C.enumValues.find(lower(n));
                if (it != C.enumIndex.end() && it->second == (int)t.b && ie != C.enumValues.end() && !C.findFunction(cls, state, n) && !C.sc.findProp(cls, n)) return n; }
        }
        return e(id);
    }
    Ref callTarget = Ref{};   // called function (to type the arguments)
    // ---------------------------------------------------------- expressions
    std::string args(const Tok& t, size_t from = 0, Ref fnForTypes = Ref{}) {
        std::vector<std::string> v; size_t last = from;
        const std::vector<Compiler::Param>* ps = fnForTypes ? &C.params(fnForTypes) : nullptr; size_t pi2 = 0;
        for (size_t k = from; k < t.kids.size(); k++, pi2++) { const Tok& a = S.toks[t.kids[k]]; if (a.op == EX_EndFunctionParms) break;
            std::string txt = a.op == EX_EmptyParmValue ? std::string() : (ps && pi2 < ps->size() ? enumOr(t.kids[k], (*ps)[pi2].ty) : e(t.kids[k]));
            v.push_back(strip(txt)); if (a.op != EX_EmptyParmValue) last = v.size(); }
        v.resize(last); std::string s; for (size_t k = 0; k < v.size(); k++) { if (k) s += ", "; s += v[k]; } return s;
    }
    std::vector<int> argIds(const Tok& t) { std::vector<int> v; for (int k : t.kids) if (S.toks[k].op != EX_EndFunctionParms) v.push_back(k); return v; }
    std::string fnName(const Ref& f) { return db.name(f); }

    // would the compiler pick this operator for these operands?
    bool operatorRoundTrips(const Ref& op, const std::vector<int>& ops, bool pre) {
        const FieldInfo& f = db.field(op); std::string sym = P->nm(f.friendly); (void)sym;
        std::string key = isalpha((unsigned char)db.P(op).nm(f.friendly)[0]) ? lower(db.P(op).nm(f.friendly)) : db.P(op).nm(f.friendly);
        auto it = C.operators.find(key); if (it == C.operators.end()) return false;
        Ref best; int bestCost = Compiler::INF;
        for (Ref cand : it->second) {
            const FieldInfo& cf = db.field(cand); const auto& ps = C.params(cand);
            if (ps.size() != ops.size()) continue;
            if (ops.size() == 1 && (((cf.funcFlags & FUNC_PreOperator) != 0) != pre)) continue;
            Ref owner = C.ownerClass(cand); if (owner && !db.isChildOf(cls, owner)) continue;
            int cost = 0;
            for (size_t k = 0; k < ops.size() && cost < Compiler::INF; k++) {
                Sem s; s.ty = typeOf(ops[k]); s.none = isNoneTok(ops[k]); s.lvalue = isLvalueTok(ops[k]);
                const Tok& at = S.toks[ops[k]]; if (at.op == EX_Skip) { s.ty = typeOf(at.kids[0]); s.none = isNoneTok(at.kids[0]); s.lvalue = isLvalueTok(at.kids[0]); }
                int c = C.convCost(s.ty, s, ps[k].ty, ps[k].flags);
                if (c >= Compiler::INF || ((ps[k].flags & CPF_OutParm) && !s.lvalue)) { cost = Compiler::INF; break; }
                cost += c;
            }
            if (cost < bestCost) { bestCost = cost; best = cand; }
        }
        return best == op;
    }
    std::string callNative(const Tok& t) {
        Ref f = nativeFn(t.native); auto ids = argIds(t);
        if (!f) return "__NFUN_" + std::to_string(t.native) + "__(" + args(t) + ")";
        const FieldInfo& fi = db.field(f);
        if (fi.funcFlags & FUNC_Operator) {
            std::string op = db.P(f).nm(fi.friendly); bool pre = (fi.funcFlags & FUNC_PreOperator) != 0;
            bool ok = ids.size() == (size_t)C.params(f).size() && operatorRoundTrips(f, ids, pre); opTotal++; if (!ok) opFallback++;
            if (ok && ids.size() == 2) return "(" + e(ids[0]) + " " + op + " " + e(ids[1]) + ")";
            if (ok && ids.size() == 1) return pre ? op + "(" + e(ids[0]) + ")" : "(" + e(ids[0]) + ")" + op;
            return "__NFUN_" + std::to_string(t.native) + "__(" + args(t) + ")";
        }
        // regular native function: does the name resolve to it?
        Ref byName = C.findFunction(cls, state, fnName(f));
        if (byName == f) return fnName(f) + "(" + args(t, 0, f) + ")";
        return "__NFUN_" + std::to_string(t.native) + "__(" + args(t, 0, f) + ")";
    }
    std::string callFinal(const Tok& t, bool inContext) {
        Ref f = R(t.ref); if (!f) return "/*?*/";
        const FieldInfo& fi = db.field(f);
        if (fi.funcFlags & FUNC_Operator) {   // script operator (static final, not native)
            auto ids = argIds(t); std::string op = db.P(f).nm(fi.friendly); bool pre = (fi.funcFlags & FUNC_PreOperator) != 0;
            if (operatorRoundTrips(f, ids, pre)) { if (ids.size() == 2) return "(" + e(ids[0]) + " " + op + " " + e(ids[1]) + ")"; if (ids.size() == 1) return pre ? op + "(" + e(ids[0]) + ")" : "(" + e(ids[0]) + ")" + op; }
        }
        if (inContext) {
            if (fi.funcFlags & FUNC_Final) return fnName(f) + "(" + args(t, 0, f) + ")";
            return "super(" + db.name(C.ownerClass(f)) + ")." + fnName(f) + "(" + args(t, 0, f) + ")";   // non-virtual on another object
        }
        Ref byName = C.findFunction(cls, state, fnName(f));
        if (byName == f && (fi.funcFlags & FUNC_Final)) return fnName(f) + "(" + args(t, 0, f) + ")";
        // "super" call: the function of a superclass / super-state
        Ref owner = C.ownerClass(f);
        Ref superFirst = C.sc.findFunc(db.super_(C.ownerClass(fn)), fnName(f));
        if (state && !stateCode) { Ref ss = db.super_(state); for (int g = 0; ss && g < 32; g++) { Ref r = C.sc.find(ss, fnName(f), [](const std::string& c) { return c == "Function"; }, false); if (r) { superFirst = r; break; } ss = db.super_(ss); } }
        if (superFirst == f) return "super." + fnName(f) + "(" + args(t, 0, f) + ")";
        Ref fo = db.outer(f); if (db.cls(fo) == "State") return "super(" + db.name(fo) + ")." + fnName(f) + "(" + args(t, 0, f) + ")";
        return "super(" + db.name(owner) + ")." + fnName(f) + "(" + args(t, 0, f) + ")";
    }
    std::string e(int id) {
        const Tok& t = S.toks[id];
        if (t.native >= 0) return callNative(t);
        switch (t.op) {
            case EX_LocalVariable: case EX_InstanceVariable: case EX_LocalOutVariable: case EX_NativeParm: return P->objName(t.ref);
            case EX_DefaultVariable: return "default." + db.name(R(t.ref));
            case EX_BoolVariable: return e(t.kids[0]);
            case EX_Let: case EX_LetBool: case EX_LetDelegate: return e(t.kids[0]) + " = " + strip(enumOr(t.kids[1], typeOf(t.kids[0])));
            case EX_DynArrayElement: case EX_ArrayElement: return e(t.kids[1]) + "[" + e(t.kids[0]) + "]";
            case EX_New: {
                std::string s = "new";
                bool any = false; for (int k = 0; k < 3; k++) if (S.toks[t.kids[k]].op != EX_Nothing) any = true;
                if (any) { std::string a; int last = 0; for (int k = 0; k < 3; k++) if (S.toks[t.kids[k]].op != EX_Nothing) last = k + 1;
                    for (int k = 0; k < last; k++) { if (k) a += ", "; if (S.toks[t.kids[k]].op != EX_Nothing) a += e(t.kids[k]); } s += "(" + a + ")"; }
                s += " " + e(t.kids[3]);
                if (S.toks[t.kids[4]].op != EX_Nothing) s += "(" + e(t.kids[4]) + ")";
                return s;
            }
            case EX_ClassContext: {
                const Tok& r = S.toks[t.kids[1]];
                std::string l = e(t.kids[0]);
                if (r.op == EX_DefaultVariable || (r.op == EX_BoolVariable && S.toks[r.kids[0]].op == EX_DefaultVariable)) { const Tok& dv = r.op == EX_BoolVariable ? S.toks[r.kids[0]] : r; return l + ".default." + db.name(R(dv.ref)); }
                Type lt = typeOf(t.kids[0]); Ref c = C.classOfObjType(lt);
                return l + ".static." + ctxRight(t.kids[1], c);
            }
            case EX_MetaCast: return "class<" + db.name(R(t.ref)) + ">(" + e(t.kids[0]) + ")";
            case EX_Self: return "self";
            case EX_Skip: return e(t.kids[0]);
            case EX_Context: case EX_RSSContext: {
                Type lt = typeOf(t.kids[0]); Ref c = (lt.k == K::Class) ? db.findClass("Class") : C.classOfObjType(lt);
                return e(t.kids[0]) + (t.op == EX_RSSContext ? "~>" : ".") + ctxRight(t.kids[1], c);
            }
            case EX_InterfaceContext: return e(t.kids[0]);
            case EX_VirtualFunction: return P->nm(t.name) + "(" + args(t, 0, C.findFunction(cls, state, P->nm(t.name))) + ")";
            case EX_GlobalFunction: return "global." + P->nm(t.name) + "(" + args(t) + ")";
            case EX_FinalFunction: return callFinal(t, false);
            case EX_DelegateFunction: return db.name(R(t.ref)) + "(" + args(t) + ")";
            case EX_IntConst: return std::to_string(t.iv);
            case EX_FloatConst: return fstr(t.fv[0]);
            case EX_StringConst: case EX_UnicodeStringConst: return strLit(t.str);
            case EX_ObjectConst: { Ref o = R(t.ref); if (!o) return "None"; return db.cls(o) + "'" + objPath(o) + "'"; }
            case EX_NameConst: return "'" + P->nm(t.name) + "'";
            case EX_RotationConst: return "rot(" + std::to_string(t.rv[0]) + ", " + std::to_string(t.rv[1]) + ", " + std::to_string(t.rv[2]) + ")";
            case EX_VectorConst: return "vect(" + fstr(t.fv[0]) + ", " + fstr(t.fv[1]) + ", " + fstr(t.fv[2]) + ")";
            case EX_ByteConst: return "byte(" + std::to_string(t.b) + ")";
            case EX_IntConstByte: return std::to_string(t.b);
            case EX_IntZero: return "0"; case EX_IntOne: return "1"; case EX_True: return "true"; case EX_False: return "false";
            case EX_NoObject: case EX_EmptyDelegate: return "None";
            case EX_DynamicCast: case EX_InterfaceCast: return P->objName(t.ref) + "(" + e(t.kids[0]) + ")";
            case EX_StructCmpEq: return "(" + e(t.kids[0]) + " == " + e(t.kids[1]) + ")";
            case EX_StructCmpNe: return "(" + e(t.kids[0]) + " != " + e(t.kids[1]) + ")";
            case EX_StructMember: return e(t.kids[0]) + "." + db.name(R(t.ref));
            case EX_DynArrayLength: return e(t.kids[0]) + ".Length";
            case EX_PrimitiveCast: {
                if (t.b == CST_InterfaceToObject || t.b == CST_ObjectToInterface) return e(t.kids[0]);   // implicit
                if (implicitCasts) {
                    const Tok& kk = S.toks[t.kids[0]];
                    bool lit = kk.op == EX_IntConst || kk.op == EX_IntZero || kk.op == EX_IntOne || kk.op == EX_IntConstByte || kk.op == EX_FloatConst || kk.op == EX_ByteConst;
                    bool au = t.b == CST_ByteToInt || t.b == CST_IntToFloat || t.b == CST_ByteToFloat || t.b == CST_IntToByte || t.b == CST_FloatToInt || t.b == CST_FloatToByte;
                    if (au && !lit) return e(t.kids[0]);
                }
                const char* n = castName(t.b); const Tok& k = S.toks[t.kids[0]];
                // cast of a numeric literal: the compiler would fold the constant -> wrap it to keep the cast
                bool numLit = k.op == EX_IntConst || k.op == EX_IntZero || k.op == EX_IntOne || k.op == EX_IntConstByte || k.op == EX_FloatConst;
                if (numLit) return std::string(n ? n : "cast") + "(" + (k.op == EX_FloatConst ? "float(" : "int(") + e(t.kids[0]) + "))";
                return std::string(n ? n : "cast") + "(" + e(t.kids[0]) + ")"; }
            case EX_DynArrayInsert: return e(t.kids[0]) + ".Insert(" + e(t.kids[1]) + ", " + e(t.kids[2]) + ")";
            case EX_DynArrayRemove: return e(t.kids[0]) + ".Remove(" + e(t.kids[1]) + ", " + e(t.kids[2]) + ")";
            case EX_DynArrayAdd: return e(t.kids[0]) + ".Add(" + e(t.kids[1]) + ")";
            case EX_DynArrayAddItem: return e(t.kids[0]) + ".AddItem(" + e(t.kids[1]) + ")";
            case EX_DynArrayRemoveItem: return e(t.kids[0]) + ".RemoveItem(" + e(t.kids[1]) + ")";
            case EX_DynArrayInsertItem: return e(t.kids[0]) + ".InsertItem(" + e(t.kids[1]) + ", " + e(t.kids[2]) + ")";
            case EX_DynArrayFind: return e(t.kids[0]) + ".Find(" + e(t.kids[1]) + ")";
            case EX_DynArrayFindStruct: return e(t.kids[0]) + ".Find(" + e(t.kids[1]) + ", " + e(t.kids[2]) + ")";
            case EX_Conditional: return "(" + e(t.kids[0]) + " ? " + e(t.kids[1]) + " : " + e(t.kids[2]) + ")";
            case EX_EqualEqual_DelDel: case EX_EqualEqual_DelFunc: { auto ids = argIds(t); return "(" + e(ids[0]) + " == " + e(ids[1]) + ")"; }
            case EX_NotEqual_DelDel: case EX_NotEqual_DelFunc: { auto ids = argIds(t); return "(" + e(ids[0]) + " != " + e(ids[1]) + ")"; }
            case EX_DelegateProperty: case EX_InstanceDelegate: return P->nm(t.name);
            case EX_EmptyParmValue: case EX_Nothing: return "";
        }
        char b[48]; snprintf(b, sizeof b, "/*op %02X*/", t.op); fallbacks++; return b;
    }
    // literal on the right side of a context = const/enum accessed through the object (obj.TRACEFLAG_Blocking)
    std::string ctxConstName(const Tok& t, Ref c) {
        bool isByte = t.op == EX_ByteConst; long v = 0;
        switch (t.op) { case EX_IntZero: v = 0; break; case EX_IntOne: v = 1; break; case EX_IntConstByte: case EX_ByteConst: v = t.b; break; case EX_IntConst: v = t.iv; break; default: return ""; }
        for (Ref x = c; x; x = db.super_(x)) {
            for (Ref ch : db.childrenOf(x)) {
                std::string k = db.cls(ch);
                if (!isByte && k == "Const") { const FieldInfo& f = db.field(ch); char* end; long cv = strtol(f.constValue.c_str(), &end, 0); if (!*end && !f.constValue.empty() && cv == v) return db.name(ch); }
                if (isByte && k == "Enum") { const FieldInfo& f = db.field(ch); if (v >= 0 && (size_t)v < f.enumNames.size()) return db.P(ch).nm(f.enumNames[v]); }
            }
        }
        return "";
    }
    // right side of a context (member of another class)
    std::string ctxRight(int id, Ref c) {
        const Tok& t = S.toks[id];
        { std::string cn = ctxConstName(t, c); if (!cn.empty()) return cn; }
        if (t.op == EX_BoolVariable) return ctxRight(t.kids[0], c);
        if (t.op == EX_InstanceVariable) return P->objName(t.ref);
        if (t.op == EX_FinalFunction) return callFinal(t, true);
        if (t.op == EX_VirtualFunction) return P->nm(t.name) + "(" + args(t, 0, C.sc.findFunc(c, P->nm(t.name))) + ")";
        if (t.native >= 0) { Ref f = nativeFn(t.native); return f ? fnName(f) + "(" + args(t) + ")" : "__NFUN_" + std::to_string(t.native) + "__(" + args(t) + ")"; }
        if (t.op == EX_DelegateFunction) return db.name(R(t.ref)) + "(" + args(t) + ")";
        return e(id);
    }

    // ---------------------------------------------------------- statements
    struct Ctx { long brk = -1, cont = -1; bool inIter = false; };
    std::vector<int> st;   // token indices of the top-level statements
    u32 posOf(size_t i) { return i < st.size() ? S.toks[st[i]].pos : scriptEnd; }
    long idxAt(u32 pos, size_t from, size_t to) { for (size_t k = from; k <= to && k <= st.size(); k++) if (posOf(k) == pos) return (long)k; return -1; }
    std::string out; int ind = 1;
    void line(const std::string& s) { out.append((size_t)ind * 4, ' '); out += s; out += "\n"; }
    std::string lbl(u32 p) { char b[16]; snprintf(b, sizeof b, "J0x%04X", p); return b; }
    void needLabel(u32 p) { jumpLabels.insert(p); }

    void range(size_t a, size_t bnd, Ctx ctx) {
        for (size_t i = a; i < bnd; i++) {
            u32 pos = posOf(i);
            { auto it = stateLabels.find(pos); if (it != stateLabels.end()) { ind--; line(it->second + ":"); ind++; } }
            if (jumpLabels.count(pos)) { ind--; line(lbl(pos) + ":"); ind++; }
            const Tok& t = S.toks[st[i]];
            // do { } until(): a JumpIfNot further ahead jumps back here
            {
                long k = -1; for (size_t j = i; j < bnd; j++) { const Tok& x = S.toks[st[j]]; if (x.op == EX_JumpIfNot && x.w == pos && j >= i) k = (long)j; }
                if (k >= 0 && !(t.op == EX_JumpIfNot && (long)i == k && false)) {
                    if (!doDone.count(pos)) {
                        doDone.insert(pos);
                        line("do"); line("{"); ind++; Ctx c2 = ctx; c2.brk = posOf((size_t)k + 1); c2.cont = S.toks[st[k]].pos; c2.inIter = false;
                        range(i, (size_t)k, c2); ind--; line("}"); line("until (" + strip(e(S.toks[st[k]].kids[0])) + ");");
                        i = (size_t)k; continue;
                    }
                }
            }
            switch (t.op) {
                case EX_JumpIfNot: {
                    u32 target = t.w;
                    if (target > pos) {
                        long j = idxAt(target, i + 1, bnd);
                        if (j >= 0) {
                            const Tok* lt = (j - 1 > (long)i) ? &S.toks[st[j - 1]] : nullptr;
                            std::string cond = e(t.kids[0]);
                            if (lt && lt->op == EX_Jump && lt->w == pos) {   // while
                                line("while (" + strip(cond) + ")"); line("{"); ind++; Ctx c2; c2.brk = target; c2.cont = pos; range(i + 1, (size_t)j - 1, c2); ind--; line("}");
                                i = (size_t)j - 1; continue;
                            }
                            if (lt && lt->op == EX_Jump && lt->w >= target && (long)lt->w != ctx.brk && (long)lt->w != ctx.cont && contained(i + 1, (size_t)j - 1, lt->pos, ctx)) {
                                long k = idxAt(lt->w, (size_t)j, bnd);
                                if (k >= 0) {
                                    line("if (" + strip(cond) + ")"); line("{"); ind++; range(i + 1, (size_t)j - 1, ctx); ind--; line("}");
                                    line("else"); line("{"); ind++; range((size_t)j, (size_t)k, ctx); ind--; line("}");
                                    i = (size_t)k - 1; continue;
                                }
                            }
                            line("if (" + strip(cond) + ")"); line("{"); ind++; range(i + 1, (size_t)j, ctx); ind--; line("}");
                            i = (size_t)j - 1; continue;
                        }
                    }
                    fallbacks++; needLabel(target); line("__jumpifnot(" + e(t.kids[0]) + ", " + lbl(target) + ");"); continue;
                }
                case EX_Jump: {
                    if ((long)t.w == ctx.brk) { line("break;"); continue; }
                    if ((long)t.w == ctx.cont) { line("continue;"); continue; }
                    fallbacks++; needLabel(t.w); line("goto " + lbl(t.w) + ";"); continue;
                }
                case EX_IteratorNext: {
                    line("__iteratornext;"); continue;   // (rare: explicit IteratorNext followed by break)
                }
                case EX_IteratorPop: {
                    // break inside foreach = IteratorPop + Jump(end); return inside = IteratorPop + Return
                    if (i + 1 < bnd) { const Tok& n = S.toks[st[i + 1]]; if (n.op == EX_Jump && (long)n.w == ctx.brk) { line("break;"); i++; continue; } if (n.op == EX_Return) { continue; } if (n.op == EX_IteratorPop) continue; }
                    fallbacks++; line("__iteratorpop;"); continue;
                }
                case EX_Iterator: case EX_DynArrayIterator: {
                    u32 popAt = t.w; long jn = idxAt(popAt - 1, i + 1, bnd), jp = idxAt(popAt, i + 1, bnd);
                    if (jn < 0 || jp < 0 || S.toks[st[jn]].op != EX_IteratorNext || S.toks[st[jp]].op != EX_IteratorPop) { fallbacks++; line("/* foreach? */"); continue; }
                    std::string head;
                    if (t.op == EX_Iterator) head = "foreach " + e(t.kids[0]);
                    else head = "foreach " + e(t.kids[0]) + "(" + e(t.kids[1]) + (t.b ? ", " + e(t.kids[2]) : std::string()) + ")";
                    line(head); line("{"); ind++; Ctx c2; c2.brk = popAt; c2.cont = popAt - 1; c2.inIter = true; range(i + 1, (size_t)jn, c2); ind--; line("}");
                    i = (size_t)jp; continue;
                }
                case EX_Switch: {
                    // follows the "case" chain (each one points to the next); default = last label
                    u32 end = posOf(bnd); size_t cur = i + 1; long defIdx = -1; std::set<size_t> chain;
                    if (cur < bnd && S.toks[st[cur]].op == EX_Case) {
                        for (int g = 0; g < 100000; g++) {
                            const Tok& c = S.toks[st[cur]]; chain.insert(cur);
                            if (c.w == 0xFFFF) { defIdx = (long)cur; break; }
                            long j = idxAt(c.w, cur + 1, bnd);
                            if (j < 0 || j >= (long)bnd || S.toks[st[j]].op != EX_Case) { end = c.w; break; }
                            cur = (size_t)j;
                        }
                        if (defIdx >= 0) {   // end = target of the "break"s (forward jumps after the default)
                            u32 dpos = S.toks[st[defIdx]].pos, mx = 0;
                            for (size_t q = i + 1; q < bnd; q++) { const Tok& x = S.toks[st[q]]; if (x.op == EX_Jump && x.w > dpos && x.w <= posOf(bnd)) mx = std::max<u32>(mx, x.w); }
                            end = mx ? mx : posOf(bnd);
                        }
                    }
                    long ke = idxAt(end, i + 1, bnd); if (ke < 0) ke = (long)bnd;
                    Type swT = typeOf(t.kids[0]); line("switch (" + strip(e(t.kids[0])) + ")"); line("{");
                    Ctx c2 = ctx; c2.brk = end;
                    size_t segStart = i + 1;
                    for (size_t q = i + 1; q <= (size_t)ke; q++) {
                        bool isCase = q < (size_t)ke && chain.count(q);
                        if (isCase || q == (size_t)ke) {
                            if (q > segStart) { ind++; range(segStart, q, c2); ind--; }
                            if (isCase) { const Tok& x = S.toks[st[q]]; if (x.w == 0xFFFF) line("default:"); else line("case " + strip(enumOr(x.kids[0], swT)) + ":"); }
                            segStart = q + 1;
                        }
                    }
                    line("}");
                    i = (size_t)ke - 1; continue;
                }
                case EX_Return: {
                    if (i > a && S.toks[st[i - 1]].op == EX_IteratorPop) {}
                    const Tok& k0 = S.toks[t.kids[0]];
                    if (k0.op == EX_Nothing || k0.op == EX_ReturnNothing) line("return;"); else line("return " + strip(stateCode ? e(t.kids[0]) : enumOr(t.kids[0], C.returnType(fn))) + ";");
                    continue;
                }
                case EX_EatReturnValue: continue;
                case EX_Nothing: line("__nothing;"); continue;
                case EX_Stop: line("stop;"); continue;
                case EX_GotoLabel: line("goto " + e(t.kids[0]) + ";"); continue;
                case EX_Assert: line("assert(" + e(t.kids[0]) + ", " + std::to_string(t.w) + ");"); continue;
                case EX_LabelTable: case EX_EndOfScript: continue;
                case EX_Case: fallbacks++; line("/* case? */"); continue;
                default: {
                    std::string s = strip(e(st[i])); line(s + ";"); continue;
                }
            }
        }
    }
    std::set<u32> doDone;
    // does no jump (other than break/continue) inside [a,b) go beyond 'limit'? (otherwise the final Jump belongs to an inner if)
    bool contained(size_t a, size_t b, u32 limit, const Ctx& ctx) {
        std::function<bool(int)> ok = [&](int id) -> bool {
            const Tok& t = S.toks[id];
            if ((t.op == EX_Jump || t.op == EX_JumpIfNot) && t.w > limit && (long)t.w != ctx.brk && (long)t.w != ctx.cont) return false;
            return true;
        };
        for (size_t k = a; k < b; k++) if (!ok(st[k])) return false;
        return true;
    }

    DecompResult run(Ref f) {
        DecompResult R0; fn = f; stateLabels.clear(); jumpLabels.clear(); doDone.clear(); pi = f.pkg; P = &db.P(f); std::string c = db.cls(f);
        stateCode = c == "State"; Ref o = db.outer(f);
        if (stateCode) { state = f; cls = o; } else if (db.cls(o) == "State") { state = o; cls = db.outer(o); } else { state = Ref{}; cls = o; }
        // the compiler needs the same scope for the lookups
        C.func = f; C.pi = pi; C.cls = cls; C.state = state; C.stateCode = stateCode;
        const FieldInfo& fi = db.field(f);
        S = tokenize(*P, P->dataPtr(P->exports[f.idx - 1]) + fi.scriptOff, (u32)fi.scriptSize);
        if (!S.err.empty()) { R0.err = S.err; return R0; }
        scriptEnd = (u32)fi.scriptSize;
        st.clear(); for (int id : S.stmts) st.push_back(id);
        // default values (DefaultParmValue at the start)
        size_t first = 0;
        { size_t nopt = 0; if (!stateCode) for (auto& p : C.params(f)) if (p.flags & CPF_OptionalParm) nopt++;
          while (first < st.size() && R0.defaults.size() < nopt && (S.toks[st[first]].op == EX_DefaultParmValue || S.toks[st[first]].op == EX_Nothing)) {
              const Tok& d = S.toks[st[first]]; size_t di = R0.defaults.size(); Type pt; { size_t n = 0; for (auto& p : C.params(f)) if (p.flags & CPF_OptionalParm) { if (n == di) { pt = p.ty; break; } n++; } }
              R0.defaults.push_back(d.op == EX_Nothing ? std::string() : strip(enumOr(d.kids[0], pt))); first++; } }
        // removes the epilogue: [Return(Nothing|ReturnNothing)] EndOfScript
        size_t last = st.size();
        while (last > first && S.toks[st[last - 1]].op == EX_EndOfScript) last--;
        if (stateCode) {
            if (last > first && S.toks[st[last - 1]].op == EX_LabelTable) { for (auto& l : S.toks[st[last - 1]].labels) if (P->nm(l.first) != "None") stateLabels[(u32)l.second] = P->nm(l.first); last--; }
        } else if (last > first) {
            const Tok& r = S.toks[st[last - 1]];
            if (r.op == EX_Return && (S.toks[r.kids[0]].op == EX_Nothing || S.toks[r.kids[0]].op == EX_ReturnNothing)) last--;
        }
        scriptEnd = last < st.size() ? S.toks[st[last]].pos : scriptEnd;
        // pass 1 (finds fallback labels), pass 2 (final text)
        for (int pass = 0; pass < 2; pass++) {
            out.clear(); ind = 1; fallbacks = 0; doDone.clear();
            std::vector<int> keep(st.begin() + first, st.begin() + last); st = keep;
            Ctx ctx; range(0, st.size(), ctx);
            // restores the full list for the second pass
            st.clear(); for (int id : S.stmts) st.push_back(id);
            if (jumpLabels.empty()) break;
        }
        // label at the end (target = end of the body)
        if (jumpLabels.count(scriptEnd)) { out += lbl(scriptEnd) + ":\n"; }
        R0.body = out; R0.fallbacks = fallbacks;
        return R0;
    }
};

} // namespace ucc
} // namespace bm
