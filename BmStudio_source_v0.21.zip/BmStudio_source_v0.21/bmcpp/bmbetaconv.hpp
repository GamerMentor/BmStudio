// bmbetaconv.hpp - conversion of objects from the 2007 BETA (Xbox 360, big-endian, v512) to the PC game format (v576/lic21).
//
//   normalize(P)          : rewrites the properties of every object of a beta package as little-endian (the native
//                           data stays big-endian). After this, objProps/findTag/... from the rest of the code work.
//   readStaticMesh(P, x)  : beta StaticMesh (native v512) -> Mesh (all little-endian, PC vertex layout)
//   buildStaticMeshNative : Mesh -> native data of a PC StaticMesh (checked with smdump against the game packages)
//
// v512 (beta) vs v576 (PC) layout, per LOD:
//   beta: RawTris bulk | sections (9 ints) | pos (stride, n, bulk) | vb (ntc, item, n, full, bulk) | shadow (4, 0, empty bulk)
//         | NumVerts | indices | indices2 | edges (16 bytes, empty) | fEC (bytes, empty)
//   PC  : RawTris bulk | elements (9 ints + fragments) | pos (stride, 2n, bNeedsCPUAccess, bulk) | vb (ntc, stride, 2n, full, bulk)
//         | shadow extrusion (4, 2n, bulk: 0..0 1..1) | NumVerts | indices | wireframe | edges (4 x u16) | ShadowTriangleDoubleSided
//   On PC the positions and the vertex buffer are DUPLICATED (second half = copy, for the shadow volume).
//   Final PC: LODInfo(1) + ThumbnailAngle(3) + ThumbnailDistance + HighResSourceMeshName("") + CRC + ForceShadowVolumes;
//   the beta only goes up to ThumbnailDistance.
//   kDOP: 32-byte node (6 floats, bIsLeaf int, 2 x u16) and 4 x u16 triangle - same layout, just swap bytes per field.
#pragma once
#include "bmbeta.hpp"
#include "bmasset.hpp"
#include "bmteximp.hpp"
#include <map>
#include <unordered_map>
#include <algorithm>
#include <cmath>
#include <array>
#include <functional>
#include <random>
#include <set>

namespace bm { namespace betaconv {

using beta::BE;

// ------------------------------------------------------------------ properties -> little-endian
struct NormalizeReport { int converted = 0, skipped = 0, failed = 0; };
inline NormalizeReport normalize(Package& P) {
    NormalizeReport R;
    for (size_t k = 0; k < P.exports.size(); k++) {
        i32 x = (i32)k + 1; Export& e = P.exports[k];
        long ps = beta::findPropStartBE(P, x); if (ps < 0) { R.skipped++; continue; }
        const u8* d = P.dataPtr(e); size_t n = P.dataLen(e);
        try {
            size_t end = 0; auto tags = beta::readPropsBE(P, d, n, (size_t)ps, &end);
            std::vector<u8> nd(d, d + ps); beta::swap4(nd);                       // prefix: NetIndex / TemplateOwnerClass + TemplateName (4-byte fields)
            auto pb = beta::writeTagsLE(P, tags); nd.insert(nd.end(), pb.begin(), pb.end());
            nd.insert(nd.end(), d + end, d + n);                                  // native: stays big-endian
            e.data = std::move(nd); e.owned = true; R.converted++;
        } catch (...) { R.failed++; }
    }
    return R;
}

// ------------------------------------------------------------------ generic mesh (little-endian, PC vertex layout)
struct Section { i32 mat = 0; i32 col = 1, oldCol = 1, shadow = 1; u32 first = 0, ntris = 0, minV = 0, maxV = 0; };
struct Mesh {
    float bounds[7] = { 0 };                 // origin, extent, radius
    std::vector<u8> kdopNodes, kdopTris;     // 32 and 8 bytes per item, little-endian (empty = build it)
    std::vector<Section> secs;
    std::vector<float> pos;                  // 3 per vertex
    std::vector<u8> vtx; int ntc = 1, stride = 16; bool fullUV = false;   // packed tangents + UVs (half or float)
    std::vector<uint16_t> idx;
    i32 thumb[3] = { 0, 0, 0 }; float thumbDist = 0;
    i32 bodySetup = 0;                       // v0.19: beta RB_BodySetup (index in the beta package) -> collision shapes
    i32 bodyOut = 0;                         // ... and the converted one in the target
    i32 lightMapRes = 32, lightMapCoord = 1;
    std::string err;
    size_t numVerts() const { return pos.size() / 3; }
};

inline uint16_t rbe16(const u8* d) { return (uint16_t)(d[0] << 8 | d[1]); }
inline float rbef(const u8* d) { u32 u = beta::rbe(d); float f; memcpy(&f, &u, 4); return f; }

// beta StaticMesh. P = beta package ALREADY normalized (LE properties, BE native data).
inline Mesh readStaticMesh(const Package& P, i32 x) {
    Mesh M;
    try {
        ObjProps op = objProps(P, x); if (!op.ok) throw Err("unreadable properties");
        if (const Tag* t = findTag(op.tags, "LightMapResolution")) memcpy(&M.lightMapRes, t->raw.data(), 4);
        if (const Tag* t = findTag(op.tags, "LightMapCoordinateIndex")) memcpy(&M.lightMapCoord, t->raw.data(), 4);
        const Export& e = P.exports[x - 1]; const u8* d = P.dataPtr(e); size_t n = P.dataLen(e);
        BE r(d, n, op.end);
        for (int k = 0; k < 7; k++) { r.need(4); M.bounds[k] = rbef(d + r.p); r.p += 4; }
        M.bodySetup = r.i();                                                     // BodySetup (v0.19: converted -> collision for Batman/enemies)
        { i32 es = r.i(), c = r.i(); if (es != 32 || c < 0) throw Err("kDOP: nodes with unexpected size"); r.need((size_t)es * c);
          M.kdopNodes.assign(d + r.p, d + r.p + (size_t)es * c); r.p += (size_t)es * c;
          for (size_t q = 0; q < M.kdopNodes.size(); q += 32) { u8* b = &M.kdopNodes[q]; for (int f = 0; f < 7; f++) { std::swap(b[f * 4], b[f * 4 + 3]); std::swap(b[f * 4 + 1], b[f * 4 + 2]); } std::swap(b[28], b[29]); std::swap(b[30], b[31]); } }
        { i32 es = r.i(), c = r.i(); if (es != 8 || c < 0) throw Err("kDOP: triangles with unexpected size"); r.need((size_t)es * c);
          M.kdopTris.assign(d + r.p, d + r.p + (size_t)es * c); r.p += (size_t)es * c;
          for (size_t q = 0; q + 1 < M.kdopTris.size(); q += 2) std::swap(M.kdopTris[q], M.kdopTris[q + 1]); }
        i32 iv = r.i(); if (iv >= 17) { i32 m = r.i(); r.need((size_t)m * 8); r.p += (size_t)m * 8; }
        i32 nl = r.i(); if (nl < 1 || nl > 8) throw Err("invalid LOD count");
        // LOD0 only (the others are skipped)
        for (i32 l = 0; l < nl; l++) {
            beta::readBulkBE(r);                                                 // RawTriangles
            i32 ns = r.i(); if (ns < 0 || ns > 1024) throw Err("invalid sections");
            std::vector<Section> secs;
            for (i32 s = 0; s < ns; s++) { Section S; S.mat = r.i(); S.col = r.i(); S.oldCol = r.i(); S.shadow = r.i(); S.first = r.u(); S.ntris = r.u(); S.minV = r.u(); S.maxV = r.u(); r.i(); secs.push_back(S); }
            i32 pst = r.i(), pn = r.i(); i32 pes = r.i(), pc = r.i(); if (pst != 12 || pes != 12 || pc != pn) throw Err("unexpected positions"); r.need((size_t)pc * 12);
            std::vector<float> pos((size_t)pc * 3); for (size_t q = 0; q < pos.size(); q++) pos[q] = rbef(d + r.p + q * 4); r.p += (size_t)pc * 12;
            i32 ntc = r.i(), item = r.i(), vn = r.i(), full = r.i(), ves = r.i(), vc = r.i();
            if (vc != pc || vn != pc || ves != item || ntc < 1 || ntc > 8) throw Err("unexpected vertex buffer");
            int uvB = ntc * (full ? 8 : 4), tang = (item - uvB) / 4; if (tang < 2 || tang > 3 || tang * 4 + uvB != item) throw Err("unexpected vertex stride");
            r.need((size_t)vc * item); std::vector<u8> vtx(d + r.p, d + r.p + (size_t)vc * item); r.p += (size_t)vc * item;
            for (i32 v = 0; v < vc; v++) { u8* b = &vtx[(size_t)v * item];
                for (int t = 0; t < tang; t++) { std::swap(b[t * 4], b[t * 4 + 3]); std::swap(b[t * 4 + 1], b[t * 4 + 2]); }
                u8* uv = b + tang * 4; if (full) { for (int q = 0; q < ntc * 2; q++) { std::swap(uv[q * 4], uv[q * 4 + 3]); std::swap(uv[q * 4 + 1], uv[q * 4 + 2]); } }
                else for (int q = 0; q < ntc * 2; q++) std::swap(uv[q * 2], uv[q * 2 + 1]); }
            r.i(); r.i(); { i32 es = r.i(), c = r.i(); r.need((size_t)es * c); r.p += (size_t)es * c; }   // shadow volume (empty in the beta)
            r.i();                                                               // NumVerts
            i32 ies = r.i(), ic = r.i(); if (ies != 2) throw Err("32-bit indices are not supported"); r.need((size_t)ic * 2);
            std::vector<uint16_t> idx(ic); for (i32 q = 0; q < ic; q++) idx[q] = rbe16(d + r.p + (size_t)q * 2); r.p += (size_t)ic * 2;
            { i32 es = r.i(), c = r.i(); r.need((size_t)es * c); r.p += (size_t)es * c; }   // indices2
            { i32 es = r.i(), c = r.i(); r.need((size_t)es * c); r.p += (size_t)es * c; }   // edges
            { i32 c = r.i(); r.need((size_t)std::max(0, c)); r.p += (size_t)std::max(0, c); }
            if (l == 0) { M.secs = secs; M.pos = std::move(pos); M.vtx = std::move(vtx); M.ntc = ntc; M.stride = item; M.fullUV = full != 0; M.idx = std::move(idx); }
        }
        if (r.p + 20 <= n) { r.i(); for (int k = 0; k < 3; k++) M.thumb[k] = r.i(); M.thumbDist = rbef(d + r.p); r.p += 4; }
        for (auto& s : M.secs) if ((size_t)s.first + (size_t)s.ntris * 3 > M.idx.size()) throw Err("section outside the indices");
        for (auto i : M.idx) if (i >= M.numVerts()) throw Err("index outside the vertices");
    } catch (std::exception& ex) { M.err = ex.what(); }
    return M;
}

// ------------------------------------------------------------------ kDOP (collision tree) - when it does not come ready-made (BSP -> mesh)
// Same as UE3's TkDOPTree::Build: splits along the axis of largest centroid variance, leaf node with up to 5 triangles.
inline void buildKDop(Mesh& M) {
    struct Tri { uint16_t v[3], mat; float c[3]; };
    std::vector<Tri> tris;
    for (size_t s = 0; s < M.secs.size(); s++) for (u32 t = 0; t < M.secs[s].ntris; t++) { Tri T; for (int k = 0; k < 3; k++) T.v[k] = M.idx[M.secs[s].first + t * 3 + k]; T.mat = (uint16_t)s;
        for (int a = 0; a < 3; a++) T.c[a] = (M.pos[T.v[0] * 3 + a] + M.pos[T.v[1] * 3 + a] + M.pos[T.v[2] * 3 + a]) / 3.f; tris.push_back(T); }
    struct Node { float mn[3], mx[3]; i32 leaf; uint16_t a, b; };
    std::vector<Node> nodes;
    std::function<void(int, int, int)> split = [&](int ni, int s, int e) {
        Node& N0 = nodes[ni]; (void)N0;
        float mn[3] = { 1e30f, 1e30f, 1e30f }, mx[3] = { -1e30f, -1e30f, -1e30f };
        for (int t = s; t < e; t++) for (int k = 0; k < 3; k++) for (int a = 0; a < 3; a++) { float v = M.pos[tris[t].v[k] * 3 + a]; mn[a] = std::min(mn[a], v); mx[a] = std::max(mx[a], v); }
        for (int a = 0; a < 3; a++) { nodes[ni].mn[a] = mn[a]; nodes[ni].mx[a] = mx[a]; }
        if (e - s <= 5) { nodes[ni].leaf = 1; nodes[ni].a = (uint16_t)(e - s); nodes[ni].b = (uint16_t)s; return; }
        int best = 0; double bv = -1;
        for (int a = 0; a < 3; a++) { double m = 0, m2 = 0; for (int t = s; t < e; t++) { m += tris[t].c[a]; m2 += (double)tris[t].c[a] * tris[t].c[a]; } m /= (e - s); double var = m2 / (e - s) - m * m; if (var > bv) { bv = var; best = a; } }
        int mid = (s + e) / 2;
        std::nth_element(tris.begin() + s, tris.begin() + mid, tris.begin() + e, [&](const Tri& x, const Tri& y) { return x.c[best] < y.c[best]; });
        nodes[ni].leaf = 0; int l = (int)nodes.size(); nodes.push_back(Node()); int rgt = (int)nodes.size(); nodes.push_back(Node());
        nodes[ni].a = (uint16_t)l; nodes[ni].b = (uint16_t)rgt;
        split(l, s, mid); split(rgt, mid, e);
    };
    M.kdopNodes.clear(); M.kdopTris.clear();
    if (tris.empty()) return;
    nodes.push_back(Node()); split(0, 0, (int)tris.size());
    for (auto& N : nodes) { u8 b[32]; memcpy(b, N.mn, 12); memcpy(b + 12, N.mx, 12); memcpy(b + 24, &N.leaf, 4); memcpy(b + 28, &N.a, 2); memcpy(b + 30, &N.b, 2); M.kdopNodes.insert(M.kdopNodes.end(), b, b + 32); }
    for (auto& T : tris) { u8 b[8]; memcpy(b, T.v, 6); memcpy(b + 6, &T.mat, 2); M.kdopTris.insert(M.kdopTris.end(), b, b + 8); }
}

// ------------------------------------------------------------------ native data of a PC StaticMesh
// edges: (v0, v1, face0, face1) as u16, neighbor faces by welded position (0xFFFF = open edge)
inline std::vector<uint16_t> buildEdges(const Mesh& M) {
    std::vector<uint16_t> out; size_t nv = M.numVerts(); if (nv > 65535) return out;
    std::map<std::array<float, 3>, u32> weld; std::vector<u32> wid(nv);
    for (size_t v = 0; v < nv; v++) { std::array<float, 3> k = { M.pos[v * 3], M.pos[v * 3 + 1], M.pos[v * 3 + 2] }; auto it = weld.find(k); if (it == weld.end()) it = weld.emplace(k, (u32)weld.size()).first; wid[v] = it->second; }
    std::map<std::pair<u32, u32>, std::vector<size_t>> open;   // (a, b) welded -> open edges with that direction
    size_t nt = M.idx.size() / 3; if (nt > 65535) return out;
    for (size_t t = 0; t < nt; t++) for (int k = 0; k < 3; k++) {
        uint16_t a = M.idx[t * 3 + k], b = M.idx[t * 3 + (k + 1) % 3];
        auto rk = std::make_pair(wid[b], wid[a]); auto it = open.find(rk);
        if (it != open.end() && !it->second.empty()) { size_t e = it->second.back(); it->second.pop_back(); out[e * 4 + 3] = (uint16_t)t; continue; }
        size_t e = out.size() / 4; out.push_back(a); out.push_back(b); out.push_back((uint16_t)t); out.push_back(0xFFFF);
        open[std::make_pair(wid[a], wid[b])].push_back(e);
    }
    return out;
}

// 'base' = SerialOffset the export will have at save time (the save fixes the absolute offset of the inline bulk)
// 'dataStart' = bytes before the native data (prefix + properties); 'mats' = material of each section, already in the target package
inline std::vector<u8> buildStaticMeshNative(const Mesh& M, i32 base, size_t dataStart, const std::vector<i32>& mats) {
    Writer w; size_t nv = M.numVerts(), nt = M.idx.size() / 3;
    for (int k = 0; k < 7; k++) w.f(M.bounds[k]);
    w.i(M.bodyOut);                                                               // BodySetup
    w.i(32); w.i((i32)(M.kdopNodes.size() / 32)); w.raw(M.kdopNodes);
    w.i(8); w.i((i32)(M.kdopTris.size() / 8)); w.raw(M.kdopTris);
    w.i(18); w.i(0);                                                              // InternalVersion, ContentTags
    w.i(1);                                                                       // LODs
    w.u(0); w.i(0); w.i(0); w.i(base + (i32)(dataStart + w.b.size()) + 4);       // RawTriangles (empty; offset = right after the header)
    w.i((i32)M.secs.size());
    for (size_t s = 0; s < M.secs.size(); s++) { const Section& S = M.secs[s];
        w.i(s < mats.size() ? mats[s] : 0); w.i(S.col); w.i(S.oldCol); w.i(S.shadow); w.u(S.first); w.u(S.ntris); w.u(S.minV); w.u(S.maxV); w.i((i32)s);
        w.i(1); w.i((i32)S.first); w.i((i32)S.ntris); }                         // 1 fragment
    w.i(12); w.i((i32)(nv * 2)); w.i(1); w.i(12); w.i((i32)(nv * 2));
    for (int rep = 0; rep < 2; rep++) for (float f : M.pos) w.f(f);
    w.i(M.ntc); w.i(M.stride); w.i((i32)(nv * 2)); w.i(M.fullUV ? 1 : 0); w.i(M.stride); w.i((i32)(nv * 2)); w.raw(M.vtx); w.raw(M.vtx);
    w.i(4); w.i((i32)(nv * 2)); w.i(4); w.i((i32)(nv * 2)); for (size_t v = 0; v < nv; v++) w.f(0.f); for (size_t v = 0; v < nv; v++) w.f(1.f);
    w.i((i32)nv);
    w.i(2); w.i((i32)M.idx.size()); for (auto i : M.idx) { u8 t[2]; memcpy(t, &i, 2); w.raw(t, 2); }
    w.i(2); w.i(0);                                                               // wireframe
    auto ed = buildEdges(M); w.i(8); w.i((i32)(ed.size() / 4)); for (auto v : ed) { u8 t[2]; memcpy(t, &v, 2); w.raw(t, 2); }
    w.i((i32)nt); for (size_t t = 0; t < nt; t++) w.raw(std::vector<u8>{ 0 });  // ShadowTriangleDoubleSided
    w.i(1); for (int k = 0; k < 3; k++) w.i(M.thumb[k]); w.f(M.thumbDist); w.i(0); w.i(0); w.i(0);
    return w.b;
}

// ------------------------------------------------------------------ create objects in the target package
// package (export of class Package) by path "A.B.C", creating whatever is missing (copying the row of an existing Package)
inline i32 ensurePackageExport(Package& T, const std::string& path) {
    i32 have = T.findPath(path); if (have > 0) return have;
    size_t dot = path.rfind('.'); i32 outer = dot == std::string::npos ? 0 : ensurePackageExport(T, path.substr(0, dot));
    i32 tmpl = 0; for (size_t k = 0; k < T.exports.size(); k++) if (T.classOf(T.exports[k]) == "Package") { tmpl = (i32)k + 1; break; }
    if (!tmpl) throw Err("the target package has no export of class Package to use as a template");
    Export ne = T.exports[tmpl - 1]; ne.data = T.dataCopy(T.exports[tmpl - 1]); ne.owned = true; ne.netObjects.clear(); memset(ne.guid, 0, 16);
    ne.outer = outer; ne.name.idx = T.addName(dot == std::string::npos ? path : path.substr(dot + 1)); ne.name.num = 0;
    T.exports.push_back(ne); return (i32)T.exports.size();
}
// new export copying the row (class, flags) of 'tmpl'; data = 'data'
inline i32 newExportLike(Package& T, i32 tmpl, i32 outer, const std::string& name) {
    Export ne = T.exports[tmpl - 1]; ne.data.clear(); ne.owned = true; ne.netObjects.clear(); memset(ne.guid, 0, 16);
    ne.outer = outer; ne.name.idx = T.addName(name); ne.name.num = 0; ne.archetype = 0;
    T.exports.push_back(ne); return (i32)T.exports.size();
}

// brand-new asset: class (import), cooked asset flags, UObject prefix (NetIndex = 0)
inline i32 newAsset(Package& T, const std::string& classPath, i32 outer, const std::string& name, u64 flags = 0x000f000400000000ull) {
    Export ne; ne.cls = T.ensureRef(classPath, "Core", "Class"); ne.outer = outer; ne.name.idx = T.addName(name); ne.name.num = 0; ne.flags = flags; ne.owned = true;
    ne.serialOffset = 0x40000000;                       // dummy base for the inline bulk offsets (the save recomputes them)
    ne.data.assign(4, 0); T.exports.push_back(ne); return (i32)T.exports.size();
}
// new PC StaticMesh in T built from M
inline i32 createStaticMesh(Package& T, i32 outer, const std::string& name, const Mesh& M0, const std::vector<i32>& mats, std::function<i32(i32)> makeBody = nullptr) {
    if (T.findPath((outer ? T.objPath(outer) + "." : "") + name) != 0) throw Err("already exists " + name);
    i32 x = newAsset(T, "Engine.StaticMesh", outer, name);
    Mesh M = M0; M.bodyOut = makeBody ? makeBody(x) : 0;
    std::vector<Tag> tags;
    if (M.bodyOut) tags.push_back(objTag("BodySetup", M.bodyOut));
    { Tag t; t.name = "LightMapCoordinateIndex"; t.type = "IntProperty"; t.raw.resize(4); memcpy(t.raw.data(), &M.lightMapCoord, 4); tags.push_back(t); }
    { Tag t; t.name = "LightMapResolution"; t.type = "IntProperty"; t.raw.resize(4); memcpy(t.raw.data(), &M.lightMapRes, 4); tags.push_back(t); }
    // v0.18: per-polygon collision (kDOP tree). Without a BodySetup, the engine default (UseSimpleBoxCollision=True) let
    // Batman and the enemies walk through everything. RigidBody: PhysX cooks the mesh on load (ragdolls/objects on the floor).
    if (!M.bodyOut) for (const char* b : { "UseSimpleLineCollision", "UseSimpleBoxCollision", "UseSimpleRigidBodyCollision" }) { Tag t; t.name = b; t.type = "BoolProperty"; t.isBool = true; t.boolVal = 0; tags.push_back(t); }
    std::vector<u8> d(4, 0); auto pb = writeProps(T, tags); d.insert(d.end(), pb.begin(), pb.end());
    auto nat = buildStaticMeshNative(M, T.exports[x - 1].serialOffset, d.size(), mats); d.insert(d.end(), nat.begin(), nat.end());
    T.exports[x - 1].data = std::move(d);
    return x;
}


// ------------------------------------------------------------------ textures and materials
// DDS with the beta mip chain (already in the PC layout)
inline std::vector<u8> makeDDSChain(const beta::BetaTexture& bt) {
    TextureInfo ti; ti.format = bt.format; const auto& m0 = bt.mips[0];
    // only the continuous chain starting at the first readable mip (each one half of the previous)
    std::vector<const beta::BetaMip*> chain; int w = m0.w, h = m0.h;
    for (auto& m : bt.mips) { if (m.w != w || m.h != h) { if (chain.empty()) continue; break; } if (m.data.size() < ti.mipBytes(m.w, m.h)) break; chain.push_back(&m); if (w == 1 && h == 1) break; w = std::max(1, w / 2); h = std::max(1, h / 2); }
    Writer wr; wr.u(0x20534444); wr.u(124); u32 flags = 0x1 | 0x2 | 0x4 | 0x1000 | 0x20000 | (ti.blockBytes() ? 0x80000 : 0x8);
    wr.u(flags); wr.u((u32)m0.h); wr.u((u32)m0.w); wr.u(ti.blockBytes() ? (u32)ti.mipBytes(m0.w, m0.h) : (u32)m0.w * 4); wr.u(0); wr.u((u32)chain.size()); for (int k = 0; k < 11; k++) wr.u(0);
    wr.u(32);
    if (ti.blockBytes()) { wr.u(0x4); wr.u(bt.format == "PF_DXT1" ? 0x31545844 : bt.format == "PF_DXT3" ? 0x33545844 : 0x35545844); wr.u(0); wr.u(0); wr.u(0); wr.u(0); wr.u(0); }
    else { wr.u(0x41); wr.u(0); wr.u(32); wr.u(0x00FF0000); wr.u(0x0000FF00); wr.u(0x000000FF); wr.u(0xFF000000); }
    wr.u(0x1000 | 0x8 | 0x400000); wr.u(0); wr.u(0); wr.u(0); wr.u(0);
    for (auto* m : chain) wr.raw(m->data.data(), ti.mipBytes(m->w, m->h));
    return wr.b;
}

using ReadTfc = std::function<bool(const std::string&, uint64_t, size_t, std::vector<u8>&)>;
struct Ctx {
    Package& B;                 // beta, normalized (LE properties)
    const Package& Braw;        // beta as read (BE properties) - for the texture reader
    Package& T;                 // target (PC)
    ReadTfc readTfc;
    std::string prefix = "Beta";                // new top-level package: Beta<Original> (does not clash with the final game asset)
    i32 tmplMIC = 0;
    i32 white = 0, flatNormal = 0;
    std::map<i32, i32> done;    // beta export -> export in the target
    std::vector<std::string> log;
    int meshes = 0, materials = 0, textures = 0, failed = 0, skippedFx = 0, bodies = 0;
    Ctx(Package& b, const Package& br, Package& t) : B(b), Braw(br), T(t) {}
    void L(const std::string& s) { log.push_back(s); }
};

// name/path in the target for a beta object: <prefix><Top>.<...>.<Name>; creates the outer packages
inline i32 destOuter(Ctx& C, i32 bx) {
    std::string op = C.B.objPath(C.B.exports[bx - 1].outer);
    if (op.empty() || op == "None") return ensurePackageExport(C.T, C.prefix + "Converted");
    return ensurePackageExport(C.T, C.prefix + op);
}
inline i32 setEnumTag(Package& T, std::vector<Tag>& tags, const std::string& name, const std::string& val) {
    for (auto& t : tags) if (t.name == name) { i32 n = T.addName(val), z = 0; t.raw.resize(8); memcpy(t.raw.data(), &n, 4); memcpy(t.raw.data() + 4, &z, 4); return 1; }
    Tag t; t.name = name; t.type = "ByteProperty"; t.raw.resize(8); i32 n = T.addName(val), z = 0; memcpy(t.raw.data(), &n, 4); memcpy(t.raw.data() + 4, &z, 4); tags.push_back(t); return 0;
}
// simple beta properties carried to the target (bool/int/float as they are; enum/name translated by text)
inline std::vector<Tag> transplantSimple(const Package& B, const std::vector<Tag>& in, Package& T, std::initializer_list<const char*> keep) {
    std::vector<Tag> out;
    for (auto& t : in) { bool k = false; for (auto* n : keep) if (t.name == n) k = true; if (!k) continue;
        if (t.isBool || t.type == "IntProperty" || t.type == "FloatProperty") { out.push_back(t); continue; }
        if ((t.type == "ByteProperty" && t.raw.size() == 8) || t.type == "NameProperty") { FName f; memcpy(&f.idx, t.raw.data(), 4); memcpy(&f.num, t.raw.data() + 4, 4); Tag c = t; i32 n = T.addName(B.nm(f)); memcpy(c.raw.data(), &n, 4); memcpy(c.raw.data() + 4, &f.num, 4); out.push_back(c); }
        else if (t.type == "ByteProperty") out.push_back(t); }
    return out;
}

// new texture from a DDS; 'props' = extra properties already in the target format
inline i32 createTexture(Ctx& C, i32 outer, const std::string& name, const std::vector<Tag>& props, const std::vector<u8>& dds, const std::string& fmt) {
    i32 x = newAsset(C.T, "Engine.Texture2D", outer, name); i32 base = C.T.exports[x - 1].serialOffset;
    std::vector<Tag> tags;
    auto intT = [&](const char* n, i32 v) { Tag t; t.name = n; t.type = "IntProperty"; t.raw.resize(4); memcpy(t.raw.data(), &v, 4); tags.push_back(t); };
    intT("SizeX", 4); intT("SizeY", 4); setEnumTag(C.T, tags, "Format", "PF_DXT1"); intT("MipTailBaseIdx", 0);
    for (auto& t : props) { bool rep = false; for (auto& q : tags) if (q.name == t.name && q.index == t.index) { q = t; rep = true; } if (!rep) tags.push_back(t); }
    Writer w; w.raw(std::vector<u8>(4, 0)); w.raw(writeProps(C.T, tags));
    w.u(0); w.i(0); w.i(0); w.i(base + (i32)w.b.size() + 4);                     // empty SourceArt
    w.i(1); w.u(0); w.i(8); w.i(8); w.i(base + (i32)w.b.size() + 4); w.raw(std::vector<u8>(8, 0)); w.i(4); w.i(4);   // 1 temporary mip
    { static std::mt19937 rng{ std::random_device{}() }; for (int k = 0; k < 4; k++) w.u(rng()); }                     // GUID
    C.T.exports[x - 1].data = std::move(w.b);
    auto rep = importTexture2D(C.T, x, dds, fmt); if (!rep.ok) { C.T.exports.pop_back(); throw Err("texture " + name + ": " + rep.err); }
    C.T.exports[x - 1].data = std::move(rep.newData);
    return x;
}
// 4x4 white texture (opacity of opaque materials) / flat normal
inline i32 solidTexture(Ctx& C, const std::string& name, u8 r, u8 g, u8 b, bool normal) {
    i32 have = C.T.findPath(C.prefix + "Converted." + name); if (have > 0) return have;
    std::vector<u8> png;   // single-color 4x4 DXT1 DDS
    uint16_t c565 = (uint16_t)((r >> 3) << 11 | (g >> 2) << 5 | (b >> 3));
    Writer wr; wr.u(0x20534444); wr.u(124); wr.u(0x1 | 0x2 | 0x4 | 0x1000 | 0x80000); wr.u(4); wr.u(4); wr.u(8); wr.u(0); wr.u(1); for (int k = 0; k < 11; k++) wr.u(0);
    wr.u(32); wr.u(0x4); wr.u(0x31545844); for (int k = 0; k < 5; k++) wr.u(0); wr.u(0x1000); for (int k = 0; k < 4; k++) wr.u(0);
    u8 blk[8] = { (u8)(c565 & 255), (u8)(c565 >> 8), (u8)(c565 & 255), (u8)(c565 >> 8), 0, 0, 0, 0 }; wr.raw(blk, 8);
    std::vector<Tag> props;
    if (normal) { setEnumTag(C.T, props, "CompressionSettings", "TC_Normalmap"); setEnumTag(C.T, props, "LODGroup", "TEXTUREGROUP_WorldNormalMap"); }
    return createTexture(C, ensurePackageExport(C.T, C.prefix + "Converted"), name, props, wr.b, "PF_DXT1");
}

inline i32 createMIC(Ctx& C, i32 outer, const std::string& name, i32 diff, i32 spec, i32 norm, i32 opac, float specPower);
// "greybox" material (BSP surfaces with no material in the beta: blocking walls, like the editor's grey DefaultMaterial)
inline i32 greyboxMIC(Ctx& C) {
    i32 have = C.T.findPath(C.prefix + "Converted.Greybox_MIC"); if (have > 0) return have;
    // 64x64: medium grey with a darker border (grid line every 128 units on the BSP)
    const int N = 64; Writer wr; wr.u(0x20534444); wr.u(124); wr.u(0x1 | 0x2 | 0x4 | 0x1000 | 0x8); wr.u(N); wr.u(N); wr.u(N * 4); wr.u(0); wr.u(1); for (int k = 0; k < 11; k++) wr.u(0);
    wr.u(32); wr.u(0x41); wr.u(0); wr.u(32); wr.u(0x00FF0000); wr.u(0x0000FF00); wr.u(0x000000FF); wr.u(0xFF000000); wr.u(0x1000); for (int k = 0; k < 4; k++) wr.u(0);
    for (int y = 0; y < N; y++) for (int x = 0; x < N; x++) { bool line = x < 1 || y < 1 || x == N / 2 || y == N / 2; u8 v = line ? 70 : 118; u8 px[4] = { v, v, v, 255 }; wr.raw(px, 4); }
    i32 outer = ensurePackageExport(C.T, C.prefix + "Converted");
    i32 d = createTexture(C, outer, "Greybox_D", {}, wr.b, "PF_DXT1");
    if (!C.white) C.white = solidTexture(C, "White", 255, 255, 255, false);
    if (!C.flatNormal) C.flatNormal = solidTexture(C, "FlatNormal", 128, 128, 255, true);
    i32 spec = solidTexture(C, "Dark", 40, 40, 40, false);
    return createMIC(C, outer, "Greybox_MIC", d, spec, C.flatNormal, C.white, 8.f);
}

inline i32 convTexture(Ctx& C, i32 bx) {
    if (bx <= 0) return 0; auto it = C.done.find(bx); if (it != C.done.end()) return it->second;
    std::string name = C.B.objName(bx);
    { i32 have = C.T.findPath(C.prefix + C.B.objPath(bx)); if (have > 0 && C.T.classOf(C.T.exports[have - 1]) == "Texture2D") { C.done[bx] = have; return have; } }
    auto bt = beta::readTexture(C.Braw, bx, C.readTfc);
    if (!bt.err.empty()) { C.L("  texture " + C.B.objPath(bx) + ": " + bt.err); C.failed++; C.done[bx] = 0; return 0; }
    if (bt.format != "PF_DXT1" && bt.format != "PF_DXT5" && bt.format != "PF_DXT3" && bt.format != "PF_A8R8G8B8") { C.L("  texture " + C.B.objPath(bx) + ": format " + bt.format + " cannot be converted"); C.failed++; C.done[bx] = 0; return 0; }
    ObjProps bp = objProps(C.B, bx);
    auto props = transplantSimple(C.B, bp.tags, C.T, { "SRGB", "CompressionNoAlpha", "UnpackMin", "UnpackMax", "CompressionSettings", "LODGroup", "AddressX", "AddressY", "Filter", "LODBias" });
    i32 x = 0;
    { i32 to = destOuter(C, bx); if (C.T.findPath(C.T.objPath(to) + "." + name) != 0) name += "_Tex"; }
    try { x = createTexture(C, destOuter(C, bx), name, props, makeDDSChain(bt), bt.format == "PF_DXT3" ? "PF_DXT5" : bt.format); C.textures++; }
    catch (std::exception& e) { C.L(std::string("  ") + e.what()); C.failed++; }
    C.done[bx] = x; return x;
}

// texture wired to a material input (DiffuseColor, Normal...) - follows the expression graph; MIC: overrides and Parent
inline i32 betaInputTexture(const Package& B, i32 mat, const std::string& input, float* constOut = nullptr) {
    auto valid = [&](i32 o) { return o > 0 && o <= (i32)B.exports.size(); };
    std::map<std::string, i32> overrides; i32 cur = mat;
    for (int depth = 0; depth < 8 && valid(cur); depth++) {
        ObjProps op = objProps(B, cur); if (!op.ok) return 0;
        if (const Tag* tp = findTag(op.tags, "TextureParameterValues")) { try { Reader r(tp->raw.data(), tp->raw.size()); i32 n = r.i();
            for (i32 k = 0; k < n && k < 64; k++) { size_t end = 0; auto sub = readProps(B, tp->raw.data(), tp->raw.size(), r.p, &end); r.p = end;
                std::string pn = tagName(B, sub, "ParameterName"); const Tag* pv = findTag(sub, "ParameterValue"); if (pv && tagObj(*pv) && !overrides.count(pn)) overrides[pn] = tagObj(*pv); } } catch (...) {} }
        if (B.classOf(B.exports[cur - 1]) == "Material") {
            std::vector<i32> q; std::set<i32> seen;
            if (const Tag* dc = findTag(op.tags, input)) { try { size_t e = 0; auto sub = readProps(B, dc->raw.data(), dc->raw.size(), 0, &e); if (const Tag* ex = findTag(sub, "Expression")) q.push_back(tagObj(*ex)); } catch (...) {} }
            for (size_t qi = 0; qi < q.size() && qi < 400; qi++) {
                i32 o = q[qi]; if (!valid(o) || !seen.insert(o).second) continue;
                ObjProps ep = objProps(B, o); if (!ep.ok) continue;
                if (qi == 0 && constOut && B.classOf(B.exports[o - 1]) == "MaterialExpressionConstant") { if (const Tag* rr = findTag(ep.tags, "R")) memcpy(constOut, rr->raw.data(), 4); }
                if (const Tag* tx = findTag(ep.tags, "Texture")) { std::string pn = tagName(B, ep.tags, "ParameterName"); if (!pn.empty() && pn != "None" && overrides.count(pn)) return overrides[pn]; if (tagObj(*tx)) return tagObj(*tx); }
                for (auto& t : ep.tags) if (t.type == "StructProperty") { try { size_t e = 0; auto sub = readProps(B, t.raw.data(), t.raw.size(), 0, &e); if (const Tag* ex = findTag(sub, "Expression")) q.push_back(tagObj(*ex)); } catch (...) {} }
            }
            return 0;
        }
        const Tag* par = findTag(op.tags, "Parent"); if (!par) break; cur = tagObj(*par);
    }
    return 0;
}

// new MIC copying the template (MasterShader_Basic_Opacity: DiffuseTexture/SpecularTexture/NormalMapTexture/Opacity_Texture)
inline i32 createMIC(Ctx& C, i32 outer, const std::string& name, i32 diff, i32 spec, i32 norm, i32 opac, float specPower) {
    i32 tm = C.tmplMIC; ObjProps op = objProps(C.T, tm); long ps = findPropStart(C.T, tm); if (!op.ok || ps < 0) throw Err("unreadable template MIC");
    std::map<std::string, i32> texFor = { { "DiffuseTexture", diff }, { "SpecularTexture", spec }, { "NormalMapTexture", norm }, { "Opacity_Texture", opac } };
    std::map<std::string, float> scal = { { "DiffuseMultiplier", 1.f }, { "SpecularMultiplier", 1.f }, { "IsItRaining?", 0.f }, { "SpecularPower", specPower } };
    std::map<i32, i32> remap;
    std::vector<Tag> tags;
    for (auto t : op.tags) {
        if (t.name == "TextureParameterValues" || t.name == "ScalarParameterValues") {
            Reader r(t.raw.data(), t.raw.size()); i32 n = r.i(); Writer w; w.i(n);
            for (i32 k = 0; k < n; k++) { size_t end = 0; auto sub = readProps(C.T, t.raw.data(), t.raw.size(), r.p, &end); r.p = end;
                std::string pn = tagName(C.T, sub, "ParameterName");
                for (auto& s : sub) if (s.name == "ParameterValue") {
                    if (t.name == "TextureParameterValues" && texFor.count(pn) && texFor[pn]) { remap[tagObj(s)] = texFor[pn]; memcpy(s.raw.data(), &texFor[pn], 4); }
                    if (t.name == "ScalarParameterValues" && scal.count(pn)) memcpy(s.raw.data(), &scal[pn], 4); }
                w.raw(writeProps(C.T, sub)); }
            t.raw = w.b;
        }
        if (t.name == "VectorParameterValues") {   // v0.19: the template MIC had NormalMapMultiplier=(1,1,0): normal without Z -> lighting all wrong in game
            Reader r(t.raw.data(), t.raw.size()); i32 n = r.i(); Writer w; w.i(n);
            for (i32 k = 0; k < n; k++) { size_t end = 0; auto sub = readProps(C.T, t.raw.data(), t.raw.size(), r.p, &end); r.p = end;
                std::string pn = tagName(C.T, sub, "ParameterName");
                for (auto& s : sub) if (s.name == "ParameterValue" && s.raw.size() >= 16 && pn == "NormalMapMultiplier") { float v[4] = { 1, 1, 1, 0 }; memcpy(s.raw.data(), v, 16); }
                w.raw(writeProps(C.T, sub)); }
            t.raw = w.b;
        }
        if (t.name == "PhysMaterial") continue;
        tags.push_back(t);
    }
    for (auto& t : tags) if (t.name == "ReferencedTextures") { for (size_t q = 4; q + 4 <= t.raw.size(); q += 4) { i32 o; memcpy(&o, &t.raw[q], 4); auto it = remap.find(o); if (it != remap.end()) memcpy(&t.raw[q], &it->second, 4); } }
    i32 x = newExportLike(C.T, tm, outer, name);
    const u8* d = C.T.dataPtr(C.T.exports[tm - 1]); size_t n = C.T.dataLen(C.T.exports[tm - 1]);
    std::vector<u8> nd(d, d + ps); auto pb = writeProps(C.T, tags); nd.insert(nd.end(), pb.begin(), pb.end()); nd.insert(nd.end(), d + op.end, d + n);
    C.T.exports[x - 1].data = std::move(nd);
    return x;
}

inline i32 convMaterial(Ctx& C, i32 bx) {
    if (bx == 0) return 0; auto it = C.done.find(bx); if (it != C.done.end()) return it->second;
    if (bx < 0) { C.L("  material " + C.B.objPath(bx) + " is in another beta package (import) - not converted"); C.done[bx] = 0; return 0; }
    { i32 have = C.T.findPath(C.prefix + C.B.objPath(bx)); if (have > 0 && C.T.classOf(C.T.exports[have - 1]) == "MaterialInstanceConstant") { C.done[bx] = have; return have; } }
    float sp = 20.f;
    i32 bd = betaInputTexture(C.B, bx, "DiffuseColor"), bs = betaInputTexture(C.B, bx, "SpecularColor"), bn = betaInputTexture(C.B, bx, "Normal"), bo = betaInputTexture(C.B, bx, "OpacityMask");
    betaInputTexture(C.B, bx, "SpecularPower", &sp);
    if (!bd) bd = betaInputTexture(C.B, bx, "EmissiveColor");
    int blend = materialBlendMode(C.B, bx);
    if (blend >= 2) C.L("  material " + C.B.objPath(bx) + ": translucent/additive in the beta - converted as opaque/masked");
    i32 d = convTexture(C, bd), s = convTexture(C, bs), nrm = convTexture(C, bn), o = blend == 1 ? convTexture(C, bo) : 0;
    if (!C.white) C.white = solidTexture(C, "White", 255, 255, 255, false);
    if (!C.flatNormal) C.flatNormal = solidTexture(C, "FlatNormal", 128, 128, 255, true);
    i32 x = 0;
    std::string mn = C.B.objName(bx); i32 mo = destOuter(C, bx); if (C.T.findPath(C.T.objPath(mo) + "." + mn) != 0) mn += "_MIC";
    if (!s) s = solidTexture(C, "Dark", 40, 40, 40, false);                                  // no specular texture: matte (white would be far too shiny)
    try { x = createMIC(C, mo, mn, d ? d : C.white, s, nrm ? nrm : C.flatNormal, o ? o : C.white, sp); C.materials++; }
    catch (std::exception& e) { C.L(std::string("  material: ") + e.what()); C.failed++; }
    C.done[bx] = x; return x;
}

// ------------------------------------------------------------------ v0.19: beta collision shapes (RB_BodySetup)
// The final game collides Batman/enemies with meshes through the simple shapes (AggGeom: boxes/convexes/capsules), not through the
// triangles. The beta ones have the same layout as PC (checked with the beta ARCH_Concrete_Supports_PillarBase vs Admin_A_Static);
// only the names have to go to the target package, plus the immutable structs (Box/Matrix) that normalize left big-endian.
inline bool saneF(float f) { float a = fabsf(f); return f == 0 || (a > 1e-6f && a < 1e7f && f == f); }
inline void fixFloats(std::vector<u8>& raw, size_t off, size_t n) {
    if (raw.size() < off + n * 4) return; int le = 0, be = 0;
    for (size_t i = 0; i < n; i++) { float f; memcpy(&f, &raw[off + i * 4], 4); le += saneF(f); u8 b[4] = { raw[off + i * 4 + 3], raw[off + i * 4 + 2], raw[off + i * 4 + 1], raw[off + i * 4] }; memcpy(&f, b, 4); be += saneF(f); }
    if (be > le) for (size_t i = 0; i < n; i++) { std::swap(raw[off + i * 4], raw[off + i * 4 + 3]); std::swap(raw[off + i * 4 + 1], raw[off + i * 4 + 2]); }
}
inline std::vector<Tag> retagGeom(const Package& B, const std::vector<Tag>& in, Package& T) {
    static const std::set<std::string> structs = { "KAggregateGeom", "KConvexElem", "KBoxElem", "KSphereElem", "KSphylElem" };
    static const std::set<std::string> arrays = { "ConvexElems", "BoxElems", "SphereElems", "SphylElems" };
    std::vector<Tag> out;
    for (auto t : in) {
        if (t.type == "ObjectProperty" || t.type == "ComponentProperty" || t.type == "ClassProperty") continue;   // PhysMaterial etc.: keeps the default
        if (t.type == "StructProperty" && structs.count(t.strct)) { size_t e = 0; auto sub = readProps(B, t.raw.data(), t.raw.size(), 0, &e); t.raw = writeProps(T, retagGeom(B, sub, T)); }
        else if (t.type == "StructProperty") { if (t.strct == "Box") fixFloats(t.raw, 0, 6); else fixFloats(t.raw, 0, t.raw.size() / 4); }
        else if (t.type == "ArrayProperty" && arrays.count(t.name)) {
            Reader r(t.raw.data(), t.raw.size()); i32 n = r.i(); Writer w; w.i(n);
            for (i32 k = 0; k < n; k++) { size_t e = 0; auto sub = readProps(B, t.raw.data(), t.raw.size(), r.p, &e); r.p = e; w.raw(writeProps(T, retagGeom(B, sub, T))); }
            t.raw = w.b; }
        else if ((t.type == "ByteProperty" && t.raw.size() == 8) || t.type == "NameProperty") { FName f; memcpy(&f.idx, t.raw.data(), 4); memcpy(&f.num, t.raw.data() + 4, 4); i32 nn = T.addName(B.nm(f)); memcpy(t.raw.data(), &nn, 4); }
        out.push_back(t);
    }
    return out;
}
inline i32 convBodySetup(Ctx& C, i32 bb, i32 outerMesh) {
    if (bb <= 0 || C.B.classOf(C.B.exports[bb - 1]) != "RB_BodySetup") return 0;
    ObjProps op = objProps(C.B, bb); if (!op.ok) return 0; const Tag* ag = findTag(op.tags, "AggGeom"); if (!ag) return 0;
    std::vector<Tag> tags; { Tag v; v.name = "PreCachedPhysDataVersion"; v.type = "IntProperty"; v.raw.resize(4); i32 ver = 34079120; memcpy(v.raw.data(), &ver, 4); tags.push_back(v); }   // PC version (empty cached data, as in the game)
    for (auto& t : retagGeom(C.B, op.tags, C.T)) if (t.name != "PreCachedPhysDataVersion") tags.push_back(t);
    i32 x = newAsset(C.T, "Engine.RB_BodySetup", outerMesh, C.B.objName(bb));
    std::vector<u8> d(4, 0); auto pb = writeProps(C.T, tags); d.insert(d.end(), pb.begin(), pb.end()); d.insert(d.end(), 4, 0);   // PreCachedPhysData: empty
    C.T.exports[x - 1].data = std::move(d); C.bodies++;
    return x;
}

inline i32 convStaticMesh(Ctx& C, i32 bx) {
    if (bx <= 0) return 0; auto it = C.done.find(bx); if (it != C.done.end()) return it->second;
    { i32 have = C.T.findPath(C.prefix + C.B.objPath(bx)); if (have > 0 && C.T.classOf(C.T.exports[have - 1]) == "StaticMesh") { C.done[bx] = have; return have; } }
    Mesh M = readStaticMesh(C.B, bx);
    if (!M.err.empty()) { C.L("  mesh " + C.B.objPath(bx) + ": " + M.err); C.failed++; C.done[bx] = 0; return 0; }
    // only translucent/additive materials (light shafts, fake dirt, water...): the MasterShader is opaque/masked -> it would become a solid panel
    { bool allFx = !M.secs.empty(); for (auto& s : M.secs) if (s.mat <= 0 || materialBlendMode(C.B, s.mat) < 2) allFx = false;
      if (allFx) { C.L("  mesh " + C.B.objPath(bx) + ": translucent (effect) material only - left out"); C.skippedFx++; C.done[bx] = 0; return 0; } }
    std::vector<i32> mats; for (auto& s : M.secs) mats.push_back(convMaterial(C, s.mat));
    for (auto& m : mats) if (!m) m = 0;   // None: the game uses the default material
    i32 x = 0;
    std::string nm = C.B.objName(bx); i32 outer = destOuter(C, bx);
    if (C.T.findPath(C.T.objPath(outer) + "." + nm) != 0) nm += "_SM";                     // name already used by a group/another object
    try { x = createStaticMesh(C.T, outer, nm, M, mats, [&](i32 mesh) { try { return convBodySetup(C, M.bodySetup, mesh); } catch (std::exception& e) { C.L("  collision of " + nm + ": " + e.what()); return 0; } }); C.meshes++; }
    catch (std::exception& e) { C.L(std::string("  mesh: ") + e.what()); C.failed++; }
    C.done[bx] = x; return x;
}

// template in the target: a MIC of MasterShader_Basic_Opacity (DiffuseTexture/SpecularTexture/NormalMapTexture/Opacity_Texture)
inline i32 findMasterMIC(const Package& T) {
    for (size_t k = 0; k < T.exports.size(); k++) { if (T.classOf(T.exports[k]) != "MaterialInstanceConstant") continue; i32 x = (i32)k + 1;
        ObjProps op = objProps(T, x); const Tag* p = op.ok ? findTag(op.tags, "Parent") : nullptr; if (!p) continue;
        if (T.objName(tagObj(*p)) != "MasterShader_Basic_Opacity") continue;
        const Tag* tp = findTag(op.tags, "TextureParameterValues"); if (!tp) continue; i32 n; memcpy(&n, tp->raw.data(), 4); if (n >= 4) return x; }
    return 0;
}
inline std::string findTemplates(Ctx& C) { C.tmplMIC = findMasterMIC(C.T); return C.tmplMIC ? "" : " MIC of MasterShader_Basic_Opacity"; }

} }
