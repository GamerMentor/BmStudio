// bmpkg.hpp - reading/writing cooked Batman: Arkham Asylum packages (UE3 v576 / licensee 21, PC).
// C++ port of bmcore (Python), validated byte by byte. No dependencies beyond the STL.
#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <stdexcept>
#include <algorithm>
#include <fstream>
#include <cctype>
#include <cstdlib>
#include "bmlzo.hpp"

namespace bm {

typedef uint8_t u8; typedef int32_t i32; typedef uint32_t u32; typedef uint64_t u64;
static const u32 TAG = 0x9E2A83C1u;

struct Err : std::runtime_error { explicit Err(const std::string& s) : std::runtime_error(s) {} };

struct Reader {
    const u8* d; size_t n; size_t p;
    Reader(const u8* d_, size_t n_, size_t p_ = 0) : d(d_), n(n_), p(p_) {}
    void need(size_t k) const { if (p + k > n) throw Err("read past end of file"); }
    i32 i() { need(4); i32 v; memcpy(&v, d + p, 4); p += 4; return v; }
    u32 u() { need(4); u32 v; memcpy(&v, d + p, 4); p += 4; return v; }
    u64 q() { need(8); u64 v; memcpy(&v, d + p, 8); p += 8; return v; }
    float f() { need(4); float v; memcpy(&v, d + p, 4); p += 4; return v; }
    std::vector<u8> raw(size_t k) { need(k); std::vector<u8> v(d + p, d + p + k); p += k; return v; }
    // FString -> UTF-8
    std::string fstr() {
        i32 len = i(); if (len == 0) return "";
        std::string out;
        if (len > 0) { need(len); for (i32 k = 0; k < len - 1; k++) { unsigned char c = d[p + k]; if (c < 0x80) out += (char)c; else { out += (char)(0xC0 | (c >> 6)); out += (char)(0x80 | (c & 0x3F)); } } p += len; }
        else { len = -len; need((size_t)len * 2); for (i32 k = 0; k < len - 1; k++) { uint16_t c; memcpy(&c, d + p + k * 2, 2);
                if (c < 0x80) out += (char)c; else if (c < 0x800) { out += (char)(0xC0 | (c >> 6)); out += (char)(0x80 | (c & 0x3F)); }
                else { out += (char)(0xE0 | (c >> 12)); out += (char)(0x80 | ((c >> 6) & 0x3F)); out += (char)(0x80 | (c & 0x3F)); } }
               p += (size_t)len * 2; }
        return out;
    }
};

struct Writer {
    std::vector<u8> b;
    void i(i32 v) { u8 t[4]; memcpy(t, &v, 4); b.insert(b.end(), t, t + 4); }
    void u(u32 v) { u8 t[4]; memcpy(t, &v, 4); b.insert(b.end(), t, t + 4); }
    void q(u64 v) { u8 t[8]; memcpy(t, &v, 8); b.insert(b.end(), t, t + 8); }
    void f(float v) { u8 t[4]; memcpy(t, &v, 4); b.insert(b.end(), t, t + 4); }
    void raw(const std::vector<u8>& v) { b.insert(b.end(), v.begin(), v.end()); }
    void raw(const u8* p, size_t n) { b.insert(b.end(), p, p + n); }
    // UTF-8 -> FString (latin-1 if it fits, otherwise UTF-16)
    void fstr(const std::string& s) {
        if (s.empty()) { i(0); return; }
        std::vector<uint16_t> w; for (size_t k = 0; k < s.size();) { unsigned char c = s[k];
            if (c < 0x80) { w.push_back(c); k++; } else if ((c & 0xE0) == 0xC0 && k + 1 < s.size()) { w.push_back(((c & 0x1F) << 6) | (s[k + 1] & 0x3F)); k += 2; }
            else if (k + 2 < s.size()) { w.push_back(((c & 0x0F) << 12) | ((s[k + 1] & 0x3F) << 6) | (s[k + 2] & 0x3F)); k += 3; } else break; }
        bool latin = true; for (auto c : w) if (c > 0xFF) latin = false;
        if (latin) { i((i32)w.size() + 1); for (auto c : w) b.push_back((u8)c); b.push_back(0); }
        else { i(-((i32)w.size() + 1)); for (auto c : w) { b.push_back((u8)(c & 0xFF)); b.push_back((u8)(c >> 8)); } b.push_back(0); b.push_back(0); }
    }
};

struct FName { i32 idx = 0, num = 0; };
struct Import { FName classPkg, className; i32 outer = 0; FName name; };
struct Export {
    i32 cls = 0, super_ = 0, outer = 0; FName name; i32 archetype = 0; u64 flags = 0;
    i32 serialSize = 0, serialOffset = 0; u32 exportFlags = 0; std::vector<i32> netObjects; u8 guid[16] = {}; u32 packageFlags = 0;
    bool owned = false; std::vector<u8> data;     // owned = replaced data (otherwise read from the file)
};

struct Package {
    std::vector<u8> file;                 // owner of the bytes (load) ...
    const u8* fp = nullptr; size_t fn = 0; // ... or external view (mapped file)
    u32 fileVersion = 0, licensee = 0; i32 headerSize = 0; std::string folder; u32 packageFlags = 0;
    u8 guid[16] = {}; struct Gen { i32 exports, names, net; }; std::vector<Gen> gens;
    i32 engineVer = 0, cookerVer = 0; u32 compressionFlags = 0, packageSource = 0; std::vector<std::string> additional;
    std::vector<std::pair<std::string, u64>> names; std::vector<Import> imports; std::vector<Export> exports;
    std::vector<u8> dependsRaw, gapAfterSummary;
    size_t summaryEnd = 0;
    bool bigEndian = false;              // console package (Xbox 360 beta): big-endian object data, read only (bmbeta.hpp)

    void load(const std::string& path) {
        std::ifstream f(path, std::ios::binary); if (!f) throw Err("cannot open: " + path);
        f.seekg(0, std::ios::end); size_t n = (size_t)f.tellg(); f.seekg(0);
        file.resize(n); if (n) f.read((char*)file.data(), n);
        { std::vector<u8> d; wasCompressed = decompress(file.data(), file.size(), d); if (wasCompressed) file.swap(d); }
        fp = file.data(); fn = file.size();
        parse();
    }
    void loadBytes(std::vector<u8>&& v) { file = std::move(v); { std::vector<u8> d; wasCompressed = decompress(file.data(), file.size(), d); if (wasCompressed) file.swap(d); } fp = file.data(); fn = file.size(); parse(); }
    bool wasCompressed = false;          // the file on disk was compressed (it was decompressed on load)
    // Compressed package (LZO, like the vanilla BmGame.u/umaps): builds the decompressed image keeping EXACTLY the
    // original offsets: the decompressed stream already uses "logical" offsets, which assume the summary WITHOUT the
    // chunk table (CompressionFlags = 0, nChunks = 0, PackageSource/AdditionalPackages right after) - which is exactly
    // what we write. Flag PKG_StoreCompressed (0x02000000) removed.
    // Returns true (and the image in 'out') if the package was compressed; false if it was not (out untouched).
    static bool decompress(const u8* vp, size_t vn, std::vector<u8>& out) {
        Reader r(vp, vn);
        if (vn < 64 || r.u() != TAG) return false;
        u32 ver = r.u(); if ((ver & 0xFFFF) != 576) return false;
        r.i(); r.fstr(); size_t flagsPos = r.p; r.u();
        r.p += 7 * 4 + 16; i32 gc = r.i(); if (gc < 0 || gc > 100000) return false; r.p += (size_t)gc * 12;
        r.i(); r.i(); size_t cfPos = r.p; u32 cflags = r.u(); size_t ncPos = r.p; i32 nc = r.i();
        if (nc == 0) return false;
        if (nc < 0 || nc > 100000) throw Err("compressed package: bad chunk count");
        if (!(cflags & 2)) throw Err("compressed package (only LZO is supported)");
        struct Ch { i32 uo, us, co, cs; }; std::vector<Ch> ch(nc);
        for (auto& c : ch) { c.uo = r.i(); c.us = r.i(); c.co = r.i(); c.cs = r.i(); }
        std::vector<u8> tail; { size_t q = r.p; r.u(); i32 na = r.i(); for (i32 k = 0; k < na; k++) r.fstr(); tail.assign(vp + q, vp + r.p); }
        size_t total = 0, hdrEnd = (size_t)-1;
        for (auto& c : ch) { if (c.uo < 0 || c.us < 0 || c.co < 0 || c.cs < 0 || (size_t)c.co + c.cs > vn) throw Err("compressed package: chunk outside the file");
            total = std::max(total, (size_t)c.uo + c.us); hdrEnd = std::min(hdrEnd, (size_t)c.uo); }
        size_t sumLen = ncPos + 4 + tail.size();   // logical summary (without the chunk table)
        if (hdrEnd != sumLen) throw Err("compressed package: unexpected summary layout");
        out.assign(total, 0);
        memcpy(out.data(), vp, ncPos + 4);
        for (auto& c : ch) {
            Reader cr(vp, vn, (size_t)c.co);
            if (cr.u() != TAG) throw Err("compressed package: bad chunk tag");
            i32 bs = cr.i(); i32 csz = cr.i(); i32 usz = cr.i(); (void)csz;
            if (bs <= 0 || usz != c.us) throw Err("compressed package: bad chunk header");
            i32 nb = (usz + bs - 1) / bs; std::vector<std::pair<i32, i32>> blk(nb);
            for (auto& b : blk) { b.first = cr.i(); b.second = cr.i(); }
            size_t src = cr.p, dst = (size_t)c.uo;
            for (auto& b : blk) {
                if (b.first < 0 || b.second < 0 || src + b.first > vn || dst + b.second > out.size()) throw Err("compressed package: block outside bounds");
                size_t got = 0;
                if (!lzo1xDecompress(vp + src, (size_t)b.first, out.data() + dst, (size_t)b.second, &got) || got != (size_t)b.second)
                    throw Err("compressed package: LZO data corrupted");
                src += b.first; dst += b.second;
            }
        }
        u32 pf; memcpy(&pf, &out[flagsPos], 4); pf &= ~0x02000000u; memcpy(&out[flagsPos], &pf, 4);
        u32 z = 0; memcpy(&out[cfPos], &z, 4); memcpy(&out[ncPos], &z, 4);
        memcpy(&out[ncPos + 4], tail.data(), tail.size());
        return true;
    }
    // external view without a copy; if the package is compressed, it becomes the owner of the decompressed image (the view can be released)
    void attach(const u8* p, size_t n) { file.clear(); wasCompressed = decompress(p, n, file);
        if (wasCompressed) { fp = file.data(); fn = file.size(); } else { file.clear(); fp = p; fn = n; } parse();
    }
    void parse() {
        Reader r(fp, fn);
        if (r.u() != TAG) throw Err("not an Unreal package");
        u32 v = r.u(); fileVersion = v & 0xFFFF; licensee = v >> 16;
        headerSize = r.i(); folder = r.fstr(); packageFlags = r.u();
        i32 nameCount = r.i(), nameOff = r.i(), expCount = r.i(), expOff = r.i(), impCount = r.i(), impOff = r.i();
        i32 dependsOff = r.i(); r.need(16); memcpy(guid, fp + r.p, 16); r.p += 16;
        i32 gc = r.i(); gens.clear(); for (i32 k = 0; k < gc; k++) { Gen g; g.exports = r.i(); g.names = r.i(); g.net = r.i(); gens.push_back(g); }
        engineVer = r.i(); cookerVer = r.i(); compressionFlags = r.u();
        if (r.i() != 0) throw Err("compressed package (not supported)");
        packageSource = r.u(); i32 na = r.i(); additional.clear(); for (i32 k = 0; k < na; k++) additional.push_back(r.fstr());
        summaryEnd = r.p;
        origNameOff = nameOff; origImpOff = impOff; origExpOff = expOff; origExpCount = (size_t)expCount; origNameCount = (size_t)nameCount;
        if (fileVersion != 576 || licensee != 21) throw Err("unexpected package version (expected v576/lic21 - Arkham Asylum PC)");
        r.p = nameOff; names.clear(); names.reserve(nameCount);
        for (i32 k = 0; k < nameCount; k++) { std::string s = r.fstr(); u64 fl = r.q(); names.push_back({ s, fl }); }
        origNameLen = (i32)(r.p - nameOff);
        r.p = impOff; imports.assign(impCount, Import());
        for (auto& im : imports) { im.classPkg.idx = r.i(); im.classPkg.num = r.i(); im.className.idx = r.i(); im.className.num = r.i(); im.outer = r.i(); im.name.idx = r.i(); im.name.num = r.i(); }
        origImpLen = (i32)(r.p - impOff);
        r.p = expOff; exports.assign(expCount, Export());
        for (auto& e : exports) {
            e.cls = r.i(); e.super_ = r.i(); e.outer = r.i(); e.name.idx = r.i(); e.name.num = r.i(); e.archetype = r.i(); e.flags = r.q();
            e.serialSize = r.i(); e.serialOffset = r.i(); e.exportFlags = r.u(); i32 nn = r.i(); e.netObjects.resize(nn); for (auto& x : e.netObjects) x = r.i();
            r.need(16); memcpy(e.guid, fp + r.p, 16); r.p += 16; e.packageFlags = r.u();
            if (e.serialSize && ((size_t)e.serialOffset + (size_t)e.serialSize > fn || e.serialOffset < 0)) throw Err("export outside the file");
        }
        origExpLen = (i32)(r.p - expOff); origDependsOff = dependsOff;
        dependsRaw.assign(fp + (dependsOff ? dependsOff : headerSize), fp + headerSize);
        size_t firstTable = (size_t)std::min(nameOff, std::min(impOff, expOff));
        gapAfterSummary.assign(fp + summaryEnd, fp + firstTable);
    }
    // ---- names / paths
    std::string nm(const FName& f) const { if (f.idx < 0 || f.idx >= (i32)names.size()) return "?"; return f.num == 0 ? names[f.idx].first : names[f.idx].first + "_" + std::to_string(f.num - 1); }
    i32 findName(const std::string& s) const { for (size_t k = 0; k < names.size(); k++) if (strcasecmp_(names[k].first, s)) return (i32)k; return -1; }
    i32 addName(const std::string& s, u64 flags = 0x0007001000000000ull) { i32 k = findName(s); if (k >= 0) return k; names.push_back({ s, flags }); return (i32)names.size() - 1; }
    static bool strcasecmp_(const std::string& a, const std::string& b) { if (a.size() != b.size()) return false; for (size_t k = 0; k < a.size(); k++) if (tolower((unsigned char)a[k]) != tolower((unsigned char)b[k])) return false; return true; }
    std::string objName(i32 idx) const { if (idx > 0) return nm(exports[idx - 1].name); if (idx < 0) return nm(imports[-idx - 1].name); return "None"; }
    i32 outerOf(i32 idx) const { return idx > 0 ? exports[idx - 1].outer : imports[-idx - 1].outer; }
    std::string objPath(i32 idx) const { std::vector<std::string> p; int guard = 0; while (idx && guard++ < 64) { p.push_back(objName(idx)); idx = outerOf(idx); }
        std::string s; for (size_t k = p.size(); k-- > 0;) { s += p[k]; if (k) s += "."; } return s; }
    std::string classOf(const Export& e) const { return e.cls == 0 ? "Class" : objName(e.cls); }
    i32 findPath(const std::string& path) const {
        for (size_t k = 0; k < exports.size(); k++) if (strcasecmp_(objPath((i32)k + 1), path)) return (i32)k + 1;
        for (size_t k = 0; k < imports.size(); k++) if (strcasecmp_(objPath(-(i32)k - 1), path)) return -(i32)k - 1;
        return 0;
    }
    i32 ensureRef(const std::string& path, const std::string& clsPkg, const std::string& cls) {
        i32 idx = findPath(path); if (idx) return idx;
        size_t dot = path.rfind('.'); i32 outer = 0;
        if (dot != std::string::npos) outer = ensureRef(path.substr(0, dot), "Core", "Package");
        Import im; im.classPkg.idx = addName(clsPkg); im.className.idx = addName(cls); im.outer = outer;
        im.name.idx = addName(dot == std::string::npos ? path : path.substr(dot + 1));
        imports.push_back(im); return -(i32)imports.size();
    }
    // ---- export data
    const u8* dataPtr(const Export& e) const { return e.owned ? e.data.data() : fp + e.serialOffset; }
    size_t dataLen(const Export& e) const { return e.owned ? e.data.size() : (size_t)e.serialSize; }
    std::vector<u8> dataCopy(const Export& e) const { const u8* p = dataPtr(e); return std::vector<u8>(p, p + dataLen(e)); }

    // ---- writing (same as bmcore.serialize)
    static void fixInlineBulk(std::vector<u8>& d, i32 oldBase, i32 newBase) {
        if (oldBase == newBase || d.size() < 16) return;
        size_t n = d.size(), k = 0;
        while (k + 16 <= n) {
            i32 off; memcpy(&off, &d[k + 12], 4);
            if ((int64_t)off == (int64_t)oldBase + (int64_t)k + 16) {
                u32 fl; i32 cnt, size; memcpy(&fl, &d[k], 4); memcpy(&cnt, &d[k + 4], 4); memcpy(&size, &d[k + 8], 4);
                if (size >= 0 && k + 16 + (size_t)size <= n && fl < 0x10000 && cnt >= 0) { i32 nv = newBase + (i32)k + 16; memcpy(&d[k + 12], &nv, 4); k += 16 + size; continue; }
            }
            k++;
        }
    }
    // ---- FAITHFUL save (editor): keeps the original layout (including gaps between exports), swaps only the modified
    // exports, recomputes SerialOffset for all of them and fixes absolute offsets of inline bulk data.
    // With no change at all, the result is byte-identical to the original file.
    template <class Sink> void save(Sink& out) const {
        auto summary = [&](i32 ho, i32 no, i32 eo, i32 io, i32 dofs) {
            Writer w; w.u(TAG); w.u(fileVersion | (licensee << 16)); w.i(ho); w.fstr(folder); w.u(packageFlags);
            w.i((i32)names.size()); w.i(no); w.i((i32)exports.size()); w.i(eo); w.i((i32)imports.size()); w.i(io); w.i(dofs);
            w.raw(guid, 16); w.i((i32)gens.size()); for (auto& g : gens) { w.i(g.exports == origExpCount ? (i32)exports.size() : g.exports); w.i(g.names == origNameCount ? (i32)names.size() : g.names); w.i(g.net); }
            w.i(engineVer); w.i(cookerVer); w.u(compressionFlags); w.i(0); w.u(packageSource); w.i((i32)additional.size()); for (auto& a : additional) w.fstr(a);
            return w.b;
        };
        Writer wn; for (auto& nmv : names) { wn.fstr(nmv.first); wn.q(nmv.second); }
        Writer wi; for (auto& im : imports) { wi.i(im.classPkg.idx); wi.i(im.classPkg.num); wi.i(im.className.idx); wi.i(im.className.num); wi.i(im.outer); wi.i(im.name.idx); wi.i(im.name.num); }
        auto expBlob = [&](const std::vector<i32>& offs) {
            Writer we; for (size_t k = 0; k < exports.size(); k++) { const Export& e = exports[k]; size_t len = dataLen(e);
                we.i(e.cls); we.i(e.super_); we.i(e.outer); we.i(e.name.idx); we.i(e.name.num); we.i(e.archetype); we.q(e.flags);
                we.i((i32)len); we.i(len ? offs[k] : (k < origExpCount ? e.serialOffset : 0)); we.u(e.exportFlags); we.i((i32)e.netObjects.size()); for (auto x : e.netObjects) we.i(x);
                we.raw(e.guid, 16); we.u(e.packageFlags); }
            return we.b;
        };
        // original layout: tables in the order they had in the file, each one followed by its original gaps.
        // The export table may be OUTSIDE the header (package touched by UPK Explorer): then it stays in the same place in the body.
        std::vector<i32> zero(exports.size(), 0);
        std::vector<u8> sm = summary(0, 0, 0, 0, 0), eb0 = expBlob(zero);
        bool relocTable = origExpOff >= headerSize;
        struct Tab { i32 origOff; i32 origLen; int kind; size_t len; };
        std::vector<Tab> tabs = { { origNameOff, origNameLen, 0, wn.b.size() }, { origImpOff, origImpLen, 1, wi.b.size() } };
        if (!relocTable) tabs.push_back({ origExpOff, origExpLen, 2, eb0.size() });
        std::sort(tabs.begin(), tabs.end(), [](const Tab& a, const Tab& b) { return a.origOff < b.origOff; });
        i32 dependsStart = origDependsOff ? origDependsOff : headerSize;
        std::vector<std::pair<size_t, size_t>> tabGap(tabs.size());          // original bytes between the end of each table and the next block
        for (size_t t = 0; t < tabs.size(); t++) { i32 e0 = tabs[t].origOff + tabs[t].origLen; i32 nx = t + 1 < tabs.size() ? tabs[t + 1].origOff : dependsStart;
            tabGap[t] = (nx > e0) ? std::make_pair((size_t)e0, (size_t)(nx - e0)) : std::make_pair((size_t)0, (size_t)0); }
        i32 cur = (i32)(sm.size() + gapAfterSummary.size()); i32 no = 0, io = 0, eo = 0;
        for (size_t t = 0; t < tabs.size(); t++) { if (tabs[t].kind == 0) no = cur; else if (tabs[t].kind == 1) io = cur; else eo = cur; cur += (i32)tabs[t].len + (i32)tabGap[t].second; }
        // DependsMap: 1 TArray<INT> per export (cooked: count 0). New exports get empty entries.
        std::vector<u8> depOut = dependsRaw; if (dependsRaw.size() == origExpCount * 4 && exports.size() > origExpCount) depOut.resize(exports.size() * 4, 0);
        i32 dofs = cur; i32 ho = dofs + (i32)depOut.size();
        // body: regions of the original file in order; exports swapped for the new data
        struct Item { size_t off; size_t len; long k; };           // k = export index, -1 = relocated export table
        std::vector<Item> items; for (size_t k = 0; k < exports.size() && k < origExpCount; k++) if (exports[k].serialSize > 0) items.push_back({ (size_t)exports[k].serialOffset, (size_t)exports[k].serialSize, (long)k });
        if (relocTable) items.push_back({ (size_t)origExpOff, (size_t)origExpLen, -1 });
        std::stable_sort(items.begin(), items.end(), [](const Item& a, const Item& b) { return a.off < b.off; });
        std::vector<i32> offs(exports.size(), 0);
        struct Piece { const u8* p; size_t n; std::vector<u8> own; int table; };
        std::vector<Piece> body; i32 pos = ho; size_t oldPos = (size_t)headerSize;
        for (auto& it : items) {
            if (it.off > oldPos) { body.push_back({ fp + oldPos, it.off - oldPos, {}, 0 }); pos += (i32)(it.off - oldPos); oldPos = it.off; }
            else if (it.off < oldPos) throw Err("overlapping exports (not supported)");
            if (it.k < 0) { eo = pos; pos += (i32)eb0.size(); body.push_back({ nullptr, 0, {}, 1 }); oldPos = it.off + it.len; continue; }
            const Export& e = exports[it.k];
            std::vector<u8> d = dataCopy(e);
            fixInlineBulkEdited(d, e.serialOffset, pos, (i64)dataLen(e) - (i64)e.serialSize);
            offs[it.k] = pos; pos += (i32)d.size(); body.push_back({ nullptr, 0, std::move(d), 0 });
            oldPos = it.off + it.len;
        }
        if (oldPos < fn) { body.push_back({ fp + oldPos, fn - oldPos, {}, 0 }); pos += (i32)(fn - oldPos); }
        for (size_t k = origExpCount; k < exports.size(); k++) { std::vector<u8> d = dataCopy(exports[k]); if (d.empty()) continue; fixInlineBulk(d, exports[k].serialOffset, pos); offs[k] = pos; pos += (i32)d.size(); body.push_back({ nullptr, 0, std::move(d), 0 }); }
        std::vector<u8> eb = expBlob(offs);
        // writes
        std::vector<u8> s2 = summary(ho, no, eo, io, dofs); out(s2.data(), s2.size());
        out(gapAfterSummary.data(), gapAfterSummary.size());
        for (size_t t = 0; t < tabs.size(); t++) { if (tabs[t].kind == 0) out(wn.b.data(), wn.b.size()); else if (tabs[t].kind == 1) out(wi.b.data(), wi.b.size()); else out(eb.data(), eb.size());
            if (tabGap[t].second) out(fp + tabGap[t].first, tabGap[t].second); }
        out(depOut.data(), depOut.size());
        for (auto& pc : body) { if (pc.table) out(eb.data(), eb.size()); else if (pc.p) out(pc.p, pc.n); else out(pc.own.data(), pc.own.size()); }
    }
    std::vector<u8> saveToMemory() const { std::vector<u8> v; auto sink = [&](const u8* p, size_t n) { v.insert(v.end(), p, p + n); }; save(sink); return v; }
    // inline bulk in an EDITED export: the header may have moved 'delta' bytes (size change before it)
    typedef long long i64;
    static void fixInlineBulkEdited(std::vector<u8>& d, i32 oldBase, i32 newBase, i64 delta) {
        if (d.size() < 16) return;
        size_t n = d.size(), k = 0;
        while (k + 16 <= n) {
            i32 off; memcpy(&off, &d[k + 12], 4);
            i64 rel = (i64)off - (i64)oldBase - 16;               // ORIGINAL position of the header
            bool hit = rel == (i64)k || (delta != 0 && rel == (i64)k - delta);
            if (hit) {
                u32 fl; i32 cnt, size; memcpy(&fl, &d[k], 4); memcpy(&cnt, &d[k + 4], 4); memcpy(&size, &d[k + 8], 4);
                if (size >= 0 && k + 16 + (size_t)size <= n && fl < 0x10000 && cnt >= 0) { i32 nv = newBase + (i32)k + 16; memcpy(&d[k + 12], &nv, 4); k += 16 + size; continue; }
            }
            k++;
        }
    }
    // values kept from the original file
    size_t origExpCount = 0, origNameCount = 0; i32 origNameOff = 0, origImpOff = 0, origExpOff = 0, origNameLen = 0, origImpLen = 0, origExpLen = 0, origDependsOff = 0;
    std::vector<u8> serialize() const {
        auto summary = [&](i32 ho, i32 no, i32 eo, i32 io, i32 dofs) {
            Writer w; w.u(TAG); w.u(fileVersion | (licensee << 16)); w.i(ho); w.fstr(folder); w.u(packageFlags);
            w.i((i32)names.size()); w.i(no); w.i((i32)exports.size()); w.i(eo); w.i((i32)imports.size()); w.i(io); w.i(dofs);
            w.raw(guid, 16); w.i((i32)gens.size()); for (auto& g : gens) { w.i((i32)exports.size()); w.i((i32)names.size()); w.i(g.net); }
            w.i(engineVer); w.i(cookerVer); w.u(compressionFlags); w.i(0); w.u(packageSource); w.i((i32)additional.size()); for (auto& a : additional) w.fstr(a);
            return w.b;
        };
        Writer wn; for (auto& nmv : names) { wn.fstr(nmv.first); wn.q(nmv.second); }
        Writer wi; for (auto& im : imports) { wi.i(im.classPkg.idx); wi.i(im.classPkg.num); wi.i(im.className.idx); wi.i(im.className.num); wi.i(im.outer); wi.i(im.name.idx); wi.i(im.name.num); }
        auto expBlob = [&](const std::vector<i32>& offs) {
            Writer we; for (size_t k = 0; k < exports.size(); k++) { const Export& e = exports[k]; size_t len = dataLen(e);
                we.i(e.cls); we.i(e.super_); we.i(e.outer); we.i(e.name.idx); we.i(e.name.num); we.i(e.archetype); we.q(e.flags);
                we.i((i32)len); we.i(len ? offs[k] : 0); we.u(e.exportFlags); we.i((i32)e.netObjects.size()); for (auto x : e.netObjects) we.i(x);
                we.raw(e.guid, 16); we.u(e.packageFlags); }
            return we.b;
        };
        std::vector<u8> sm = summary(0, 0, 0, 0, 0);
        i32 no = (i32)(sm.size() + gapAfterSummary.size());
        i32 io = no + (i32)wn.b.size();
        i32 eo = io + (i32)wi.b.size();
        std::vector<i32> zero(exports.size(), 0);
        i32 dofs = eo + (i32)expBlob(zero).size();
        i32 ho = dofs + (i32)dependsRaw.size();
        std::vector<size_t> order(exports.size()); for (size_t k = 0; k < order.size(); k++) order[k] = k;
        std::stable_sort(order.begin(), order.end(), [&](size_t a, size_t b) { return exports[a].serialOffset < exports[b].serialOffset; });
        std::vector<i32> offs(exports.size(), 0); std::vector<u8> body; i32 cur = ho;
        for (size_t k : order) { const Export& e = exports[k]; size_t len = dataLen(e); if (!len) continue;
            std::vector<u8> d = dataCopy(e); fixInlineBulk(d, e.serialOffset, cur); offs[k] = cur; body.insert(body.end(), d.begin(), d.end()); cur += (i32)len; }
        std::vector<u8> out = summary(ho, no, eo, io, dofs);
        out.insert(out.end(), gapAfterSummary.begin(), gapAfterSummary.end());
        out.insert(out.end(), wn.b.begin(), wn.b.end()); out.insert(out.end(), wi.b.begin(), wi.b.end());
        std::vector<u8> eb = expBlob(offs); out.insert(out.end(), eb.begin(), eb.end());
        out.insert(out.end(), dependsRaw.begin(), dependsRaw.end()); out.insert(out.end(), body.begin(), body.end());
        return out;
    }
};

// ---- properties (UE3 v576 tags)
struct Tag { std::string name, type, strct; i32 index = 0; bool isBool = false; i32 boolVal = 0; std::vector<u8> raw; };

inline std::vector<Tag> readProps(const Package& pk, const u8* d, size_t n, size_t pos, size_t* endPos) {
    Reader r(d, n, pos); std::vector<Tag> out;
    for (int guard = 0; guard < 10000; guard++) {
        FName f; f.idx = r.i(); f.num = r.i(); std::string name = pk.nm(f); if (name == "None") break;
        Tag t; t.name = name; FName ty; ty.idx = r.i(); ty.num = r.i(); t.type = pk.nm(ty); i32 size = r.i(); t.index = r.i();
        if (t.type == "StructProperty") { FName s; s.idx = r.i(); s.num = r.i(); t.strct = pk.nm(s); }
        if (t.type == "BoolProperty") { t.isBool = true; t.boolVal = r.i(); out.push_back(t); continue; }
        if (size < 0) throw Err("invalid property");
        t.raw = r.raw((size_t)size); out.push_back(t);
    }
    if (endPos) *endPos = r.p;
    return out;
}
inline std::vector<u8> writeProps(Package& pk, const std::vector<Tag>& tags) {
    Writer w; i32 none = pk.addName("None");
    for (auto& t : tags) {
        w.i(pk.addName(t.name)); w.i(0); w.i(pk.addName(t.type)); w.i(0);
        w.i(t.isBool ? 0 : (i32)t.raw.size()); w.i(t.index);
        if (t.type == "StructProperty") { w.i(pk.addName(t.strct)); w.i(0); }
        if (t.isBool) { w.i(t.boolVal ? 1 : 0); continue; }
        w.raw(t.raw);
    }
    w.i(none); w.i(0);
    return w.b;
}
inline Tag objTag(const std::string& name, i32 idx) { Tag t; t.name = name; t.type = "ObjectProperty"; t.raw.resize(4); memcpy(t.raw.data(), &idx, 4); return t; }
inline i32 tagObj(const Tag& t) { i32 v = 0; if (t.raw.size() >= 4) memcpy(&v, t.raw.data(), 4); return v; }

// ---- where the property list of an export starts
// UObject::Serialize (BAA): [StateFrame if RF_HasStack] [Component: TemplateOwnerClass (+TemplateName if template)] NetIndex, props
inline bool isPropType(const std::string& t) {
    static const char* k[] = { "IntProperty", "FloatProperty", "BoolProperty", "ByteProperty", "NameProperty", "StrProperty", "ObjectProperty", "ClassProperty",
        "ComponentProperty", "InterfaceProperty", "StructProperty", "ArrayProperty", "MapProperty", "DelegateProperty", "StringRefProperty" };
    for (auto s : k) if (t == s) return true; return false;
}
inline bool isTemplateObj(const Package& pk, i32 idx) {   // it or some outer is a CDO/archetype
    for (int g = 0; idx > 0 && g < 64; g++) { const Export& e = pk.exports[idx - 1]; if (e.flags & 0x600ull) return true; idx = e.outer; } return false;
}
// returns the offset of the property list (or -1 if not found)
inline long findPropStart(const Package& pk, i32 idx) {
    const Export& e = pk.exports[idx - 1]; const u8* d = pk.dataPtr(e); size_t n = pk.dataLen(e);
    if (e.cls == 0) return -1;                                           // UClass: no tags
    std::string cls = pk.classOf(e);
    if (cls == "Function" || cls == "State" || cls == "ScriptStruct" || cls == "Const" || cls == "Enum" || cls == "Class" || (isPropType(cls) || cls == "Property")) return -1;
    auto ok = [&](size_t off) -> bool {
        if (off + 8 > n) return false;
        FName f; memcpy(&f.idx, d + off, 4); memcpy(&f.num, d + off + 4, 4);
        if (f.idx < 0 || f.idx >= (i32)pk.names.size() || f.num < 0 || f.num > 100000) return false;
        if (pk.nm(f) == "None") return off + 8 == n || true;
        if (off + 24 > n) return false;
        FName t; memcpy(&t.idx, d + off + 8, 4); memcpy(&t.num, d + off + 12, 4);
        if (t.idx < 0 || t.idx >= (i32)pk.names.size() || !isPropType(pk.nm(t))) return false;
        try { size_t end = 0; readProps(pk, d, n, off, &end); return true; } catch (...) { return false; }
    };
    std::vector<size_t> cand;
    bool stack = (e.flags & 0x0200000000000000ull) != 0;
    bool comp = cls.find("Component") != std::string::npos;
    size_t base = 0;
    if (stack) {   // BAA FStateFrame: Node, StateNode, ProbeMask(8), LatentAction(2), StateStack(TArray<Node,State,Offset>), [Offset if Node]
        if (n < 22) return -1;
        i32 node; memcpy(&node, d, 4); i32 cnt; memcpy(&cnt, d + 18, 4);
        if (cnt < 0 || cnt > 64) cnt = 0;
        base = 22 + (size_t)cnt * 12 + (node ? 4 : 0);
    }
    if (comp) { cand.push_back(base + (isTemplateObj(pk, idx) ? 16 : 8)); cand.push_back(base + 16); cand.push_back(base + 8); }
    cand.push_back(base + 4);
    for (size_t c : cand) if (ok(c)) return (long)c;
    // template subobject (components of non-"Component" classes: Distribution*, SpeechManager...): TemplateOwnerClass+TemplateName
    for (size_t c : { base + 16, base + 8 }) if (ok(c)) {
        FName f; memcpy(&f.idx, d + c, 4); memcpy(&f.num, d + c + 4, 4); if (pk.nm(f) != "None" || c + 8 == n) return (long)c; }
    for (size_t c = 4; c <= 256 && c < n; c++) if (ok(c)) {          // scan: requires a real tag, not just "None"
        FName f; memcpy(&f.idx, d + c, 4); memcpy(&f.num, d + c + 4, 4); if (pk.nm(f) != "None") return (long)c; }
    return -1;
}

// ---- cooked SkeletalMesh: native header up to the RefSkeleton
struct MeshInfo { std::vector<i32> materials; std::vector<std::string> bones; };
inline MeshInfo parseSkelMesh(const Package& pk, const Export& e) {
    const u8* d = pk.dataPtr(e); size_t n = pk.dataLen(e); size_t p = 0;
    readProps(pk, d, n, 4, &p);
    Reader r(d, n, p); r.p += 28;                  // Bounds
    r.f();                                         // ConservativeBounds (Batman cooked)
    i32 nb = r.i(); if (nb < 0 || nb > 100000) throw Err("invalid mesh"); r.p += (size_t)nb * 28;   // PerBoneBounds
    MeshInfo mi; i32 nm_ = r.i(); if (nm_ < 0 || nm_ > 256) throw Err("invalid mesh"); for (i32 k = 0; k < nm_; k++) mi.materials.push_back(r.i());
    r.p += 24;                                     // Origin + RotOrigin
    i32 bones = r.i(); if (bones < 0 || bones > 1024) throw Err("invalid mesh");
    for (i32 k = 0; k < bones; k++) { FName f; f.idx = r.i(); f.num = r.i(); mi.bones.push_back(pk.nm(f)); r.p += 4 + 16 + 12 + 4 + 4 + 4; }
    return mi;
}

// ---- builds the damage-state package of a level (same as bmcore.skins.build_state_package)
struct MatRef { std::string cls, path; };
inline std::vector<MatRef> meshMaterials(const Package& src, i32 idx) {
    MeshInfo mi = parseSkelMesh(src, src.exports[idx - 1]); std::vector<MatRef> out;
    for (i32 m : mi.materials) { MatRef r; r.cls = m > 0 ? src.classOf(src.exports[m - 1]) : (m < 0 ? src.nm(src.imports[-m - 1].className) : "Material"); r.path = src.objPath(m); if (m) out.push_back(r); }
    return out;
}
inline std::vector<u8> buildStatePackage(std::vector<u8>&& templateBytes, const std::string& stateName,
        const std::string& body, const std::string& head, const std::vector<MatRef>& bodyMats, const std::vector<MatRef>& headMats) {
    Package pk; pk.loadBytes(std::move(templateBytes));
    Export* st = nullptr; for (auto& e : pk.exports) if (pk.classOf(e) == "RBatmanDamageState") { st = &e; break; }
    if (!st) throw Err("RBatmanDamageState not found");
    std::string oldState = pk.nm(pk.exports[st->outer - 1].name);
    for (auto& e : pk.exports) if (pk.classOf(e) == "Package") { std::string n = pk.nm(e.name);
        if (n == oldState) { e.name.idx = pk.addName(stateName); e.name.num = 0; }
        else if (n == oldState + "_SF") { e.name.idx = pk.addName(stateName + "_SF"); e.name.num = 0; } }
    std::vector<u8> data = pk.dataCopy(*st); size_t end = 0;
    std::vector<Tag> tags = readProps(pk, data.data(), data.size(), 4, &end);
    std::vector<Tag> out;
    if (!body.empty()) out.push_back(objTag("BodyMesh", pk.ensureRef(body, "Engine", "SkeletalMesh")));
    if (!head.empty()) out.push_back(objTag("HeadMesh", pk.ensureRef(head, "Engine", "SkeletalMesh")));
    for (size_t k = 0; k < bodyMats.size() && k < 2; k++) out.push_back(objTag("BodyMaterial" + std::to_string(k), pk.ensureRef(bodyMats[k].path, "Engine", bodyMats[k].cls)));
    for (size_t k = 0; k < headMats.size() && k < 2; k++) out.push_back(objTag("HeadMaterial" + std::to_string(k), pk.ensureRef(headMats[k].path, "Engine", headMats[k].cls)));
    for (auto& t : tags) if (t.name == "CapeMaterial") out.push_back(t);
    std::vector<u8> props = writeProps(pk, out);
    std::vector<u8> nd(data.begin(), data.begin() + 4); nd.insert(nd.end(), props.begin(), props.end()); nd.insert(nd.end(), data.begin() + end, data.end());
    st->data = nd; st->owned = true;
    for (int k = 0; k < 16; k++) pk.guid[k] = (u8)(rand() & 0xFF);
    return pk.serialize();
}

} // namespace bm
