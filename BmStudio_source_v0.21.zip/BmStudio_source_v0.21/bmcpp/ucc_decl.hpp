// ucc_decl.hpp - adding members to an existing class: new variables (var), functions and events (including
// overrides of parent class functions/events). Creates the exports (UFunction/UProperty), links them into the children list,
// registers them in the class FuncMap and compiles the body with the compiler (ucc_compile.hpp).
#pragma once
#include "ucc_edit.hpp"

namespace bm {
namespace ucc {

struct ParamDecl { std::string type, name; int dim = 1; bool out = false, optional = false, coerce = false, cnst = false; std::string def; };
struct FuncDecl { bool isEvent = false; u32 mods = 0; std::string ret, name; std::vector<ParamDecl> params; std::string body; int line = 0, bodyLine = 0; };
struct VarDecl { std::string type; std::vector<std::pair<std::string, int>> names; uint64_t flags = 0; bool edit = false; std::string category; int line = 0; };
struct DefaultEntry { std::string name; int index = 0; std::string value; int line = 0; };
struct MembersDecl { std::vector<VarDecl> vars; std::vector<FuncDecl> funcs; std::vector<DefaultEntry> defaults; bool hasClass = false; std::string className, superName; bool placeable = false, abstract_ = false; int classLine = 0; };

// ---------------------------------------------------------- member parser
class MemberParser : public Parser {
public:
    const std::string& src;
    MemberParser(const std::string& s, const OpTable& o) : Parser(s, o), src(s) {}
    std::string typeName() { return typeText(); }
    MembersDecl parse() {
        MembersDecl m;
        if (isKw("class")) {   // class Name extends Parent [placeable|abstract|notplaceable|hidecategories(...)...];
            m.hasClass = true; m.classLine = cur().line; p++; m.className = ident();
            if (!acceptKw("extends")) fail("expected 'extends' (new classes must extend an existing class)");
            m.superName = ident();
            while (!isSym(";") && cur().t != TT::End) {
                std::string l = cur().t == TT::Ident ? low(cur().s) : "";
                if (l == "placeable") m.placeable = true; else if (l == "abstract") m.abstract_ = true;
                else if (l == "notplaceable" || l == "hidecategories" || l == "collapsecategories" || l == "dependson") {}
                else if (l == "native" || l == "within" || l == "config" || l == "perobjectconfig" || l == "implements" || l == "interface") fail("'" + l + "' is not supported for new classes");
                p++; if (isSym("(")) { int d = 0; do { if (isSym("(")) d++; else if (isSym(")")) d--; p++; } while (d > 0 && cur().t != TT::End); }
            }
            expect(";");
        }
        while (cur().t != TT::End) {
            if (accept(";")) continue;
            if (isKw("var")) { m.vars.push_back(varDecl()); continue; }
            if (isKw("defaultproperties")) { p++; defaultsBlock(m.defaults); continue; }
            m.funcs.push_back(funcDecl());
        }
        return m;
    }
    // defaultproperties { Name=Value  Name(2)=Value ... }  (value = text up to the end of the line)
    void defaultsBlock(std::vector<DefaultEntry>& out) {
        expect("{");
        while (!isSym("}")) {
            if (cur().t == TT::End) fail("missing '}' in defaultproperties");
            if (accept(";")) continue;
            DefaultEntry d; d.line = cur().line; d.name = ident();
            if (accept("(") || accept("[")) { if (cur().t != TT::Int) fail("expected index"); d.index = (int)cur().iv; p++; if (!accept(")")) expect("]"); }
            expect("=");
            size_t a = cur().pos; int ln = cur().line; size_t e = a;
            while (cur().t != TT::End && cur().line == ln && !isSym("}")) { e = cur().pos + std::max<size_t>(1, cur().s.size()); if (cur().t == TT::Str) e = src.find('"', cur().pos + 1) + 1; if (cur().t == TT::Name) e = src.find('\'', cur().pos + 1) + 1; p++; if (isSym(";") && cur().line == ln) { p++; break; } }
            d.value = src.substr(a, e - a); while (!d.value.empty() && (isspace((unsigned char)d.value.back()) || d.value.back() == ';')) d.value.pop_back();
            out.push_back(d);
        }
        p++;
    }
    VarDecl varDecl() {
        VarDecl v; v.line = cur().line; p++;   // var
        if (accept("(")) { v.edit = true; if (cur().t == TT::Ident) v.category = ident(); expect(")"); }
        for (;;) {   // modifiers
            std::string l = cur().t == TT::Ident ? low(cur().s) : "";
            uint64_t f = 0;
            if (l == "config") f = 0x4000; else if (l == "globalconfig") f = 0x40000 | 0x4000; else if (l == "transient") f = 0x2000; else if (l == "const") f = 0x2;
            else if (l == "editconst") f = 0x20000; else if (l == "localized") f = 0x8000; else if (l == "export") f = 0x8; else if (l == "editinline") f = 0x4000000;
            else if (l == "private" || l == "protected" || l == "noexport" || l == "duplicatetransient" || l == "noimport") f = 0;
            else if (l == "native" || l == "repnotify") fail("'" + l + "' is not allowed for new variables");
            else break;
            v.flags |= f; p++;
        }
        if (v.edit) v.flags |= 0x1;
        v.type = typeName();
        do { std::string n = ident(); int dim = 1; if (accept("[")) { if (cur().t != TT::Int) fail("expected array size"); dim = (int)cur().iv; p++; expect("]"); } v.names.push_back({ n, dim }); } while (accept(","));
        expect(";");
        return v;
    }
    FuncDecl funcDecl() {
        FuncDecl f; f.line = cur().line;
        for (;;) {
            std::string l = cur().t == TT::Ident ? low(cur().s) : "";
            if (l == "function") { p++; break; }
            if (l == "event") { p++; f.isEvent = true; f.mods |= FUNC_Event; break; }
            if (l == "simulated") f.mods |= 0x100; else if (l == "final") f.mods |= FUNC_Final; else if (l == "static") f.mods |= FUNC_Static; else if (l == "exec") f.mods |= 0x200;
            else if (l == "singular") f.mods |= 0x20; else if (l == "private") f.mods |= 0x40000 | FUNC_Final; else if (l == "protected") f.mods |= 0x80000;
            else if (l == "native" || l == "latent" || l == "iterator" || l == "operator" || l == "preoperator" || l == "postoperator" || l == "reliable" || l == "unreliable" || l == "server" || l == "client" || l == "delegate")
                fail("'" + l + "' is not supported for new functions");
            else fail("expected 'var', 'function' or 'event'");
            p++;
        }
        // optional return type
        if (!(cur().t == TT::Ident && isSym("(", 1))) f.ret = typeName();
        f.name = ident(); expect("(");
        if (!accept(")")) {
            for (;;) {
                ParamDecl pd;
                for (;;) { std::string l = cur().t == TT::Ident ? low(cur().s) : "";
                    if (l == "optional") pd.optional = true; else if (l == "out") pd.out = true; else if (l == "coerce") pd.coerce = true; else if (l == "const") pd.cnst = true; else break; p++; }
                pd.type = typeName(); pd.name = ident();
                if (accept("[")) { if (cur().t != TT::Int) fail("expected array size"); pd.dim = (int)cur().iv; p++; expect("]"); }
                if (accept("=")) {   // default value: text up to ',' or ')' at level 0
                    size_t a = cur().pos; int depth = 0;
                    while (cur().t != TT::End) { if (isSym("(")) depth++; else if (isSym(")")) { if (depth == 0) break; depth--; } else if (isSym(",") && depth == 0) break; p++; }
                    pd.def = src.substr(a, cur().pos - a); while (!pd.def.empty() && isspace((unsigned char)pd.def.back())) pd.def.pop_back();
                    pd.optional = true;
                }
                f.params.push_back(pd);
                if (accept(")")) break;
                expect(",");
            }
        }
        if (isKw("const")) p++;
        if (!isSym("{")) fail("expected '{' (function body)");
        size_t open = cur().pos; f.bodyLine = cur().line; int depth = 0; size_t close = std::string::npos;
        while (cur().t != TT::End) { if (isSym("{")) depth++; else if (isSym("}")) { depth--; if (depth == 0) { close = cur().pos; p++; break; } } p++; }
        if (close == std::string::npos) fail("missing '}'");
        f.body = src.substr(open + 1, close - open - 1);
        return f;
    }
};

// ---------------------------------------------------------- creation
class ClassEditor {
public:
    TypeDB& db; Compiler& C; ScriptEditor& E;
    ClassEditor(TypeDB& d, Compiler& c, ScriptEditor& e) : db(d), C(c), E(e) {}
    struct Result { bool ok = false; std::string err; int line = 0; int vars = 0, funcs = 0, overrides = 0; size_t bytecode = 0; std::vector<std::string> notes; };

    // is the class (or some loaded subclass) native? -> a new variable would shift C++ fields
    std::string nativeBlocker(const Ref& cls) {
        if (db.field(cls).classFlags & 0x80) return db.name(cls);
        for (int p = 0; p < (int)db.pkgs.size(); p++) { Package& P = *db.pkgs[p];
            for (size_t k = 0; k < P.exports.size(); k++) { if (P.classOf(P.exports[k]) != "Class") continue; Ref r{ p, (i32)k + 1 };
                if (r != cls && db.isChildOf(r, cls) && (db.field(r).classFlags & 0x80)) return db.name(r); } }
        return "";
    }
    bool sameSig(const Ref& a, const FuncDecl& d, std::string* why) {
        const auto& ps = C.params(a);
        if (ps.size() != d.params.size()) { *why = "parameter count differs (" + std::to_string(ps.size()) + " in the parent)"; return false; }
        Type rt = C.returnType(a); Type dr = d.ret.empty() ? Type() : typeOfText(d.ret, d.line);
        if (!(rt.k == K::None && d.ret.empty()) && !C.sameType(rt, dr)) { *why = "return type differs (parent returns " + C.typeStr(rt) + ")"; return false; }
        for (size_t i = 0; i < ps.size(); i++) {
            Type t = typeOfText(d.params[i].type, d.line);
            if (!C.sameType(ps[i].ty, t) && !(ps[i].ty.k == K::Byte && t.k == K::Byte)) { *why = "parameter " + std::to_string(i + 1) + " type differs (parent: " + C.typeStr(ps[i].ty) + ")"; return false; }
            if (((ps[i].flags & CPF_OutParm) != 0) != d.params[i].out) { *why = "parameter " + std::to_string(i + 1) + ": 'out' differs from the parent"; return false; }
        }
        return true;
    }
    Type typeOfText(const std::string& t, int line) {
        std::string tl = lower(t); Type ty;
        if (tl == "int") ty.k = K::Int; else if (tl == "float") ty.k = K::Float; else if (tl == "bool") ty.k = K::Bool; else if (tl == "byte") ty.k = K::Byte;
        else if (tl == "name") ty.k = K::Name; else if (tl == "string") ty.k = K::String;
        else if (tl.compare(0, 6, "class<") == 0) { ty.k = K::Class; ty.cls = db.findClass(t.substr(6, t.size() - 7)); }
        else if (tl.compare(0, 6, "array<") == 0) { ty.k = K::Array; ty.inner = std::make_shared<Type>(typeOfText(t.substr(6, t.size() - 7), line)); }
        else { Ref c = db.findClass(t); if (c) { bool iface = (db.field(c).classFlags & 0x4000) != 0; ty.k = iface ? K::Interface : K::Object; ty.cls = c; }
            else { Ref s = C.findStructOrEnum(t); if (!s) throw CompileError("unknown type '" + t + "'", line); if (db.cls(s) == "Enum") { ty.k = K::Byte; ty.enm = s; } else { ty.k = K::Struct; ty.strct = s; } } }
        return ty;
    }

    // creates the UFunction (without code), the parameters and the return value; links and registers in the FuncMap
    Ref createFunction(ScriptEditor::Snap& s, const Ref& cls, const FuncDecl& d, Ref superFn) {
        Package& P = db.P(cls);
        u32 flags = 0x2 /*Defined*/ | 0x20000 /*Public*/ | d.mods;
        if (superFn) { u32 sf = db.field(superFn).funcFlags; flags |= sf & (FUNC_Event | 0x100 | 0x200 | FUNC_Static | 0x8000); }
        if (flags & 0x40000) flags &= ~0x20000u;
        i32 noneIdx = P.findName("None"); if (noneIdx < 0) noneIdx = P.addName("None");
        FName nm = C.makeName(d.name);
        Writer x; x.i(0); x.i(noneIdx); x.i(0); x.i(superFn ? C.objIndex(superFn, d.line) : 0); x.i(0); x.i(0); x.i(0); x.i(0); x.i(0); x.i(0); x.i(0);
        x.b.push_back(0); x.b.push_back(0); x.b.push_back(0); x.u(flags); x.i(nm.idx); x.i(nm.num);
        // layout: NetIndex, None(8), SuperField, Next, ScriptText, Children, CppText, Line, TextPos, ScriptSize(0), iNative(2), OperPrec(1), FunctionFlags, FriendlyName
        Export e; Ref fnc = db.findPath("Core.Function"); if (!fnc) fnc = db.findClass("Function");
        e.cls = C.objIndex(fnc, d.line); e.super_ = superFn ? C.objIndex(superFn, d.line) : 0; e.outer = cls.idx; e.name = nm; e.archetype = 0; e.flags = 0x0007000400000000ull;
        e.exportFlags = P.exports[cls.idx - 1].exportFlags;   // class inside a map BmScript (forced): members too
        e.owned = true; e.data = x.b;
        P.exports.push_back(e); i32 fi = (i32)P.exports.size(); Ref fn{ cls.pkg, fi };
        // parameters + return value
        for (auto& pd : d.params) {
            uint64_t pf = CPF_Parm; if (pd.out) pf |= CPF_OutParm; if (pd.optional) pf |= CPF_OptionalParm; if (pd.coerce) pf |= CPF_CoerceParm; if (pd.cnst) pf |= CPF_Const;
            i32 pi2 = E.makeProp(fn, pd.type, pd.name, pd.dim, pf, d.line); E.appendChild(s, fn, pi2);
        }
        if (!d.ret.empty()) { i32 ri = E.makeProp(fn, d.ret, "ReturnValue", 1, CPF_Parm | CPF_OutParm | CPF_ReturnParm, d.line); E.appendChild(s, fn, ri); }
        // class: child + FuncMap
        E.appendChild(s, cls, fi);
        E.touch(s, P, cls.idx); E.setOwned(P, cls.idx);
        FieldInfo cf = parseField(P, cls.idx); Export& ce = P.exports[cls.idx - 1];
        i32 cnt; memcpy(&cnt, ce.data.data() + cf.funcMapOff, 4); cnt++; memcpy(ce.data.data() + cf.funcMapOff, &cnt, 4);
        std::vector<u8> ent(12); memcpy(&ent[0], &nm.idx, 4); memcpy(&ent[4], &nm.num, 4); memcpy(&ent[8], &fi, 4);
        ce.data.insert(ce.data.begin() + cf.funcMapOff + 4, ent.begin(), ent.end());
        db.reindex(cls.pkg); C.invalidate();
        E.fixFuncFlags(s, fn);
        return fn;
    }

    // text with var/function/event/defaultproperties -> adds to the class (apply=false: only checks, undoes everything)
    Result addMembers(const Ref& cls, const std::string& text, bool apply) {
        Result R; Package& P = db.P(cls); ScriptEditor::Snap s = E.snap(P);
        try {
            if (db.cls(cls) != "Class") throw CompileError("not a class", 0);
            C.func = cls; C.pi = cls.pkg; C.cls = cls; C.state = Ref{}; C.allowMutate = true; C.idxCache.clear();
            MemberParser mp(text, C.optable); MembersDecl md = mp.parse();
            if (md.hasClass) throw CompileError("'class' declaration only in 'New class'", md.classLine);
            addMembersImpl(cls, md, s, R);
            R.ok = true;
        } catch (CompileError& e) { R.err = e.what(); if (!R.line) R.line = e.line; }
        catch (std::exception& e) { R.err = e.what(); }
        C.allowMutate = false;
        if (!apply || !R.ok) { E.rollback(s, P); db.reindex(cls.pkg); C.invalidate(); }
        return R;
    }
    void addMembersImpl(const Ref& cls, const MembersDecl& md, ScriptEditor::Snap& s, Result& R) {
        Package& P = db.P(cls);
        {   {
            // names already used in the class itself
            std::set<std::string> own; for (Ref ch : db.children(cls)) own.insert(lower(db.name(ch)));
            for (auto& v : md.vars) {
                std::string nb = nativeBlocker(cls);
                if (!nb.empty()) throw CompileError("cannot add variables to " + db.name(cls) + ": " + nb + " is a native (C++) class, the new field would shift its C++ memory layout. Create a new subclass and add the variable there.", v.line);
                for (auto& n : v.names) {
                    if (own.count(lower(n.first))) throw CompileError("'" + n.first + "' already exists in " + db.name(cls), v.line);
                    if (C.sc.findProp(db.super_(cls), n.first)) throw CompileError("'" + n.first + "' already exists in a parent class", v.line);
                    uint64_t fl = v.flags; i32 vi = E.makeProp(cls, v.type, n.first, n.second, fl, v.line);
                    if (v.edit) { FName cat = C.makeName(v.category.empty() ? db.name(cls) : v.category); Export& ve = P.exports[vi - 1]; FieldInfo vf = parseField(P, vi); memcpy(ve.data.data() + vf.propFlagsOff + 8, &cat.idx, 4); memcpy(ve.data.data() + vf.propFlagsOff + 12, &cat.num, 4); }
                    E.appendChild(s, cls, vi); own.insert(lower(n.first)); R.vars++;
                }
                db.reindex(cls.pkg); C.invalidate();
            }
            // first creates every function (they may call each other), then compiles the bodies
            std::vector<std::pair<Ref, const FuncDecl*>> made;
            for (auto& d : md.funcs) {
                if (own.count(lower(d.name))) throw CompileError("'" + d.name + "' already exists in " + db.name(cls) + " - edit it with its own source editor", d.line);
                Ref sup = C.sc.findFunc(db.super_(cls), d.name);
                if (sup) {
                    std::string why; if (!sameSig(sup, d, &why)) throw CompileError("'" + d.name + "' overrides " + db.path(sup) + " but " + why, d.line);
                    const FieldInfo& sf = db.field(sup);
                    if (sf.funcFlags & 0x40) throw CompileError("overriding replicated (net) functions is not supported yet", d.line);
                    if (sf.funcFlags & FUNC_Final) throw CompileError(db.path(sup) + " is final and cannot be overridden", d.line);
                    R.overrides++;
                }
                Ref fn = createFunction(s, cls, d, sup); made.push_back({ fn, &d }); own.insert(lower(d.name)); R.funcs++;
            }
            for (auto& m : made) {
                const FuncDecl& d = *m.second; std::string body;
                for (auto& pd : d.params) if (pd.optional) body += "//@default " + pd.name + (pd.def.empty() ? std::string() : " = " + pd.def) + "\n";
                // keeps the line numbering of the original text in the error messages
                std::string pad; int extra = (int)std::count(body.begin(), body.end(), '\n'); for (int k = extra; k < d.bodyLine - 1; k++) pad += "\n";
                EditResult er = E.compile(m.first, pad.size() + body.size() ? body + pad + d.body : d.body, true);
                if (!er.ok) { R.line = er.line; throw CompileError("in " + d.name + ": " + er.err, er.line); }
                R.bytecode += er.newSize;
            }
            C.allowMutate = true;
            if (!md.defaults.empty()) { writeDefaults(s, cls, md.defaults); R.notes.push_back(std::to_string(md.defaults.size()) + " default(s)"); }
        }
        }
    }

    // ---------------------------------------------------------- defaultproperties -> CDO tags
    std::vector<u8> encodeDefault(Package& P, const Ref& prop, const DefaultEntry& d, Tag& t) {
        Type ty = db.propType(prop); std::string v = d.value; std::string lv = lower(v); int line = d.line;
        auto num = [&](double* out) { char* end; *out = strtod(v.c_str(), &end); return *end == 0 && !v.empty(); };
        std::vector<u8> raw; Writer w;
        t.name = db.name(prop); t.index = d.index; t.type = db.cls(prop);
        if (t.type == "ClassProperty" || t.type == "ComponentProperty") t.type = "ObjectProperty";   // how UE3 writes the tag (UClassProperty/UComponentProperty use the UObjectProperty ID)
        switch (ty.k) {
            case K::Int: { double x; if (!num(&x)) throw CompileError(d.name + ": expected an integer", line); w.i((i32)x); break; }
            case K::Float: { double x; if (!num(&x)) throw CompileError(d.name + ": expected a number", line); w.f((float)strtof(v.c_str(), nullptr)); break; }
            case K::Bool: { if (lv != "true" && lv != "false") throw CompileError(d.name + ": expected true/false", line); t.isBool = true; t.boolVal = lv == "true"; return {}; }
            case K::Name: { std::string n = v; if (n.size() >= 2 && n[0] == '\'') n = n.substr(1, n.size() - 2); FName f = C.makeName(n); w.i(f.idx); w.i(f.num); break; }
            case K::String: { std::string n = v; if (n.size() < 2 || n[0] != '"') throw CompileError(d.name + ": expected \"text\"", line); n = n.substr(1, n.size() - 2);
                if (n.empty()) w.i(0); else { w.i((i32)n.size() + 1); for (char c : n) w.b.push_back((u8)c); w.b.push_back(0); } break; }
            case K::Byte: {
                double x;
                if (ty.enm) { std::string n = v; if (num(&x)) { const FieldInfo& ef = db.field(ty.enm); if ((size_t)x >= ef.enumNames.size()) throw CompileError(d.name + ": enum value out of range", line); n = db.P(ty.enm).nm(ef.enumNames[(size_t)x]); }
                    FName f = C.makeName(n); w.i(f.idx); w.i(f.num); break; }
                if (!num(&x)) throw CompileError(d.name + ": expected 0..255", line); w.b.push_back((u8)(int)x); break; }
            case K::Object: case K::Class: case K::Interface: {
                i32 oi = 0;
                if (lv != "none") { size_t q = v.find('\''); if (q == std::string::npos || v.back() != '\'') throw CompileError(d.name + ": expected Class'Package.Object' or None", line);
                    std::string path = v.substr(q + 1, v.size() - q - 2); Ref o = db.findPath(path); if (!o) throw CompileError(d.name + ": object not found: " + path, line); oi = C.objIndex(o, line); }
                w.i(oi); break; }
            case K::Struct: {
                if (C.isVector(ty) || C.isRotator(ty)) {
                    t.strct = db.name(ty.strct);
                    size_t a = v.find('('), b2 = v.rfind(')'); if (a == std::string::npos || b2 == std::string::npos) throw CompileError(d.name + ": expected (X=..,Y=..,Z=..) or (Pitch=..,Yaw=..,Roll=..)", line);
                    std::string in = v.substr(a + 1, b2 - a - 1); double vals[3] = { 0, 0, 0 }; const char* keys[3] = { "x", "y", "z" }; const char* rk[3] = { "pitch", "yaw", "roll" };
                    size_t pp = 0; while (pp < in.size()) { size_t c = in.find(',', pp); std::string kv = in.substr(pp, c == std::string::npos ? std::string::npos : c - pp); pp = c == std::string::npos ? in.size() : c + 1;
                        size_t eq = kv.find('='); if (eq == std::string::npos) continue; std::string k = lower(kv.substr(0, eq)); k.erase(0, k.find_first_not_of(" ")); k.erase(k.find_last_not_of(" ") + 1);
                        for (int i = 0; i < 3; i++) if (k == (C.isVector(ty) ? keys[i] : rk[i])) vals[i] = strtod(kv.c_str() + eq + 1, nullptr); }
                    for (int i = 0; i < 3; i++) { if (C.isVector(ty)) w.f((float)vals[i]); else w.i((i32)vals[i]); }
                    break;
                }
                throw CompileError(d.name + ": struct defaults other than Vector/Rotator are not supported yet", line);
            }
            default: throw CompileError(d.name + ": this property type is not supported in defaultproperties yet", line);
        }
        return w.b;
    }
    void writeDefaults(ScriptEditor::Snap& s, const Ref& cls, const std::vector<DefaultEntry>& defs) {
        Package& P = db.P(cls); const FieldInfo& cf = db.field(cls); i32 cdo = cf.cdo; if (cdo <= 0) throw CompileError("class has no default object in this package", 0);
        long ps = findPropStart(P, cdo); if (ps < 0) ps = 4;
        Export& de = P.exports[cdo - 1]; const u8* d = P.dataPtr(de); size_t n = P.dataLen(de); size_t endp = 0;
        std::vector<Tag> tags = readProps(P, d, n, (size_t)ps, &endp);
        for (auto& df : defs) {
            Ref prop = C.sc.findProp(cls, df.name); if (!prop) throw CompileError("unknown variable '" + df.name + "' in defaultproperties", df.line);
            const FieldInfo& pf = db.field(prop); if (df.index < 0 || df.index >= std::max(1, pf.arrayDim)) throw CompileError(df.name + ": index out of range", df.line);
            Tag t; t.raw = encodeDefault(P, prop, df, t);
            bool done = false; for (auto& x : tags) if (lower(x.name) == lower(t.name) && x.index == t.index) { x = t; done = true; }
            if (!done) tags.push_back(t);
        }
        E.touch(s, P, cdo); E.setOwned(P, cdo);
        std::vector<u8> nd(de.data.begin(), de.data.begin() + ps); std::vector<u8> body = writeProps(P, tags); nd.insert(nd.end(), body.begin(), body.end());
        nd.insert(nd.end(), de.data.begin() + endp, de.data.end()); de.data.swap(nd);
    }

    // ---------------------------------------------------------- new class
    Result createClass(int pkg, const std::string& text, bool apply, Ref* outCls = nullptr, i32 outer = 0, u32 exportFlags = 0, u32 extraClassFlags = 0) {
        Result R; Package& P = *db.pkgs[pkg]; ScriptEditor::Snap s = E.snap(P);
        try {
            C.pi = pkg; C.allowMutate = true; C.idxCache.clear(); C.state = Ref{};
            MemberParser mp(text, C.optable); MembersDecl md = mp.parse();
            if (!md.hasClass) throw CompileError("start with: class NewName extends ParentClass;", 1);
            if (db.findClass(md.className)) throw CompileError("a class named '" + md.className + "' already exists", md.classLine);
            Ref sup = db.findClass(md.superName); if (!sup || sup.idx < 0) throw CompileError("unknown parent class '" + md.superName + "'", md.classLine);
            const FieldInfo& sf = db.field(sup);
            if (sf.classFlags & 0x4000) throw CompileError("cannot extend an interface", md.classLine);
            C.func = sup; C.cls = sup;
            u32 flags = (sf.classFlags & (0x00800000u | 0x00200000u | 0x20u | 0x1000u | 0x2000000u | 0x400u)) | 0x12u | extraClassFlags;
            if (md.placeable || (sf.classFlags & 0x200)) flags |= 0x200; if (md.abstract_) flags |= 0x1;
            Ref supCdo = db.resolve(sup.pkg, sf.cdo);
            i32 noneIdx = P.findName("None"); if (noneIdx < 0) noneIdx = P.addName("None");
            FName cn = C.makeName(md.className);
            // class export (data filled in after creating the CDO)
            Export ce; ce.cls = 0; ce.super_ = C.objIndex(sup, md.classLine); ce.outer = outer; ce.exportFlags = exportFlags; ce.name = cn; ce.archetype = 0; ce.flags = 0x000f000400000000ull; ce.owned = true;
            P.exports.push_back(ce); i32 ci = (i32)P.exports.size();
            // CDO
            Export de; de.cls = ci; de.super_ = 0; de.outer = outer; de.exportFlags = exportFlags; de.name = C.makeName("Default__" + md.className); de.archetype = supCdo ? C.objIndex(supCdo, md.classLine) : 0;
            de.flags = 0x0007000400000200ull; de.owned = true; { Writer w; w.i(0); w.i(noneIdx); w.i(0); de.data = w.b; }
            P.exports.push_back(de); i32 di = (i32)P.exports.size();
            // class data: NetIndex, Super, Next, ScriptText, Children, CppText, Line, TextPos, ScriptSize, ProbeMask, IgnoreMask, LabelTableOffset,
            // StateFlags, FuncMap, ClassFlags, Within, ConfigName, ComponentMap, Interfaces, 3 categories, CDO
            // (UClass does NOT have a property list: the BmGame.u classes start with NetIndex and SuperField directly.
            //  A "None" here misaligns everything -> the engine reads the wrong Super and hangs while loading the package.)
            // Line/TextPos = -1 and StateFlags = 2, as in the cooked script-only classes (BmScript.* of the maps)
            Writer w; w.i(0); w.i(ce.super_); w.i(0); w.i(0); w.i(0); w.i(0); w.i(-1); w.i(-1); w.i(0);
            w.q(sf.probeMask); w.q(sf.ignoreMask); w.b.push_back(0xFF); w.b.push_back(0xFF); w.u(2); w.i(0);
            w.u(flags); w.i(sf.within ? C.objIndex(db.resolve(sup.pkg, sf.within), md.classLine) : 0);
            { std::string cfg = db.P(sup).nm(sf.configName); FName f = C.makeName(cfg.empty() ? "None" : cfg); w.i(f.idx); w.i(f.num); }
            w.i(0); w.i(0); w.i(0); w.i(0); w.i(0); w.i(di);
            P.exports[ci - 1].data = w.b;
            { FieldInfo chk = parseField(P, ci); if (!chk.ok || chk.cdo != di || chk.superField != ce.super_) throw CompileError("internal: class export layout check failed (" + chk.err + ")", 0); }
            db.reindex(pkg); C.invalidate();
            Ref nc{ pkg, ci }; if (outCls) *outCls = nc;
            C.func = nc; C.cls = nc;
            addMembersImpl(nc, md, s, R);
            // ProbeMask: the engine only calls "probe" events (Tick, Timer, Touch...) if the bit is set on the class.
            // We used to copy only the parent class mask: a new Tick in a subclass of Info was never called.
            // Bits deduced from the game classes (bit 36 = Tick in 143 classes, etc.).
            {   FieldInfo nf = parseField(P, ci); static const std::pair<const char*, int> pb[] = { {"destroyed",1},{"timer",8},{"hitwall",9},{"touch",13},{"untouch",14},{"bump",15},{"tick",36},{"playertick",37},{"specialhandling",46},{"postbeginplay",57} };
                uint64_t m = nf.probeMask; for (auto& x : nf.funcMap) { std::string fnm = lower(P.nm(x.first)); for (auto& q : pb) if (fnm == q.first) m |= 1ull << q.second; }
                if (m != nf.probeMask) { size_t off = nf.scriptOff + (size_t)nf.scriptSize; uint64_t old = 0; memcpy(&old, P.exports[ci - 1].data.data() + off, 8);
                    if (old != nf.probeMask) throw CompileError("internal: probe mask offset check failed", 0);
                    memcpy(P.exports[ci - 1].data.data() + off, &m, 8); char b[80]; snprintf(b, sizeof b, "probe mask %016llx -> %016llx", (unsigned long long)nf.probeMask, (unsigned long long)m); R.notes.push_back(b); db.reindex(pkg); C.invalidate(); } }
            R.notes.push_back("class " + md.className + " extends " + db.path(sup));
            R.ok = true;
        } catch (CompileError& e) { R.err = e.what(); if (!R.line) R.line = e.line; }
        catch (std::exception& e) { R.err = e.what(); }
        C.allowMutate = false;
        if (!apply || !R.ok) { E.rollback(s, P); db.reindex(pkg); C.invalidate(); }
        return R;
    }
};

} // namespace ucc
} // namespace bm
