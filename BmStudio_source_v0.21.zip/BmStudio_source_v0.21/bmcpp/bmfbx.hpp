// bmfbx.hpp - BINARY FBX 7.4 export (the Blender importer does not read ASCII FBX).
// SkeletalMesh: mesh + armature (LimbNodes) + Skin/Clusters + BindPose (+ optional animations).
// StaticMesh: mesh only. Conversion UE (left-handed) -> FBX (right-handed): mirrors Y, flips the face winding.
// Units: cm (UnitScaleFactor 1), Z axis up.
#pragma once
#include "bmanim.hpp"
#include <array>
#include <cmath>

namespace bm {
namespace fbx {

// ------------------------------------------------------------------ binary encoding
struct Prop { char t; std::vector<u8> d; };
inline void put32(std::vector<u8>& b, u32 v) { for (int i = 0; i < 4; i++) b.push_back((u8)(v >> (i * 8))); }
inline void put64(std::vector<u8>& b, uint64_t v) { for (int i = 0; i < 8; i++) b.push_back((u8)(v >> (i * 8))); }
struct Node {
    std::string name; std::vector<Prop> props; std::vector<Node> kids;
    Node() {}
    explicit Node(const std::string& n) : name(n) {}
    Node& I(int32_t v) { Prop p{ 'I', {} }; put32(p.d, (u32)v); props.push_back(p); return *this; }
    Node& L(int64_t v) { Prop p{ 'L', {} }; put64(p.d, (uint64_t)v); props.push_back(p); return *this; }
    Node& D(double v) { Prop p{ 'D', {} }; uint64_t x; memcpy(&x, &v, 8); put64(p.d, x); props.push_back(p); return *this; }
    Node& F(float v) { Prop p{ 'F', {} }; u32 x; memcpy(&x, &v, 4); put32(p.d, x); props.push_back(p); return *this; }
    Node& C(bool v) { Prop p{ 'C', { (u8)(v ? 1 : 0) } }; props.push_back(p); return *this; }
    Node& S(const std::string& s) { Prop p{ 'S', {} }; put32(p.d, (u32)s.size()); p.d.insert(p.d.end(), s.begin(), s.end()); props.push_back(p); return *this; }
    Node& SRaw(const std::string& s) { return S(s); }
    Node& Ad(const std::vector<double>& a) { Prop p{ 'd', {} }; put32(p.d, (u32)a.size()); put32(p.d, 0); put32(p.d, (u32)(a.size() * 8)); for (double v : a) { uint64_t x; memcpy(&x, &v, 8); put64(p.d, x); } props.push_back(p); return *this; }
    Node& Af(const std::vector<float>& a) { Prop p{ 'f', {} }; put32(p.d, (u32)a.size()); put32(p.d, 0); put32(p.d, (u32)(a.size() * 4)); for (float v : a) { u32 x; memcpy(&x, &v, 4); put32(p.d, x); } props.push_back(p); return *this; }
    Node& Ai(const std::vector<int32_t>& a) { Prop p{ 'i', {} }; put32(p.d, (u32)a.size()); put32(p.d, 0); put32(p.d, (u32)(a.size() * 4)); for (int32_t v : a) put32(p.d, (u32)v); props.push_back(p); return *this; }
    Node& Al(const std::vector<int64_t>& a) { Prop p{ 'l', {} }; put32(p.d, (u32)a.size()); put32(p.d, 0); put32(p.d, (u32)(a.size() * 8)); for (int64_t v : a) put64(p.d, (uint64_t)v); props.push_back(p); return *this; }
    Node& add(const Node& n) { kids.push_back(n); return kids.back(); }
    Node& child(const std::string& n) { kids.emplace_back(n); return kids.back(); }
};
inline void writeNode(std::vector<u8>& b, const Node& n) {
    size_t start = b.size(); put32(b, 0); put32(b, (u32)n.props.size()); put32(b, 0); b.push_back((u8)n.name.size()); b.insert(b.end(), n.name.begin(), n.name.end());
    size_t ps = b.size(); for (auto& p : n.props) { b.push_back((u8)p.t); b.insert(b.end(), p.d.begin(), p.d.end()); }
    u32 plen = (u32)(b.size() - ps);
    if (!n.kids.empty() || n.props.empty()) { for (auto& k : n.kids) writeNode(b, k); b.insert(b.end(), 13, 0); }
    u32 end = (u32)b.size(); memcpy(&b[start], &end, 4); memcpy(&b[start + 8], &plen, 4);
}
inline std::vector<u8> encode(const std::vector<Node>& top) {
    std::vector<u8> b; const char magic[] = "Kaydara FBX Binary  "; b.insert(b.end(), magic, magic + 20); b.push_back(0); b.push_back(0x1a); b.push_back(0); put32(b, 7400);
    for (auto& n : top) writeNode(b, n);
    b.insert(b.end(), 13, 0);
    static const u8 footId[16] = { 0xfa, 0xbc, 0xab, 0x09, 0xd0, 0xc8, 0xd4, 0x66, 0xb1, 0x76, 0xfb, 0x83, 0x1c, 0xf7, 0x26, 0x7e };
    b.insert(b.end(), footId, footId + 16); b.insert(b.end(), 4, 0);
    size_t pad = ((b.size() + 15) & ~(size_t)15) - b.size(); if (pad == 0) pad = 16; b.insert(b.end(), pad, 0);
    put32(b, 7400); b.insert(b.end(), 120, 0);
    static const u8 footMagic[16] = { 0xf8, 0x5a, 0x8c, 0x6a, 0xde, 0xf5, 0xd9, 0x7e, 0xec, 0xe9, 0x0c, 0xe3, 0x75, 0x8f, 0x29, 0x0b };
    b.insert(b.end(), footMagic, footMagic + 16);
    return b;
}
// Properties70 helpers
inline void P(Node& p70, const std::string& n, const std::string& t1, const std::string& t2, const std::string& fl, int v) { p70.child("P").S(n).S(t1).S(t2).S(fl).I(v); }
inline void Pd(Node& p70, const std::string& n, const std::string& t1, const std::string& t2, const std::string& fl, double v) { p70.child("P").S(n).S(t1).S(t2).S(fl).D(v); }
inline void P3(Node& p70, const std::string& n, const std::string& t1, const std::string& t2, const std::string& fl, double x, double y, double z) { p70.child("P").S(n).S(t1).S(t2).S(fl).D(x).D(y).D(z); }
inline void Ps(Node& p70, const std::string& n, const std::string& t1, const std::string& t2, const std::string& fl, const std::string& v) { p70.child("P").S(n).S(t1).S(t2).S(fl).S(v); }
inline void Pl(Node& p70, const std::string& n, const std::string& t1, const std::string& t2, const std::string& fl, int64_t v) { p70.child("P").S(n).S(t1).S(t2).S(fl).L(v); }
inline std::string nameClass(const std::string& n, const char* cls) { std::string s = n; s.push_back('\0'); s.push_back('\x01'); s += cls; return s; }

// ------------------------------------------------------------------ math (column: p' = M p; matrix stored m[row][column])
struct Mat { double m[4][4]; };
inline Mat ident() { Mat r = {}; for (int i = 0; i < 4; i++) r.m[i][i] = 1; return r; }
inline Mat mul(const Mat& a, const Mat& b) { Mat r; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) { r.m[i][j] = 0; for (int k = 0; k < 4; k++) r.m[i][j] += a.m[i][k] * b.m[k][j]; } return r; }
inline Mat rigidInv(const Mat& a) { Mat r = ident(); for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) r.m[i][j] = a.m[j][i];
    for (int i = 0; i < 3; i++) r.m[i][3] = -(r.m[i][0] * a.m[0][3] + r.m[i][1] * a.m[1][3] + r.m[i][2] * a.m[2][3]); return r; }
// UE row matrix (v*M) -> column, mirroring Y (S*M^T*S)
inline Mat fromUE(const M4& u) { Mat r = ident(); double s[3] = { 1, -1, 1 };
    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) r.m[i][j] = u.m[j][i] * s[i] * s[j];
    for (int i = 0; i < 3; i++) r.m[i][3] = u.m[3][i] * s[i]; return r; }
inline std::vector<double> flat(const Mat& a) { std::vector<double> v(16); for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) v[c * 4 + r] = a.m[r][c]; return v; }   // FBX: column-major
// Euler XYZ (degrees) with R = Rz*Ry*Rx
inline void toEuler(const Mat& a, double& x, double& y, double& z) {
    const double R2D = 57.29577951308232; double sy = -a.m[2][0];
    if (sy > 0.999999) { y = 90; x = atan2(a.m[0][1], a.m[1][1]) * R2D; z = 0; }
    else if (sy < -0.999999) { y = -90; x = atan2(-a.m[0][1], a.m[1][1]) * R2D; z = 0; }
    else { y = asin(sy) * R2D; x = atan2(a.m[2][1], a.m[2][2]) * R2D; z = atan2(a.m[1][0], a.m[0][0]) * R2D; }
}

struct MeshIn {
    std::string name; std::vector<std::array<float, 3>> pos, nrm; std::vector<std::array<float, 2>> uv; std::vector<uint32_t> idx;
    struct Sec { u32 first, tris; std::string mat; }; std::vector<Sec> secs;
    // skin (optional)
    std::vector<Bone> bones; std::vector<std::array<uint16_t, 4>> vb; std::vector<std::array<u8, 4>> vw;
    std::map<std::string, std::string> matTex;   // short material name -> texture file (relative to the .fbx)
};
struct AnimIn { std::string name; int numFrames; float fps; const AnimSeq* seq; std::vector<int> trackOf; };

inline std::string shortName(std::string s) { size_t d = s.rfind('.'); if (d != std::string::npos) s = s.substr(d + 1); return s.empty() ? "None" : s; }

inline std::vector<u8> build(const MeshIn& m, const std::vector<AnimIn>& anims, const SkeletalMesh* skel) {
    int64_t nextId = 1000000; auto newId = [&]() { return nextId++; };
    std::vector<Node> top;
    // header
    { Node h("FBXHeaderExtension"); h.child("FBXHeaderVersion").I(1003); h.child("FBXVersion").I(7400); h.child("EncryptionType").I(0);
      Node& ts = h.child("CreationTimeStamp"); ts.child("Version").I(1000); ts.child("Year").I(2026); ts.child("Month").I(1); ts.child("Day").I(1); ts.child("Hour").I(0); ts.child("Minute").I(0); ts.child("Second").I(0); ts.child("Millisecond").I(0);
      h.child("Creator").S("BmStudio (Batman: Arkham Asylum)"); top.push_back(h); }
    top.push_back(Node("FileId")); { std::vector<u8> id(16, 0x42); Prop p{ 'R', {} }; put32(p.d, 16); p.d.insert(p.d.end(), id.begin(), id.end()); top.back().props.push_back(p); }
    top.push_back(Node("CreationTime")); top.back().S("1970-01-01 10:00:00:000");
    top.push_back(Node("Creator")); top.back().S("BmStudio");
    { Node g("GlobalSettings"); g.child("Version").I(1000); Node& p = g.child("Properties70");
      P(p, "UpAxis", "int", "Integer", "", 2); P(p, "UpAxisSign", "int", "Integer", "", 1); P(p, "FrontAxis", "int", "Integer", "", 1); P(p, "FrontAxisSign", "int", "Integer", "", -1);
      P(p, "CoordAxis", "int", "Integer", "", 0); P(p, "CoordAxisSign", "int", "Integer", "", 1); P(p, "OriginalUpAxis", "int", "Integer", "", 2); P(p, "OriginalUpAxisSign", "int", "Integer", "", 1);
      Pd(p, "UnitScaleFactor", "double", "Number", "", 1.0); Pd(p, "OriginalUnitScaleFactor", "double", "Number", "", 1.0);
      P(p, "TimeMode", "enum", "", "", 6); Pl(p, "TimeSpanStart", "KTime", "Time", "", 0); Pl(p, "TimeSpanStop", "KTime", "Time", "", 46186158000LL); Pd(p, "CustomFrameRate", "double", "Number", "", -1);
      top.push_back(g); }
    { Node d("Documents"); d.child("Count").I(1); Node& doc = d.child("Document"); doc.L(newId()).S("").S("Scene"); Node& p = doc.child("Properties70"); Ps(p, "SourceObject", "object", "", "", ""); Ps(p, "ActiveAnimStackName", "KString", "", "", anims.empty() ? "" : anims[0].name); doc.child("RootNode").L(0); top.push_back(d); }
    top.push_back(Node("References"));
    Node objects("Objects"); Node conns("Connections");
    auto C = [&](int64_t child, int64_t parent) { conns.child("C").S("OO").L(child).L(parent); };
    auto CP = [&](int64_t child, int64_t parent, const std::string& prop) { conns.child("C").S("OP").L(child).L(parent).S(prop); };
    int counts[16] = { 0 };   // p/ Definitions: 0 Model 1 Geometry 2 Material 3 NodeAttribute 4 Deformer 5 Pose 6 AnimStack 7 AnimLayer 8 AnimCurveNode 9 AnimCurve 10 Texture 11 Video

    // --- geometry (triangles per section; mirrors Y and flips the order)
    int64_t geoId = newId(), meshModelId = newId(); std::vector<std::string> matNames;
    { Node g("Geometry"); g.L(geoId).S(nameClass(m.name, "Geometry")).S("Mesh"); counts[1]++;
      g.child("Properties70"); g.child("GeometryVersion").I(124);
      std::vector<double> v; v.reserve(m.pos.size() * 3); for (auto& p : m.pos) { v.push_back(p[0]); v.push_back(-p[1]); v.push_back(p[2]); }
      g.child("Vertices").Ad(v);
      std::vector<int32_t> pvi; std::vector<double> nn; std::vector<int32_t> uvIdx, matIdx;
      std::vector<std::string> uniq; std::vector<int> secMat; for (auto& s : m.secs) { std::string n = shortName(s.mat); int f = -1; for (size_t u = 0; u < uniq.size(); u++) if (uniq[u] == n) f = (int)u; if (f < 0) { f = (int)uniq.size(); uniq.push_back(n); } secMat.push_back(f); }
      matNames = uniq;
      for (size_t si = 0; si < m.secs.size(); si++) { const auto& s = m.secs[si];
          for (u32 t = 0; t < s.tris; t++) { size_t b = s.first + (size_t)t * 3; if (b + 2 >= m.idx.size()) break; uint32_t c[3] = { m.idx[b], m.idx[b + 2], m.idx[b + 1] };
              for (int k = 0; k < 3; k++) { int32_t vi = (int32_t)c[k]; pvi.push_back(k == 2 ? ~vi : vi); uvIdx.push_back(vi);
                  const auto& n = m.nrm[vi]; nn.push_back(n[0]); nn.push_back(-n[1]); nn.push_back(n[2]); }
              matIdx.push_back((int32_t)secMat[si]); } }
      g.child("PolygonVertexIndex").Ai(pvi);
      { Node& ln = g.child("LayerElementNormal"); ln.I(0); ln.child("Version").I(101); ln.child("Name").S(""); ln.child("MappingInformationType").S("ByPolygonVertex"); ln.child("ReferenceInformationType").S("Direct"); ln.child("Normals").Ad(nn); }
      { Node& lu = g.child("LayerElementUV"); lu.I(0); lu.child("Version").I(101); lu.child("Name").S("UVMap"); lu.child("MappingInformationType").S("ByPolygonVertex"); lu.child("ReferenceInformationType").S("IndexToDirect");
        std::vector<double> uv; uv.reserve(m.uv.size() * 2); for (auto& t : m.uv) { uv.push_back(t[0]); uv.push_back(1.0 - t[1]); } lu.child("UV").Ad(uv); lu.child("UVIndex").Ai(uvIdx); }
      { Node& lm = g.child("LayerElementMaterial"); lm.I(0); lm.child("Version").I(101); lm.child("Name").S(""); lm.child("MappingInformationType").S("ByPolygon"); lm.child("ReferenceInformationType").S("IndexToDirect"); lm.child("Materials").Ai(matIdx); }
      { Node& l = g.child("Layer"); l.I(0); l.child("Version").I(100);
        for (const char* t : { "LayerElementNormal", "LayerElementMaterial", "LayerElementUV" }) { Node& e = l.child("LayerElement"); e.child("Type").S(t); e.child("TypedIndex").I(0); } }
      objects.add(g); }
    { Node mo("Model"); mo.L(meshModelId).S(nameClass(m.name, "Model")).S("Mesh"); counts[0]++; mo.child("Version").I(232); Node& p = mo.child("Properties70"); P(p, "DefaultAttributeIndex", "int", "Integer", "", 0);
      mo.child("Shading").C(true); mo.child("Culling").S("CullingOff"); objects.add(mo); }
    C(geoId, meshModelId); C(meshModelId, 0);
    // --- materials (one per section, unique names)
    for (auto& n : matNames) { int64_t id = newId(); Node mt("Material"); mt.L(id).S(nameClass(n, "Material")).S(""); counts[2]++; mt.child("Version").I(102); mt.child("ShadingModel").S("phong"); mt.child("MultiLayer").I(0);
        Node& p = mt.child("Properties70"); P3(p, "DiffuseColor", "Color", "", "A", 0.8, 0.8, 0.8); objects.add(mt); C(id, meshModelId);   // connection order = material index
        auto tf = m.matTex.find(n); if (tf == m.matTex.end() || tf->second.empty()) continue;
        std::string tn = tf->second; size_t dot = tn.rfind('.'); std::string base = dot == std::string::npos ? tn : tn.substr(0, dot);
        int64_t tid = newId(), vid = newId();
        { Node t("Texture"); t.L(tid).S(nameClass(base, "Texture")).S(""); counts[10]++; t.child("Type").S("TextureVideoClip"); t.child("Version").I(202); t.child("TextureName").S(nameClass(base, "Texture"));
          Node& tp = t.child("Properties70"); P(tp, "UseMaterial", "bool", "", "", 1); t.child("Media").S(nameClass(base, "Video")); t.child("FileName").S(tn); t.child("RelativeFilename").S(tn);
          t.child("ModelUVTranslation").D(0).D(0); t.child("ModelUVScaling").D(1).D(1); t.child("Texture_Alpha_Source").S("None"); t.child("Cropping").I(0).I(0).I(0).I(0); objects.add(t); }
        { Node v("Video"); v.L(vid).S(nameClass(base, "Video")).S("Clip"); counts[11]++; v.child("Type").S("Clip"); Node& vp = v.child("Properties70"); Ps(vp, "Path", "KString", "XRefUrl", "", tn);
          v.child("UseMipMap").I(0); v.child("Filename").S(tn); v.child("RelativeFilename").S(tn); objects.add(v); }
        C(vid, tid); CP(tid, id, "DiffuseColor"); }
    // --- bones
    if (skel && !m.bones.empty()) {
        size_t nb = m.bones.size(); std::vector<M4> ref; std::vector<int> none; poseBones(*skel, nullptr, none, 0, ref);
        std::vector<Mat> G(nb); for (size_t b = 0; b < nb; b++) G[b] = fromUE(ref[b]);
        std::vector<int64_t> boneModel(nb), boneAttr(nb);
        int64_t armId = newId(); { Node a("Model"); a.L(armId).S(nameClass("Armature", "Model")).S("Null"); counts[0]++; a.child("Version").I(232); a.child("Properties70"); objects.add(a);
            int64_t na = newId(); Node at("NodeAttribute"); at.L(na).S(nameClass("Armature", "NodeAttribute")).S("Null"); counts[3]++; at.child("TypeFlags").S("Null"); objects.add(at); C(na, armId); C(armId, 0); }
        for (size_t b = 0; b < nb; b++) {
            boneModel[b] = newId(); boneAttr[b] = newId(); int pa = m.bones[b].parent;
            Mat L = (b == 0 || pa < 0 || pa >= (int)b) ? G[b] : mul(rigidInv(G[pa]), G[b]);
            double ex, ey, ez; toEuler(L, ex, ey, ez);
            Node bm("Model"); bm.L(boneModel[b]).S(nameClass(m.bones[b].name, "Model")).S("LimbNode"); counts[0]++; bm.child("Version").I(232);
            Node& p = bm.child("Properties70"); P3(p, "Lcl Translation", "Lcl Translation", "", "A", L.m[0][3], L.m[1][3], L.m[2][3]); P3(p, "Lcl Rotation", "Lcl Rotation", "", "A", ex, ey, ez); P3(p, "Lcl Scaling", "Lcl Scaling", "", "A", 1, 1, 1);
            objects.add(bm);
            Node at("NodeAttribute"); at.L(boneAttr[b]).S(nameClass(m.bones[b].name, "NodeAttribute")).S("LimbNode"); counts[3]++; Node& ap = at.child("Properties70"); Pd(ap, "Size", "double", "Number", "", 3.0); at.child("TypeFlags").S("Skeleton"); objects.add(at);
            C(boneAttr[b], boneModel[b]); C(boneModel[b], (b == 0 || pa < 0 || pa >= (int)b) ? armId : boneModel[pa]);
        }
        // skin
        int64_t skinId = newId(); { Node sk("Deformer"); sk.L(skinId).S(nameClass(m.name, "Deformer")).S("Skin"); counts[4]++; sk.child("Version").I(101); sk.child("Link_DeformAcuracy").D(50.0); objects.add(sk); C(skinId, geoId); }
        std::vector<std::vector<int32_t>> bi(nb); std::vector<std::vector<double>> bw(nb);
        for (size_t v = 0; v < m.vb.size(); v++) for (int j = 0; j < 4; j++) { if (!m.vw[v][j]) continue; int b = m.vb[v][j]; if (b >= (int)nb) continue; bi[b].push_back((int32_t)v); bw[b].push_back(m.vw[v][j] / 255.0); }
        for (size_t b = 0; b < nb; b++) {
            int64_t cl = newId(); Node c("Deformer"); c.L(cl).S(nameClass(m.bones[b].name, "SubDeformer")).S("Cluster"); counts[4]++; c.child("Version").I(100); c.child("UserData").S("").S("");
            c.child("Indexes").Ai(bi[b]); c.child("Weights").Ad(bw[b]); c.child("Transform").Ad(flat(rigidInv(G[b]))); c.child("TransformLink").Ad(flat(G[b]));
            objects.add(c); C(cl, skinId); C(boneModel[b], cl);
        }
        // bind pose
        { int64_t pid = newId(); Node po("Pose"); po.L(pid).S(nameClass("BindPose", "Pose")).S("BindPose"); counts[5]++; po.child("Type").S("BindPose"); po.child("Version").I(100); po.child("NbPoseNodes").I((int32_t)nb + 1);
          { Node& pn = po.child("PoseNode"); pn.child("Node").L(meshModelId); pn.child("Matrix").Ad(flat(ident())); }
          for (size_t b = 0; b < nb; b++) { Node& pn = po.child("PoseNode"); pn.child("Node").L(boneModel[b]); pn.child("Matrix").Ad(flat(G[b])); }
          objects.add(po); }
        // animations
        const int64_t KT = 46186158000LL;   // ticks per second
        for (auto& an : anims) {
            if (!an.seq || an.numFrames < 1) continue;
            int64_t stack = newId(), layer = newId(); int64_t stop = (int64_t)((an.numFrames - 1) / (double)an.fps * KT);
            { Node s("AnimationStack"); s.L(stack).S(nameClass(an.name, "AnimStack")).S(""); counts[6]++; Node& p = s.child("Properties70"); Pl(p, "LocalStop", "KTime", "Time", "", stop); Pl(p, "ReferenceStop", "KTime", "Time", "", stop); objects.add(s); }
            { Node l("AnimationLayer"); l.L(layer).S(nameClass("BaseLayer", "AnimLayer")).S(""); counts[7]++; objects.add(l); }
            C(layer, stack);
            std::vector<int64_t> times(an.numFrames); for (int f = 0; f < an.numFrames; f++) times[f] = (int64_t)(f / (double)an.fps * KT);
            std::vector<std::vector<Mat>> Lf(nb, std::vector<Mat>(an.numFrames));
            for (int f = 0; f < an.numFrames; f++) { std::vector<M4> w; poseBones(*skel, an.seq, an.trackOf, (float)f, w); std::vector<Mat> g(nb); for (size_t b = 0; b < nb; b++) g[b] = fromUE(w[b]);
                for (size_t b = 0; b < nb; b++) { int pa = m.bones[b].parent; Lf[b][f] = (b == 0 || pa < 0 || pa >= (int)b) ? g[b] : mul(rigidInv(g[pa]), g[b]); } }
            for (size_t b = 0; b < nb; b++) {
                if (b >= an.trackOf.size() || an.trackOf[b] < 0) continue;
                std::vector<float> ch[6]; double prev[3] = { 0, 0, 0 };
                for (int f = 0; f < an.numFrames; f++) { const Mat& L = Lf[b][f]; double e[3]; toEuler(L, e[0], e[1], e[2]);
                    for (int k = 0; k < 3; k++) { if (f) { while (e[k] - prev[k] > 180) e[k] -= 360; while (e[k] - prev[k] < -180) e[k] += 360; } prev[k] = e[k]; }   // continuity
                    for (int k = 0; k < 3; k++) { ch[k].push_back((float)L.m[k][3]); ch[3 + k].push_back((float)e[k]); } }
                const char* nodeNames[2] = { "T", "R" }; const char* props[2] = { "Lcl Translation", "Lcl Rotation" };
                for (int t = 0; t < 2; t++) {
                    int64_t cn = newId(); Node n("AnimationCurveNode"); n.L(cn).S(nameClass(nodeNames[t], "AnimCurveNode")).S(""); counts[8]++;
                    Node& p = n.child("Properties70"); Pd(p, "d|X", "Number", "", "A", ch[t * 3][0]); Pd(p, "d|Y", "Number", "", "A", ch[t * 3 + 1][0]); Pd(p, "d|Z", "Number", "", "A", ch[t * 3 + 2][0]); objects.add(n);
                    C(cn, layer); CP(cn, boneModel[b], props[t]);
                    const char* ax[3] = { "d|X", "d|Y", "d|Z" };
                    for (int k = 0; k < 3; k++) { int64_t cv = newId(); Node c("AnimationCurve"); c.L(cv).S(nameClass("", "AnimCurve")).S(""); counts[9]++;
                        c.child("Default").D(ch[t * 3 + k][0]); c.child("KeyVer").I(4008); c.child("KeyTime").Al(times); c.child("KeyValueFloat").Af(ch[t * 3 + k]);
                        c.child("KeyAttrFlags").Ai({ 0x00000104 }); c.child("KeyAttrDataFloat").Af({ 0, 0, 0, 0 }); c.child("KeyAttrRefCount").Ai({ (int32_t)an.numFrames });   // linear
                        objects.add(c); CP(cv, cn, ax[k]); }
                }
            }
        }
    }
    // Definitions
    { Node d("Definitions"); d.child("Version").I(100); int total = 1; for (int i = 0; i < 12; i++) total += counts[i]; d.child("Count").I(total);
      { Node& ot = d.child("ObjectType"); ot.S("GlobalSettings"); ot.child("Count").I(1); }
      const char* names[12] = { "Model", "Geometry", "Material", "NodeAttribute", "Deformer", "Pose", "AnimationStack", "AnimationLayer", "AnimationCurveNode", "AnimationCurve", "Texture", "Video" };
      for (int i = 0; i < 12; i++) if (counts[i]) { Node& ot = d.child("ObjectType"); ot.S(names[i]); ot.child("Count").I(counts[i]); }
      top.push_back(d); }
    top.push_back(objects); top.push_back(conns);
    { Node t("Takes"); t.child("Current").S(anims.empty() ? "" : anims[0].name); top.push_back(t); }
    return encode(top);
}

} // namespace fbx

// SkeletalMesh (LOD) -> FBX; optional anims (AnimSet sequences already mapped to the mesh bones)
inline std::vector<u8> exportFBXSkeletal(const SkeletalMesh& sm, int lod, const std::string& name, const std::vector<fbx::AnimIn>& anims = {}, const std::map<std::string, std::string>& matTex = {}) {
    if (sm.lods.empty()) throw Err("mesh has no LODs");
    const SkelLOD& l = sm.lods[std::min<size_t>(lod, sm.lods.size() - 1)];
    fbx::MeshIn m; m.name = name;
    for (auto& v : l.verts) { m.pos.push_back({ v.pos[0], v.pos[1], v.pos[2] }); m.nrm.push_back({ v.normal[0], v.normal[1], v.normal[2] }); m.uv.push_back({ v.uv[0], v.uv[1] }); }
    m.idx = l.indices;
    for (auto& s : l.sections) m.secs.push_back({ s.baseIndex, s.numTris, (s.material >= 0 && s.material < (int)sm.materials.size()) ? sm.materials[s.material] : "None" });
    m.matTex = matTex; m.bones = sm.bones; auto gb = globalVertexBones(l); m.vb = gb; for (auto& v : l.verts) m.vw.push_back({ v.weights[0], v.weights[1], v.weights[2], v.weights[3] });
    return fbx::build(m, anims, &sm);
}
inline std::vector<u8> exportFBXStatic(const StaticMesh& st, int lod, const std::string& name, const std::map<std::string, std::string>& matTex = {}) {
    if (st.lods.empty()) throw Err("mesh has no LODs");
    const StaticLOD& l = st.lods[std::min<size_t>(lod, st.lods.size() - 1)];
    fbx::MeshIn m; m.name = name;
    for (auto& v : l.verts) { m.pos.push_back({ v.pos[0], v.pos[1], v.pos[2] }); m.nrm.push_back({ v.normal[0], v.normal[1], v.normal[2] }); m.uv.push_back({ v.uv[0], v.uv[1] }); }
    m.matTex = matTex; m.idx = l.indices; for (auto& e : l.elements) m.secs.push_back({ e.firstIndex, e.numTris, e.materialPath });
    return fbx::build(m, {}, nullptr);
}


// writes the diffuse texture of each material as PNG in 'dir' and returns { short material name -> file }.
// readFile(path, off, n, out) as in loadMip; writeFile(fileName, bytes). Chosen mip: largest side <= maxSize.
extern "C" void* tdefl_write_image_to_png_file_in_memory(const void* pImage, int w, int h, int num_chans, size_t* pLen_out);
template <class ReadFileFn, class WriteFileFn>
inline std::map<std::string, std::string> writeMaterialTextures(const Package& pk, const std::vector<std::pair<std::string, i32>>& mats, const std::string& cookedDir, ReadFileFn readFile, WriteFileFn writeFile, int maxSize = 4096) {
    std::map<std::string, std::string> out; std::map<i32, std::string> done;
    for (auto& mp : mats) {
        std::string mn = fbx::shortName(mp.first); if (out.count(mn)) continue;
        i32 t = 0; try { t = findDiffuseTexture(pk, mp.second); } catch (...) { t = 0; } if (t <= 0 || pk.classOf(pk.exports[t - 1]) != "Texture2D") continue;
        if (done.count(t)) { out[mn] = done[t]; continue; }
        try {
            TextureInfo ti = parseTexture(pk, t); if (ti.mips.empty()) continue;
            int want = 0; while (want + 1 < (int)ti.mips.size() && std::max(ti.mips[want].w, ti.mips[want].h) > maxSize) want++;
            std::vector<u8> data, rgba; int got = -1;
            for (int k = want; k < (int)ti.mips.size(); k++) if (loadMip(pk, t, ti, ti.mips[k], cookedDir, readFile, data)) { got = k; break; }
            if (got < 0 || !decodeToRGBA(ti, ti.mips[got].w, ti.mips[got].h, data.data(), data.size(), rgba)) continue;
            size_t len = 0; void* png = tdefl_write_image_to_png_file_in_memory(rgba.data(), ti.mips[got].w, ti.mips[got].h, 4, &len); if (!png) continue;
            std::vector<u8> bytes((u8*)png, (u8*)png + len); free(png);
            std::string fn = pk.objName(t) + ".png"; if (!writeFile(fn, bytes)) continue;
            out[mn] = fn; done[t] = fn;
        } catch (...) {}
    }
    return out;
}

} // namespace bm
