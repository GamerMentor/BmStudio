// bmhole.hpp - "Cut hole": opens a passage (oriented box) in the walls of a cooked BAA level.
//
// Static meshes: the instance that crosses the box gets a COPY of the mesh with the triangles clipped (whatever is
// inside the box goes away; attributes interpolated), with a new kDOP. A per-vertex lightmap (which would depend on the
// vertex count) is dropped; a texture lightmap stays valid.
// BSP: the polygons that cross the box disappear (collapsed vertices - the same "hide faces" method tested in game)
// and come back as a clipped StaticMesh, with the SAME lightmap of the ModelComponent element (copy of the FLightMap2D +
// shadow coordinates of the BSP itself as UV 1) -> the lighting stays the same.
// BSP collision: the solid cells (LeafHulls) that cross the box are switched off (box moved away + NotCsg, as in the
// collision tool) and replaced by an invisible mesh = convex cell MINUS the box (per-polygon collision).
// Inner faces of the hole (the wall thickness) go into a separate mesh with the wall material.
//
// ModelComponent layout (v576, checked on Alley_C1_Static): Model, ZoneIndex, Elements[]{ LightMapRef (u32 type;
// 2 = FLightMap2D: LightGuids[] + 4 x (texture, FVector scale) + CoordinateScale(2) + CoordinateBias(2)), Component,
// Material, Nodes (u16[]), ShadowMaps (obj[]), IrrelevantLights (guid[]) }, ComponentIndex, Nodes (u16[]).
// StaticMeshComponent LODData: count + { ShadowMaps (obj[]), ShadowVertexBuffers (obj[]), LightMapRef }.
#pragma once
#include "bmbetaconv.hpp"
#include "bmbspedit.hpp"
#include "bmplace.hpp"

namespace bm { namespace hole {

using betaconv::Mesh; using betaconv::Section;

// ------------------------------------------------------------------ box
struct Box { float c[3] = { 0, 0, 0 }, half[3] = { 96, 64, 160 }; float yaw = 0; };   // yaw in degrees (around Z); half[0] = width/2, [1] = depth/2, [2] = height/2
struct Plane { float n[3], d; };
inline float pdist(const Plane& p, const float* x) { return p.n[0] * x[0] + p.n[1] * x[1] + p.n[2] * x[2] - p.d; }
inline void boxAxes(const Box& b, float ax[3][3]) { float r = b.yaw * 3.14159265f / 180.f, c = cosf(r), s = sinf(r);
    ax[0][0] = c; ax[0][1] = s; ax[0][2] = 0; ax[1][0] = -s; ax[1][1] = c; ax[1][2] = 0; ax[2][0] = 0; ax[2][1] = 0; ax[2][2] = 1; }
// 6 planes, inside = all <= 0
inline std::vector<Plane> boxPlanes(const Box& b) {
    float ax[3][3]; boxAxes(b, ax); std::vector<Plane> out;
    for (int a = 0; a < 3; a++) for (int s = -1; s <= 1; s += 2) { Plane p; for (int k = 0; k < 3; k++) p.n[k] = ax[a][k] * s; p.d = p.n[0] * b.c[0] + p.n[1] * b.c[1] + p.n[2] * b.c[2] + b.half[a]; out.push_back(p); }
    return out;
}
inline void boxCorners(const Box& b, float out[8][3]) { float ax[3][3]; boxAxes(b, ax);
    for (int i = 0; i < 8; i++) { float s[3] = { (i & 1) ? 1.f : -1.f, (i & 2) ? 1.f : -1.f, (i & 4) ? 1.f : -1.f }; for (int k = 0; k < 3; k++) out[i][k] = b.c[k] + ax[0][k] * s[0] * b.half[0] + ax[1][k] * s[1] * b.half[1] + ax[2][k] * s[2] * b.half[2]; } }
inline void boxAABB(const Box& b, float mn[3], float mx[3]) { float c[8][3]; boxCorners(b, c); for (int k = 0; k < 3; k++) { mn[k] = 1e30f; mx[k] = -1e30f; } for (auto& p : c) for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], p[k]); mx[k] = std::max(mx[k], p[k]); } }
inline Plane xformPlane(const Plane& p, const M4& worldToLocalInvT) { (void)worldToLocalInvT; return p; }

// ------------------------------------------------------------------ polygons with attributes (float per channel)
struct V { std::vector<float> a; };          // a[0..2] = position, rest = interpolatable attributes
using Poly = std::vector<V>;
inline V lerpV(const V& x, const V& y, float t) { V r; r.a.resize(x.a.size()); for (size_t k = 0; k < x.a.size(); k++) r.a[k] = x.a[k] + (y.a[k] - x.a[k]) * t; return r; }
// splits 'p' by the plane: in (<= 0) and out (> 0)
inline void splitPoly(const Poly& p, const Plane& pl, Poly& in, Poly& out) {
    in.clear(); out.clear(); size_t n = p.size(); if (n < 3) return;
    for (size_t i = 0; i < n; i++) {
        const V& a = p[i]; const V& b = p[(i + 1) % n]; float da = pdist(pl, a.a.data()), db = pdist(pl, b.a.data());
        if (da <= 0) in.push_back(a); else out.push_back(a);
        if ((da < 0 && db > 0) || (da > 0 && db < 0)) { V m = lerpV(a, b, da / (da - db)); in.push_back(m); out.push_back(m); }
    }
    if (in.size() < 3) in.clear(); if (out.size() < 3) out.clear();
}
// polygon MINUS the convex region (planes with inside <= 0): convex pieces that remain
inline std::vector<Poly> subtract(const Poly& p, const std::vector<Plane>& region) {
    std::vector<Poly> keep; Poly cur = p;
    for (auto& pl : region) { Poly in, out; splitPoly(cur, pl, in, out); if (!out.empty()) keep.push_back(out); if (in.empty()) return keep; cur = in; }
    return keep;   // 'cur' (inside all of them) is what goes away
}
inline bool intersects(const Poly& p, const std::vector<Plane>& region) {
    Poly cur = p; for (auto& pl : region) { Poly in, out; splitPoly(cur, pl, in, out); if (in.empty()) return false; cur = in; }
    double area = 0; for (size_t i = 1; i + 1 < cur.size(); i++) { float e1[3], e2[3]; for (int k = 0; k < 3; k++) { e1[k] = cur[i].a[k] - cur[0].a[k]; e2[k] = cur[i + 1].a[k] - cur[0].a[k]; }
        float c[3] = { e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0] }; area += sqrt(c[0] * c[0] + c[1] * c[1] + c[2] * c[2]) * 0.5; }
    return area > 1.0;
}

// ------------------------------------------------------------------ packed StaticMesh vertex (PC) <-> floats
inline float unN(u8 b) { return (float)b / 127.5f - 1.0f; }
inline u8 pkN(float v) { int i = (int)lroundf((v + 1.0f) * 127.5f); return (u8)std::max(0, std::min(255, i)); }
inline uint16_t f2h(float f) { u32 x; memcpy(&x, &f, 4); u32 s = (x >> 16) & 0x8000; i32 e = (i32)((x >> 23) & 0xFF) - 127 + 15; u32 m = x & 0x7FFFFF;
    if (e <= 0) return (uint16_t)s; if (e >= 31) return (uint16_t)(s | 0x7C00); u32 h = s | ((u32)e << 10) | (m >> 13); if (m & 0x1000) h++; return (uint16_t)h; }
// layout: 'tang' packed dwords (4 channels each), then ntc UVs (half or float)
struct VLayout { int tang = 3, ntc = 1; bool full = false; int stride = 20; int nattr() const { return tang * 4 + ntc * 2; } };
inline V unpackVert(const float* pos, const u8* raw, const VLayout& L) {
    V v; v.a.assign(pos, pos + 3);
    for (int t = 0; t < L.tang; t++) for (int k = 0; k < 4; k++) v.a.push_back(unN(raw[t * 4 + k]));
    const u8* uv = raw + L.tang * 4; for (int k = 0; k < L.ntc * 2; k++) { if (L.full) { float f; memcpy(&f, uv + k * 4, 4); v.a.push_back(f); } else { uint16_t h; memcpy(&h, uv + k * 2, 2); v.a.push_back(halfToFloat(h)); } }
    return v;
}
inline void packVert(const V& v, const VLayout& L, std::vector<float>& pos, std::vector<u8>& raw) {
    pos.insert(pos.end(), v.a.begin(), v.a.begin() + 3); size_t at = raw.size(); raw.resize(at + L.stride, 0); u8* r = &raw[at];
    for (int t = 0; t < L.tang; t++) { float x = v.a[3 + t * 4], y = v.a[4 + t * 4], z = v.a[5 + t * 4], w = v.a[6 + t * 4];
        float l = sqrtf(x * x + y * y + z * z); if (l > 1e-6f && t < 2) { x /= l; y /= l; z /= l; } r[t * 4] = pkN(x); r[t * 4 + 1] = pkN(y); r[t * 4 + 2] = pkN(z); r[t * 4 + 3] = pkN(w); }
    u8* uv = r + L.tang * 4; size_t b = 3 + (size_t)L.tang * 4;
    for (int k = 0; k < L.ntc * 2; k++) { if (L.full) memcpy(uv + k * 4, &v.a[b + k], 4); else { uint16_t h = f2h(v.a[b + k]); memcpy(uv + k * 2, &h, 2); } }
}

// ------------------------------------------------------------------ PC StaticMesh -> Mesh (LOD0)
struct PcMesh { Mesh M; VLayout L; std::vector<i32> mats; std::string err; };
inline PcMesh readPcStaticMesh(const Package& P, i32 x) {
    PcMesh R;
    try {
        ObjProps op = objProps(P, x); if (!op.ok) throw Err("properties");
        R.M.lightMapRes = tagInt(op.tags, "LightMapResolution", 32); R.M.lightMapCoord = tagInt(op.tags, "LightMapCoordinateIndex", 1);
        const u8* d = P.dataPtr(P.exports[x - 1]); size_t n = P.dataLen(P.exports[x - 1]); Reader r(d, n, op.end);
        memcpy(R.M.bounds, d + r.p, 28); r.p += 28; r.i();
        for (int q = 0; q < 2; q++) { i32 es = r.i(), c = r.i(); r.need((size_t)es * c); r.p += (size_t)es * c; }
        i32 iv = r.i(); if (iv >= 17) { i32 m = r.i(); r.p += (size_t)m * 8; }
        i32 nl = r.i(); if (nl < 1) throw Err("no LOD");
        u32 fl = r.u(); r.i(); i32 sz = r.i(); r.i(); if (!(fl & 1)) r.p += std::max(0, sz);
        i32 ne = r.i(); if (ne < 0 || ne > 1024) throw Err("sections");
        for (i32 k = 0; k < ne; k++) { Section S; S.mat = r.i(); S.col = r.i(); S.oldCol = r.i(); S.shadow = r.i(); S.first = r.u(); S.ntris = r.u(); S.minV = r.u(); S.maxV = r.u(); r.i(); i32 nf = r.i(); r.p += (size_t)std::max(0, nf) * 8;
            R.mats.push_back(S.mat); R.M.secs.push_back(S); }
        r.i(); i32 pn = r.i(); r.i(); i32 pes = r.i(), pc = r.i(); if (pes != 12 || pc != pn) throw Err("positions"); r.need((size_t)pc * 12);
        i32 nv = pc / 2; R.M.pos.resize((size_t)nv * 3); memcpy(R.M.pos.data(), d + r.p, (size_t)nv * 12); r.p += (size_t)pc * 12;
        i32 ntc = r.i(), stride = r.i(); r.i(); i32 full = r.i(), ves = r.i(), vc = r.i(); if (ves != stride || vc != pc) throw Err("vertex buffer");
        R.L.ntc = ntc; R.L.full = full != 0; R.L.stride = stride; R.L.tang = (stride - ntc * (full ? 8 : 4)) / 4; if (R.L.tang < 2 || R.L.tang > 3) throw Err("stride");
        R.M.ntc = ntc; R.M.stride = stride; R.M.fullUV = full != 0; R.M.vtx.assign(d + r.p, d + r.p + (size_t)nv * stride); r.p += (size_t)vc * stride;
        r.i(); r.i(); { i32 es = r.i(), c = r.i(); r.p += (size_t)es * c; } r.i();
        i32 ies = r.i(), ic = r.i(); if (ies != 2) throw Err("32-bit indices"); r.need((size_t)ic * 2); R.M.idx.resize(ic); memcpy(R.M.idx.data(), d + r.p, (size_t)ic * 2);
    } catch (std::exception& e) { R.err = e.what(); }
    return R;
}
inline void finishMesh(Mesh& M) {
    float mn[3] = { 1e30f, 1e30f, 1e30f }, mx[3] = { -1e30f, -1e30f, -1e30f };
    for (size_t k = 0; k < M.pos.size(); k += 3) for (int a = 0; a < 3; a++) { mn[a] = std::min(mn[a], M.pos[k + a]); mx[a] = std::max(mx[a], M.pos[k + a]); }
    float rad = 0; for (int a = 0; a < 3; a++) { M.bounds[a] = (mn[a] + mx[a]) / 2; M.bounds[3 + a] = (mx[a] - mn[a]) / 2; rad += M.bounds[3 + a] * M.bounds[3 + a]; } M.bounds[6] = sqrtf(rad);
    betaconv::buildKDop(M);
}
// fan triangles of each polygon, grouped by section
struct MeshBuilder {
    VLayout L; Mesh M; std::vector<std::vector<uint16_t>> secIdx; std::vector<Section> secs;
    bool add(int sec, const Poly& p, bool fixWinding, const float* normalHint) {
        if (p.size() < 3) return true; if (M.pos.size() / 3 + p.size() > 65000) return false;
        while ((int)secIdx.size() <= sec) secIdx.emplace_back();
        uint16_t base = (uint16_t)(M.pos.size() / 3); for (auto& v : p) packVert(v, L, M.pos, M.vtx);
        for (size_t k = 1; k + 1 < p.size(); k++) { uint16_t a = base, b = (uint16_t)(base + k), c = (uint16_t)(base + k + 1);
            if (fixWinding && normalHint) { const float* A = &M.pos[a * 3]; const float* B = &M.pos[b * 3]; const float* C = &M.pos[c * 3];
                float e1[3] = { B[0] - A[0], B[1] - A[1], B[2] - A[2] }, e2[3] = { C[0] - A[0], C[1] - A[1], C[2] - A[2] };
                float cr[3] = { e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0] };
                if (cr[0] * normalHint[0] + cr[1] * normalHint[1] + cr[2] * normalHint[2] > 0) std::swap(b, c); }
            secIdx[sec].push_back(a); secIdx[sec].push_back(b); secIdx[sec].push_back(c); }
        return true;
    }
    bool empty() const { for (auto& s : secIdx) if (!s.empty()) return false; return true; }
    Mesh finish(const std::vector<Section>& tmpl, bool keepEmpty = false) {
        Mesh o = M; o.ntc = L.ntc; o.stride = L.stride; o.fullUV = L.full; o.idx.clear(); o.secs.clear();
        size_t ns = keepEmpty ? std::max(secIdx.size(), tmpl.size()) : secIdx.size(); while (secIdx.size() < ns) secIdx.emplace_back();
        for (size_t s = 0; s < ns; s++) { if (secIdx[s].empty()) { if (keepEmpty) { Section S = s < tmpl.size() ? tmpl[s] : Section(); S.first = (u32)o.idx.size(); S.ntris = 0; S.minV = S.maxV = 0; o.secs.push_back(S); } continue; } Section S = s < tmpl.size() ? tmpl[s] : Section(); S.first = (u32)o.idx.size(); S.ntris = (u32)secIdx[s].size() / 3;
            u32 mn = 0xFFFFFFFF, mx = 0; for (auto i : secIdx[s]) { mn = std::min<u32>(mn, i); mx = std::max<u32>(mx, i); } S.minV = mn; S.maxV = mx;
            o.idx.insert(o.idx.end(), secIdx[s].begin(), secIdx[s].end()); o.secs.push_back(S); }
        finishMesh(o); return o;
    }
};

struct Report { int meshesCut = 0, bspFaces = 0, bspPieces = 0, cells = 0, revealTris = 0; std::vector<std::string> log; std::string err; std::vector<i32> newActors; };

// ------------------------------------------------------------------ level helpers
inline std::string freeName(Package& P, i32 outer, const std::string& base) {
    std::string pre = outer ? P.objPath(outer) + "." : ""; for (int k = 1; k < 10000; k++) { std::string n = base + "_" + std::to_string(k); if (P.findPath(pre + n) == 0) return n; } return base + "_x"; }
inline i32 holeOuter(Package& P) { return betaconv::ensurePackageExport(P, "BmStudioHoles"); }

// ------------------------------------------------------------------ static meshes
inline void cutMeshes(Package& P, const Box& B, Report& R) {
    std::vector<Plane> hp = boxPlanes(B); float bmn[3], bmx[3]; boxAABB(B, bmn, bmx);
    Level L = parseLevel(P);
    std::map<i32, PcMesh> cache;
    for (auto& m : L.meshes) {
        if (m.kind != 0 || m.mesh <= 0 || m.comp <= 0) continue;
        auto it = cache.find(m.mesh); if (it == cache.end()) it = cache.emplace(m.mesh, readPcStaticMesh(P, m.mesh)).first;
        PcMesh& pm = it->second; if (!pm.err.empty()) continue;
        // world box of the instance (transformed mesh bounds) x hole box
        float c[3] = { pm.M.bounds[0], pm.M.bounds[1], pm.M.bounds[2] }, e[3] = { pm.M.bounds[3], pm.M.bounds[4], pm.M.bounds[5] };
        float wmn[3], wmx[3]; for (int k = 0; k < 3; k++) { float cc = c[0] * m.world.m[0][k] + c[1] * m.world.m[1][k] + c[2] * m.world.m[2][k] + m.world.m[3][k];
            float r = fabsf(e[0] * m.world.m[0][k]) + fabsf(e[1] * m.world.m[1][k]) + fabsf(e[2] * m.world.m[2][k]); wmn[k] = cc - r; wmx[k] = cc + r; }
        bool ov = true; for (int k = 0; k < 3; k++) if (wmx[k] < bmn[k] || wmn[k] > bmx[k]) ov = false; if (!ov) continue;
        // hole planes in mesh local space: n_local = M * n (3x3 row of the world matrix), d_local = n.p - d
        std::vector<Plane> lp; for (auto& p : hp) { Plane q; for (int a = 0; a < 3; a++) q.n[a] = m.world.m[a][0] * p.n[0] + m.world.m[a][1] * p.n[1] + m.world.m[a][2] * p.n[2];
            q.d = p.d - (m.world.m[3][0] * p.n[0] + m.world.m[3][1] * p.n[1] + m.world.m[3][2] * p.n[2]); lp.push_back(q); }
        MeshBuilder mb; mb.L = pm.L; int cutTris = 0; bool overflow = false;
        for (size_t s = 0; s < pm.M.secs.size(); s++) { const Section& S = pm.M.secs[s];
            for (u32 t = 0; t < S.ntris; t++) { Poly tri; float nrm[3];
                for (int k = 0; k < 3; k++) { uint16_t vi = pm.M.idx[S.first + t * 3 + k]; tri.push_back(unpackVert(&pm.M.pos[vi * 3], &pm.M.vtx[(size_t)vi * pm.L.stride], pm.L)); }
                if (!intersects(tri, lp)) { if (!mb.add((int)s, tri, false, nullptr)) overflow = true; continue; }
                cutTris++; for (int k = 0; k < 3; k++) nrm[k] = tri[0].a[7 + k];
                for (auto& piece : subtract(tri, lp)) if (!mb.add((int)s, piece, false, nrm)) overflow = true; } }
        if (!cutTris) continue;
        if (overflow) { R.log.push_back("  " + P.objPath(m.mesh) + ": too many vertices after clipping (skipped)"); continue; }
        Mesh nm = mb.finish(pm.M.secs, true);   // empty sections stay (the component Materials are by index) if (nm.idx.empty()) { /* the whole mesh fell inside the hole: hide it */ }
        std::vector<i32> mats; for (auto& s : nm.secs) { size_t k = &s - &nm.secs[0]; (void)k; mats.push_back(s.mat); }
        try {
            i32 sm = 0;
            if (!nm.idx.empty()) { i32 outer = holeOuter(P); sm = betaconv::createStaticMesh(P, outer, freeName(P, outer, P.objName(m.mesh)), nm, mats); }
            ObjProps cp = objProps(P, m.comp); std::vector<Tag> tags = cp.tags;
            if (sm) { bool has = false; for (auto& t : tags) if (t.name == "StaticMesh") { memcpy(t.raw.data(), &sm, 4); has = true; } if (!has) tags.insert(tags.begin(), objTag("StaticMesh", sm)); }
            else { place::setTag(tags, place::boolT("HiddenGame", true)); for (const char* b : { "CollideActors", "BlockActors", "BlockZeroExtent", "BlockNonZeroExtent", "BlockRigidBody" }) place::setTag(tags, place::boolT(b, false)); }
            replaceProps(P, m.comp, tags);
            // per-vertex lightmap (type 1) depends on the vertex count: drop the LODData
            { ObjProps c2 = objProps(P, m.comp); const u8* d = P.dataPtr(P.exports[m.comp - 1]); size_t n = P.dataLen(P.exports[m.comp - 1]);
              if (n >= c2.end + 4) { i32 cnt; memcpy(&cnt, d + c2.end, 4); bool vertexLM = false;
                  if (cnt > 0) { try { Reader r(d, n, c2.end + 4); i32 a = r.i(); r.p += 4 * (size_t)a; i32 b = r.i(); r.p += 4 * (size_t)b; u32 ty = r.u(); vertexLM = ty == 1 || b > 0; } catch (...) { vertexLM = true; } }
                  if (vertexLM && sm) { place::own(P, m.comp); auto& dd = P.exports[m.comp - 1].data; dd.resize(c2.end); u8 z[4] = { 0, 0, 0, 0 }; dd.insert(dd.end(), z, z + 4); } } }
            R.meshesCut++; R.log.push_back("  mesh " + P.objPath(m.mesh) + ": " + std::to_string(cutTris) + " triangles clipped" + (sm ? "" : " (it was entirely inside the hole: hidden)"));
        } catch (std::exception& e) { R.log.push_back(std::string("  mesh: ") + e.what()); }
    }
}

// ------------------------------------------------------------------ BSP
// ModelComponent element: where the LightMapRef and the ShadowMaps are
struct ElemInfo { i32 comp = 0; i32 material = 0; std::vector<u8> lightMap; std::vector<i32> shadowMaps; };
inline bool readModelComponent(const Package& P, i32 comp, std::vector<ElemInfo>& out) {
    try {
        ObjProps op = objProps(P, comp); const u8* d = P.dataPtr(P.exports[comp - 1]); size_t n = P.dataLen(P.exports[comp - 1]); Reader r(d, n, op.end);
        r.i(); r.i(); i32 ne = r.i(); if (ne < 0 || ne > 4096) return false;
        for (i32 e = 0; e < ne; e++) { ElemInfo E; E.comp = comp; size_t lm0 = r.p; u32 ty = r.u();
            if (ty == 2) { i32 g = r.i(); r.need((size_t)g * 16); r.p += (size_t)g * 16; r.p += 4 * 16 + 16; }
            else if (ty != 0) return false;                                   // per-vertex lightmap on the BSP: not handled
            E.lightMap.assign(d + lm0, d + r.p);
            r.i(); E.material = r.i(); i32 nn = r.i(); r.need((size_t)nn * 2); r.p += (size_t)nn * 2;
            i32 ns = r.i(); for (i32 k = 0; k < ns; k++) E.shadowMaps.push_back(r.i());
            i32 il = r.i(); r.need((size_t)il * 16); r.p += (size_t)il * 16;
            out.push_back(E); }
        return true;
    } catch (...) { return false; }
}
inline std::map<int, i32> modelComponentsByIndex(const Package& P, i32 model) {
    std::map<int, i32> m; for (size_t k = 0; k < P.exports.size(); k++) { if (P.classOf(P.exports[k]) != "ModelComponent") continue; ObjProps op = objProps(P, (i32)k + 1); if (!op.ok) continue;
        const u8* d = P.dataPtr(P.exports[k]); size_t n = P.dataLen(P.exports[k]); if (n < op.end + 12) continue; i32 mdl; memcpy(&mdl, d + op.end, 4); if (mdl != model) continue;
        // ComponentIndex comes after the elements
        try { Reader r(d, n, op.end); r.i(); r.i(); i32 ne = r.i();
            for (i32 e = 0; e < ne; e++) { u32 ty = r.u(); if (ty == 2) { i32 g = r.i(); r.p += (size_t)g * 16 + 80; } r.i(); r.i(); i32 nn = r.i(); r.p += (size_t)nn * 2; i32 ns = r.i(); r.p += 4 * (size_t)ns; i32 il = r.i(); r.p += 16 * (size_t)il; }
            i32 ci = r.i(); m[ci] = (i32)k + 1; } catch (...) {} }
    return m;
}

// convex polyhedron from half-spaces (inside <= 0): faces as polygons (position only)
inline std::vector<Poly> polyhedron(const std::vector<Plane>& hs, const float mn[3], const float mx[3]) {
    std::vector<Poly> faces;
    // initial cube (loose box)
    float c[8][3]; for (int i = 0; i < 8; i++) for (int k = 0; k < 3; k++) c[i][k] = ((i >> k) & 1) ? mx[k] + 8 : mn[k] - 8;
    int F[6][4] = { { 0, 2, 3, 1 }, { 4, 5, 7, 6 }, { 0, 1, 5, 4 }, { 2, 6, 7, 3 }, { 0, 4, 6, 2 }, { 1, 3, 7, 5 } };
    for (auto& f : F) { Poly p; for (int k = 0; k < 4; k++) { V v; v.a.assign(c[f[k]], c[f[k]] + 3); p.push_back(v); } faces.push_back(p); }
    for (auto& pl : hs) {
        std::vector<Poly> nf; std::vector<V> cut;
        for (auto& f : faces) { Poly in, out; splitPoly(f, pl, in, out); if (!in.empty()) nf.push_back(in);
            for (auto& v : in) if (fabsf(pdist(pl, v.a.data())) < 0.01f) cut.push_back(v); }
        // cap: points on the plane, sorted around the center
        if (cut.size() >= 3) { float ctr[3] = { 0, 0, 0 }; for (auto& v : cut) for (int k = 0; k < 3; k++) ctr[k] += v.a[k] / cut.size();
            float u[3], w[3]; float ref[3] = { fabsf(pl.n[2]) < 0.9f ? 0.f : 1.f, 0, fabsf(pl.n[2]) < 0.9f ? 1.f : 0.f };
            u[0] = pl.n[1] * ref[2] - pl.n[2] * ref[1]; u[1] = pl.n[2] * ref[0] - pl.n[0] * ref[2]; u[2] = pl.n[0] * ref[1] - pl.n[1] * ref[0];
            w[0] = pl.n[1] * u[2] - pl.n[2] * u[1]; w[1] = pl.n[2] * u[0] - pl.n[0] * u[2]; w[2] = pl.n[0] * u[1] - pl.n[1] * u[0];
            std::sort(cut.begin(), cut.end(), [&](const V& a, const V& b) { float ax = 0, ay = 0, bx = 0, by = 0; for (int k = 0; k < 3; k++) { ax += (a.a[k] - ctr[k]) * u[k]; ay += (a.a[k] - ctr[k]) * w[k]; bx += (b.a[k] - ctr[k]) * u[k]; by += (b.a[k] - ctr[k]) * w[k]; } return atan2f(ay, ax) < atan2f(by, bx); });
            Poly cap; for (auto& v : cut) { bool dup = false; for (auto& q : cap) { float dd = 0; for (int k = 0; k < 3; k++) dd += (q.a[k] - v.a[k]) * (q.a[k] - v.a[k]); if (dd < 0.01f) dup = true; } if (!dup) cap.push_back(v); }
            if (cap.size() >= 3) nf.push_back(cap); }
        faces = nf; if (faces.empty()) break;
    }
    return faces;
}

// affine mapping position -> attribute on a planar polygon (for the texture of the inner faces)
struct Affine { float a[2][4]; bool ok = false; };
inline Affine fitAffine(const Poly& p, int attr) {
    Affine A; if (p.size() < 3) return A;
    // basis on the plane + normal (attribute constant along the normal)
    const float* p0 = p[0].a.data(); size_t i1 = 1, i2 = 2; float best = 0;
    for (size_t j = 2; j < p.size(); j++) { float e1[3], e2[3]; for (int k = 0; k < 3; k++) { e1[k] = p[1].a[k] - p0[k]; e2[k] = p[j].a[k] - p0[k]; } float c[3] = { e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0] }; float l = c[0] * c[0] + c[1] * c[1] + c[2] * c[2]; if (l > best) { best = l; i2 = j; } }
    if (best < 1e-6f) return A;
    float e1[3], e2[3], nn[3]; for (int k = 0; k < 3; k++) { e1[k] = p[i1].a[k] - p0[k]; e2[k] = p[i2].a[k] - p0[k]; }
    nn[0] = e1[1] * e2[2] - e1[2] * e2[1]; nn[1] = e1[2] * e2[0] - e1[0] * e2[2]; nn[2] = e1[0] * e2[1] - e1[1] * e2[0];
    // solves [e1 e2 nn]^T * g = [du1 du2 0] for each channel
    double M[3][3] = { { e1[0], e1[1], e1[2] }, { e2[0], e2[1], e2[2] }, { nn[0], nn[1], nn[2] } }, Inv[3][3];
    double det = M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]); if (fabs(det) < 1e-12) return A;
    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) { int a1 = (j + 1) % 3, a2 = (j + 2) % 3, b1 = (i + 1) % 3, b2 = (i + 2) % 3; Inv[i][j] = (M[a1][b1] * M[a2][b2] - M[a1][b2] * M[a2][b1]) / det; }
    for (int ch = 0; ch < 2; ch++) { double r0 = p[i1].a[attr + ch] - p[0].a[attr + ch], r1 = p[i2].a[attr + ch] - p[0].a[attr + ch];
        double g[3]; for (int k = 0; k < 3; k++) g[k] = Inv[k][0] * r0 + Inv[k][1] * r1;
        for (int k = 0; k < 3; k++) A.a[ch][k] = (float)g[k]; A.a[ch][3] = (float)(p[0].a[attr + ch] - (g[0] * p0[0] + g[1] * p0[1] + g[2] * p0[2])); }
    A.ok = true; return A;
}

// the BSP part: returns meshes to place (render with lightmap / collision / inner faces)
struct PlaceReq { i32 mesh = 0; bool hidden = false, collide = true; std::vector<u8> lodData; };
inline void cutBsp(Package& P, i32 model, const Box& B, Report& R, std::vector<PlaceReq>& place) {
    ModelLayout L = modelLayout(P, model); if (!L.ok || L.vbes < 36) { R.log.push_back("  BSP " + P.objPath(model) + ": unexpected layout (" + L.err + ")"); return; }
    std::vector<Plane> hp = boxPlanes(B); float bmn[3], bmx[3]; boxAABB(B, bmn, bmx);
    auto comps = modelComponentsByIndex(P, model);
    std::map<i32, std::vector<ElemInfo>> elems; for (auto& kv : comps) { std::vector<ElemInfo> v; if (readModelComponent(P, kv.second, v)) elems[kv.second] = v; }
    const u8* d0 = P.dataPtr(P.exports[model - 1]);
    // 1) visible faces that cross the box
    struct Face { i32 node; Poly poly; i32 comp; i32 elem; i32 material; float normal[3]; };
    std::vector<Face> faces;
    for (i32 n = 0; n < L.nNodes; n++) {
        BspNodeV nd = readNode(d0, L, n); if (nd.nv < 3 || nd.iSurf < 0 || nd.iSurf >= L.nSurfs || nd.iVertexIndex < 0 || nd.iVertexIndex + nd.nv > L.vbn) continue;
        u32 pf; memcpy(&pf, d0 + L.surfsAt + (size_t)nd.iSurf * 56 + 4, 4); if (pf & 1) continue;
        Poly p; for (int k = 0; k < nd.nv; k++) { const float* v = (const float*)(d0 + L.vbAt + (size_t)L.vbes * (nd.iVertexIndex + k)); const u8* t = (const u8*)v;
            V vv; vv.a.assign(v, v + 3); for (int q = 0; q < 4; q++) vv.a.push_back(unN(t[12 + q])); for (int q = 0; q < 4; q++) vv.a.push_back(unN(t[16 + q]));
            vv.a.push_back(v[5]); vv.a.push_back(v[6]); vv.a.push_back(v[7]); vv.a.push_back(v[8]); p.push_back(vv); }
        bool coll = true; for (size_t k = 1; k < p.size(); k++) if (fabsf(p[k].a[0] - p[0].a[0]) > 0.01f || fabsf(p[k].a[1] - p[0].a[1]) > 0.01f || fabsf(p[k].a[2] - p[0].a[2]) > 0.01f) coll = false; if (coll) continue;   // already hidden
        if (!intersects(p, hp)) continue;
        uint16_t ci; i32 ei; memcpy(&ci, d0 + L.nodesAt + (size_t)n * 64 + 28, 2); memcpy(&ei, d0 + L.nodesAt + (size_t)n * 64 + 32, 4);
        Face f; f.node = n; f.poly = p; f.comp = comps.count(ci) ? comps[ci] : 0; f.elem = ei; i32 sm; memcpy(&sm, d0 + L.surfsAt + (size_t)nd.iSurf * 56, 4); f.material = sm;
        for (int k = 0; k < 3; k++) f.normal[k] = p[0].a[7 + k]; faces.push_back(f);
    }
    // 2) solid cells that cross the box
    struct Cell { size_t at; std::vector<i32> nodes; float mn[3], mx[3]; };
    std::vector<Cell> cells;
    { const i32* h = (const i32*)(d0 + L.hullsAt); i32 i = 0;
      while (i < L.nHulls) { Cell c; while (i < L.nHulls && h[i] != -1) { c.nodes.push_back(h[i]); i++; } i++; if (i + 6 > L.nHulls) break;
          c.at = L.hullsAt + 4 * (size_t)i; memcpy(c.mn, h + i, 12); memcpy(c.mx, h + i + 3, 12); i += 6;
          if (c.mn[0] > 1e7f * 0.5f) continue;   // already switched off
          bool ov = true; for (int k = 0; k < 3; k++) if (c.mx[k] < bmn[k] - 1 || c.mn[k] > bmx[k] + 1) ov = false; if (!ov) continue;
          // does the hole box really cross the cell? (cell center inside the polyhedron + test with the corners)
          cells.push_back(c); } }
    if (faces.empty() && cells.empty()) return;
    // 3) render meshes (with the element lightmap)
    std::map<std::pair<i32, i32>, std::vector<const Face*>> groups; for (auto& f : faces) groups[{ f.comp, f.elem }].push_back(&f);
    VLayout VL; VL.tang = 3; VL.ntc = 2; VL.full = false; VL.stride = 20;
    auto toMeshVert = [&](const V& v) { V o; o.a.assign(v.a.begin(), v.a.begin() + 3); for (int q = 0; q < 8; q++) o.a.push_back(v.a[3 + q]); for (int q = 0; q < 4; q++) o.a.push_back(1.f); for (int q = 0; q < 4; q++) o.a.push_back(v.a[11 + q]); return o; };
    i32 outer = holeOuter(P);
    for (auto& [key, fl] : groups) {
        MeshBuilder mb; mb.L = VL; const ElemInfo* E = nullptr; if (elems.count(key.first) && key.second >= 0 && key.second < (i32)elems[key.first].size()) E = &elems[key.first][key.second];
        int pieces = 0;
        for (const Face* f : fl) for (auto& piece : subtract(f->poly, hp)) { Poly mp; for (auto& v : piece) mp.push_back(toMeshVert(v)); mb.add(0, mp, true, f->normal); pieces++; }
        R.bspFaces += (int)fl.size(); R.bspPieces += pieces;
        if (mb.empty()) continue;
        Section S; S.mat = E ? E->material : fl[0]->material; Mesh m = mb.finish({ S }); m.lightMapCoord = 1; m.lightMapRes = 0;
        i32 sm = betaconv::createStaticMesh(P, outer, freeName(P, outer, "BSP_Clip"), m, { S.mat });
        PlaceReq pr; pr.mesh = sm; pr.collide = false;
        if (E && E->lightMap.size() > 4) { Writer w; w.i(1); w.i((i32)E->shadowMaps.size()); for (i32 s : E->shadowMaps) w.i(s); w.i(0); w.raw(E->lightMap); pr.lodData = w.b; }
        place.push_back(pr);
    }
    // 4) hides the original faces (collapsed vertices)
    place::own(P, model); u8* d = P.exports[model - 1].data.data();
    for (auto& f : faces) { BspNodeV nd = readNode(d, L, f.node); float c[3]; memcpy(c, d + L.vbAt + (size_t)L.vbes * nd.iVertexIndex, 12);
        for (int k = 1; k < nd.nv; k++) memcpy(d + L.vbAt + (size_t)L.vbes * (nd.iVertexIndex + k), c, 12); }
    // 5) collision: convex cell minus the box -> invisible mesh; original cell switched off
    MeshBuilder cb; cb.L = VL; MeshBuilder rb; rb.L = VL;   // collision / inner faces
    Affine tex; i32 revealMat = faces.empty() ? 0 : (elems.count(faces[0].comp) && faces[0].elem < (i32)elems[faces[0].comp].size() ? elems[faces[0].comp][faces[0].elem].material : faces[0].material);
    if (!faces.empty()) tex = fitAffine(faces[0].poly, 11);
    auto plainV = [&](const float* p, const float* n) { V o; o.a.assign(p, p + 3); for (int q = 0; q < 4; q++) o.a.push_back(q == 0 ? 1.f : 0.f); for (int q = 0; q < 3; q++) o.a.push_back(n[q]); o.a.push_back(1.f); for (int q = 0; q < 4; q++) o.a.push_back(1.f);
        float u = 0, v = 0; if (tex.ok) { u = tex.a[0][0] * p[0] + tex.a[0][1] * p[1] + tex.a[0][2] * p[2] + tex.a[0][3]; v = tex.a[1][0] * p[0] + tex.a[1][1] * p[1] + tex.a[1][2] * p[2] + tex.a[1][3]; }
        o.a.push_back(u); o.a.push_back(v); o.a.push_back(0); o.a.push_back(0); return o; };
    for (auto& c : cells) {
        // half-spaces of the cell: node planes (oriented toward the center) + the box itself
        float ctr[3]; for (int k = 0; k < 3; k++) ctr[k] = (c.mn[k] + c.mx[k]) / 2;
        std::vector<Plane> hs;
        for (i32 raw : c.nodes) { i32 n = raw & 0x3FFFFFFF; if (n < 0 || n >= L.nNodes) continue; BspNodeV nd = readNode(d, L, n); Plane p; for (int k = 0; k < 3; k++) p.n[k] = nd.plane[k]; p.d = nd.plane[3];
            if (raw & 0x40000000) { for (auto& x : p.n) x = -x; p.d = -p.d; }
            hs.push_back(p); }
        for (int a = 0; a < 3; a++) { Plane p1{}, p2{}; p1.n[a] = 1; p1.d = c.mx[a]; p2.n[a] = -1; p2.d = -c.mn[a]; hs.push_back(p1); hs.push_back(p2); }
        // orientation: if the center of the cell box lies outside a plane, the plane is flipped
        for (auto& p : hs) if (pdist(p, ctr) > 0.5f) { for (auto& x : p.n) x = -x; p.d = -p.d; }
        auto cellFaces = polyhedron(hs, c.mn, c.mx); if (cellFaces.empty()) continue;
        // does the box cross the solid part of the cell?
        bool hit = false; for (auto& f : cellFaces) if (intersects(f, hp)) { hit = true; break; }
        { float cc[8][3]; boxCorners(B, cc); for (auto& q : cc) { bool in = true; for (auto& p : hs) if (pdist(p, q) > 0) in = false; if (in) hit = true; } }
        if (!hit) continue;
        // pieces = cell MINUS box: cell ∩ (outside plane i) ∩ (inside planes < i)
        std::vector<Plane> acc = hs;
        for (size_t i = 0; i < hp.size(); i++) {
            Plane outP = hp[i]; for (auto& x : outP.n) x = -x; outP.d = -outP.d;
            std::vector<Plane> piece = acc; piece.push_back(outP);
            for (auto& f : polyhedron(piece, c.mn, c.mx)) {
                float n[3]; { float e1[3], e2[3]; for (int k = 0; k < 3; k++) { e1[k] = f[1].a[k] - f[0].a[k]; e2[k] = f[2].a[k] - f[0].a[k]; } n[0] = e1[1] * e2[2] - e1[2] * e2[1]; n[1] = e1[2] * e2[0] - e1[0] * e2[2]; n[2] = e1[0] * e2[1] - e1[1] * e2[0]; float l = sqrtf(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]); if (l < 1e-6f) continue; for (auto& x : n) x /= l; }
                // outward normal of the piece: compare with the piece center
                Poly cp; for (auto& v : f) cp.push_back(plainV(v.a.data(), n)); cb.add(0, cp, false, nullptr);
                // face on a hole plane = inner wall of the passage
                bool onHole = true; for (auto& v : f) if (fabsf(pdist(hp[i], v.a.data())) > 0.05f) onHole = false;
                if (onHole) { float hn[3] = { -hp[i].n[0], -hp[i].n[1], -hp[i].n[2] }; Poly rp; for (auto& v : f) rp.push_back(plainV(v.a.data(), hn)); float wn[3] = { -hn[0], -hn[1], -hn[2] }; (void)wn; rb.add(0, rp, true, hn); R.revealTris += (int)f.size() - 2; }
            }
            acc.push_back(hp[i]);
        }
        // switches off the original cell (box moved away) + NotCsg on its nodes
        float bx[6]; memcpy(bx, d + c.at, 24); for (auto& f : bx) f += 1e7f; memcpy(d + c.at, bx, 24);
        for (i32 raw : c.nodes) { i32 n = raw & 0x3FFFFFFF; if (n >= 0 && n < L.nNodes) d[L.nodesAt + 64 * (size_t)n + 55] |= NF_NotCsg; }
        R.cells++;
    }
    if (!cb.empty()) { Section S; Mesh m = cb.finish({ S }); i32 sm = betaconv::createStaticMesh(P, outer, freeName(P, outer, "BSP_Collision"), m, { 0 }); PlaceReq pr; pr.mesh = sm; pr.hidden = true; pr.collide = true; place.push_back(pr); }
    if (!rb.empty()) { Section S; Mesh m = rb.finish({ S }); i32 sm = betaconv::createStaticMesh(P, outer, freeName(P, outer, "BSP_Inner"), m, { revealMat }); PlaceReq pr; pr.mesh = sm; pr.collide = false; place.push_back(pr); }
}

// ------------------------------------------------------------------ everything
// donor: game map with a StaticMeshActor (template) in case the level has none
inline Report openHole(Package& P, const cp::TypeDB& db, Package* donor, const Box& B, bool doMeshes = true, bool doBsp = true) {
    Report R;
    try {
        if (doMeshes) cutMeshes(P, B, R);
        std::vector<PlaceReq> place;
        if (doBsp) for (i32 m : levelModels(P)) cutBsp(P, m, B, R, place);
        if (!place.empty()) {
            place::Template T; for (size_t k = 0; k < P.exports.size() && !T.actor; k++) { if (P.classOf(P.exports[k]) != "StaticMeshActor" || P.objPath(P.exports[k].outer) != "TheWorld.PersistentLevel" || (P.exports[k].flags & 0x600ull)) continue;
                for (i32 s : place::actorSet(P, (i32)k + 1)) if (P.classOf(P.exports[s - 1]) == "StaticMeshComponent") { T.actor = (i32)k + 1; T.comp = s; T.cls = "StaticMeshActor"; } }
            if (!T.actor) { if (!donor) throw Err("the level has no StaticMeshActor to use as a template and there is no donor map");
                place::Template D; for (size_t k = 0; k < donor->exports.size() && !D.actor; k++) { if (donor->classOf(donor->exports[k]) != "StaticMeshActor" || donor->objPath(donor->exports[k].outer) != "TheWorld.PersistentLevel" || (donor->exports[k].flags & 0x600ull)) continue;
                    for (i32 s : place::actorSet(*donor, (i32)k + 1)) if (donor->classOf(donor->exports[s - 1]) == "StaticMeshComponent") { D.actor = (i32)k + 1; D.comp = s; } }
                if (!D.actor) throw Err("the donor map has no StaticMeshActor");
                auto ac = place::importFromDonor(P, db, *donor, D, place::Kind::Mesh); T.actor = ac.first; T.comp = ac.second; T.cls = "StaticMeshActor";
                // the template itself becomes the first actor
            }
            float zero[3] = { 0, 0, 0 };
            for (auto& pr : place) {
                auto ac = place::cloneInLevel(P, db, T, true); place::configurePlaced(P, ac.first, ac.second, pr.mesh, zero);
                { ObjProps cp = objProps(P, ac.second); std::vector<Tag> tags = cp.tags;
                  if (!pr.collide) for (const char* b : { "CollideActors", "BlockActors", "BlockZeroExtent", "BlockNonZeroExtent", "BlockRigidBody" }) place::setTag(tags, place::boolT(b, false));
                  else for (const char* b : { "CollideActors", "BlockActors", "BlockZeroExtent", "BlockNonZeroExtent" }) place::setTag(tags, place::boolT(b, true));
                  if (pr.hidden) place::setTag(tags, place::boolT("HiddenGame", true));
                  place::setTag(tags, place::boolT("CastShadow", false));
                  replaceProps(P, ac.second, tags); }
                if (!pr.lodData.empty()) { ObjProps cp = objProps(P, ac.second); place::own(P, ac.second); auto& dd = P.exports[ac.second - 1].data; dd.resize(cp.end); dd.insert(dd.end(), pr.lodData.begin(), pr.lodData.end()); }
                place::addActorToLevel(P, ac.first); R.newActors.push_back(ac.first);
            }
        }
        char b[256]; snprintf(b, sizeof b, "clipped meshes: %d | BSP: %d faces -> %d pieces, %d collision cells rebuilt, %d inner wall triangles", R.meshesCut, R.bspFaces, R.bspPieces, R.cells, R.revealTris); R.log.insert(R.log.begin(), b);
    } catch (std::exception& e) { R.err = e.what(); }
    return R;
}

} }
