// bmlzo.hpp - LZO1X decompressor (format used by UE3 in compressed .tfc/.upk files). Own implementation, with
// bounds checks on every copy. Returns false if the data is corrupt.
#pragma once
#include <cstdint>
#include <cstddef>

namespace bm {
inline bool lzo1xDecompress(const uint8_t* in, size_t inLen, uint8_t* out, size_t outCap, size_t* outLen) {
    const uint8_t* ip = in; const uint8_t* const ipEnd = in + inLen;
    uint8_t* op = out; uint8_t* const opEnd = out + outCap;
    size_t t = 0; const uint8_t* mPos = nullptr;
#define NEED_IP(n) if ((size_t)(ipEnd - ip) < (size_t)(n)) return false
#define NEED_OP(n) if ((size_t)(opEnd - op) < (size_t)(n)) return false
#define LOOKBEHIND(p) if ((p) < out || (p) >= op) return false
    NEED_IP(1);
    if (*ip > 17) {
        t = *ip++ - 17;
        if (t < 4) goto match_next;
        NEED_OP(t); NEED_IP(t + 1);
        do *op++ = *ip++; while (--t > 0);
        goto first_literal_run;
    }
    for (;;) {
        NEED_IP(1);
        t = *ip++;
        if (t >= 16) goto match;
        if (t == 0) { while (*ip == 0) { t += 255; ip++; NEED_IP(1); } t += 15 + *ip++; }
        NEED_OP(t + 3); NEED_IP(t + 4);
        for (size_t k = 0; k < t + 3; k++) *op++ = *ip++;
first_literal_run:
        NEED_IP(1);
        t = *ip++;
        if (t >= 16) goto match;
        mPos = op - (1 + 0x0800); mPos -= t >> 2; NEED_IP(1); mPos -= (size_t)(*ip++) << 2;
        LOOKBEHIND(mPos); NEED_OP(3);
        *op++ = *mPos++; *op++ = *mPos++; *op++ = *mPos;
        goto match_done;
        for (;;) {
match:
            if (t >= 64) {
                NEED_IP(1); mPos = op - 1; mPos -= (t >> 2) & 7; mPos -= (size_t)(*ip++) << 3; t = (t >> 5) - 1;
                LOOKBEHIND(mPos); NEED_OP(t + 2);
                goto copy_match;
            } else if (t >= 32) {
                t &= 31;
                if (t == 0) { NEED_IP(1); while (*ip == 0) { t += 255; ip++; NEED_IP(1); } t += 31 + *ip++; }
                NEED_IP(2); mPos = op - 1; mPos -= ((size_t)ip[0] >> 2) + ((size_t)ip[1] << 6); ip += 2;
            } else if (t >= 16) {
                mPos = op; mPos -= (t & 8) << 11;
                t &= 7;
                if (t == 0) { NEED_IP(1); while (*ip == 0) { t += 255; ip++; NEED_IP(1); } t += 7 + *ip++; }
                NEED_IP(2); mPos -= ((size_t)ip[0] >> 2) + ((size_t)ip[1] << 6); ip += 2;
                if (mPos == op) goto eof_found;
                mPos -= 0x4000;
            } else {
                NEED_IP(1); mPos = op - 1; mPos -= t >> 2; mPos -= (size_t)(*ip++) << 2;
                LOOKBEHIND(mPos); NEED_OP(2);
                *op++ = *mPos++; *op++ = *mPos;
                goto match_done;
            }
            LOOKBEHIND(mPos); NEED_OP(t + 2);
copy_match:
            *op++ = *mPos++; *op++ = *mPos++;
            do *op++ = *mPos++; while (--t > 0);
match_done:
            t = ip[-2] & 3;
            if (t == 0) break;
match_next:
            NEED_OP(t); NEED_IP(t + 1);
            *op++ = *ip++; if (t > 1) { *op++ = *ip++; if (t > 2) *op++ = *ip++; }
            t = *ip++;
        }
    }
eof_found:
    *outLen = (size_t)(op - out);
    return t == 1 && ip == ipEnd;
#undef NEED_IP
#undef NEED_OP
#undef LOOKBEHIND
}
} // namespace bm
